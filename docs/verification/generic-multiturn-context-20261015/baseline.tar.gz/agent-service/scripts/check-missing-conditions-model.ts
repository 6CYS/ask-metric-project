/** 同一真实模型的缺项/继承回归；业务目录和SQL全部隔离，不连接业务数据库。 */
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFile, writeFile, mkdir, mkdtemp} from 'node:fs/promises';
import {dirname, join, resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {pathToFileURL} from 'node:url';
import {BACKGROUND_CONTEXT} from '@earendil-works/pi-agent-core';
import type {BackendClient, BackendUser} from '../src/backendClient.js';

assert(process.argv.includes('--live'), '真实模型验证须显式传入 --live');
const arg = (key: string, fallback: string) => process.argv.find(x => x.startsWith(`--${key}=`))?.slice(key.length + 3) ?? fallback;
const sourceRoot = resolve(arg('source-root', '.'));
const report = resolve(arg('report', '../docs/verification/missing-conditions-loop-20261015/after.json'));
const selected = new Set(arg('cases', '').split(',').filter(Boolean));
const imports = await Promise.all(['config', 'models', 'harnessHost', 'nativeSessions', 'businessSkills', 'sessionProjection', 'tools/index', 'semantic-task/feedback', 'semantic-task/store', 'backendClient'].map(name => import(pathToFileURL(join(sourceRoot, 'src', `${name}.ts`)).href)));
const [{loadConfig}, {createAskMetricModels}, {HarnessHost}, {NativeSessionStore}, {loadBusinessSkills, createBusinessSkillReadTool}, {projectEntries}, {createAskMetricTools}, {isSemanticFeedback}, {NativeSemanticTaskStore}, {BackendApiError}] = imports;
const config = loadConfig();
const cache = new Map<string, any>();
const fixture = join(import.meta.dirname, 'missing-conditions-fixture.py');
const pythonPath = resolve('../backend-next/.venv/bin/python');
function python(payload: Record<string, unknown>) {
  const key = JSON.stringify(payload);
  if (payload.action !== 'query' && cache.has(key)) return structuredClone(cache.get(key));
  const out = JSON.parse(execFileSync(pythonPath, [fixture], {input: key, encoding: 'utf8', timeout: 30000,
    maxBuffer: 4 * 1024 * 1024, env: {PATH: '/usr/bin:/bin:/opt/homebrew/bin'}}));
  if (!out.ok) throw new BackendApiError(422, out.message, out.error);
  if (payload.action !== 'query') cache.set(key, out.value);
  return out.value;
}
const metrics = [
  {metric_code: 'SYNTH_M:D', metric_name: '经营收益金额当日数', unit: '元', score: 1, match_type: 'exact'},
  {metric_code: 'SYNTH_M:Y', metric_name: '经营收益金额较同期', unit: '元', score: 1, match_type: 'exact'},
  {metric_code: 'SYNTH_DEPOSIT:D', metric_name: '对公协定存款余额当日数', unit: '元', score: 1, match_type: 'exact'},
];
function backend() {
  const queries: any[] = [], results = new Map<string, any>();
  const client = {
    resolveBusinessField: async (entity: string, raw: string[], _options?: unknown, year?: number, source?: unknown) => python({action: 'resolve', entity, raw, year, source}),
    inspectBusinessGoal: async (question: string, businessDate: string, _options?: unknown, reference_year?: number) => python({action: 'inspect', question, business_date: businessDate, reference_year}),
    admitSemanticPlan: async (payload: unknown) => python({action: 'admit', payload}),
    matchMetricQuestion: async (question: string) => python({action: 'mentions', question}),
    metricCatalogOverview: async () => ({total: metrics.length, groups: [{unit: '元', count: metrics.length, examples: metrics.map(m => ({code: m.metric_code, name: m.metric_name}))}]}),
    searchMetrics: async (keyword: string) => ({total: metrics.filter(m => m.metric_name.includes(keyword)).length, items: metrics.filter(m => m.metric_name.includes(keyword)), semantic_suggestions: []}),
    searchOrganizations: async (keyword: string) => {const items = ['甲', '乙', '丙', '丁'].map((name, index) => ({org_code: `SYNTH_O${index + 1}`, org_name: `合成机构${name}`, score: 1, match_type: 'exact'})).filter(o => o.org_name.includes(keyword)); return {total: items.length, items};},
    createAgentQueryContext: async () => ({conversation_id: 'synthetic-semantic'}),
    basicQueries: async (spec: any) => {
      const row: any = {spec}; queries.push(row);
      const actual = python({action: 'query', spec}), id = `query-${queries.length}`;
      const result = {status: 'succeeded', task_id: id, result_id: `result-${id}`, rows: actual.rows,
        columns: Object.keys(actual.rows[0] ?? {}), row_count: actual.rows.length, truncated: false,
        facts: actual.rows.flatMap((r: any, index: number) => r.metric_value == null ? [] : [{fact_id: `fact:${id}:${index}:metric_value`, task_id: id, field: 'metric_value', value: String(r.metric_value), unit: r.unit ?? '元', metric_code: r.metric_code, org_code: r.org_code, date: r.stat_date}])};
      row.row_count = actual.rows.length; results.set(id, result); return {query: spec, result};
    },
    getTask: async (id: string) => {if (!results.has(id)) throw new BackendApiError(404, '合成任务不存在', 'TASK_NOT_FOUND'); return {task_id: id, status: 'SUCCEEDED', version: 1, result: {result_id: `result-${id}`}};},
    getTaskResult: async (id: string) => {if (!results.has(id)) throw new BackendApiError(404, '合成结果不存在', 'RESULT_NOT_FOUND'); return results.get(id);},
  } as unknown as BackendClient;
  return {client, queries};
}
type Expected = {status: string; missing?: string[]; metric?: string; metrics?: string[]; org?: string; day?: string};
type Scenario = {id: string; messages: string[]; expected: Expected[]};
const success = (metric = 'SYNTH_M:D', org = 'SYNTH_O1', day = '2026-05-31'): Expected => ({status: 'succeeded', metric, org, day});
const missing = (...fields: string[]): Expected => ({status: 'needs_user', missing: fields});
const scenarios: Scenario[] = [
  ...[1, 2, 3].map(i => ({id: `original-missing-both-${i}`, messages: ['帮我查对公协定存款余额当日数'], expected: [missing('organizations', 'time')]})),
  {id: 'other-metric-missing-both', messages: ['查询经营收益金额当日数'], expected: [missing('organizations', 'time')]},
  {id: 'missing-date', messages: ['查合成机构甲的经营收益金额当日数'], expected: [missing('time')]},
  {id: 'missing-organization', messages: ['查2026年5月31日的经营收益金额当日数'], expected: [missing('organizations')]},
  {id: 'supplement-and-inherit', messages: ['查询经营收益金额当日数', '机构用合成机构甲', '日期用2026年5月31日', '再查对公协定存款余额当日数'], expected: [missing('organizations', 'time'), missing('time'), success(), success('SYNTH_DEPOSIT:D')]},
  {id: 'confirmed-prepare-inherit', messages: ['准备合成机构乙2026年6月30日的经营收益金额当日数查询条件，先不要执行', '查询对公协定存款余额当日数'], expected: [{status: 'prepared'}, success('SYNTH_DEPOSIT:D', 'SYNTH_O2', '2026-06-30')]},
  {id: 'partially-confirmed-inherit', messages: ['查合成机构甲的经营收益金额当日数', '改查对公协定存款余额当日数'], expected: [missing('time'), missing('time')]},
  {id: 'confirmed-multiple-new-metrics', messages: ['准备合成机构乙2026年6月30日的经营收益金额当日数查询条件，先不要执行', '分别查询对公协定存款余额当日数和经营收益金额较同期'], expected: [{status: 'prepared'}, {status: 'succeeded', metrics: ['SYNTH_DEPOSIT:D', 'SYNTH_M:Y'], org: 'SYNTH_O2', day: '2026-06-30'}]},
  {id: 'explicit-clear-date', messages: ['查合成机构甲2026年5月31日的经营收益金额当日数', '清除日期，保留机构和指标', '日期用2026年6月30日'], expected: [success(), missing('time'), success('SYNTH_M:D', 'SYNTH_O1', '2026-06-30')]},
  {id: 'complete-direct-query', messages: ['查合成机构甲2026年5月31日的经营收益金额当日数'], expected: [success()]},
];
const directory = await mkdtemp(join(tmpdir(), 'missing-conditions-model-'));
const sessions = new NativeSessionStore(directory), skills = await loadBusinessSkills();
const local = {...config, dataDir: directory, businessProtocol: 'semantic_v2'};
const host = new HarnessHost(local, (association: any) => createAskMetricModels(local, association), sessions,
  [...createAskMetricTools(), createBusinessSkillReadTool(skills)], {skills});
const actor: BackendUser = {id: 'synthetic-semantic', username: 'synthetic', display_name: '缺项循环合成验收', org_code: 'SYNTH_ROOT', org_name: '合成集团', role_code: 'USER'};
const turns: any[] = [];
let gatewayBlocked = false;
const sourceHashes = Object.fromEntries(await Promise.all(['src/harnessHost.ts', 'src/semantic-task/service.ts', 'src/semantic-task/planService.ts', 'src/semantic-task/feedback.ts', 'src/semantic-task/prompt.ts'].map(async p => [p, createHash('sha256').update(await readFile(join(sourceRoot, p))).digest('hex')])));
async function save() {await mkdir(dirname(report), {recursive: true}); await writeFile(report, JSON.stringify({
  environment: 'real_model_synthetic_catalog_in_memory_SQL', real_database: false, source_root: sourceRoot, source_hashes: sourceHashes,
  model: config.model.name, gateway_origin: new URL(config.model.baseUrl).origin,
  model_settings: {max_tokens: config.model.maxTokens, context_window: config.model.contextWindow,
    extra_body: Object.fromEntries(Object.entries(config.model.extraBody).filter(([key]) => ['temperature', 'top_p', 'top_k', 'seed', 'enable_thinking', 'thinking', 'reasoning_effort'].includes(key))),
    retry: config.modelRetry, first_response_timeout_ms: config.modelFirstResponseTimeoutMs, stream_idle_timeout_ms: config.modelStreamIdleTimeoutMs},
  native_session_directory: directory, planned_turns: scenarios.filter(s => !selected.size || selected.has(s.id)).reduce((n, s) => n + s.messages.length, 0),
  gateway_blocked: gatewayBlocked, total: turns.length, passed: turns.filter(t => t.passed).length, turns,
}, null, 2));}
try {
  scenariosLoop: for (const scenario of scenarios.filter(s => !selected.size || selected.has(s.id))) {
    const hosted = await host.createSession(actor), b = backend();
    try {
      for (const [index, message] of scenario.messages.entries()) {
        const expected = scenario.expected[index]!, before = b.queries.length, started = performance.now();
        let failure: string | undefined, guardAborted = false;
        const admission = await host.admitPrompt(hosted, {protocol_version: 3, request_id: `${scenario.id}-${index}`, message}, {actor, backend: b.client});
        assert(admission.ok);
        // 验收预算只防止失败基线消耗模型费用，业务修复不调整任何超时或重试配置。
        const timer = setTimeout(() => {guardAborted = true; void host.abort(hosted, admission.operationId);}, Number(arg('guard-ms', '90000')));
        try {const result = await host.drivePrompt(hosted, admission); assert(result.ok && result.outcome.kind === 'settled' && result.outcome.outcome.status === 'completed', 'TURN_COMPLETED');}
        catch (e) {failure = e instanceof Error ? e.message : String(e);} finally {clearTimeout(timer);}
        const entries = await hosted.lane.findEntries({order: 'oldestFirst'}, BACKGROUND_CONTEXT);
        const start = entries.map((e: any) => e.type === 'message' && e.message.role === 'user').lastIndexOf(true);
        const current = entries.slice(start), messages = current.flatMap((e: any) => e.type === 'message' ? [e.message] : []);
        const receipts = messages.flatMap((m: any) => m.role === 'toolResult' ? [{name: m.toolName, details: m.details, is_error: !!m.isError}] : []);
        const calls = messages.flatMap((m: any) => m.role === 'assistant' ? m.content.filter((c: any) => c.type === 'toolCall').map((c: any) => ({name: c.name, args: c.arguments})) : []);
        const modelErrorCodes = messages.flatMap((m: any) => m.role === 'assistant' && ['error', 'aborted'].includes(m.stopReason)
          ? [/^(\d{3})\b/u.exec(m.errorMessage ?? '')?.[1] ? `HTTP_${/^(\d{3})\b/u.exec(m.errorMessage)![1]}` : 'MODEL_TRANSPORT_ERROR'] : []);
        gatewayBlocked = modelErrorCodes.some((code: string) => ['HTTP_401', 'HTTP_402', 'HTTP_403'].includes(code));
        const formal = receipts.filter((r: any) => isSemanticFeedback(r.details)).at(-1)?.details;
        const answer = projectEntries(current).filter((m: any) => m.role === 'assistant').map((m: any) => m.text).join('\n');
        const queries = b.queries.slice(before);
        try {
          assert(!guardAborted, 'TEST_GUARD_ABORTED'); assert.equal(formal?.status, expected.status, 'FORMAL_STATUS'); assert(answer.trim(), 'VISIBLE_ANSWER');
          if (expected.missing) {
            assert.equal(formal.continuation.actor, 'user', 'USER_RESPONSIBILITY'); assert.equal(queries.length, 0, 'NO_PREMATURE_EXECUTION');
            for (const field of expected.missing) assert(formal.issues.some((issue: any) => issue.field === field && issue.remediation === 'user'), `MISSING_${field}`);
            assert.deepEqual([...new Set(formal.issues.filter((issue: any) => issue.remediation === 'user').map((issue: any) => issue.field))].sort(), [...expected.missing].sort(), 'ONLY_ACTUAL_MISSING_FIELDS');
            const waiting = receipts.findIndex((r: any) => isSemanticFeedback(r.details) && r.details.status === 'needs_user');
            assert.equal(receipts.slice(waiting + 1).filter((r: any) => r.name === 'read' || r.name === 'business_context_read').length, 0, 'NO_HISTORY_AFTER_WAITING');
          } else if (expected.status === 'succeeded') {
            if (expected.metrics) {
              assert(queries.length >= 1 && queries.length <= expected.metrics.length, 'ONLY_REQUIRED_EXECUTIONS');
              assert.deepEqual(queries.flatMap(q => q.spec.metric_codes).sort(), [...expected.metrics].sort(), 'ALL_METRICS_ONCE');
            } else {assert.equal(queries.length, 1, 'ONE_EXECUTION'); assert.deepEqual(queries[0].spec.metric_codes, [expected.metric]);}
            for (const query of queries) {assert.deepEqual(query.spec.org_codes, [expected.org]); assert.equal(query.spec.time.start, expected.day); assert.equal(query.spec.time.end, expected.day);}
          } else assert.equal(queries.length, 0, 'PREPARE_DOES_NOT_EXECUTE');
        } catch (e) {failure ??= e instanceof Error ? e.message : String(e);}
        const store = new NativeSemanticTaskStore(hosted.session), plan = await store.plan((await store.planIndex()).focus ?? '');
        const turn = {scenario: scenario.id, turn: index + 1, message, expected, passed: !failure, failure, guard_aborted: guardAborted, model_error_codes: modelErrorCodes,
          status: formal?.status, elapsed_ms: Math.round(performance.now() - started), model_calls: admission.request.timings?.model_ms.length,
          history_reads: calls.filter((c: any) => c.name === 'read').length, calls, receipts, queries, completion: plan?.completion, answer};
        turns.push(turn); await save(); console.log(JSON.stringify({scenario: turn.scenario, turn: turn.turn, passed: turn.passed, status: turn.status, history_reads: turn.history_reads, elapsed_ms: turn.elapsed_ms, failure}));
        if (gatewayBlocked) break scenariosLoop;
        if (guardAborted) break;
      }
    } finally {await host.closeSession(hosted.sessionId);}
  }
} finally {await save(); await host.close(); await sessions.close();}
if (turns.some(t => !t.passed)) process.exitCode = 1;
