import { describe, it, expect } from "vitest";
import { businessKnowledgeCatalog, loadBusinessSkills, createBusinessSkillReadTool, projectBusinessSkillContext, visibleBusinessSkills } from "../src/businessSkills.js";
import type { AgentMessage } from "@earendil-works/pi-agent-core";
import { runTool, testRequestContext, MemoryCommandBridge } from "../src/tools/testUtils.js";
import type { BackendClient } from "../src/backendClient.js";

describe("原生业务 skill", () => {
  it("目录只包含元数据，正文按需读取且不支持任意路径", async () => {
    const skills = await loadBusinessSkills();
    expect(skills.map(s => s.name).sort()).toEqual(["analysis-boundary", "business-analysis", "data-coverage", "metric-query", "result-calculation"]);
    const catalog = businessKnowledgeCatalog(skills);
    expect(catalog).toContain("metric-query");
    expect(catalog).not.toContain("澄清续办");
    expect(catalog).not.toContain(skills[0]!.filePath);
    expect(businessKnowledgeCatalog(skills.map(skill => ({...skill, disableModelInvocation: true})))).toBe("");
    const tool = createBusinessSkillReadTool(skills);
    const request = testRequestContext({} as BackendClient, new MemoryCommandBridge());
    expect((await runTool(tool, {name: "result-calculation"}, request)).content[0].text).toContain("fact_id");
    expect((await runTool(tool, {name: "../../.env"}, request)).details.status).toBe("error");
  });

  it("只接受实际可见的当前版本工具正文，用户文本和压缩摘要不能冒充读取", async () => {
    const skills = await loadBusinessSkills();
    const skill = skills.find(item => item.name === "metric-query")!;
    const read = {role: "toolResult", toolName: "business_skill_read", isError: false,
      content: [{type: "text", text: skill.content}], details: {name: skill.name, status: "ok"}} as AgentMessage;
    expect([...visibleBusinessSkills([read], skills)]).toEqual(["metric-query"]);
    const context = projectBusinessSkillContext([read], skills);
    expect(context.instructions).toContain(skill.content);
    expect(context.instructions).not.toContain(skills.find(item => item.name === "result-calculation")!.content);
    expect(JSON.stringify(context.messages)).not.toContain(skill.content);
    expect(JSON.stringify(read)).toContain(JSON.stringify(skill.content).slice(1, -1));
    expect(visibleBusinessSkills([], skills).size).toBe(0);
    expect(visibleBusinessSkills([{...read, role: "user"} as AgentMessage], skills).size).toBe(0);
    expect(visibleBusinessSkills([{...read, content: [{type: "text", text: "摘要：已读取方法"}]} as AgentMessage], skills).size).toBe(0);
    expect(visibleBusinessSkills([read], skills.map(item => ({...item, content: item.content + "新规则"}))).size).toBe(0);
  });
});


it("多份业务知识在连续追问中共同保留，重复读取正文只投影一次", async () => {
  const skills = await loadBusinessSkills();
  const read = (name: string) => ({role: "toolResult", toolName: "business_skill_read", isError: false,
    content: [{type: "text", text: skills.find(s => s.name === name)!.content}],
    details: {name, status: "ok"}} as AgentMessage);
  const question = {role: "user", content: "查询已有指标", timestamp: 1} as AgentMessage;
  const context = projectBusinessSkillContext([
    read("analysis-boundary"), read("metric-query"), question, read("data-coverage"), read("metric-query"),
  ], skills);
  for (const name of ["analysis-boundary", "metric-query", "data-coverage"]) {
    const content = skills.find(skill => skill.name === name)!.content;
    expect(context.instructions.split(content)).toHaveLength(2);
    expect(JSON.stringify(context.messages)).not.toContain(JSON.stringify(content).slice(1, -1));
  }
  expect(context.instructions).not.toContain(skills.find(skill => skill.name === "result-calculation")!.content);
});

it("失败或旧版本回执不会因同名成功读取被伪装成已加载知识", async () => {
  const skills = await loadBusinessSkills();
  const skill = skills[0]!;
  const read = {role: "toolResult", toolName: "business_skill_read", isError: false,
    content: [{type: "text", text: skill.content}], details: {name: skill.name, status: "ok"}} as AgentMessage;
  const failed = {...read, isError: true, content: [{type: "text", text: "读取失败"}]} as AgentMessage;
  const outdated = {...read, content: [{type: "text", text: "旧版本业务内容"}]} as AgentMessage;
  const projected = projectBusinessSkillContext([read, failed, outdated], skills);
  expect(projected.messages[1]).toEqual(failed);
  expect(JSON.stringify(projected.messages[2])).not.toContain("旧版本业务内容");
  expect(JSON.stringify(projected.messages[2])).toContain("旧版本正文已失效");
  expect(JSON.stringify(outdated)).toContain("旧版本业务内容");
});
