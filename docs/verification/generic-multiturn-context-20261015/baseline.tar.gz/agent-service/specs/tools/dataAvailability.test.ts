import { describe, expect, it, vi } from "vitest";
import { BackendApiError, type BackendClient } from "../../src/backendClient.js";
import { businessEvidence } from "../../src/answerEvidence.js";
import { createDataAvailabilityTool } from "../../src/tools/dataAvailability.js";
import { MemoryCommandBridge, runTool, testRequestContext } from "../../src/tools/testUtils.js";

describe("覆盖查询参数纠正", () => {
  it.each([
    {org_codes: ["A"], start: "2026-02-30", end: "2026-03-01"},
    {org_codes: ["A"], start: "2026-03-31", end: "2026-03-01"},
    {org_codes: [], start: "2026-03-01", end: "2026-03-31"},
  ])("拒绝无效范围且允许原生循环纠正：%j", async params => {
    const dataAvailability = vi.fn();
    const request = testRequestContext({dataAvailability} as unknown as BackendClient, new MemoryCommandBridge());
    const result = await runTool(createDataAvailabilityTool(), {dimension: "metrics", ...params}, request);
    expect(dataAvailability).not.toHaveBeenCalled();
    // pi 不识别 execute 返回值中的 isError；宿主依靠真实回执的 retryable 决定续跑。
    expect(businessEvidence(result.details)).toMatchObject({status: "error", retryable: true});
    expect(result.details.public_answer).toContain("保持用户指定范围");
  });

  it.each([[422, true], [403, undefined], [401, undefined]] as const)(
    "后端 %i 保留可纠正/不可继续边界", async (status, retryable) => {
      const dataAvailability = vi.fn().mockRejectedValue(new BackendApiError(status, "隔离错误"));
      const request = testRequestContext({dataAvailability} as unknown as BackendClient, new MemoryCommandBridge());
      const result = await runTool(createDataAvailabilityTool(), {
        dimension: "metrics", org_codes: ["A"], start: "2026-03-01", end: "2026-03-31",
      }, request);
      expect(businessEvidence(result.details)?.retryable).toBe(retryable);
      expect(result.details.status).toBe("error");
      expect(dataAvailability).toHaveBeenCalledOnce();
    },
  );
});
