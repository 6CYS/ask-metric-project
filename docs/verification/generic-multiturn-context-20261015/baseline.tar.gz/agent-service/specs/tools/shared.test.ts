/**
 * 共享错误分类：所有业务工具对后端失败按同一语义映射——
 * 401/403 固定文案，422 可纠正并透传具体原因，未知状态如实表达。
 */
import { describe, expect, it } from "vitest";
import { BackendApiError } from "../../src/backendClient.js";
import { backendErrorResult, type ErrorDetails } from "../../src/tools/shared.js";

const details: ErrorDetails = { kind: "metric_calculate", status: "error" };

describe("backendErrorResult", () => {
  it("422 参数错误可纠正并透传后端具体原因", () => {
    const result = backendErrorResult(
      new BackendApiError(422, "只有无量纲比值才能展示为百分比。", "CALCULATION_INVALID"),
      details,
    )!;
    expect(result.details.retryable).toBe(true);
    expect(result.details.public_answer).toContain("无量纲比值");
  });

  it("REQUEST_INVALID 纯校验错误带字段级摘要", () => {
    const result = backendErrorResult(
      new BackendApiError(422, "请求参数未通过校验。", "REQUEST_INVALID", {
        fields: [{ path: "constants._", rule: "string_pattern_mismatch" }],
      }),
      details,
    )!;
    expect(result.details.retryable).toBe(true);
    expect(result.details.public_answer).toContain("constants._");
  });

  it("未知状态（5xx/无 code）如实表达，不暗示存在后台任务", () => {
    const result = backendErrorResult(new BackendApiError(502, "HTTP 502"), details)!;
    expect(result.details.retryable).toBeUndefined();
    expect(result.details.public_answer).toBe("本次请求未得到确认响应，请勿重复提交。");
    expect(result.details.public_answer).not.toContain("回查");
  });

  it("401/403 固定文案不变", () => {
    expect(backendErrorResult(new BackendApiError(401, "x", "AUTH_TOKEN_INVALID"), details)!
      .details.public_answer).toBe("登录状态已失效，请刷新页面重新登录。");
    expect(backendErrorResult(new BackendApiError(403, "x", "CALCULATION_FORBIDDEN"), details)!
      .details.public_answer).toBe("无权访问所选数据，请确认机构权限。");
  });

  it("非后端错误返回 undefined，由调用方 rethrow", () => {
    expect(backendErrorResult(new Error("boom"), details)).toBeUndefined();
  });
});
