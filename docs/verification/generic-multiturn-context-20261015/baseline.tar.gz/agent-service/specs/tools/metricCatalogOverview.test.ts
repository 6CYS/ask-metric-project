import { expect, it } from "vitest";
import { BACKGROUND_CONTEXT } from "@earendil-works/pi-agent-core";
import { createMetricCatalogOverviewTool } from "../../src/tools/metricCatalogOverview.js";
import type { AskMetricRequestContext } from "../../src/requestContext.js";

it("目录介绍引用实时目录数量和完整指标名，不创建问数任务", async () => {
  const request = {backend: {metricCatalogOverview: async () => ({total: 2, groups: [{unit: "%", count: 2, examples: [{code: "m", name: "金融机构数量较同期增幅"}]}]})}} as unknown as AskMetricRequestContext;
  const result = await createMetricCatalogOverviewTool().execute("call", {}, () => {}, request, {} as never, BACKGROUND_CONTEXT);
  expect(result.details).toMatchObject({status: "catalog", public_answer: expect.stringContaining("启用了 2 个指标")});
  expect(result.details).toMatchObject({public_answer: expect.stringContaining("金融机构数量较同期增幅")});
});
