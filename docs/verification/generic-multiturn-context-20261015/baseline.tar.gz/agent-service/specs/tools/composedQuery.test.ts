import { expect, it } from "vitest";
import { resultAnswer } from "../../src/answerEvidence.js";

it("覆盖月份结果按指标机构分组，并显式说明截断", () => {
  const answer = resultAnswer({row_count: 2, truncated: true, rows: [
    {org_name: "甲", metric_name: "存款", available_period: "2025-12"},
    {org_name: "乙", metric_name: "存款", available_period: "2026-01"},
  ]});
  expect(answer).toContain("甲的存款有数据的期间：2025-12");
  expect(answer).toContain("乙的存款有数据的期间：2026-01");
  expect(answer).toContain("未覆盖全部结果");
});
