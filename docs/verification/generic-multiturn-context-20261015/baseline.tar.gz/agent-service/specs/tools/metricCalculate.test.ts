/**
 * metric_calculate 参数契约：变量/常数键名必须与后端同一规则。
 * 非法键在宿主运行时校验（validateToolArguments）阶段即被拒绝，不会发到后端。
 */
import { describe, expect, it } from "vitest";
import { validateToolArguments, type Tool, type ToolCall } from "@earendil-works/pi-ai";
import { createMetricCalculateTool } from "../../src/tools/metricCalculate.js";

const tool = createMetricCalculateTool() as unknown as Tool;

function call(args: unknown): ToolCall {
  return { id: "call-1", name: "metric_calculate", arguments: args } as ToolCall;
}

function validArgs(constantsKey: string) {
  return {
    expressions: [{ name: "diff", label: "两项余额差值", expression: "val1 - val2" }],
    bindings: {
      val1: { fact_id: "fact:t:0:metric_value" },
      val2: { fact_id: "fact:t:1:metric_value" },
    },
    constants: { [constantsKey]: { value: "2", source_text: "2" } },
  };
}

describe("metric_calculate 参数 schema", () => {
  it("非法键 '_' 在校验阶段被拒绝", () => {
    expect(() => validateToolArguments(tool, call(validArgs("_")))).toThrow(/Validation failed/);
  });

  it("非法 bindings 键同样被拒绝", () => {
    const args = validArgs("c2");
    expect(() =>
      validateToolArguments(tool, call({ ...args, bindings: { "_x": { fact_id: "fact:t:0:metric_value" } } })),
    ).toThrow(/Validation failed/);
  });

  it("合法键与合法参数通过", () => {
    const validated = validateToolArguments(tool, call(validArgs("c2"))) as Record<string, unknown>;
    expect(validated.bindings).toBeTruthy();
  });

  it("空 bindings 被拒绝", () => {
    expect(() =>
      validateToolArguments(tool, call({
        expressions: [{ name: "diff", label: "差值", expression: "val1" }],
        bindings: {},
      })),
    ).toThrow(/Validation failed/);
  });
});
