import { expect, it } from "vitest";
import { projectEntries, projectBusinessTasks } from "../src/sessionProjection.js";
import type { Entry } from "@earendil-works/pi-agent-core";
const entry = (message: unknown) => ({ type: "message", id: "e", message, timestamp: 1 }) as Entry;

it("刷新投影保持调用与结果的相同 ID，页面不会把一次调用计成两次", () => {
  const messages = projectEntries([
    entry({role: "assistant", content: [{type: "toolCall", id: "call-1", name: "metric_calculate"}]}),
    entry({role: "toolResult", toolCallId: "call-1", toolName: "metric_calculate", details: {}}),
  ]);
  expect(messages[0]).toMatchObject({tool_calls: [{id: "call-1", tool: "metric_calculate"}]});
  expect(messages[1]).toMatchObject({tool_call_id: "call-1"});
});

it("目录参数纠正成功后不再把已恢复的错误显示成最终部分失败", () => {
  const messages = projectEntries([
    entry({role: "user", content: "查询并求差"}),
    entry({role: "toolResult", toolName: "org_catalog_search", isError: true}),
    entry({role: "toolResult", toolName: "org_catalog_search", isError: false, details: {total: 1}}),
    entry({role: "toolResult", toolName: "metric_calculate", details: {kind: "metric_calculate", status: "succeeded", public_answer: "差值已确认。"}}),
    entry({role: "assistant", content: [{type: "text", text: "结束"}]}),
  ]);
  expect(messages.at(-1)).toMatchObject({text: "差值已确认。"});
});

it("计算失败与模型中断不会被中间查询成功覆盖，计算不改写查询任务状态", () => {
  const entries=[entry({role:"user",content:"取值并求差"}),
    entry({role:"toolResult",toolName:"metric_query_structured",details:{kind:"metric_query_structured",status:"succeeded",task_id:"t",result_id:"r",public_answer:"原值10元"}}),
    entry({role:"toolResult",toolName:"metric_calculate",details:{kind:"metric_calculate",status:"error",task_id:"t",public_answer:"日期不同，不能计算。"}}),
    entry({role:"assistant",content:[],errorMessage:"provider failed"})];
  const messages=projectEntries(entries);
  const text=JSON.stringify(messages.at(-1));
  expect(text).toContain("原值10元");
  expect(text).toContain("不能计算");
  expect(text).toContain("处理未完成");
  expect(projectBusinessTasks(messages)[0]).toMatchObject({status:"succeeded",result_id:"r"});
});

it("调用上限终止理由可交付且不能被已有成功结果覆盖", () => {
  const limit = "本轮已达到工具调用限额，处理未完成。请重试本轮问题，无需重复已确认的条件。";
  const previous = entry({role: "toolResult", toolName: "metric_ask", details: {
    kind: "metric_ask", status: "succeeded", public_answer: "已取得部分数据。",
  }});
  for (const hasEvidence of [false, true]) {
    for (const ending of [
      entry({role: "toolResult", toolName: "business_skill_read", isError: true, content: [{type: "text", text: limit}]}),
      entry({role: "assistant", content: [{type: "text", text: limit}]}),
    ]) {
      const messages = projectEntries([entry({role: "user", content: "继续处理"}), ...(hasEvidence ? [previous] : []), ending]);
      expect(messages.at(-1)).toMatchObject({role: "assistant", tools: []});
      expect(JSON.stringify(messages.at(-1))).toContain(limit);
      if (hasEvidence) expect(JSON.stringify(messages.at(-1))).toContain("已取得部分数据");
    }
  }
});
