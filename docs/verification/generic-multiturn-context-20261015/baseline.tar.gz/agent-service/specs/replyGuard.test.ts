/**
 * 无证据回答交付门：提问放行（数字是在向用户求证）；
 * 陈述句中的每个数字都必须能在用户原话中找到来源。
 */
import { describe, expect, it } from "vitest";
import { mayDeliverWithoutEvidence, numberTokens } from "../src/replyGuard.js";

const question = "查询紫金农商行2026年3月31日个人活期存款余额当日数和个人经营性贷款余额当日数，并计算前者减后者";

describe("mayDeliverWithoutEvidence", () => {
  it("提问放行：澄清问句中的序号、日期不受限", () => {
    expect(mayDeliverWithoutEvidence(
      "请问「紫金」指哪家机构？1. 紫金农商行 2. 紫金县联社。另外确认是2026年6月末吗？",
      "2026年6月末 紫金 涉农及小微贷款余额当日数减去涉农及小微贷款余额较同期的差值是多少？",
    )).toBe(true);
  });

  it("数字全部来自用户原话的陈述放行", () => {
    expect(mayDeliverWithoutEvidence("2026年3月31日的数据需要先确认口径。", question)).toBe(true);
  });

  it("含外来数字的陈述拦截", () => {
    expect(mayDeliverWithoutEvidence("两项差值为1,514,742.01万元。", question)).toBe(false);
    expect(mayDeliverWithoutEvidence("较同期增长12.5%。", question)).toBe(false);
    expect(mayDeliverWithoutEvidence("余额为987654.32元。还需要查其他日期吗？", question)).toBe(false);
  });

  it("子串不等于同源：'2' 蒙混不了用户写的 '2026'", () => {
    expect(numberTokens("2026年").has("2")).toBe(false);
    expect(mayDeliverWithoutEvidence("结果约为其2倍。", question)).toBe(false);
  });

  it("无数字陈述放行", () => {
    expect(mayDeliverWithoutEvidence("本轮需要您先确认机构范围。", question)).toBe(true);
  });

  it("全角数字与半角等价", () => {
    expect(mayDeliverWithoutEvidence("２０２６年的数据……", question)).toBe(true);
  });
});
