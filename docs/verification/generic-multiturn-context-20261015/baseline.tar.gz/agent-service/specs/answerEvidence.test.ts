import { describe, expect, it } from "vitest";
import { projectEntries, projectWatchEvent, projectBusinessTasks } from "../src/sessionProjection.js";
import { resultAnswer, resultAnswerBlocks, currentTurnEvidence, selectEvidence } from "../src/answerEvidence.js";
import type { AnswerBlock } from "../src/backendClient.js";
import type { Entry } from "@earendil-works/pi-agent-core";
const entry = (message: unknown, id = "e") => ({ type: "message", id, message, timestamp: 1 }) as Entry;

describe("事实交付回归", () => {
  it("pi 只交付目标结果，目录排查留在日志，重放保持选择与原始精度", () => {
    const entries = [entry({role: "user", content: "查余额"}),
      entry({role: "toolResult", details: {kind: "data_availability", status: "succeeded", public_answer: "共4830个指标"}}, "catalog"),
      entry({role: "toolResult", details: {kind: "metric_query_structured", status: "succeeded", public_answer: "余额1.123456元（结果存在截断）。"}}, "query")];
    const refs = currentTurnEvidence(entries.filter(e => e.type === "message").map(e => e.message));
    const delivered = selectEvidence(refs, ["e2"]);
    const projection = projectEntries([...entries, entry({role: "toolResult", details: delivered}, "delivery")]);
    expect(projection.at(-1)).toMatchObject({role: "assistant", text: "余额1.123456元（结果存在截断）。"});
    expect(projection.filter(m => m.role === "assistant").some(m => m.text.includes("4830"))).toBe(false);
    expect(projection.find(m => m.entry_id === "catalog")).toMatchObject({details: {answer_selected: false}});
    expect(projection.find(m => m.entry_id === "query")).toMatchObject({details: {answer_selected: true}});
  });
  it("拒绝无证据、重复和跨回合引用，不让局部成功隐藏失败", () => {
    const refs = currentTurnEvidence([{role: "toolResult", details: {kind: "metric_ask", status: "succeeded", public_answer: "旧值"}},
      {role: "user"},
      {role: "toolResult", details: {kind: "metric_query_structured", status: "succeeded", public_answer: "本期值"}},
      {role: "toolResult", details: {kind: "metric_calculate", status: "error", retryable: true, public_answer: "计算未完成"}}]);
    expect(refs).toHaveLength(2);
    expect(() => selectEvidence(refs, [])).toThrow();
    expect(() => selectEvidence(refs, ["e1", "e1"])).toThrow();
    expect(() => selectEvidence(refs, ["e3"])).toThrow();
    expect(() => selectEvidence(refs, ["e1"])).toThrow("未解决");
    expect(selectEvidence(refs, ["e1", "e2"]).public_answer).toBe("本期值\n\n计算未完成");
  });
  it("参数纠正后可只交付新结果，不能选择被替代的错误", () => {
    const refs = currentTurnEvidence([{role: "user"},
      {role: "toolResult", details: {kind: "metric_query_structured", status: "error", retryable: true, public_answer: "完整名称冲突"}},
      {role: "toolResult", details: {kind: "metric_query_structured", status: "succeeded", public_answer: "目标值"}}]);
    expect(selectEvidence(refs, ["e2"]).public_answer).toBe("目标值");
    expect(() => selectEvidence(refs, ["e1"])).toThrow("替代");
  });
  it("500 后旧机构金额不进入历史、重连，原始流也不泄露", () => {
    const entries = [
      entry({role:"user", content:"查紫金"}),
      entry({role:"toolResult", toolName:"metric_ask", details:{kind:"metric_ask", task_id:"old", status:"succeeded", result_id:"r1", public_answer:"紫金：15147420074元。"}}),
      entry({role:"assistant", content:[{type:"text",text:"紫金：15147420074元。"}]}),
      entry({role:"user", content:"那江阴呢？"}),
      entry({role:"toolResult", toolName:"metric_ask", details:{kind:"metric_ask", task_id:"new", status:"error", error_code:"INTERNAL_SERVER_ERROR"}}),
      entry({role:"assistant", content:[{type:"text",text:"江阴15147420074元。"}]}),
    ];
    const projected = projectEntries(entries);
    expect(JSON.stringify(projected.slice(projected.findIndex(message => message.role === "user" && message.text === "那江阴呢？")))).not.toContain("15147420074");
    expect(projectBusinessTasks(projected)).toEqual([{task_id:"new", status:"error", result_id:null,error_code:"INTERNAL_SERVER_ERROR"}]);
    expect(projectWatchEvent({type:"message_update",frame:{type:"text_delta",delta:"江阴15147420074元"}})).toBeNull();
    expect(projectWatchEvent({type:"message_end",message:{role:"assistant",content:"江阴15147420074元"}})).toBeNull();
  });
  it("空结果不编为零；后端渲染 message 优先于本地拼接", () => {
    expect(resultAnswer({rows:[],row_count:0})).toBe("查询完成，暂无匹配数据。");
    // 排名指标：数据库 Numeric(24,6) 原始值带尾零，正文必须使用后端渲染文本而非原始字符串
    expect(resultAnswer({
      rows:[{org_name:"泰州农商行",metric_name:"个人经营性贷款余额层级排名",stat_date:"2026-03-31",metric_value:"14.000000",unit:"名"}],
      row_count:1,
      message:"2026年03月31日，泰州农商行的个人经营性贷款余额层级排名为第14名。",
    })).toBe("2026年03月31日，泰州农商行的个人经营性贷款余额层级排名为第14名。");
    // 截断时保留截断提示
    expect(resultAnswer({
      rows:[{org_name:"泰州农商行",metric_name:"存款余额",stat_date:"2026-03-31",metric_value:"1.000000",unit:"元"}],
      row_count:1,
      truncated:true,
      message:"2026年03月31日，泰州农商行的存款余额为1.00元。",
    })).toContain("结果存在截断");
    // 后端未给 message 时兜底拼接保持原始精度与单位不换算
    expect(resultAnswer({rows:[{org_name:"江阴",metric_name:"存款余额",stat_date:"2026-03-31",metric_value:"15147420074.0000",unit:"元"}],row_count:1})).toContain("15147420074.0000");
  });
  it("answer_blocks 原样透传；截断追加独立提示段落块；无 blocks 返回 undefined", () => {
    const blocks: AnswerBlock[] = [
      {type:"paragraph",segments:[{text:"2026年03月31日，",bold:false},{text:"泰州农商行",bold:true},{text:"的存款余额为1.00元。",bold:false}]},
      {type:"list",ordered:false,items:[[{text:"第一项",bold:false}]]},
      {type:"table",header:[[{text:"机构",bold:true}]],rows:[[[{text:"泰州",bold:false}]]],aligns:["left"]},
    ];
    // 后端给了 blocks：原样返回，不重新解析
    expect(resultAnswerBlocks({answer_blocks:blocks,truncated:false})).toEqual(blocks);
    // 截断时把与 resultAnswer 同款提示追加为独立段落块，不改动原块
    const truncated = resultAnswerBlocks({answer_blocks:blocks,truncated:true});
    expect(truncated).toHaveLength(blocks.length + 1);
    expect(truncated?.slice(0, blocks.length)).toEqual(blocks);
    expect(truncated?.at(-1)).toEqual({type:"paragraph",segments:[{text:"（结果存在截断，完整结果请查看数据明细。）",bold:false}]});
    // 后端未给 blocks（null / 缺省 / 空数组）：返回 undefined，前端回退纯文本
    expect(resultAnswerBlocks({answer_blocks:null})).toBeUndefined();
    expect(resultAnswerBlocks({})).toBeUndefined();
    expect(resultAnswerBlocks({answer_blocks:[]})).toBeUndefined();
  });
});
