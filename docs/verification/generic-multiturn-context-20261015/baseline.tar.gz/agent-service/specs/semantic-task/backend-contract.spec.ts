import {execFileSync} from "node:child_process";
import {resolve} from "node:path";
import {afterEach, expect, it} from "vitest";
import {SemanticPlanService} from "../../src/semantic-task/planService.js";
import {SemanticTaskService} from "../../src/semantic-task/service.js";
import {createSemanticExecuteTool} from "../../src/semantic-task/tools.js";
import {semanticFeedback, semanticPublicAnswer} from "../../src/semantic-task/feedback.js";
import {runTool} from "../../src/tools/testUtils.js";
import type {BackendClient} from "../../src/backendClient.js";
import {createSyntheticBackend} from "../../scripts/phase4-synthetic-backend.js";
import {fixture, proposal} from "./fixtures.js";
const clean: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of clean.splice(0)) await close();});
const cache = new Map<string, any>();
function python(payload: unknown, script = "semantic-task-fixture.py"): any {
  const input = JSON.stringify(payload), key = script + input;
  if (cache.has(key)) return structuredClone(cache.get(key));
  const output = JSON.parse(execFileSync(resolve("../backend-next/.venv/bin/python"), [resolve("scripts", script)],
    {input, encoding: "utf8", timeout: 30000, env: {PATH: "/usr/bin:/bin:/opt/homebrew/bin"}}));
  expect(output.ok, output.message).toBe(true); cache.set(key, output.value); return output.value;
}
async function setup(script?: string) {
  const f = await fixture(); clean.push(f.close);
  const invoke = (payload: unknown) => python(payload, script);
  const request = (id: string, message: string) => ({...f.request(id, message), backend: {
    ...f.backend,
    inspectBusinessGoal: async (question: string, business_date: string, _options?: unknown, reference_year?: number) => invoke({action: "inspect", question, business_date, reference_year}),
    admitSemanticPlan: async (payload: unknown) => invoke({action: "admit", payload}),
    resolveBusinessField: async (entity: string, raw: string[], _options?: unknown, year?: number, source?: unknown) => invoke({action: "resolve", entity, raw, year, source}),
    matchMetricQuestion: async (question: string) => invoke({action: "mentions", question}),
  } as unknown as BackendClient});
  return {...f, request, invoke};
}
const base = [
  {action: "set", field: "organizations", value: "合成机构甲"},
  {action: "set", field: "metrics", value: "经营收益金额当日数"},
  {action: "set", field: "time", value: "2026年5月31日"},
] as const;
it("合成后端不能把不存在的任务或结果当成功",async()=>{
 const b=createSyntheticBackend();
 await expect(b.client.getTask("unobserved")).rejects.toMatchObject({status:404});
 await expect(b.client.getTaskResult("unobserved")).rejects.toMatchObject({status:404});
});
it("真实目录解析补全模型遗漏的已明确指标口径，编译请求通过后端来源校验和SQL", async () => {
  const f = await setup(), request = f.request("exact", "查询合成机构甲2026年5月31日的经营收益金额当日数");
  const result = await new SemanticTaskService(request).resolve(proposal(base.map(operation => operation.field === "metrics" ? {...operation, value: "经营收益金额"} : operation)));
  expect(result.status).toBe("ready");
  await runTool(createSemanticExecuteTool(), {task_ref: result.task!.ref, target_ref: result.task!.target.ref}, request);
  expect(python({action: "query", spec: f.backend.basicQueries.mock.calls[0]![0]}).rows).toHaveLength(1);
}, 15000);
it("多成员名称通过一对一目录身份对齐，保留原句完整口径且不新增指标", async () => {
  const f = await setup(), request = f.request("multiple-basis", "查询合成机构甲2026年5月31日的经营收益金额当日数和经营收益金额较同期");
  const result = await new SemanticTaskService(request).resolve(proposal(base.map(op => op.field === "metrics" ? {...op, value: "经营收益金额，经营收益金额较同期"} : op)));
  expect({status:result.status,issues:result.task?.issues}).toEqual({status:"ready",issues:[]});
  expect(result.task!.target.fields.metrics!.resolvedValue).toMatchObject({codes:["SYNTH_M:D","SYNTH_M:Y"]});
}, 15000);
it("唯一待补任务日期续补误用new时绑定原焦点，沿用正式指标身份", async () => {
  const f = await setup(), source = f.request("without-date", "查询合成机构甲的经营收益金额当日数");
  const first = await new SemanticPlanService(source).resolve(proposal(base.filter(op=>op.field!=="time")));
  expect(first.status).toBe("needs_user");
  const request = f.request("date-only", "2026年5月31日"),service = new SemanticPlanService(request);
  const next = await service.resolve(proposal([...base]));
  expect((await request.semanticTasks!.planIndex()).focus).toBe(first.state.task_ref);
  expect(next.status).toBe("ready"); expect(next.state.task_ref).toBe(first.state.task_ref);
}, 20000);
it("真实目录的连续new续补不降格已确认指标口径，机构日期齐备后原来源获准", async () => {
  const f = await setup();
  const first = await new SemanticPlanService(f.request("metric-only", "查询经营收益金额当日数")).resolve(proposal([
    {action: "set", field: "metrics", value: "经营收益金额"}, {action: "set", field: "selection", value: "当日数"},
  ]));
  expect(first.status).toBe("needs_user");
  const organization = await new SemanticPlanService(f.request("organization-only", "机构用合成机构甲")).resolve(proposal([
    {action: "set", field: "organizations", value: "合成机构甲"}, {action: "set", field: "time", value: "当日"},
    {action: "set", field: "metrics", value: "经营收益金额"}, {action: "set", field: "selection", value: "当日数"},
  ]));
  expect(organization.status).toBe("needs_user"); expect(organization.state.task_ref).toBe(first.state.task_ref);
  expect(organization.issues.map(issue => issue.field)).toEqual(["time"]);
  const request = f.request("calendar-only", "日期用2026年5月31日"), next = await new SemanticPlanService(request).resolve(proposal([...base]));
  expect({status: next.status, issues: next.issues}).toEqual({status: "ready", issues: []});
  expect(next.state.task_ref).toBe(first.state.task_ref);
  await runTool(createSemanticExecuteTool(), {task_ref: next.state.task_ref, target_ref: next.state.targets[0]!.target_ref}, request);
  const spec = f.backend.basicQueries.mock.calls[0]![0];
  expect(spec).toMatchObject({metric_codes: ["SYNTH_M:D"], org_codes: ["SYNTH_O1"], time: {start: "2026-05-31"}});
  expect(python({action: "query", spec}).rows).toHaveLength(1);
}, 30000);
it.each(["prepared", "succeeded"])("旧目标%s时，多指标修提案不把额外空reference变成查询义务", async previousStatus => {
  const f = await setup("missing-conditions-fixture.py"), original = f.request("previous-metric", "准备合成机构乙2026年6月30日的经营收益金额当日数查询条件");
  const previous = await new SemanticPlanService(original).resolve(proposal(base.map(op => op.field === "organizations" ? {...op, value: "合成机构乙"}
    : op.field === "time" ? {...op, value: "2026年6月30日"} : op), {kind: "new"}, previousStatus === "prepared" ? "prepare" : "query"));
  if (previousStatus === "succeeded") await runTool(createSemanticExecuteTool(), {task_ref: previous.state.task_ref, target_ref: previous.state.targets[0]!.target_ref}, original);
  f.backend.basicQueries.mockClear();
  const request = f.request("multiple-after-context", "分别查询对公协定存款余额当日数和经营收益金额较同期"), service = new SemanticPlanService(request);
  const first = proposal([
    {action: "set", field: "organizations", value: "合成机构乙"}, {action: "set", field: "time", value: "2026年6月30日"},
    {action: "set", field: "metrics", value: "对公协定存款余额"},
  ]);
  first.targets.push({source: {kind: "reference", task_ref: previous.state.task_ref!, target_ref: previous.state.targets[0]!.target_ref}, operations: []},
    {source: {kind: "new"}, operations: [{action: "set", field: "organizations", value: "合成机构乙"},
      {action: "set", field: "time", value: "较同期"}, {action: "set", field: "metrics", value: "经营收益金额"}]});
  await expect(service.resolve(first)).rejects.toMatchObject({issue: {code: "PROPOSAL_REFERENCE_NOT_REQUESTED"}});
  expect((await request.semanticTasks!.planIndex()).focus).toBe(previous.state.task_ref);
  const corrected = proposal(first.targets[0]!.operations);
  corrected.targets.push({source: {kind: "new"}, operations: [
    {action: "set", field: "organizations", value: "合成机构乙"}, {action: "set", field: "time", value: "较同期"},
    {action: "set", field: "metrics", value: "经营收益金额较同期"},
  ]});
  const next = await service.resolve(corrected);
  expect({status: next.status, issues: next.issues}).toEqual({status: "ready", issues: []});
  expect(next.state.targets).toHaveLength(2);
  for (const target of next.state.targets) await runTool(createSemanticExecuteTool(), {task_ref: next.state.task_ref, target_ref: target.target_ref}, request);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(2);
  const specs = f.backend.basicQueries.mock.calls.map(call => call[0]) as Array<{metric_codes: string[]; org_codes: string[]; time: {start: string; end: string}}>;
  expect(specs.map(spec => spec.metric_codes)).toEqual([["SYNTH_DEPOSIT:D"], ["SYNTH_M:Y"]]);
  for (const spec of specs) {
    expect(spec).toMatchObject({org_codes: ["SYNTH_O2"], time: {start: "2026-06-30", end: "2026-06-30"}});
    f.invoke({action: "query", spec});
  }
  expect((await request.semanticTasks!.plan(previous.state.task_ref!))!.steps).toHaveLength(1);
}, 40000);
it("真实Python准入下同轮修复保留起始条件快照，不能借移动后的焦点补默认值", async () => {
  const f = await setup("missing-conditions-fixture.py"), original = f.request("context-start", "准备合成机构乙2026年6月30日的经营收益金额当日数查询条件");
  await new SemanticPlanService(original).resolve(proposal(base.map(op => op.field === "organizations" ? {...op, value: "合成机构乙"}
    : op.field === "time" ? {...op, value: "2026年6月30日"} : op), {kind: "new"}, "prepare"));
  const request = f.request("repair-with-snapshot", "分别查询对公协定存款余额当日数和经营收益金额较同期"), service = new SemanticPlanService(request);
  const incomplete = await service.resolve(proposal([{action: "set", field: "metrics", value: "对公协定存款余额当日数"}]));
  expect(incomplete.status).toBe("needs_interpretation");
  const plan = (await request.semanticTasks!.plan(incomplete.state.task_ref!))!;
  expect(plan.contextFields?.organizations?.resolvedValue).toMatchObject({codes: ["SYNTH_O2"]});
  // 模拟焦点被本轮无确认条件的草案移动；同轮修复必须仍使用已保存起始快照。
  await new SemanticPlanService(f.request("other-draft", "查经营收益金额较同期重新开始")).resolve(proposal([{action: "set", field: "metrics", value: "经营收益金额较同期"}]));
  const corrected = proposal([{action: "set", field: "metrics", value: "对公协定存款余额当日数"}]);
  corrected.targets.push({source: {kind: "new"}, operations: [{action: "set", field: "metrics", value: "经营收益金额较同期"}]});
  const next = await service.resolve(corrected);
  expect({status: next.status, issues: next.issues}).toEqual({status: "ready", issues: []});
  for (const target of next.state.targets) await runTool(createSemanticExecuteTool(), {task_ref: next.state.task_ref, target_ref: target.target_ref}, request);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(2);
  for (const [spec] of f.backend.basicQueries.mock.calls) {expect(spec).toMatchObject({org_codes: ["SYNTH_O2"], time: {start: "2026-06-30"}}); f.invoke({action: "query", spec});}
}, 40000);
it("同指标旧成功目标的机构日期与本轮不符时先修来源，不能永久带入旧范围", async () => {
  const f = await setup(), previousRequest = f.request("old-succeeded-scope", "查询合成机构甲2026年5月31日的经营收益金额当日数");
  const previous = await new SemanticPlanService(previousRequest).resolve(proposal([...base]));
  await runTool(createSemanticExecuteTool(), {task_ref: previous.state.task_ref, target_ref: previous.state.targets[0]!.target_ref}, previousRequest);
  f.backend.basicQueries.mockClear();
  const request = f.request("changed-scope", "查询合成机构乙2026年6月30日的经营收益金额当日数"), service = new SemanticPlanService(request);
  await expect(service.resolve(proposal([], {kind: "reference", task_ref: previous.state.task_ref!, target_ref: previous.state.targets[0]!.target_ref})))
    .rejects.toMatchObject({issue: {code: "PROPOSAL_REFERENCE_NOT_REQUESTED"}});
  expect((await request.semanticTasks!.planIndex()).focus).toBe(previous.state.task_ref);
  const next = await service.resolve(proposal(base.map(op => op.field === "organizations" ? {...op, value: "合成机构乙"}
    : op.field === "time" ? {...op, value: "2026年6月30日"} : op)));
  expect({status: next.status, issues: next.issues}).toEqual({status: "ready", issues: []});
  await runTool(createSemanticExecuteTool(), {task_ref: next.state.task_ref, target_ref: next.state.targets[0]!.target_ref}, request);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(1);
  expect(f.backend.basicQueries.mock.calls[0]![0]).toMatchObject({metric_codes: ["SYNTH_M:D"], org_codes: ["SYNTH_O2"], time: {start: "2026-06-30"}});
  f.invoke({action: "query", spec: f.backend.basicQueries.mock.calls[0]![0]});
}, 30000);
it("真实目录current新指标与new混合首提建立本轮义务，同轮全new修正不污染旧查询", async () => {
  const f = await setup("missing-conditions-fixture.py"), original = f.request("before-current-new", "准备合成机构乙2026年6月30日的经营收益金额当日数查询条件");
  const previous = await new SemanticPlanService(original).resolve(proposal(base.map(op => op.field === "organizations" ? {...op, value: "合成机构乙"}
    : op.field === "time" ? {...op, value: "2026年6月30日"} : op), {kind: "new"}, "prepare"));
  const before = await original.semanticTasks!.plan(previous.state.task_ref!);
  const request = f.request("mixed-current-new", "分别查询对公协定存款余额当日数和经营收益金额较同期"), service = new SemanticPlanService(request);
  const first = proposal([{action: "set", field: "metrics", value: "对公协定存款余额"}], {kind: "current"});
  first.targets.push({source: {kind: "new"}, operations: [
    {action: "set", field: "organizations", value: "合成机构乙"}, {action: "set", field: "metrics", value: "经营收益金额"},
    {action: "set", field: "time", value: "2026年6月30日"}, {action: "set", field: "selection", value: "当日数"},
    {action: "set", field: "operation", value: "较同期"},
  ]});
  const initial = await service.resolve(first);
  expect({status: initial.status, issues: initial.issues}).toEqual({status: "ready", issues: []});
  expect(initial.state.task_ref).not.toBe(previous.state.task_ref);
  expect(await request.semanticTasks!.plan(previous.state.task_ref!)).toEqual(before);
  const corrected = proposal([
    {action: "set", field: "organizations", value: "合成机构乙"}, {action: "set", field: "metrics", value: "对公协定存款余额当日数"},
    {action: "set", field: "time", value: "2026年6月30日"}, {action: "set", field: "selection", value: "当日数"},
  ]);
  corrected.targets.push({source: {kind: "new"}, operations: [
    {action: "set", field: "organizations", value: "合成机构乙"}, {action: "set", field: "metrics", value: "经营收益金额较同期"},
    {action: "set", field: "time", value: "2026年6月30日"}, {action: "set", field: "selection", value: "当日数"},
  ]});
  const next = await service.resolve(corrected);
  expect({status: next.status, issues: next.issues}).toEqual({status: "ready", issues: []}); expect(next.state.targets).toHaveLength(2);
  for (const target of next.state.targets) await runTool(createSemanticExecuteTool(), {task_ref: next.state.task_ref, target_ref: target.target_ref}, request);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(2);
  expect(f.backend.basicQueries.mock.calls.map(call => (call[0] as {metric_codes: string[]}).metric_codes)).toEqual([["SYNTH_DEPOSIT:D"], ["SYNTH_M:Y"]]);
  for (const [spec] of f.backend.basicQueries.mock.calls) {expect(spec).toMatchObject({org_codes: ["SYNTH_O2"], time: {start: "2026-06-30"}}); f.invoke({action: "query", spec});}
  expect(await request.semanticTasks!.plan(previous.state.task_ref!)).toEqual(before);
}, 40000);
it("真实目录按既有高置信纠错确定身份，原句绑定通过独立后端核验", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("typo", "查询合成机构甲2026年5月31日的经营收益金融当日数")).resolve(proposal(base.map(operation =>
    operation.field === "metrics" ? {...operation, value: "经营收益金额"} : operation)));
  expect(first.status).toBe("ready");
  const request = f.request("explicit", "查询合成机构甲2026年5月31日的经营收益金额");
  const pending = await new SemanticTaskService(request).resolve(proposal([...base]));
  expect(pending.status).toBe("needs_user");
  const confirmation = f.request("choice", "指标用经营收益金额当日数");
  const next = await new SemanticTaskService(confirmation).resolve(proposal([{action: "confirm", field: "metrics", value: "经营收益金额当日数"}], {kind: "current"}));
  expect(next.status).toBe("ready");
  await runTool(createSemanticExecuteTool(), {task_ref: next.task!.ref, target_ref: next.task!.target.ref}, confirmation);
  expect(python({action: "query", spec: f.backend.basicQueries.mock.calls[0]![0]}).rows).toHaveLength(1);
}, 15000);
it("真实相对年日历反馈公开完整选项，确认后保留全部数据点口径", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("years", "查询合成机构甲近5年的经营收益金额当日数全部数据")).resolve(proposal([
    ...base.filter(operation => operation.field !== "time"), {action: "set", field: "time", value: "近5年"}, {action: "set", field: "selection", value: "全部数据"},
  ]));
  expect(first.status).toBe("needs_user");
  expect(semanticPublicAnswer(semanticFeedback(first.task, first.status))).toContain("最近5个完整年度");
  const next = await new SemanticTaskService(f.request("year-choice", "日期用第二项")).resolve(proposal([{action: "confirm", field: "time", value: "第二项"}], {kind: "current"}));
  expect(next.status).toBe("ready");
  expect(next.task!.target.fields.selection!.resolvedValue).toBe("all_in_range");
}, 15000);
it("指标片段误填日期直接澄清真正缺少的日期，不进入日期修复循环", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("missing", "查询合成机构甲的经营收益金额当日数")).resolve(proposal(base.map(operation =>
    operation.field === "time" ? {...operation, value: "当日数"} : operation)));
  expect(first.status).toBe("needs_user");
  expect(first.task!.issues.map(issue => issue.code)).toEqual(["FIELD_REQUIRED"]);
  expect(first.task!.target.fields.metrics!.resolvedValue).toMatchObject({codes: ["SYNTH_M:D"]});
  expect(f.backend.basicQueries).not.toHaveBeenCalled();
}, 15000);

it("待修提案从单查询改为双查询时按步骤类型绑定，日期及算式保持整笔义务", async () => {
  const f = await setup(), request = f.request("split-repair", "查询合成机构甲2026年5月31日与2026年6月30日的经营收益金额当日数，计算六月减五月的差额");
  const service = new SemanticPlanService(request);
  const first = proposal([...base.filter(op => op.field !== "time"), {action: "set", field: "time", value: "2026年5月31日与2026年6月30日"}, {action: "set", field: "selection", value: "当日数"}], {kind: "new"}, "calculate");
  first.targets.push({source: {kind: "new"}, operations: [{action: "set", field: "calculation", value: '`2026年6月30日经营收益金额当日数` - `2026年5月31日经营收益金额当日数`'}]});
  const pending = await service.resolve(first); expect(pending.status).toBe("needs_interpretation");
  const next = proposal(base.map(op => op.field === "metrics" ? {...op, value: "经营收益"} : op), {kind: "new"}, "calculate");
  next.targets.push({source: {kind: "new"}, operations: base.map(op => op.field === "time" ? {...op, value: "2026年6月30日"} : op)}, first.targets[1]!);
  const ready = await service.resolve(next);
  expect({status: ready.status, issues: ready.issues}).toEqual({status: "ready", issues: []});
  const plan = (await request.semanticTasks!.plan(ready.state.task_ref!))!;
  expect(plan.steps.filter(step => step.kind === "query")).toHaveLength(2);
  expect(plan.steps.filter(step => step.kind === "calculation")).toHaveLength(1);
  expect(f.backend.basicQueries).not.toHaveBeenCalled();
  for (const target of ready.state.targets.filter(target => target.kind === "query")) await runTool(createSemanticExecuteTool(), {task_ref: ready.state.task_ref, target_ref: target.target_ref}, request);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(2);
  for (const [spec] of f.backend.basicQueries.mock.calls) expect(python({action: "query", spec}).rows).toHaveLength(1);
}, 25000);
it("历史来源可派生两个独立日期目标，原任务不被覆盖，本轮日期必须完整核验", async () => {
  const f = await setup(), original = f.request("history-base", "查询合成机构甲2026年5月31日的经营收益金额当日数");
  const first = await new SemanticPlanService(original).resolve(proposal([...base], {kind: "new"}, "prepare"));
  expect(first.status).toBe("prepared");
  const source = {kind: "reference" as const, task_ref: first.state.task_ref!, target_ref: first.state.targets[0]!.target_ref};
  const request = f.request("history-split", "查询2026年5月31日与2026年6月30日的原指标");
  const input = proposal([{action: "set", field: "time", value: "2026年5月31日"}], source);
  input.targets.push({source, operations: [{action: "set", field: "time", value: "2026年6月30日"}]});
  const result = await new SemanticPlanService(request).resolve(input);
  expect({status: result.status, issues: result.issues}).toEqual({status: "ready", issues: []});
  expect(new Set((await request.semanticTasks!.plan(result.state.task_ref!))!.steps.map(step => step.id)).size).toBe(2);
  expect((await request.semanticTasks!.plan(first.state.task_ref!))!.steps[0]!.targetRef).toBe(source.target_ref);
}, 25000);
it("年份省略的历史追问沿用规范来源年份，独立准入使用相同年份事实", async () => {
  const f = await setup(), request = f.request("year-base", "查询合成机构甲2025年5月31日的经营收益金额当日数");
  const first = await new SemanticPlanService(request).resolve(proposal(base.map(op => op.field === "time" ? {...op, value: "2025年5月31日"} : op), {kind: "new"}, "prepare"));
  expect(first.status).toBe("prepared");
  const followup = f.request("year-followup", "日期换成6月30日");
  const result = await new SemanticPlanService(followup).resolve(proposal([{action: "set", field: "time", value: "6月30日"}], {kind: "current"}));
  expect({status: result.status, issues: result.issues}).toEqual({status: "ready", issues: []});
  const plan = (await followup.semanticTasks!.plan(result.state.task_ref!))!, task = (await followup.semanticTasks!.get(plan.steps[0]!.taskRef!))!;
  expect(task.target.fields.time!.resolvedValue).toEqual({start: "2025-06-30", end: "2025-06-30"});
}, 15000);
it("指标口径缩写误放selection时由同一目录解析器重建身份，不能向用户追问已明确口径", async () => {
  const f = await setup(), request = f.request("basis-placement", "分析合成机构甲2026年5月31日的经营收益金额当日数与经营收益金额较同期，先查询当日数，拿到结果后继续较同期");
  const input = proposal(base.map(op => op.field === "metrics" ? {...op, value: "经营收益金额"} : op), {kind: "new"}, "analyze");
  input.targets[0]!.operations.push({action: "set", field: "selection", value: "当日"});
  const result = await new SemanticPlanService(request).resolve(input);
  expect({status: result.status, issues: result.issues}).toEqual({status: "ready", issues: []});
  const plan = (await request.semanticTasks!.plan(result.state.task_ref!))!, task = (await request.semanticTasks!.get(plan.steps[0]!.taskRef!))!;
  expect(task.target.fields.metrics!.resolvedValue).toMatchObject({codes: ["SYNTH_M:D"]});
}, 15000);


it("模型拆错同一榜单可重组未获准提案，旧提案保留且不可单独执行", async () => {
  const f = await setup(), request = f.request("rank-regroup", "合成机构甲和合成机构乙2026年5月31日的经营收益金额当日数，前1名");
  const service = new SemanticPlanService(request), wrong = proposal([...base]);
  wrong.targets.push({source: {kind: "new"}, operations: base.map(op => op.field === "organizations" ? {...op, value: "合成机构乙"} : op)});
  const blocked = await service.resolve(wrong);
  expect(blocked.status).toBe("needs_interpretation");
  const old = blocked.state.targets[1]!.target_ref;
  const merged = await service.resolve(proposal(base.map(op => op.field === "organizations" ? {...op, value: "合成机构甲和合成机构乙"} : op)));
  expect({status: merged.status, issues: merged.issues}).toEqual({status: "ready", issues: []});
  const plan = (await request.semanticTasks!.plan(merged.state.task_ref!))!;
  expect(plan.steps).toHaveLength(1); expect(plan.supersededSteps).toHaveLength(1);
  await expect(service.locate(plan.ref, old)).rejects.toMatchObject({issue: {code: "REFERENCE_INVALID"}});
  await runTool(createSemanticExecuteTool(), {task_ref: plan.ref, target_ref: merged.state.targets[0]!.target_ref}, request);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(1);
  expect(f.backend.basicQueries.mock.calls[0]![0]).toMatchObject({org_codes: ["SYNTH_O1", "SYNTH_O2"], operation: {kind: "ranking", top_n: 1}});
}, 20000);

it("离散日期的分析义务由多个成功来源联合覆盖，不能要求单个来源包含全部日期", async () => {
  const f = await setup(), request = f.request("analysis-dates", "分析合成机构甲2026年5月31日与2026年6月30日的经营收益金额当日数");
  const service = new SemanticPlanService(request), input = proposal([...base], {kind: "new"}, "analyze");
  input.targets.push({source: {kind: "new"}, operations: base.map(op => op.field === "time" ? {...op, value: "2026年6月30日"} : op)});
  const ready = await service.resolve(input); expect(ready.status).toBe("ready");
  await runTool(createSemanticExecuteTool(), {task_ref: ready.state.task_ref, target_ref: ready.state.targets[0]!.target_ref}, request);
  const partial = (await request.semanticTasks!.plan(ready.state.task_ref!))!;
  expect(partial.completion).toBe("partial"); expect(partial.issues[0]!.code).toBe("ANALYSIS_EVIDENCE_PENDING");
  await runTool(createSemanticExecuteTool(), {task_ref: ready.state.task_ref, target_ref: ready.state.targets[1]!.target_ref}, request);
  const full = (await request.semanticTasks!.plan(ready.state.task_ref!))!;
  expect(full.completion).toBe("full"); expect(full.issues).toEqual([]);
}, 20000);

it("完整原句已经确定机构身份，模型缩写不制造新的用户确认", async () => {
  const f=await setup(),request=f.request("org-abbreviation","查询合成机构丙2026年5月30日的经营收益金额当日数");
  const input=proposal(base.map(op=>op.field==="organizations"?{...op,value:"丙"}:op.field==="time"?{...op,value:"2026年5月30日"}:op));
  const ready=await new SemanticPlanService(request).resolve(input);
  expect({status:ready.status,issues:ready.issues}).toEqual({status:"ready",issues:[]});
  await runTool(createSemanticExecuteTool(),{task_ref:ready.state.task_ref,target_ref:ready.state.targets[0]!.target_ref},request);
  expect(f.backend.basicQueries.mock.calls[0]![0]).toMatchObject({org_codes:["SYNTH_O3"]});
  expect(python({action:"query",spec:f.backend.basicQueries.mock.calls[0]![0]}).rows[0].metric_value).toBe(40);
},15000);

it("仅修改日期时，模型重复陈述相同的已绑定机构不会要求用户重述机构", async () => {
  const f=await setup(),firstRequest=f.request("same-org-base","查询合成机构甲2026年5月31日的经营收益金额当日数");
  await new SemanticPlanService(firstRequest).resolve(proposal([...base],{kind:"new"},"prepare"));
  const request=f.request("same-org-date","日期改成2026年6月30日，其他条件不变");
  const ready=await new SemanticPlanService(request).resolve(proposal([{action:"set",field:"organizations",value:"合成机构甲"},{action:"set",field:"time",value:"2026年6月30日"}],{kind:"current"}));
  expect({status:ready.status,issues:ready.issues}).toEqual({status:"ready",issues:[]});
},15000);


it("同一原句的跨机构计算可拆成标量来源，完整性由整笔任务独立核验",async()=>{
 const f=await setup(),b=createSyntheticBackend(),request={...f.request("cross-org-calculation","查询合成机构甲和合成机构丙2026年5月30日的经营收益金额当日数，计算丙减甲的差额"),backend:b.client};
 const source=(org:string,label:string)=>[...base.map(op=>op.field==="organizations"?{...op,value:org}:op.field==="time"?{...op,value:"2026年5月30日"}:op),{action:"set" as const,field:"objective" as const,value:label}];
 const input=proposal(source("合成机构甲","甲项"),{kind:"new"},"calculate");
 input.targets.push({source:{kind:"new"},operations:source("合成机构丙","丙项")},{source:{kind:"new"},operations:[{action:"set",field:"calculation",value:"`丙项` - `甲项`"}]});
 const ready=await new SemanticPlanService(request).resolve(input);expect({status:ready.status,issues:ready.issues}).toEqual({status:"ready",issues:[]});
 let final:any;for(const target of ready.state.targets)final=await runTool(createSemanticExecuteTool(),{task_ref:ready.state.task_ref,target_ref:target.target_ref},request);
 expect(b.queries).toHaveLength(2);expect(final.details.status).toBe("succeeded");
 expect(final.details.state.evidence.results[0].value).toBe("10");
},25000);
it("多目标签发的正式来源跨轮计算仍有效且不重查",async()=>{
 const f=await setup(),b=createSyntheticBackend(),request={...f.request("signed-queries","分别查询合成机构甲2026年5月31日与合成机构丙2026年6月30日的经营收益金额当日数"),backend:b.client};
 const input=proposal([...base]);
 input.targets.push({source:{kind:"new"},operations:base.map(op=>op.field==="organizations"?{...op,value:"合成机构丙"}:op.field==="time"?{...op,value:"2026年6月30日"}:op)});
 const ready=await new SemanticPlanService(request).resolve(input);expect(ready.status).toBe("ready");
 for(const target of ready.state.targets)await runTool(createSemanticExecuteTool(),{task_ref:ready.state.task_ref,target_ref:target.target_ref},request);
 const next={...f.request("signed-calc","用刚才的正式结果计算丙减甲，不重新查询"),backend:b.client};
 const calc=proposal([{action:"set",field:"objective",value:"甲项"}],{kind:"reference",task_ref:ready.state.task_ref!,target_ref:ready.state.targets[0]!.target_ref},"calculate");
 calc.targets.push({source:{kind:"reference",task_ref:ready.state.task_ref!,target_ref:ready.state.targets[1]!.target_ref},operations:[{action:"set",field:"objective",value:"丙项"}]},
 {source:{kind:"new"},operations:[{action:"set",field:"calculation",value:"`丙项` - `甲项`"}]});
 const permitted=await new SemanticPlanService(next).resolve(calc);expect({status:permitted.status,issues:permitted.issues}).toEqual({status:"ready",issues:[]});
 const target=permitted.state.targets.find(x=>x.kind==="calculation")!;
 const result=await runTool(createSemanticExecuteTool(),{task_ref:permitted.state.task_ref,target_ref:target.target_ref},next);
 expect(result.details.status).toBe("succeeded");expect(b.queries).toHaveLength(2);
 const oldSource={kind:"reference" as const,task_ref:ready.state.task_ref!,target_ref:ready.state.targets[0]!.target_ref};
 const again=await new SemanticPlanService({...f.request("original-ref-reuse","重显合成机构甲的原始结果"),backend:b.client}).resolve(proposal([],oldSource,"reuse"));
 expect(again.status).toBe("reused");expect(b.queries).toHaveLength(2);
},40000);
