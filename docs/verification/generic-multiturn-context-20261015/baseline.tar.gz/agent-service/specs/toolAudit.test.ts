import {expect,it} from "vitest";
import {summarizeToolArguments} from "../src/toolAudit.js";

it("调用审计保留可比较指纹，不记录原文、金额、编码、密钥或任意字段",()=>{
  const args={action:"followup",source:{task_id:"private-task",version:3},question:"private-question",
    api_key:"private-secret",org_codes:["private-org"],metric_value:"private-value",secret_field:"anything"};
  const summary=summarizeToolArguments(args);
  const text=JSON.stringify(summary);
  expect(summary).toMatchObject({action:"followup",org_codes_count:1});
  expect(text).not.toContain("private-");
  expect(text).not.toContain("secret_field");
  expect(summary.arguments_sha256).toEqual(summarizeToolArguments({...args}).arguments_sha256);
  expect(summary.arguments_sha256).not.toEqual(summarizeToolArguments({...args,source:{task_id:"other",version:3}}).arguments_sha256);
  expect(summarizeToolArguments({action:"private-value"})).not.toHaveProperty("action");
});
