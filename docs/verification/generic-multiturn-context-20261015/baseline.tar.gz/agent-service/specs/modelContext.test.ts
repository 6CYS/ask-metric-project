import { expect, it } from "vitest";
import type { AgentMessage } from "@earendil-works/pi-agent-core";
import { projectHistoricalResults } from "../src/modelContext.js";
import { queryReferenceContext } from "../src/queryContext.js";

const user = { role: "user", content: "再问一次", timestamp: 1 } as AgentMessage;
function result(overrides = {}): AgentMessage {
  return {
    role: "toolResult", toolName: "metric_read", toolCallId: "call-1", isError: false, timestamp: 1,
    content: [{ type: "text", text: JSON.stringify({
      status: "succeeded", task_id: "t1", result_id: "r1", version: 3, row_count: 20,
      rows: Array.from({length: 20}, (_, i) => ({ org_name: "测试行", metric_value: `private-value-${i}` })),
      comparisons: [{ value: "private-comparison" }], has_more: true, next_offset: 20,
      query_evidence: { logical_dsl: {time:{start:"2026-03-31",end:"2026-03-31"},orgs:["O"],metrics:["M"]},
        catalog: {metrics:[{code:"M",name:"存款余额",unit:"元"}],organizations:[{code:"O",name:"测试行"}]},
        coverage_notice: "覆盖不完整" }, ...overrides,
    }) }],
  };
}

it("历史发送副本省略行值，原生消息保持完整，条件、告警和分页仍可回读", () => {
  const original = [user, result(), user];
  const before = JSON.stringify(original);
  const projected = projectHistoricalResults(original);
  const serialized = JSON.stringify(projected);
  expect(serialized).not.toContain("private-value");
  expect(serialized).not.toContain("private-comparison");
  expect(serialized).toContain('next_offset');
  expect(serialized).toContain("覆盖不完整");
  expect(queryReferenceContext(projected)).toContain("2026-03-31");
  expect(JSON.stringify(original)).toBe(before);
  expect(serialized.length).toBeLessThan(before.length);
});

it.each([
  {status:"failed"}, {status:"clarification_required"}, {query_evidence:{}}, {result_id:null},
  {query_evidence:{logical_dsl:{time:{start:"2026-03-31"},orgs:["O"],metrics:["M"]}}},
])("失败、澄清或缺少完整正式条件不裁剪 %j", overrides => {
  const message = result(overrides);
  expect(projectHistoricalResults([user,message,user])[1]).toBe(message);
});

it("当前轮与没有用户边界的消息不裁剪", () => {
  const message = result();
  expect(projectHistoricalResults([user,message])[1]).toBe(message);
  expect(projectHistoricalResults([message])[0]).toBe(message);
});

it("零行成功保留正式条件与零行状态", () => {
  const projected=projectHistoricalResults([user,result({rows:[],row_count:0}),user]);
  expect(JSON.stringify(projected)).toContain('row_count\\\":0');
  expect(queryReferenceContext(projected)).toContain('"row_count":0');
});

it("统一 read 的正式历史结果同样裁剪，历史正文分支不冒充结果", () => {
  const original = result();
  const read = {...original, toolName: "read", details: {kind: "metric_read"}} as AgentMessage;
  expect(JSON.stringify(projectHistoricalResults([user, read, user]))).not.toContain("private-value");
  const history = {...read, details: {kind: "session_history_read"}} as AgentMessage;
  expect(projectHistoricalResults([user, history, user])[1]).toBe(history);
});

it("历史解析保留条件和引用、移除旧执行指令，本轮指令与原始记录不变", () => {
  const receipt = {status: "READY", frameId: "old", executionMode: "execute", issues: [],
    next_action: "execute_business_frame", arguments: {frameId: "old"}, message: "立即执行旧引用",
    fields: {metrics: {rawValue: ["合成指标"], resolvedValue: {codes: ["M"]}, resolutionStatus: "resolved"}}};
  const tool = {...result(), toolName: "resolve_business_turn", content: [{type: "text", text: JSON.stringify(receipt)}]} as AgentMessage;
  const original = [user, tool, user, tool];
  const before = JSON.stringify(original);
  const projected = projectHistoricalResults(original);
  const payload = (index: number) => {
    const message = projected[index] as {content: Array<{text: string}>};
    return JSON.parse(message.content[0]!.text);
  };
  expect(payload(1)).toMatchObject({historical: true, frameId: "old", status: "READY", fields: receipt.fields});
  expect(payload(1)).not.toHaveProperty("next_action");
  expect(payload(1)).not.toHaveProperty("arguments");
  expect(payload(1)).not.toHaveProperty("message");
  expect(payload(3)).toMatchObject(receipt);
  expect(JSON.stringify(original)).toBe(before);
});
