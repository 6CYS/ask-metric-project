import {expect,it} from 'vitest';
import {createAssistantMessageEventStream,isRetryableAssistantError,type AssistantMessage,type Model,type ProviderStreams} from '@earendil-works/pi-ai';
import {wrapStreamsWithAuthorization} from '../src/models.js';
const model:Model<'openai-completions'>={id:'test',name:'test',api:'openai-completions',provider:'test',baseUrl:'http://test.invalid',reasoning:false,input:['text'],cost:{input:0,output:0,cacheRead:0,cacheWrite:0},contextWindow:1000,maxTokens:100};
function aborted():ReturnType<ProviderStreams['streamSimple']>{
  const stream=createAssistantMessageEventStream();
  const message:AssistantMessage={role:'assistant',content:[],api:model.api,provider:model.provider,model:model.id,stopReason:'aborted',timestamp:1,
    usage:{input:0,output:0,cacheRead:0,cacheWrite:0,totalTokens:0,cost:{input:0,output:0,cacheRead:0,cacheWrite:0,total:0}}};
  queueMicrotask(()=>{stream.push({type:'error',reason:'aborted',error:message});stream.end(message);});
  return stream;
}
const inner:ProviderStreams={stream:aborted,streamSimple:aborted};
it('provider自行中断转换为流失败，不冒充用户取消或应用计时超时',async()=>{
  const stream=wrapStreamsWithAuthorization(inner,()=>true,100).streamSimple(model,{messages:[]});
  const events=[];for await(const event of stream)events.push(event);
  expect(await stream.result()).toMatchObject({stopReason:'error',errorMessage:expect.stringContaining('MODEL_STREAM_FAILED')});
  expect(events.at(-1)).toMatchObject({type:'error',reason:'error'});
});
it('用户真正取消保留aborted',async()=>{
  const controller=new AbortController();controller.abort();
  const stream=wrapStreamsWithAuthorization(inner,()=>true,100).streamSimple(model,{messages:[]},{signal:controller.signal});
  expect((await stream.result()).stopReason).toBe('aborted');
});

/** 按调用方信号结束的模型桩：delays 为各事件相对开始的毫秒数；未发完即被中断时返回 aborted。 */
function scripted(events: Array<{at: number; text?: string}>, finishAt: number): ProviderStreams['streamSimple'] {
  return (_model, _context, options) => {
    const stream = createAssistantMessageEventStream();
    const message: AssistantMessage = {role:'assistant',content:[],api:model.api,provider:model.provider,model:model.id,stopReason:'stop',timestamp:1,
      usage:{input:0,output:0,cacheRead:0,cacheWrite:0,totalTokens:0,cost:{input:0,output:0,cacheRead:0,cacheWrite:0,total:0}}};
    const timers: ReturnType<typeof setTimeout>[] = [];
    const abort = () => {
      timers.forEach(clearTimeout);
      const aborted = {...message, stopReason: 'aborted' as const};
      stream.push({type:'error',reason:'aborted',error:aborted}); stream.end(aborted);
    };
    options?.signal?.addEventListener('abort', abort, {once: true});
    stream.push({type:'start',partial:message});
    for (const event of events) timers.push(setTimeout(() => stream.push({type:'text_delta',contentIndex:0,delta:event.text ?? '好',partial:message}), event.at));
    timers.push(setTimeout(() => { options?.signal?.removeEventListener('abort', abort); stream.push({type:'done',reason:'stop',message}); stream.end(message); }, finishAt));
    return stream;
  };
}
const wrap = (streamSimple: ProviderStreams['streamSimple'], idle: number, first: number) =>
  wrapStreamsWithAuthorization({stream: streamSimple, streamSimple}, () => true, idle, first).streamSimple(model, {messages: []});

it('首次响应超时：模型迟迟不返回内容时尽早结束，并标记为可自动重试', async () => {
  const result = await wrap(scripted([], 5_000), 5_000, 40).result();
  expect(result).toMatchObject({stopReason: 'error', errorMessage: expect.stringContaining('MODEL_FIRST_RESPONSE_TIMEOUT')});
  expect(isRetryableAssistantError(result)).toBe(true);
});
it('已开始返回内容后不受首次响应时限影响，长回答正常完成', async () => {
  const result = await wrap(scripted([{at: 10}, {at: 60}], 120), 5_000, 40).result();
  expect(result.stopReason).toBe('stop');
});
it('已开始返回后停止输出超过空闲时限：不自动重放已有输出的请求', async () => {
  const result = await wrap(scripted([{at: 10}], 5_000), 80, 40).result();
  expect(result).toMatchObject({stopReason: 'error', errorMessage: expect.stringContaining('MODEL_STREAM_IDLE_EXCEEDED')});
  expect(isRetryableAssistantError(result)).toBe(false);
});
