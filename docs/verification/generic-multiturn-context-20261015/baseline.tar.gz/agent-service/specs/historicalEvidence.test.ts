import { expect, it } from "vitest";
import type { AgentMessage } from "@earendil-works/pi-agent-core";
import { projectHistoricalResults } from "../src/modelContext.js";

const user = {role: "user", content: "3月份呢？", timestamp: 1} as AgentMessage;
function result(extra: Record<string, unknown>): AgentMessage {
  return {role: "toolResult", toolName: "metric_read", toolCallId: "call", isError: false, timestamp: 1,
    content: [{type: "text", text: JSON.stringify({status: "succeeded", task_id: "task", result_id: "result",
      rows: [{metric_value: "987654.321"}],
      query_evidence: {logical_dsl: {metrics: ["M"], orgs: ["O"], time: {start: "2026-03-31", end: "2026-03-31"}}},
      ...extra})}]};
}

it("历史正文、工具格式化答案与事实金额一起省略，当前答案及原记录不变", () => {
  const assistant = {role: "assistant", content: [{type: "text", text: "旧金额987654.321元。"}]} as AgentMessage;
  const receipt = result({message: "旧金额987654.321元。", facts: [{value: "987654.321"}],
    answer_blocks: [{text: "987654.321"}]});
  const original = [user, receipt, assistant, user, assistant];
  const projected = projectHistoricalResults(original);
  expect(JSON.stringify(projected.slice(0, 4))).not.toContain("987654.321");
  expect(projected[4]).toBe(assistant);
  expect(JSON.stringify(original)).toContain("987654.321");
});
