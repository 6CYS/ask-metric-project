import { expect, it } from "vitest";
import { modelUsage } from "../src/modelUsage.js";
const usage={input:100,output:20,cacheRead:30,cacheWrite:10,totalTokens:160,cost:{input:0,output:0,cacheRead:0,cacheWrite:0,total:0}};
it("合并 pi 非缓存输入与缓存输入，不将未配置单价的零费用当账单",()=>{
  expect(modelUsage(usage)).toMatchObject({usage_known:true,input_tokens:140,output_tokens:20,total_tokens:160});
  expect(modelUsage(usage)).not.toHaveProperty("cost");
});
it("pi 默认全零和非法计数是未知用量",()=>{
  expect(modelUsage({...usage,input:0,output:0,cacheRead:0,cacheWrite:0,totalTokens:0})).toMatchObject({usage_known:false,total_tokens:null});
  expect(modelUsage({...usage,input:NaN})).toMatchObject({usage_known:false,input_tokens:null});
});
