import {Type} from "@earendil-works/pi-ai";
import {Compile} from "typebox/compile";
export type SemanticField = "organizations" | "comparison_organizations" | "metrics" | "time" | "selection" | "operation" | "objective" | "calculation" | "availability";
export type SemanticOperation = {action: "set" | "add" | "confirm"; field: SemanticField; value: string}
  | {action: "replace"; field: SemanticField; subject: string; value: string}
  | {action: "exclude"; field: SemanticField; subject: string} | {action: "clear"; field: SemanticField};
export type SemanticSource = {kind: "new" | "current"} | {kind: "reference"; task_ref: string; target_ref: string};
export interface SemanticRequest {protocol_version: 2; intent: "query" | "prepare" | "reuse" | "analyze" | "availability" | "calculate";
  targets: Array<{source: SemanticSource; operations: SemanticOperation[]}>}
// 与已评审的版本2契约一致；部署不依赖仓库docs目录。
export const semanticParameters = Type.Unsafe<SemanticRequest>({
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "urn:ask-metric:pi-semantic-task:request:v2",
  "title": "Pi 语义业务提案请求候选协议",
  "description": "版本2语义提议协议，按会话显式启用。工具名为 resolve_business_turn。Schema 仅校验提案形状；原文、身份、版本、目录、权限、语义与执行许可由宿主绑定及核验；当前实际能力以工具说明和回执为准。",
  "type": "object",
  "additionalProperties": false,
  "required": ["protocol_version", "intent", "targets"],
  "properties": {
    "protocol_version": {"type": "integer", "const": 2},
    "intent": {
      "type": "string",
      "enum": ["query", "analyze", "availability", "calculate", "reuse", "prepare"],
      "description": "本次业务意图。prepare 只整理并保存条件；reuse 只重显已有结果。其它意图也须完成语义、目录与权限校验，不能仅凭意图执行。"
    },
    "targets": {
      "type": "array",
      "minItems": 1,
      "maxItems": 100,
      "items": {"$ref": "#/definitions/target"},
      "description": "分别绑定机构、时间、指标和操作的目标组。数组位置只是传输顺序，不是跨轮目标身份。"
    }
  },
  "definitions": {
    "businessText": {
      "type": "string",
      "minLength": 1,
      "maxLength": 4000,
      "description": "自然语言业务表达。允许忠实概括，不要求复制原文或填写内部编码。宿主仍须核验其本轮依据、可信继承或获授权的分析来源。"
    },
    "field": {
      "type": "string",
      "enum": ["organizations", "comparison_organizations", "metrics", "time", "selection", "operation", "objective", "calculation", "availability"],
      "description": "业务概念槽位，不能解释为已实现的后端字段或能力承诺。"
    },
    "source": {
      "oneOf": [
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["kind"],
          "properties": {"kind": {"const": "new"}}
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["kind"],
          "properties": {"kind": {"const": "current"}}
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["kind", "task_ref", "target_ref"],
          "properties": {
            "kind": {"const": "reference"},
            "task_ref": {
              "type": "string", "minLength": 1, "maxLength": 512,
              "description": "只复制宿主在上下文工具或回执中签发的同会话任务引用，不构造、不改写、不把自然语言指代填入此处。"
            },
            "target_ref": {
              "type": "string", "minLength": 1, "maxLength": 512,
              "description": "只复制宿主签发且属于 task_ref 的目标引用；有效性与最新状态由宿主复核。"
            }
          }
        }
      ]
    },
    "operation": {
      "oneOf": [
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["action", "field", "value"],
          "properties": {
            "action": {"const": "set"},
            "field": {"$ref": "#/definitions/field"},
            "value": {"$ref": "#/definitions/businessText"}
          }
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["action", "field", "subject", "value"],
          "properties": {
            "action": {"const": "replace"},
            "field": {"$ref": "#/definitions/field"},
            "subject": {"$ref": "#/definitions/businessText"},
            "value": {"$ref": "#/definitions/businessText"}
          }
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["action", "field", "value"],
          "properties": {
            "action": {"const": "add"},
            "field": {"$ref": "#/definitions/field"},
            "value": {"$ref": "#/definitions/businessText"}
          }
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["action", "field", "subject"],
          "properties": {
            "action": {"const": "exclude"},
            "field": {"$ref": "#/definitions/field"},
            "subject": {"$ref": "#/definitions/businessText"}
          }
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["action", "field"],
          "properties": {
            "action": {"const": "clear"},
            "field": {"$ref": "#/definitions/field"}
          }
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": ["action", "field", "value"],
          "properties": {
            "action": {"const": "confirm"},
            "field": {"$ref": "#/definitions/field"},
            "value": {"$ref": "#/definitions/businessText"}
          }
        }
      ]
    },
    "target": {
      "type": "object",
      "additionalProperties": false,
      "required": ["source", "operations"],
      "properties": {
        "source": {"$ref": "#/definitions/source"},
        "operations": {
          "type": "array",
          "minItems": 0,
          "maxItems": 100,
          "items": {"$ref": "#/definitions/operation"},
          "description": "首轮和修改均用相同动作形状。空数组仅表示不修改已选目标；新建空目标不能直接执行。同字段冲突动作及意图不符由宿主语义校验处理。"
        }
      }
    }
  }
});
const validator = Compile(semanticParameters);
/** 必须先校验原始参数；SDK的类型转换不能使错误协议版本通过。 */
export function prepareSemanticArguments(raw: unknown): SemanticRequest {
  if (!validator.Check(raw)) throw new Error("SEMANTIC_INPUT_SHAPE_INVALID: 请使用版本2工具Schema，保留原用户目标后修正参数形状。");
  return structuredClone(raw) as SemanticRequest;
}
