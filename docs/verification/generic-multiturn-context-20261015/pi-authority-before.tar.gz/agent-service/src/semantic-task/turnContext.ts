import type {AskMetricRequestContext} from "../requestContext.js";
import {hasInputEvidence} from "../business-context/inputEvidence.js";
import type {SemanticOperation, SemanticRequest} from "./protocol.js";
import type {SemanticTask, SemanticTurn} from "./store.js";

type Goal = Awaited<ReturnType<AskMetricRequestContext["backend"]["inspectBusinessGoal"]>>;
export const resetsContext = (message: string) => /重新开始|换(?:个|一个)(?:话题|问题)|新(?:的)?话题|独立(?:的)?(?:问题|查询)|(?:不|别|无需|不要)(?:再)?(?:沿用|继承)(?:(?:之前|原来|当前|已选)?(?:的)?(?:条件|上下文|历史)|[，,。；;！!？?\s]*$)|清空(?:全部)?(?:条件|上下文)/u.test(message);

function supplied(goal: Goal, field: string) {
  return goal.fragments.some(fragment => field === "organizations" ? fragment.organizations.length > 0
    : field === "metrics" ? fragment.mentions.length > 0
    : field === "time" ? fragment.calendar.ranges.length > 0 || fragment.calendar.unresolved.length > 0 : false);
}

/** Pi决定业务变化；宿主只在唯一来源和本轮事实均明确时绑定省略条件，不从名称猜指标身份。 */
export function bindQueryContinuation(input: SemanticRequest, goal: Goal, turn: SemanticTurn,
  reject: (code: string, message: string, category?: string) => never, boundPlanRef?: string) {
  if (!["query", "prepare"].includes(input.intent)) return;
  if (resetsContext(turn.originalMessage)) {
    if (input.targets.some(target => target.source.kind !== "new" && (!boundPlanRef
      || target.source.kind === "reference" && target.source.task_ref !== boundPlanRef))) reject("CONTEXT_RESET_REQUIRES_NEW",
      "本轮明确不沿用上下文，请使用new并仅提交本轮条件；不能用current/reference回填已清除的条件。");
    return;
  }
  if (input.intent !== "query" || supplied(goal, "metrics") || input.targets.length !== 1) return;
  const target = input.targets[0]!;
  if (target.source.kind !== "new" || target.operations.some(op => ["calculation", "availability"].includes(op.field))) return;
  const explicitMetric = target.operations.some(op => op.field === "metrics" && "value" in op && hasInputEvidence(turn.originalMessage, op.value));
  if (explicitMetric || !["organizations", "time"].some(name => supplied(goal, name))) return;
  const steps = turn.context?.plan?.steps ?? [];
  const sources = turn.context?.tasks ?? [];
  if (!sources.length) return;
  if (steps.length > 1 || sources.length > 1) reject("TARGET_REFERENCE_REQUIRED",
    "本轮只给出了条件变化，但历史包含多个绑定目标。请读取上下文并用签发的reference选择要修改的目标，不能任取指标或把条件交叉组合。", "reference");
  if (steps.length === 1 && steps[0]!.kind !== "query") return;
  target.source = {kind: "current"};
}

/** 无本轮依据的模型复述不能把已确认身份退回目录歧义；真实新值、集合变化、确认和清除交由原解析器处理。 */
export function preserveConfirmedIdentities(operations: SemanticOperation[], base: SemanticTask | undefined,
  goal: Goal, originalMessage: string): SemanticOperation[] {
  if (!base) return operations;
  return operations.filter(op => op.action !== "set" || !["organizations", "metrics", "time"].includes(op.field)
    || base.target.fields[op.field]?.resolutionStatus !== "resolved"
    || supplied(goal, op.field) || hasInputEvidence(originalMessage, op.value));
}
