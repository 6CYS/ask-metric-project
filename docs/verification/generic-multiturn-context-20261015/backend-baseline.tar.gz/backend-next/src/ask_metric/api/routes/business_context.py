"""业务字段事实接口：复用启用目录与权限，禁止调用自然语言模型或执行指标 SQL。"""

from datetime import date, datetime
from typing import Annotated, Literal
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, StringConstraints

from ask_metric.api.dependencies import require_actor
from ask_metric.api.routes.catalogs import get_overview_permissions, get_overview_settings, get_uow
from ask_metric.application.field_resolution import resolve_catalog_field, resolve_date_field, source_calendar_constraints, source_organization_codes
from ask_metric.application.metric_candidates import metric_candidate_index
from ask_metric.application.goal_facts import inspect_goal
from ask_metric.application.analysis_selection import issue_selection, verify_selection
from ask_metric.application.organization_query_scope import resolve_query_scope
from ask_metric.application.ports import PermissionDeniedError, ScopedOrganizationPermissionService
from ask_metric.application.requests import ActorContext
from ask_metric.core.config import Settings
from ask_metric.core.errors import ApplicationError
from ask_metric.domain.organization_scope import (
    AuthorizedCohortScope,
    ChildrenOfScope,
    OrganizationScopeError,
    is_authorized_cohort_source,
)
from ask_metric.domain.basic_query import BasicQuerySpec
from ask_metric.infrastructure.db.org_hierarchy import SqlAlchemyOrgHierarchyProvider
from ask_metric.infrastructure.db.unit_of_work import SqlAlchemyUnitOfWork

router = APIRouter(prefix="/api/v1/business-context", tags=["business-context"])
# 与语义提议的businessText边界一致，完整多指标表达不能被单名称的旧长度限制截断。
RawName = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=4000)]


class ResolveFieldRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    entity: Literal["metric", "organization", "date"]
    raw_values: list[RawName] = Field(min_length=1, max_length=100)
    reference_year: int | None = Field(default=None, ge=1, le=9999)
    business_date: date | None = None
    source_question: str | None = Field(default=None, min_length=1, max_length=8000)


class MetricMentionsRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    question: str = Field(min_length=1, max_length=8000)


class InspectGoalRequest(MetricMentionsRequest):
    business_date: date
    reference_year: int | None = Field(default=None, ge=1, le=9999)


class PlanAdmissionStep(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target_ref: str = Field(min_length=1, max_length=128)
    fragment: int = Field(ge=0, le=99)
    origin: Literal["user_explicit", "history", "analysis_selected"]
    spec: BasicQuerySpec
    source_question: str | None = Field(default=None, min_length=1, max_length=8000)
    source_semantic_receipt: str | None = Field(default=None, min_length=1, max_length=16000, repr=False)
    bindings: list[dict] = Field(default_factory=list, max_length=100)
    exclusions: list[dict] = Field(default_factory=list, max_length=100)


class PlanAdmissionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    conversation_id: str = Field(min_length=1, max_length=128)
    session_id: str = Field(min_length=1, max_length=128)
    goal: str = Field(min_length=1, max_length=8000)
    business_date: date
    analysis: bool = False
    reference_year: int | None = Field(default=None, ge=1, le=9999)
    steps: list[PlanAdmissionStep] = Field(min_length=1, max_length=100)
    fragment_bindings: dict[str, list[dict]] = Field(default_factory=dict)


@router.post("/admit-plan")
def admit_semantic_plan(
    payload: PlanAdmissionRequest,
    actor: Annotated[ActorContext, Depends(require_actor)],
    uow: Annotated[SqlAlchemyUnitOfWork, Depends(get_uow)],
    permissions: Annotated[ScopedOrganizationPermissionService, Depends(get_overview_permissions)],
    settings: Annotated[Settings, Depends(get_overview_settings)],
) -> dict:
    from ask_metric.api.routes.tasks import _verify_metric_coverage, SourceMetricBinding, SourceMetricSpan
    with uow:
        if uow.conversations.get_owned(payload.conversation_id, actor.user_id) is None:
            raise HTTPException(status_code=404, detail="任务会话不可读取")
        catalog = uow.metric_catalog.list_enabled()
        organizations = uow.organization_catalog.list_enabled()
        allowed = permissions.authorized_org_codes(actor=actor, available_org_codes={item.code for item in organizations})
    facts = inspect_goal(payload.goal, payload.business_date, catalog, [item for item in organizations if item.code in allowed], reference_year=payload.reference_year)
    # 重规划保留的旧草案不能与新来源重复取同一份事实；操作或比较总体不同的查询独立核验。
    for number, step in enumerate(payload.steps):
        for previous in payload.steps[:number]:
            same_operation = step.spec.operation == previous.spec.operation and step.spec.selection == previous.spec.selection and step.spec.comparison_scope == previous.spec.comparison_scope
            if same_operation and step.spec.time == previous.spec.time and set(step.spec.org_codes) & set(previous.spec.org_codes) and set(step.spec.metric_codes) & set(previous.spec.metric_codes):
                raise ApplicationError("PLAN_SOURCE_OVERLAP", "提案含重叠的查询来源。未执行草案请用完整new提案重组为不重叠的来源；已有正式结果请引用复用。", status_code=409)
    for step in payload.steps:
        if step.spec.organization_scope or not set(step.spec.org_codes) <= allowed or (step.spec.comparison_scope and (step.spec.comparison_scope.organization_scope or not set(step.spec.comparison_scope.org_codes) <= allowed)):
            raise HTTPException(status_code=403, detail="任务范围不可签发")
        if step.origin == "analysis_selected" and not payload.analysis:
            raise ApplicationError("ANALYSIS_NOT_AUTHORIZED", "普通查询不能使用分析选指标来源。", status_code=409)
        if step.origin == "history":
            if step.source_semantic_receipt:
                # 历史来源复用已签发身份与范围，但当前权限、目录和会话归属仍重新核验。
                verify_selection(step.source_semantic_receipt, owner=actor.user_id, conversation=payload.conversation_id,
                    codes=step.spec.metric_codes, scope=step.spec.model_dump(mode="json", exclude_none=True), catalog=catalog, secret=settings.jwt_secret)
            elif not step.source_question:
                raise ApplicationError("HISTORY_SOURCE_MISSING", "历史条件需要保留原始绑定依据。", status_code=409)
            else:
                _verify_metric_coverage(step.source_question, step.spec.metric_codes, catalog,
                    [SourceMetricBinding.model_validate(item) for item in step.bindings],
                    [SourceMetricSpan.model_validate(item) for item in step.exclusions])
    # 每个显式片段独立对账，禁止把甲行六月/乙行七月改成机构、日期和指标的交叉组合。
    for number, fragment in enumerate(facts["fragments"]):
        steps = [step for step in payload.steps if step.fragment == number]
        if not steps:
            if payload.analysis:
                continue
            raise ApplicationError("PLAN_TARGETS_INCOMPLETE", "原始问题还有目标没有进入任务。", status_code=409)
        for step in steps:
            if fragment["organizations"] and not set(step.spec.org_codes) <= set(fragment["organizations"]):
                raise ApplicationError("PLAN_TARGET_BINDING_CONFLICT", "机构与指标日期的原始绑定不符。", status_code=409)
            # 榜单是整个比较总体上的操作；各机构分别取前N再求并集不能替代原榜单。
            if step.spec.operation.kind == "ranking" and fragment["organizations"] and set(step.spec.org_codes) != set(fragment["organizations"]):
                raise ApplicationError("PLAN_RANKING_SCOPE_INCOMPLETE", "同一榜单的完整比较机构须进入同一查询目标，请合并机构后重提。", status_code=409)
            ranges = fragment["calendar"]["ranges"]
            if ranges and not any(step.spec.time.start.isoformat() >= value["start"] and step.spec.time.end.isoformat() <= value["end"] for value in ranges):
                raise ApplicationError("PLAN_TARGET_BINDING_CONFLICT", "目标日期不属于对应原始片段。", status_code=409)
        requested = list(dict.fromkeys(code for step in steps for code in step.spec.metric_codes))
        bindings = [SourceMetricBinding.model_validate(item) for item in payload.fragment_bindings.get(str(number), [])]
        explicit = [item for item in fragment["mentions"] if item["resolution"]["status"] == "resolved"]
        required = {code for item in explicit for code in item["resolution"]["value"]["codes"]}
        if (payload.analysis or all(step.origin == "history" for step in steps)) and not fragment["mentions"]:
            required = set(requested)
        else:
            # 分析可以增加目录指标，但明确提及和已确认的指标仍须逐片段完整绑定。
            from ask_metric.api.routes.tasks import _verify_metric_bindings
            required = _verify_metric_bindings(fragment["question"], fragment["mentions"], bindings, [], metric_candidate_index(catalog))
            if not payload.analysis and (not required <= set(requested) or any(step.origin != "history" for step in steps) and required != set(requested)):
                raise ApplicationError("PLAN_TARGETS_INCOMPLETE", "普通查询须整批覆盖原始指标；若是分析中的支持步骤，应使用analyze保留完整目标并分阶段取证。", status_code=409)
        orgs = fragment["organizations"]
        calendars = fragment["calendar"]["ranges"]
        # 独立核验每个显式机构、指标、日期组合；仅核对集合并集会漏掉半份目标。
        for code in required & set(requested) if payload.analysis else required:
            # 继承目标未在本轮重复机构名称时，沿用各指标自己的机构绑定，不能生成跨目标笛卡尔积。
            bound_orgs = orgs or list(dict.fromkeys(org for step in steps if code in step.spec.metric_codes for org in step.spec.org_codes))
            for org in bound_orgs:
                covering = [step for step in steps if code in step.spec.metric_codes and
                    (org in step.spec.org_codes or step.spec.comparison_scope and org in step.spec.comparison_scope.org_codes)]
                if not covering:
                    raise ApplicationError("PLAN_TARGETS_INCOMPLETE", "原始机构与指标组合没有完整进入任务。", status_code=409)
                for calendar in calendars:
                    expected_dates = calendar.get("dates")
                    if expected_dates:
                        actual = {value for step in covering for value in
                            (step.spec.time.dates or ([step.spec.time.start] if step.spec.time.start == step.spec.time.end else []))}
                        complete = set(expected_dates) <= {value.isoformat() for value in actual}
                    else:
                        complete = any(step.spec.time.start.isoformat() == calendar["start"] and
                            step.spec.time.end.isoformat() == calendar["end"] and not step.spec.time.dates for step in covering)
                    if not complete:
                        raise ApplicationError("PLAN_TARGETS_INCOMPLETE", "原始机构、指标和日期的组合未完整覆盖。", status_code=409)
    receipts = []
    for step in payload.steps:
        scope = step.spec.model_dump(mode="json", exclude_none=True)
        receipts.append({"target_ref": step.target_ref, "receipt": issue_selection(owner=actor.user_id, conversation=payload.conversation_id,
            session=payload.session_id, goal=payload.goal, codes=step.spec.metric_codes, scope=scope, catalog=catalog, secret=settings.jwt_secret)})
    return {"status": "admitted", "receipts": receipts}


@router.post("/inspect-goal")
def inspect_business_goal(
    payload: InspectGoalRequest,
    actor: Annotated[ActorContext, Depends(require_actor)],
    uow: Annotated[SqlAlchemyUnitOfWork, Depends(get_uow)],
    permissions: Annotated[ScopedOrganizationPermissionService, Depends(get_overview_permissions)],
) -> dict:
    with uow:
        metrics = uow.metric_catalog.list_enabled()
        organizations = uow.organization_catalog.list_enabled()
        allowed = permissions.authorized_org_codes(actor=actor, available_org_codes={item.code for item in organizations})
    return inspect_goal(payload.question, payload.business_date, metrics, [item for item in organizations if item.code in allowed], reference_year=payload.reference_year)


class ResolveCohortRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["authorized_cohort"]
    cohort: Literal["rural_commercial_banks"]
    source_text: RawName


class ResolveChildrenRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["children_of"]
    parent_name: RawName
    source_text: RawName


ResolveScopeRequest = Annotated[
    ResolveCohortRequest | ResolveChildrenRequest, Field(discriminator="kind")
]


def get_scope_hierarchy(
    settings: Annotated[Settings, Depends(get_overview_settings)],
) -> SqlAlchemyOrgHierarchyProvider:
    return SqlAlchemyOrgHierarchyProvider(
        root_level=settings.sit_org_head_office_hier_code,
        cohort_level=settings.sit_org_legal_entity_hier_code,
    )


@router.post("/resolve-scope")
def resolve_scope(
    payload: ResolveScopeRequest,
    actor: Annotated[ActorContext, Depends(require_actor)],
    uow: Annotated[SqlAlchemyUnitOfWork, Depends(get_uow)],
    permissions: Annotated[ScopedOrganizationPermissionService, Depends(get_overview_permissions)],
    hierarchy: Annotated[SqlAlchemyOrgHierarchyProvider, Depends(get_scope_hierarchy)],
) -> dict:
    """机构集合意图由 Agent 绑定原文，服务端独立解析正式目录和当前账号权限。"""
    if payload.kind == "authorized_cohort" and not is_authorized_cohort_source(
        payload.cohort, payload.source_text,
    ):
        raise ApplicationError(
            "SCOPE_SOURCE_INVALID",
            "原文未明确表达机构集合，不能将具体机构或未知名称扩大为全部可见农商行",
            status_code=422,
        )
    with uow:
        organizations = uow.organization_catalog.list_enabled()
    try:
        if payload.kind == "authorized_cohort":
            scope = AuthorizedCohortScope(kind=payload.kind, cohort=payload.cohort)
        else:
            snapshot = hierarchy.strict_snapshot()
            allowed = permissions.authorized_org_codes(
                actor=actor, available_org_codes={node.code for node in snapshot.nodes},
                hierarchy_snapshot=snapshot,
            )
            parent = resolve_catalog_field(
                "organization", [payload.parent_name],
                [item for item in organizations if item.code in allowed],
            )
            if parent["status"] != "resolved":
                return parent
            scope = ChildrenOfScope(kind=payload.kind, parent_code=parent["value"]["codes"][0])
        return {"status": "resolved", "value": resolve_query_scope(
            scope=scope, actor=actor, organizations=organizations,
            permissions=permissions, hierarchy=hierarchy,
        )}
    except PermissionDeniedError as error:
        raise OrganizationScopeError("PERMISSION_DENIED", "无法确认当前账号的机构权限") from error


@router.post("/metric-mentions")
def metric_mentions(
    payload: MetricMentionsRequest,
    actor: Annotated[ActorContext, Depends(require_actor)],
    uow: Annotated[SqlAlchemyUnitOfWork, Depends(get_uow)],
) -> dict:
    """对完整原文匹配启用目录，不调用模型、不执行指标 SQL。取数权限仍在执行层校验。"""
    with uow:
        items = uow.metric_catalog.list_enabled()
    return {"mentions": metric_candidate_index(items).mentions(payload.question)}


@router.post("/resolve-field")
def resolve_field(
    payload: ResolveFieldRequest,
    actor: Annotated[ActorContext, Depends(require_actor)],
    uow: Annotated[SqlAlchemyUnitOfWork, Depends(get_uow)],
    permissions: Annotated[ScopedOrganizationPermissionService, Depends(get_overview_permissions)],
) -> dict:
    if payload.entity == "date":
        if len(payload.raw_values) != 1:
            return {"status": "invalid"}
        today = payload.business_date or datetime.now(ZoneInfo("Asia/Shanghai")).date()
        result = resolve_date_field(
            payload.raw_values[0], today, reference_year=payload.reference_year
        )
        if payload.source_question:
            result["metadata"] = {**result.get("metadata", {}),
                                  "source_calendar": source_calendar_constraints(payload.source_question, today, reference_year=payload.reference_year)}
        return result
    with uow:
        if payload.entity == "metric":
            items = uow.metric_catalog.list_enabled()
        else:
            items = uow.organization_catalog.list_enabled()
            if items:
                try:
                    authorized = permissions.authorize_logical_dsl(actor=actor, logical_dsl={
                        "orgs": [item.code for item in items],
                        "options": {"organization_scope": "synchronized_catalog"},
                    })
                except PermissionDeniedError as error:
                    raise HTTPException(status_code=403, detail="无权解析机构范围") from error
                allowed = set(authorized.get("orgs", []))
                items = [item for item in items if item.code in allowed]
        result = resolve_catalog_field(payload.entity, payload.raw_values, items)
        if payload.entity == "organization" and payload.source_question:
            result["metadata"] = {**result.get("metadata", {}),
                                  "source_codes": source_organization_codes(payload.source_question, items)}
        return result
