/** 只读整理已经产生的模型调用证据，不调用模型、不改写原始报告与 JSONL。 */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir, readFile, readdir, writeFile} from 'node:fs/promises';
import {dirname, join, resolve} from 'node:path';
import {loadConfig} from '../src/config.js';

const argument = (name: string) => process.argv.find(value => value.startsWith(`--${name}=`))?.slice(name.length + 3);
const paths = argument('reports')?.split(','), output = argument('output');
assert.ok(paths?.length && output, '--reports=file1,file2 --output=path required');
const key = loadConfig().model.apiKey;
const hash = (value: Buffer) => createHash('sha256').update(value).digest('hex');
const summaries: any[] = [];
for (const reportPath of paths!) {
  const reportBytes = await readFile(reportPath), report = JSON.parse(reportBytes.toString()), native: any[] = [];
  const visit = async (directory: string): Promise<void> => {
    for (const entry of await readdir(directory, {withFileTypes: true})) {
      const path = join(directory, entry.name);
      if (entry.isDirectory()) {await visit(path); continue;}
      if (!entry.name.endsWith('.jsonl')) continue;
      const bytes = await readFile(path); assert.ok(!bytes.includes(Buffer.from(key)), 'NATIVE_ARCHIVE_HAS_SECRET');
      const records = bytes.toString().split('\n').filter(Boolean).flatMap(line => {const item = JSON.parse(line); return Array.isArray(item) ? item : [item];});
      const messages = records.filter(record => record.kind === 'entry' && record.type === 'message').map(record => record.message);
      const errors = messages.filter(message => message.role === 'assistant' && message.errorMessage).map(message => message.errorMessage);
      const generations = messages.filter(message => message.role === 'assistant' && !message.errorMessage && (message.usage?.input > 0 || message.usage?.output > 0));
      const target = resolve(`${reportPath.replace(/\.json$/, '')}-native`, entry.name);
      await mkdir(dirname(target), {recursive: true}); await writeFile(target, bytes);
      native.push({path: target, sha256: hash(bytes), error_messages: [...new Set(errors)], failed_model_attempts: errors.length,
        successful_model_generations: generations.length, usage: generations.map(message => message.usage)});
    }
  };
  await visit(report.session_data);
  const errors = [...new Set(native.flatMap(item => item.error_messages))];
  summaries.push({report_path: resolve(reportPath), original_report_sha256: hash(reportBytes), phase: report.phase,
    model_signature: report.model_signature, summary: report.summary, error_messages: errors,
    interpretation: errors.length && native.every(item => item.successful_model_generations === 0)
      ? 'Infrastructure failure before model generation; not a business regression result.'
      : 'Model generation occurred; retain per-turn business assertions and all observed failures.', native});
}
await mkdir(dirname(resolve(output!)), {recursive: true});
await writeFile(`${output}.json`, JSON.stringify({created_at: new Date().toISOString(), model_called_by_this_script: false,
  original_records_modified: false, evidence: summaries,
  approval_rejection: {action: 'fixed-baseline 13 turns x 3 repetitions', classification: 'automatic_approval_rejected',
    reason: 'Internal system prompt, tool contracts and business rules would be sent to a model endpoint not explicitly trusted by the approval reviewer.',
    configured_destination: 'https://api.siliconflow.cn', configured_model: 'deepseek-ai/DeepSeek-V4-Flash',
    bypass_attempted: false, subsequent_model_calls: false}}, null, 2));
console.log(JSON.stringify({output: `${output}.json`, reports: summaries.map(summary => ({path: summary.report_path, errors: summary.error_messages, summary: summary.summary}))}));
