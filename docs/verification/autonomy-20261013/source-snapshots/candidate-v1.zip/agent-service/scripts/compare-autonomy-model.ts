/** 只比较匹配的固定样本；基础设施失败单列，不能冒充业务退化或改进。 */
import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const option = (name: string) => process.argv.find(value => value.startsWith(`--${name}=`))?.slice(name.length + 3);
const baselinePaths = option('baseline')?.split(','), candidatePaths = option('candidate')?.split(','), output = option('output');
assert.ok(baselinePaths?.length && candidatePaths?.length && output, '--baseline=reports --candidate=reports --output=path required');
const load = async (paths: string[]) => Promise.all(paths.map(async path => ({path: resolve(path), ...JSON.parse(await readFile(path, 'utf8'))})));
const baseline = await load(baselinePaths!), candidate = await load(candidatePaths!);
const all = [...baseline, ...candidate];
for (const report of all.slice(1)) {
  assert.equal(report.dataset_sha256, all[0].dataset_sha256, 'SAME_DATASET');
  assert.equal(report.workbook_sha256, all[0].workbook_sha256, 'SAME_WORKBOOK');
  assert.equal(report.script_sha256, all[0].script_sha256, 'SAME_EVALUATION_SCRIPT');
  assert.deepEqual(report.model_signature, all[0].model_signature, 'SAME_MODEL_PARAMETERS');
  assert.equal(report.provider_budget?.limit, all[0].provider_budget?.limit, 'SAME_PROVIDER_CALL_LIMIT');
}
for (const report of all) {
  assert.equal(report.source_changed_during_run, false, 'IMMUTABLE_SOURCE_DURING_RUN');
  for (const turn of report.turns) assert.ok(turn.passed || ['infrastructure', 'business_or_runtime', 'budget_error'].includes(turn.failure_class), 'FAILURE_CLASSIFICATION_REQUIRED');
}
const key = (turn: any) => `${turn.repeat}:${turn.scenario}:${turn.turn}`;
const before = new Map(baseline.flatMap(report => report.turns.map((turn: any) => [key(turn), turn])));
const after = new Map(candidate.flatMap(report => report.turns.map((turn: any) => [key(turn), turn])));
assert.equal(before.size, baseline.reduce((n, report) => n + report.turns.length, 0), 'DUPLICATE_BASELINE_SAMPLE');
assert.equal(after.size, candidate.reduce((n, report) => n + report.turns.length, 0), 'DUPLICATE_CANDIDATE_SAMPLE');
const paired = [...new Set([...before.keys(), ...after.keys()])].map(id => {
  const old: any = before.get(id), next: any = after.get(id);
  const classification = !old || !next ? 'unpaired' : old.failure_class === 'budget_error' || next.failure_class === 'budget_error' ? 'budget_incomparable'
    : old.failure_class === 'infrastructure' || next.failure_class === 'infrastructure'
    ? 'infrastructure_incomparable' : old.passed ? next.passed ? 'shared_pass' : 'candidate_only_failure' : next.passed ? 'baseline_only_failure' : 'shared_failure';
  const oldPrompt = old?.model_usage?.first_request_prompt_tokens, newPrompt = next?.model_usage?.first_request_prompt_tokens;
  const promptReduction = typeof oldPrompt === 'number' && oldPrompt > 0 && typeof newPrompt === 'number' ? (oldPrompt - newPrompt) / oldPrompt : null;
  return {id, category: old?.category ?? next?.category, classification, first_request_prompt_token_reduction: promptReduction,
    baseline: old ? {passed: old.passed, failure: old.failure, model_errors: old.model_errors, measures: old.measures, model_usage: old.model_usage} : null,
    candidate: next ? {passed: next.passed, failure: next.failure, model_errors: next.model_errors, measures: next.measures, model_usage: next.model_usage} : null};
});
const counts = Object.fromEntries(['shared_pass', 'candidate_only_failure', 'baseline_only_failure', 'shared_failure', 'infrastructure_incomparable', 'budget_incomparable', 'unpaired']
  .map(name => [name, paired.filter(item => item.classification === name).length]));
const result = {created_at: new Date().toISOString(), environment: 'real_model_api_synthetic_backend', real_database_verified: false,
  dataset_sha256: all[0].dataset_sha256, model_signature: all[0].model_signature,
  reports: {baseline: baseline.map(report => report.path), candidate: candidate.map(report => report.path)},
  suite_completed: all.every(report => report.summary.turns === report.summary.planned_turns && !report.provider_budget?.exhausted),
  prompt_token_measurement: ['precise', 'context', 'analysis', 'all'].map(category => {
    const eligible = paired.filter(item => item.first_request_prompt_token_reduction !== null && (category === 'all' || item.category === category));
    const old = eligible.reduce((count, item) => count + item.baseline!.model_usage.first_request_prompt_tokens, 0);
    const next = eligible.reduce((count, item) => count + item.candidate!.model_usage.first_request_prompt_tokens, 0);
    return {category, measured_pairs: eligible.length, baseline_prompt_tokens: eligible.length ? old : null,
      candidate_prompt_tokens: eligible.length ? next : null, weighted_reduction: old > 0 ? (old - next) / old : null,
      reaches_40_percent: old > 0 ? (old - next) / old >= 0.4 : null};
  }), counts, paired};
await writeFile(`${output}.json`, JSON.stringify(result, null, 2));
await writeFile(`${output}.md`, `# 自主分析基线对照\n\n真实模型 API＋隔离合成业务数据；未验证真实湖值。相同模型参数、provider硬预算和数据集。基础设施/预算失败单列，不据此判断功能退化或能力改善。全部计划样本完成：${result.suite_completed}。\n\n${JSON.stringify(counts, null, 2)}\n\n首个模型请求prompt token采用provider上报的pi-ai usage input+cacheRead+cacheWrite，保留raw usage，不用字符数估计。无usage为null。精确/上下文与新增分析分别计量；分析新增执行步骤导致总消耗变化，应与单请求上下文减少分开解读。\n\n|类别|有计量配对|基线首请求prompt tokens|候选首请求prompt tokens|加权减少|达到40%|\n|---|---|---|---|---|---|\n${result.prompt_token_measurement.map(item => `|${item.category}|${item.measured_pairs}|${item.baseline_prompt_tokens ?? '-'}|${item.candidate_prompt_tokens ?? '-'}|${item.weighted_reduction === null ? '-' : (item.weighted_reduction * 100).toFixed(1) + '%'}|${item.reaches_40_percent ?? '-'}|`).join('\n')}\n\n|样本|分类|基线|候选|首请求prompt减少|\n|---|---|---|---|---|\n${paired.map(item => `|${item.id}|${item.classification}|${item.baseline?.passed ?? '-'} ${item.baseline?.model_errors?.join('; ') ?? item.baseline?.failure ?? ''}|${item.candidate?.passed ?? '-'} ${item.candidate?.model_errors?.join('; ') ?? item.candidate?.failure ?? ''}|${item.first_request_prompt_token_reduction === null ? '-' : (item.first_request_prompt_token_reduction * 100).toFixed(1) + '%'}|`).join('\n')}\n`);
console.log(JSON.stringify({output, counts}));
