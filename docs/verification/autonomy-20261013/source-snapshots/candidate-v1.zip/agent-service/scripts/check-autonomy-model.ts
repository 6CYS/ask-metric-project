/** 同一数据集/脚本动态加载冻结基线或候选；真实模型 + 隔离合成业务结果，绝不连接业务库。 */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir, mkdtemp, readFile, readdir, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {dirname, join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {BACKGROUND_CONTEXT} from '@earendil-works/pi-agent-core';

type Obj = Record<string, any>;
const option = (name: string, fallback?: string) => process.argv.find(a => a.startsWith(`--${name}=`))?.slice(name.length + 3) ?? fallback;
const sha = (value: string | Buffer) => createHash('sha256').update(value).digest('hex');
const normalized = (value: string) => value.normalize('NFKC').replace(/\s+/g, '').toLowerCase();
const object = (value: any): Obj => value && typeof value === 'object' ? value : {};
const sorted = (values: string[]) => [...values].sort();
const equalSet = (actual: string[], expected: string[], label: string) => assert.deepEqual(sorted(actual), sorted(expected), label);
const canonical = (value: any): string => JSON.stringify(value, (_key, item) => item && typeof item === 'object' && !Array.isArray(item)
  ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item);
/** 复用provider发出HTTP前的授权边界，计数覆盖重试与不同会话；预算不能提高到24以上。 */
function providerBudget(limit: number) {
  assert.ok(Number.isInteger(limit) && limit >= 1 && limit <= 24, 'MAX_MODEL_CALLS_MUST_BE_1_TO_24');
  const state = {limit, used: 0, denied: 0, exhausted: false};
  return {state, guard: (authorize: () => boolean) => () => {
    if (!authorize()) return false;
    if (state.used >= state.limit) {state.denied++; state.exhausted = true; return false;}
    state.used++; return true;
  }};
}
const usageKeys = ['input', 'output', 'cacheRead', 'cacheWrite', 'totalTokens'] as const;
function measuredUsage(messages: Obj[], model: string) {
  const records = messages.filter(message => message.role === 'assistant' && message.provider === 'ask-metric' && message.model === model && message.usage)
    .map(message => ({stop_reason: message.stopReason, ...(message.responseId ? {response_id: message.responseId} : {}), raw_usage: structuredClone(message.usage),
      usage_reported: usageKeys.some(key => typeof message.usage[key] === 'number' && message.usage[key] > 0)}));
  const known = records.filter(record => record.usage_reported);
  const sum = Object.fromEntries(usageKeys.map(key => [key, known.length ? known.reduce((count, record) => count + (record.raw_usage[key] ?? 0), 0) : null]));
  const promptTokens = (record: Obj | undefined) => record?.usage_reported && typeof record.raw_usage.input === 'number'
    ? record.raw_usage.input + (record.raw_usage.cacheRead ?? 0) + (record.raw_usage.cacheWrite ?? 0) : null;
  return {raw: records, totals: sum, usage_reported_generations: known.length, usage_unavailable_generations: records.length - known.length,
    first_request_prompt_tokens: promptTokens(records[0]), first_successful_request_prompt_tokens: promptTokens(known[0]),
    first_request_reported_total_minus_output_tokens: records[0]?.usage_reported ? records[0].raw_usage.totalTokens - records[0].raw_usage.output : null,
    accounting: 'pi-ai provider usage: prompt=input+cacheRead+cacheWrite; preserve raw counters; unavailable is null, never inferred from characters'};
}
/** 只排除可识别的外部传输/鉴权/配额故障；400/422和工具协议问题必须保留为候选回归。 */
function infrastructureModelFailure(errors: string[], modelGenerated: boolean, toolCalls: number): boolean {
  if (!errors.length || modelGenerated || toolCalls > 0) return false;
  return errors.every(error => {
    const statusMatch = error.match(/(?:^|\bhttp(?:\/[\d.]+)?[\s:]+|\bstatus(?:[_\s-]*code)?[\s:=]+)([45]\d{2})\b/i);
    const status = statusMatch ? Number(statusMatch[1]) : undefined;
    if (status === 400 || status === 422 || /MODEL_TOOL_PROTOCOL_ERROR|context_length_exceeded|(?:invalid|malformed|unsupported)[^\n]*(?:tool|schema|argument|parameter)|(?:tool|schema|argument|parameter)[^\n]*(?:invalid|malformed|unsupported)/i.test(error)) return false;
    if (status !== undefined && ([401, 402, 403, 408, 429].includes(status) || status >= 500 && status <= 599 && ![501, 505].includes(status))) return true;
    return /\b(?:ECONNRESET|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH|ERR_NETWORK)\b|socket hang up|(?:connection|network)\s+(?:error|failed|failure|reset|refused)|fetch failed|failed to fetch|MODEL_FIRST_RESPONSE_TIMEOUT|MODEL_STREAM_IDLE_EXCEEDED|\b(?:timeout|timed out)\b|rate[_ -]?limit(?:ed|[_ -]exceeded)?|too many requests|insufficient[_ -](?:quota|balance)|payment[_ -]required|quota exceeded|authentication (?:failed|error)|invalid api key|api key (?:expired|invalid)|\bunauthorized\b/i.test(error);
  });
}
async function sourceManifest(root: string) {
  const files: string[] = [];
  const visit = async (relative: string) => {
    let entries; try {entries = await readdir(join(root, 'agent-service', relative), {withFileTypes: true});} catch {return;}
    for (const entry of entries) {
      const path = join(relative, entry.name);
      if (entry.isDirectory()) await visit(path);
      else if (/\.(ts|json|md)$/.test(entry.name)) files.push(path);
    }
  };
  await Promise.all(['src', 'skills', 'config'].map(visit));
  files.push('package.json', 'package-lock.json');
  const entries = await Promise.all(files.sort().map(async file => {
    try {return [file, sha(await readFile(join(root, 'agent-service', file)))];} catch {return [file, 'absent'];}
  }));
  return Object.fromEntries(entries);
}

async function main() {
  const sourceRoot = resolve(option('source-root', resolve(import.meta.dirname, '../..'))!);
  const datasetPath = resolve(option('dataset', resolve(import.meta.dirname, '../../docs/verification/autonomy-20261013/model-dataset.json'))!);
  const workbookPath = resolve(option('workbook', resolve(dirname(datasetPath), 'workbook-normalized.json'))!);
  const reportBase = resolve(option('report-base', resolve(dirname(datasetPath), `model-${option('phase', 'candidate')}`))!);
  const phase = option('phase', 'candidate')!, repetitions = Number(option('repetitions', '1'));
  assert.ok(Number.isInteger(repetitions) && repetitions > 0, 'REPETITIONS_POSITIVE_INTEGER');
  const budget = providerBudget(Number(option('max-model-calls', '24')));
  const datasetBytes = await readFile(datasetPath), workbookBytes = await readFile(workbookPath);
  const dataset = JSON.parse(datasetBytes.toString()), workbook = JSON.parse(workbookBytes.toString());
  const scenarioFilter = option('scenarios')?.split(','), categoryFilter = option('categories')?.split(',');
  const scenarios = dataset.scenarios.filter((s: Obj) => (!scenarioFilter || scenarioFilter.includes(s.name)) && (!categoryFilter || categoryFilter.includes(s.category)));
  assert.ok(scenarios.length, 'SCENARIOS_REQUIRED');
  const module = (file: string) => import(pathToFileURL(join(sourceRoot, 'agent-service/src', file)).href);
  const [configModule, modelsModule, hostModule, sessionModule, storeModule, toolsModule, skillsModule, projectionModule, backendModule] = await Promise.all([
    module('config.ts'), module('models.ts'), module('harnessHost.ts'), module('nativeSessions.ts'), module('business-context/store.ts'),
    module('tools/index.ts'), module('businessSkills.ts'), module('sessionProjection.ts'), module('backendClient.ts'),
  ]);
  const {BackendApiError} = backendModule;
  const data = await mkdtemp(join(tmpdir(), `autonomy-${phase}-`)), sessions = new sessionModule.NativeSessionStore(data);
  const config = {...configModule.loadConfig(), dataDir: data};
  const skills = await skillsModule.loadBusinessSkills(join(sourceRoot, 'agent-service/skills'), {analysisPlanning: !!config.analysisPlanning});
  // 固定两个版本的采样参数。运行命令通过同一当前.env加载鉴权，不把密钥写入报告。
  config.model.extraBody = {...config.model.extraBody, temperature: 0};
  const modelSignature = {name: config.model.name, max_tokens: config.model.maxTokens, context_window: config.model.contextWindow,
    extra_body: config.model.extraBody, suffix_sha256: sha(config.model.userMessageSuffix), compact_turn_args: !!config.compactTurnArgs};
  const sourceHashes = await sourceManifest(sourceRoot);
  const scriptHash = sha(await readFile(new URL(import.meta.url)));
  const unique = new Map<string, Obj>();
  for (const metric of workbook.metrics) {
    if (metric.business_label.includes('不含协定')) continue;
    if (!unique.has(metric.code)) unique.set(metric.code, {...metric, synonyms: [...new Set([
      metric.name, metric.base_name + metric.dimension,
      ...metric.aliases.map((alias: string) => metric.dimension === '当日数' ? alias : alias + metric.dimension),
    ])]});
  }
  const metrics = [...unique.values()], orgs = dataset.organizations as Record<string, string>;
  const catalogByName = new Map<string, Obj>();
  for (const metric of metrics) for (const name of metric.synonyms) catalogByName.set(normalized(name), metric);
  const matchMetric = (raw: string) => unique.get(raw) ?? catalogByName.get(normalized(raw));
  const metricMention = (question: string) => {
    const candidates: Obj[] = [];
    for (const metric of metrics) for (const name of metric.synonyms) {
      if (!name) continue;
      let start = question.indexOf(name);
      while (start >= 0) {
        candidates.push({text: name, start, end: start + name.length, metric});
        start = question.indexOf(name, start + name.length);
      }
    }
    const longest = candidates.sort((a, b) => b.text.length - a.text.length || a.start - b.start);
    const accepted: Obj[] = [];
    for (const item of longest) if (!accepted.some(other => item.start < other.end && item.end > other.start)) accepted.push(item);
    return accepted.sort((a, b) => a.start - b.start).map(({text, start, end, metric}) => ({text, start, end,
      resolution: {status: 'resolved', value: {codes: [metric.code], names: [metric.name]}}}));
  };
  const parseDate = (raw: string[]) => {
    const text = normalized(raw.join(''));
    let m = text.match(/(2026)[年-](\d{1,2})[月-](\d{1,2})日?/);
    if (m) { const date = `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`; return {start: date, end: date}; }
    m = text.match(/(2026)年(\d{1,2})月/);
    if (m) { const month = Number(m[2]), last = new Date(Date.UTC(2026, month, 0)).getUTCDate(); return {start: `2026-${m[2].padStart(2, '0')}-01`, end: `2026-${m[2].padStart(2, '0')}-${last}`}; }
    return null;
  };
  const resolveCatalog = async (entity: string, raw: string[]) => {
    if (entity === 'date') { const date = parseDate(raw); return date ? {status: 'resolved', value: date} : {status: 'invalid'}; }
    const hits = entity === 'metric' ? raw.map(matchMetric) : raw.map(name => {
      const entry = Object.entries(orgs).find(([label, code]) => normalized(label) === normalized(name) || code === name);
      return entry ? {code: entry[1], name: entry[0]} : undefined;
    });
    return hits.length && hits.every(Boolean) ? {status: 'resolved', value: {codes: hits.map(hit => hit!.code), names: hits.map(hit => hit!.name)}} : {status: 'not_found', candidates: []};
  };
  function fixture(kind: string | undefined) {
    const queries: Obj[] = [], calculations: Obj[] = [], coverage: Obj[] = [], reads: string[] = [], constraints: Obj[] = [], prepared: Obj[] = [];
    const results = new Map<string, Obj>(), refs = new Map<string, string>(), preparation = new Map<string, Obj>();
    let emittedMissing = false, boundRequest: Obj | undefined;
    const fail = (code: string, message: string): never => {throw new BackendApiError(422, message, code);};
    const valueOf = (org: string, metric: Obj, date: string) => {
      const offset = Number(org.replace('SYNTH_O', '')) - 1, next = date === '2026-08-31' ? 20 : 0;
      if (metric.dimension.includes('增幅') || metric.dimension.includes('完成率')) return String(5 + offset + (next ? 1 : 0));
      if (metric.base_code.includes('PRPR') || metric.base_code.includes('_SHR_RT')) return String(metric.base_code.includes('PSON') ? 60 : 40);
      const base = metric.base_code === 'ORG_VRS_DEPT_BAL' ? 1000 : metric.base_code === 'ORG_PSON_DEPT_BAL' ? 600 : metric.base_code === 'ORG_CORP_DEPT_BAL' ? 400 : 200;
      return String(base + offset * 100 + next);
    };
    const execute = async (spec: Obj, analysis = false, preparedTaskId?: string) => {
      assert.ok(spec.metric_codes?.length && spec.org_codes?.length, 'FIXTURE_QUERY_HAS_SCOPE');
      for (const code of spec.metric_codes) if (!unique.has(code)) fail('UNKNOWN_METRIC_CODE', '指标未在工作簿正式编码集合中。');
      for (const code of spec.org_codes) if (!Object.values(orgs).includes(code)) fail('ORG_SCOPE_DENIED', '机构未授权。');
      if (!dataset.dates.includes(spec.time.end)) fail('FIXTURE_DATE_OUT_OF_SCOPE', '隔离样本日期不存在。');
      const missingCodes = kind === 'missing_total_growth' && !emittedMissing
        ? spec.metric_codes.filter((code: string) => unique.get(code)!.dimension !== '当日数' && !unique.get(code)!.base_code.includes('PRPR')) : [];
      if (missingCodes.length) emittedMissing = true;
      const task = preparedTaskId ?? `synthetic-query-${queries.length + 1}`;
      const facts: Obj[] = [];
      for (const org of spec.org_codes) for (const code of spec.metric_codes) {
        if (missingCodes.includes(code)) continue;
        const metric = unique.get(code)!;
        facts.push({fact_id: `fact:${task}:${facts.length}:metric_value`, task_id: task, field: 'metric_value', value: valueOf(org, metric, spec.time.end),
          unit: metric.unit, metric_code: code, metric_name: metric.name, org_code: org,
          org_name: Object.keys(orgs).find(name => orgs[name] === org), date: spec.time.end});
      }
      const rows = facts.map(fact => ({...fact, stat_date: fact.date, metric_value: fact.value}));
      const result = {task_id: task, result_id: `result-${task}`, status: 'succeeded', facts, rows, columns: Object.keys(rows[0] ?? {}), row_count: rows.length,
        truncated: false, message: '隔离合成数据查询完成；这些值不是数据湖事实。',
        evidence: {logical_dsl: structuredClone(spec), synthetic_data: true, missing_metric_codes: missingCodes,
          missing_metric_notice: missingCodes.length ? '选定增长指标在隔离样本中无有效值，不能按零解释。' : null}};
      queries.push({spec: structuredClone(spec), analysis, task_id: task, missing_codes: missingCodes, result: structuredClone(result)});
      results.set(task, result);
      return {query: structuredClone(spec), result};
    };
    const reference = async (payload: Obj) => ({references: payload.metric_codes.map((code: string) => {
      if (!unique.has(code)) fail('UNKNOWN_METRIC_CODE', '不存在的目录编码');
      const ref = `synthetic-catalog:${code}`; refs.set(ref, code); return {metric_code: code, catalog_ref: ref};
    })});
    const constraint = async (payload: Obj) => {
      assert.equal(payload.source_question_sha256, sha(payload.source_question), 'ANALYSIS_SOURCE_HASH');
      for (const target of payload.targets) for (const org of target.org_codes) if (!Object.values(orgs).includes(org)) fail('ORG_SCOPE_DENIED', '机构未授权。');
      const prior = constraints.find(c => c.analysis_id === payload.analysis_id && c.constraint_version === payload.constraint_version);
      if (prior && canonical(prior.payload) !== canonical(payload)) fail('ANALYSIS_CONSTRAINT_CONFLICT', '相同约束版本不能重定义。');
      const saved = prior ?? {constraint_ref: `synthetic-constraint:${constraints.length + 1}`, analysis_id: payload.analysis_id, constraint_version: payload.constraint_version, payload: structuredClone(payload)};
      if (!prior) constraints.push(saved);
      return {constraint_ref: saved.constraint_ref, analysis_id: saved.analysis_id, constraint_version: saved.constraint_version};
    };
    const prepare = async (payload: Obj) => {
      const saved = constraints.find(c => c.constraint_ref === payload.constraint_ref); if (!saved) fail('ANALYSIS_CONSTRAINT_NOT_FOUND', '约束不存在。');
      const target = saved!.payload.targets.find((t: Obj) => t.target_id === payload.target_id); if (!target) fail('ANALYSIS_TARGET_NOT_FOUND', '目标不存在。');
      let runtimeState: Obj | undefined;
      if (boundRequest) {
        assert.ok(boundRequest.analysis, 'ANALYSIS_NATIVE_CONTEXT_BOUND');
        const task = await boundRequest.analysis.read(saved!.analysis_id, boundRequest);
        const step = task?.steps.find((item: Obj) => item.id === payload.step_id);
        assert.equal(step?.status, 'preparing', 'ANALYSIS_PREPARING_PERSISTED_BEFORE_BACKEND');
        assert.equal(step.prepareKey, payload.prepare_key, 'ANALYSIS_PREPARE_KEY_PERSISTED_BEFORE_BACKEND');
        assert.equal(step.stepRevision, payload.step_revision, 'ANALYSIS_CURRENT_STEP_REVISION');
        assert.equal(task.constraintVersion, saved!.constraint_version, 'ANALYSIS_CURRENT_CONSTRAINT_VERSION');
        const anchors = task.anchor.targets ?? [{targetId: task.anchor.targetId ?? 'target-1', fields: task.anchor.fields}];
        const anchor = anchors.find((item: Obj) => item.targetId === payload.target_id);
        assert.ok(anchor, 'ANALYSIS_CURRENT_TARGET_EXISTS');
        equalSet(payload.query.org_codes, anchor.fields.organizations.resolvedValue.codes, 'ANALYSIS_QUERY_MATCHES_CURRENT_TARGET_ORGANIZATIONS');
        assert.deepEqual(payload.query.time, anchor.fields.time.resolvedValue, 'ANALYSIS_QUERY_MATCHES_CURRENT_TARGET_DATE');
        runtimeState = {analysis_id: task.analysisId, plan_revision: task.planRevision, constraint_version: task.constraintVersion,
          target_id: payload.target_id, step_id: step.id, step_status: step.status, step_revision: step.stepRevision, prepare_key: step.prepareKey};
      }
      equalSet(payload.query.org_codes, target.org_codes, 'ANALYSIS_FIXED_ORGANIZATION');
      assert.deepEqual(payload.query.time, target.time, 'ANALYSIS_FIXED_DATE');
      for (const code of payload.query.metric_codes) {
        if (!unique.has(code)) fail('UNKNOWN_METRIC_CODE', '分析指标不在正式目录。');
        if (target.metric_selection_policy !== 'catalog' && !target.allowed_metric_codes.includes(code) && !target.fixed_metric_codes.includes(code)) {
          fail('ANALYSIS_METRIC_NOT_AUTHORIZED', '指标超出固定约束。');
        }
      }
      for (const code of payload.query.metric_codes) if (!payload.catalog_refs.some((reference: string | Obj) => {
        const ref = typeof reference === 'string' ? reference : reference.catalog_ref;
        return refs.get(ref) === code && (typeof reference === 'string' || reference.metric_code === code);
      })) fail('ANALYSIS_CATALOG_REF_INVALID', '目录引用无效。');
      const old = preparation.get(payload.prepare_key);
      if (old && canonical(old.payload) !== canonical(payload)) fail('ANALYSIS_PREPARE_CONFLICT', '准备键不可重定义。');
      if (old) return old.receipt;
      const receipt = {prepared_query_ref: `synthetic-prepared:${prepared.length + 1}`, prepare_key: payload.prepare_key, spec_hash: sha(canonical(payload.query)),
        status: 'prepared', query: structuredClone(payload.query), task_id: `synthetic-prepared-task-${prepared.length + 1}`, task_version: 1};
      const item = {payload: structuredClone(payload), receipt, ...(runtimeState ? {runtime_state: runtimeState} : {})}; prepared.push(item); preparation.set(payload.prepare_key, item); return receipt;
    };
    const executePrepared = async (input: Obj | string) => {
      const ref = typeof input === 'string' ? input : input.prepared_query_ref;
      const item = prepared.find(p => p.receipt.prepared_query_ref === ref); if (!item) fail('ANALYSIS_PREPARED_NOT_FOUND', '准备引用不存在。');
      if (!item!.execution) item!.execution = await execute(item!.payload.query, true, item!.receipt.task_id);
      return item!.execution;
    };
    const client: Obj = {
      resolveBusinessField: resolveCatalog,
      matchMetricQuestion: async (question: string) => ({mentions: metricMention(question)}),
      searchMetrics: async (keyword: string, limit = 20) => {
        const needle = normalized(keyword), matching = metrics.filter(metric => metric.code === keyword || metric.synonyms.some((name: string) => normalized(name).includes(needle)));
        const hits = matching.map(metric => ({metric_code: metric.code, metric_name: metric.name, unit: metric.unit, synonyms: metric.synonyms,
          score: metric.code === keyword || metric.synonyms.some((name: string) => normalized(name) === needle) ? 1 : 0.8,
          match_type: metric.code === keyword || metric.synonyms.some((name: string) => normalized(name) === needle) ? 'exact' : 'contains'}));
        return {total: hits.length, items: hits.slice(0, limit), semantic_suggestions: []};
      },
      searchOrganizations: async (keyword: string, limit = 20) => { const hits = Object.entries(orgs).filter(([name, code]) => name.includes(keyword) || code === keyword)
        .map(([name, code]) => ({org_code: code, org_name: name, score: 1, match_type: name === keyword || code === keyword ? 'exact' : 'contains'})); return {total: hits.length, items: hits.slice(0, limit)}; },
      metricCatalogOverview: async () => ({total: metrics.length, groups: ['亿元', '%'].map(unit => ({unit, count: metrics.filter(m => m.unit === unit).length,
        examples: metrics.filter(m => m.unit === unit).slice(0, 10).map(m => ({code: m.code, name: m.name}))}))}),
      createAgentQueryContext: async () => ({conversation_id: 'synthetic-autonomy-conversation'}),
      basicQueries: async (spec: Obj) => execute(spec),
      getTask: async (task: string) => {if (!results.has(task)) fail('TASK_NOT_FOUND', '任务不存在'); return {task_id: task, status: 'SUCCEEDED', version: 1, result: {result_id: `result-${task}`}};},
      getTaskResult: async (task: string, offset = 0, limit = 100) => {
        reads.push(task); const result = results.get(task); if (!result) fail('TASK_NOT_FOUND', '任务不存在');
        const has_more = offset + limit < result!.row_count;
        return {...result, facts: result!.facts.slice(offset, offset + limit), rows: result!.rows.slice(offset, offset + limit), comparisons: [],
          offset, limit, has_more, next_offset: has_more ? offset + limit : null};
      },
      calculate: async (spec: Obj) => {
        calculations.push(structuredClone(spec));
        const all = [...results.values()].flatMap(result => result.facts), inputs: Obj = {};
        for (const [key, binding] of Object.entries(spec.bindings) as [string, Obj][]) {
          const fact = all.find(f => f.fact_id === binding.fact_id); if (!fact) fail('CALCULATION_FACT_NOT_FOUND', '事实身份不存在'); inputs[key] = fact;
        }
        const output = spec.expressions.map((expression: Obj) => {
          const tokens = expression.expression.replace(/[()\s]/g, '').match(/^([A-Za-z_]\w*)([-+/*])([A-Za-z_]\w*)$/);
          if (!tokens || !inputs[tokens[1]] || !inputs[tokens[3]]) fail('FIXTURE_CALCULATION_UNSUPPORTED', '隔离计算只接受两个正式事实的基础运算');
          const left = Number(inputs[tokens![1]].value), right = Number(inputs[tokens![3]].value);
          if (tokens![2] === '/' && right === 0) fail('CALCULATION_DIVISION_ZERO', '分母为零');
          const value = (tokens![2] === '-' ? left - right : tokens![2] === '+' ? left + right : tokens![2] === '*' ? left * right : left / right).toFixed(expression.decimal_places ?? 2);
          return {...expression, value, display_value: value, unit: inputs[tokens![1]].unit, variables: [tokens![1], tokens![3]]};
        });
        return {status: 'succeeded', calculation_id: `synthetic-calc-${calculations.length}`, task_id: all[0]?.task_id, scope_id: spec.scope_id,
          inputs, results: output, public_answer: output.map((row: Obj) => `${row.label}：${row.display_value}${row.unit}`).join('；')};
      },
      dataAvailability: async (spec: Obj) => {coverage.push(structuredClone(spec)); return {status: 'succeeded', request: spec, mode: spec.dimension,
        metric_count: metrics.length, org_count: spec.org_codes.length, org_names: Object.keys(orgs), items: metrics.slice(0, 20).map(m => ({metric_code: m.code, metric_name: m.name})),
        groups: [{date_count: 2, earliest: dataset.dates[0], latest: dataset.dates[1], dates: dataset.dates, has_more: false}], page: spec.page ?? 1,
        page_size: spec.page_size ?? 20, has_more: metrics.length > 20, notice: '隔离记录覆盖不是生产数据有效性证明。'};},
      issueAnalysisCatalogReferences: reference, createAnalysisCatalogReferences: reference, analysisCatalogReferences: reference,
      registerAnalysisConstraints: constraint, registerAnalysisConstraint: constraint, createAnalysisConstraints: constraint,
      prepareAnalysisQuery: prepare, executeAnalysisQuery: executePrepared,
      getPreparedAnalysisQuery: async (key: string) => {
        const found = preparation.get(key)?.receipt;
        if (!found) throw new BackendApiError(404, '准备键不存在', 'ANALYSIS_PREPARED_NOT_FOUND');
        return found;
      },
    };
    return {client, queries, calculations, coverage, reads, constraints, prepared, bindRequest: (request: Obj) => {boundRequest = request;},
      readAnalysis: async () => boundRequest?.analysis ? boundRequest.analysis.read(undefined, boundRequest) : undefined};
  }
  const turns: Obj[] = [], nativeRecordings: Obj[] = []; let sourceChangedDuringRun = false;
  const report = () => ({phase, created_at: new Date().toISOString(), environment: 'configured_real_model_isolated_synthetic_backend', real_database: false,
    production_accessed: false, synthetic_values: true, source_root: sourceRoot, source_hashes: sourceHashes,
    source_changed_during_run: sourceChangedDuringRun, script_sha256: scriptHash,
    dataset_sha256: sha(datasetBytes), workbook_sha256: sha(workbookBytes), model_signature: modelSignature, repetitions,
    scenarios: scenarios.map((s: Obj) => s.name), session_data: data, native_recordings: nativeRecordings,
    provider_budget: {...budget.state},
    sampling: 'fixed repetitions; preserve every failed sample; no selective reruns',
    summary: {planned_turns: repetitions * scenarios.reduce((count: number, scenario: Obj) => count + scenario.steps.length, 0),
      turns: turns.length, passed: turns.filter(t => t.passed).length, failed: turns.filter(t => !t.passed).length,
      budget_errors: turns.filter(t => t.failure_class === 'budget_error').length,
      infrastructure_failures: turns.filter(t => t.failure_class === 'infrastructure').length,
      business_failures: turns.filter(t => t.failure_class === 'business_or_runtime').length,
      token_usage: Object.fromEntries(usageKeys.map(key => {const known = turns.filter(turn => turn.model_usage.totals[key] !== null);
        return [key, known.length ? known.reduce((count, turn) => count + turn.model_usage.totals[key], 0) : null];})),
      usage_reported_generations: turns.reduce((count, turn) => count + turn.model_usage.usage_reported_generations, 0),
      usage_unavailable_generations: turns.reduce((count, turn) => count + turn.model_usage.usage_unavailable_generations, 0),
      by_category: Object.fromEntries(['precise', 'context', 'analysis'].map(category => [category, {total: turns.filter(t => t.category === category).length, passed: turns.filter(t => t.category === category && t.passed).length}]))}, turns});
  const save = async () => {await mkdir(dirname(reportBase), {recursive: true}); await writeFile(`${reportBase}.json`, JSON.stringify(report(), null, 2));};
  if (!process.argv.includes('--live')) {
    const fixtureResult = await fixture(undefined).client.basicQueries({metric_codes: ['ORG_VRS_DEPT_BAL'], org_codes: ['SYNTH_O1'], time: {start: dataset.dates[0], end: dataset.dates[0]}, selection: 'exact'});
    assert.equal(fixtureResult.result.facts[0].value, '1000');
    assert.equal(metricMention('机构个人存款余额较年初增幅')[0].resolution.value.codes[0], 'ORG_PSON_DEPT_BAL_CMPBGNYR_INCRRNG');
    const f = fixture(undefined), source = '分析合成机构甲2026年7月31日存款经营情况';
    const query = {metric_codes: ['ORG_VRS_DEPT_BAL'], org_codes: ['SYNTH_O1'], time: {start: dataset.dates[0], end: dataset.dates[0]}, selection: 'exact'};
    const references = await f.client.createAnalysisCatalogReferences({conversation_id: 'fixture', metric_codes: query.metric_codes});
    const registered = await f.client.registerAnalysisConstraints({schema_version: 1, conversation_id: 'fixture', analysis_id: 'fixture-analysis', constraint_version: 1,
      source_question: source, source_question_sha256: sha(source), targets: [{target_id: 'target-1', org_codes: query.org_codes, time: query.time,
        fixed_metric_codes: [], allowed_metric_codes: query.metric_codes}], requirements: [{requirement_id: 'req-1', target_ids: ['target-1'], description: '总量'}]}, 'fixed-constraint-key');
    const payload = {constraint_ref: registered.constraint_ref, prepare_key: 'fixed-prepare-key', step_id: 'step-1', step_revision: 1,
      target_id: 'target-1', requirement_ids: ['req-1'], query, catalog_refs: references.references};
    const prepared = await f.client.prepareAnalysisQuery(payload, payload.prepare_key);
    assert.deepEqual(await f.client.getPreparedAnalysisQuery(payload.prepare_key, 'fixture'), prepared, 'FIXTURE_PREPARE_RECOVERY');
    const once = await f.client.executeAnalysisQuery(prepared.prepared_query_ref, payload.prepare_key);
    assert.equal(once.result.task_id, prepared.task_id, 'FIXTURE_PREPARE_EXECUTE_TASK_IDENTITY');
    assert.deepEqual(await f.client.executeAnalysisQuery(prepared.prepared_query_ref, payload.prepare_key), once, 'FIXTURE_EXECUTE_IDEMPOTENCY');
    assert.equal(f.queries.length, 1, 'FIXTURE_DUPLICATE_EXECUTE_NO_SECOND_QUERY');
    await assert.rejects(f.client.prepareAnalysisQuery({...payload, query: {...query, org_codes: ['SYNTH_O2']}}, payload.prepare_key), /ANALYSIS_FIXED_ORGANIZATION/);
    await assert.rejects(f.client.prepareAnalysisQuery({...payload, catalog_refs: []}, payload.prepare_key), /目录引用无效/);
    await assert.rejects(f.client.executeAnalysisQuery('forged-prepared-ref', 'forged-key'), /准备引用不存在/);
    const dryBudget = providerBudget(24), allowed = dryBudget.guard(() => true);
    let simulatedHttpCalls = 0;
    for (let i = 0; i < 30; i++) if (allowed()) simulatedHttpCalls++;
    assert.equal(simulatedHttpCalls, 24, 'PROVIDER_HARD_LIMIT_BEFORE_HTTP');
    assert.equal(dryBudget.state.denied, 6, 'PROVIDER_OVER_BUDGET_CALLS_DENIED');
    assert.equal(dryBudget.state.exhausted, true, 'PROVIDER_BUDGET_EXHAUSTION_RECORDED');
    const unauthorized = providerBudget(1); assert.equal(unauthorized.guard(() => false)(), false);
    assert.equal(unauthorized.state.used, 0, 'UNAUTHORIZED_REQUEST_DOES_NOT_CONSUME_CALL_BUDGET');
    const usage = measuredUsage([{role: 'assistant', provider: 'ask-metric', model: 'fixture', usage: {input: 50, output: 20, cacheRead: 100, cacheWrite: 0, totalTokens: 170}}], 'fixture');
    assert.equal(usage.first_request_prompt_tokens, 150, 'PROVIDER_REPORTED_PROMPT_INCLUDES_CACHE');
    assert.equal(usage.first_request_reported_total_minus_output_tokens, 150, 'PROVIDER_PROMPT_COUNTER_CROSSCHECK');
    assert.equal(measuredUsage([], 'fixture').totals.input, null, 'MISSING_USAGE_IS_NOT_ZERO');
    for (const message of ['Connection error.', 'fetch failed', 'ECONNRESET', '402 status code (no body)', '401 unauthorized', '403 Forbidden',
      '429 Too Many Requests', '408 Request Timeout', '503 Service Unavailable', 'MODEL_FIRST_RESPONSE_TIMEOUT: first response timeout']) {
      assert.equal(infrastructureModelFailure([message], false, 0), true, `KNOWN_EXTERNAL_FAILURE_${message}`);
    }
    for (const message of ['400 Invalid tool schema: $defs unsupported', '422 invalid parameters', 'MODEL_TOOL_PROTOCOL_ERROR: malformed call',
      'context_length_exceeded', 'unexpected response shape', '500 invalid tool schema']) {
      assert.equal(infrastructureModelFailure([message], false, 0), false, `INTEGRATION_FAILURE_NOT_HIDDEN_${message}`);
    }
    assert.equal(infrastructureModelFailure(['Connection error.', '400 invalid tool schema'], false, 0), false, 'MIXED_NETWORK_AND_SCHEMA_FAILURE_NOT_HIDDEN');
    assert.equal(infrastructureModelFailure(['Connection error.'], true, 0), false, 'GENERATED_TURN_NOT_EXCLUDED_BY_CONNECTION_TEXT');
    assert.equal(infrastructureModelFailure(['Connection error.'], false, 1), false, 'EXECUTED_TURN_NOT_EXCLUDED_BY_CONNECTION_TEXT');
    await sessions.close(); console.log(JSON.stringify({status: 'fixture_valid', model_called: false, checks: ['precise_dimension_match', 'synthetic_query_value',
      'analysis_register_prepare_execute', 'prepare_recovery', 'execution_idempotency', 'fixed_scope_rejection', 'forged_catalog_rejection', 'forged_prepared_rejection', 'provider_call_budget_before_http', 'provider_reported_usage_accounting', 'strict_infrastructure_classification'],
      dataset_sha256: sha(datasetBytes), scenarios: scenarios.length, repetitions})); return;
  }
  const host = new hostModule.HarnessHost(config, (authorize: () => boolean) => modelsModule.createAskMetricModels(config, budget.guard(authorize)), sessions,
    [...toolsModule.createAskMetricTools({compactTurnArgs: config.compactTurnArgs, turnContractV2: config.turnContractV2,
      analysisPlanning: config.analysisPlanning, analysisAcceptNew: config.analysisAcceptNew,
      analysisCatalogFile: config.analysisCatalogFile}), skillsModule.createBusinessSkillReadTool(skills)], {skills});
  try {
    sampling: for (let repeat = 1; repeat <= repetitions; repeat++) for (const scenario of scenarios) {
      const hosted = await host.createSession(dataset.actor), frames = new storeModule.NativeFrameStore(hosted.session), f = fixture(scenario.fixture);
      for (const [index, step] of scenario.steps.entries()) {
        const before = {query: f.queries.length, calculate: f.calculations.length, coverage: f.coverage.length, prepared: f.prepared.length, reads: f.reads.length, provider: budget.state.used};
        const started = performance.now(); let failure: string | undefined, modelCalls = 0;
        try {
          const admitted = await host.admitPrompt(hosted, {protocol_version: 3, request_id: `${repeat}-${scenario.name}-${index + 1}`, message: step.message}, {actor: dataset.actor, backend: f.client});
          assert.ok(admitted.ok, 'PROMPT_ADMISSION');
          f.bindRequest(admitted.request);
          const timer = setTimeout(() => void host.abort(hosted, admitted.operationId), Number(option('turn-deadline-ms', '180000')));
          try {const out = await host.drivePrompt(hosted, admitted); assert.ok(out.ok && out.outcome.kind === 'settled' && out.outcome.outcome.status === 'completed', 'MODEL_TURN_COMPLETED');}
          finally {clearTimeout(timer); modelCalls = admitted.request.timings?.model_ms.length ?? 0;}
        } catch (error) {failure = error instanceof Error ? error.message : String(error);}
        const entries = await hosted.lane.findEntries({order: 'oldestFirst'}, BACKGROUND_CONTEXT);
        const lastUser = entries.map((e: Obj) => e.type === 'message' && e.message.role === 'user').lastIndexOf(true), current = entries.slice(lastUser);
        const messages = current.flatMap((e: Obj) => e.type === 'message' ? [e.message] : []);
        const modelErrors = messages.filter((m: Obj) => m.role === 'assistant' && m.errorMessage)
          .map((m: Obj) => String(m.errorMessage).replaceAll(config.model.apiKey, '[REDACTED]'));
        const modelGenerated = messages.some((m: Obj) => m.role === 'assistant' && !m.errorMessage && (m.usage?.input > 0 || m.usage?.output > 0));
        const modelUsage = measuredUsage(messages, config.model.name);
        const calls = messages.flatMap((m: Obj) => m.role === 'assistant' ? m.content.filter((c: Obj) => c.type === 'toolCall').map((c: Obj) => ({id: c.id, name: c.name, args: c.arguments})) : []);
        const receipts = messages.flatMap((m: Obj) => m.role === 'toolResult' ? [{id: m.toolCallId, name: m.toolName, is_error: !!m.isError, details: m.details, content: m.content}] : []);
        const answers = projectionModule.projectEntries(current).filter((m: Obj) => m.role === 'assistant' && m.text?.trim()), answer = answers.at(-1)?.text ?? '';
        const state = await frames.state(), focus = await frames.get(state.focusFrameId ?? ''), allFrames = await frames.list();
        const analysisState = await f.readAnalysis();
        const queries = f.queries.slice(before.query), calculations = f.calculations.slice(before.calculate), expect = step.expect;
        try {
          if (failure) throw new Error(failure);
          assert.ok(answer.trim(), 'VISIBLE_FINAL_ANSWER');
          if (expect.kind === 'query') {
            assert.equal(queries.length, 1, 'PRECISE_QUERY_EXECUTES_ONCE'); const spec = queries[0].spec;
            equalSet(spec.org_codes, expect.orgs, 'PRECISE_ORGANIZATIONS_PRESERVED'); equalSet(spec.metric_codes, expect.codes, 'PRECISE_METRICS_PRESERVED');
            assert.deepEqual(spec.time, {start: expect.date, end: expect.date}, 'PRECISE_DATE_PRESERVED'); assert.equal(spec.selection, 'exact', 'PRECISE_SELECTION');
            assert.equal(spec.operation?.kind ?? 'value', 'value', 'PRECISE_QUERY_KIND'); assert.equal(focus?.status, 'success', 'PRECISE_FORMAL_RESULT');
            assert.equal(f.calculations.length - before.calculate, 0, 'PRECISE_NO_EXTRA_CALCULATION');
          } else if (expect.kind === 'calculate') {
            assert.equal(queries.length, 0, 'HISTORICAL_FACTS_NO_REQUERY'); assert.equal(calculations.length, 1, 'HISTORICAL_FORMAL_CALCULATION');
            assert.ok(f.reads.length - before.reads >= 1, 'HISTORICAL_FACT_REVALIDATION'); assert.ok(answer.includes(expect.value), 'CALCULATION_VALUE_DELIVERED');
          } else {
            assert.ok(queries.length, 'ANALYSIS_ACTUALLY_QUERIED');
            for (const query of queries) {equalSet(query.spec.org_codes, expect.orgs, 'ANALYSIS_FIXED_ORGANIZATIONS'); assert.deepEqual(query.spec.time, {start: expect.date, end: expect.date}, 'ANALYSIS_FIXED_DATE');}
            const codes = [...new Set<string>(queries.flatMap((query: Obj) => query.spec.metric_codes))];
            for (const code of expect.must_codes) assert.ok(codes.includes(code), `ANALYSIS_REQUIRED_METRIC_${code}`);
            assert.ok(codes.length >= expect.min_distinct_codes, 'ANALYSIS_SELECTED_ADDITIONAL_METRICS');
            assert.ok(calls.some((call: Obj) => call.name === 'analysis_task') || f.prepared.length > before.prepared, 'ANALYSIS_PERSISTED_PLAN');
            assert.ok(f.prepared.length > before.prepared && queries.some((q: Obj) => q.analysis), 'ANALYSIS_PREPARED_EXECUTION');
            assert.ok(f.prepared.slice(before.prepared).every((item: Obj) => item.runtime_state?.step_status === 'preparing'), 'ANALYSIS_REAL_PREPARING_STATE_VERIFIED');
            assert.ok(analysisState?.steps?.length && analysisState?.evidence?.length, 'ANALYSIS_PERSISTED_STEPS_AND_FORMAL_EVIDENCE');
            assert.ok(analysisState.evidence.some((evidence: Obj) => evidence.complete && evidence.factRefs?.length), 'ANALYSIS_HAS_COMPLETE_FACT_EVIDENCE');
            assert.ok(analysisState.status === 'complete' || expect.requires_result_replan && analysisState.status === 'partial' && analysisState.gaps?.length,
              'ANALYSIS_GOAL_COMPLETION_CHECKED');
            if (expect.requires_result_replan) {
              const missingIndex = queries.findIndex((q: Obj) => q.missing_codes.length);
              assert.ok(missingIndex >= 0 && missingIndex < queries.length - 1, 'RESULT_DRIVEN_REPLAN_AFTER_MISSING_FACT');
              const missing = queries[missingIndex].missing_codes;
              assert.ok(queries.slice(missingIndex + 1).some((q: Obj) => q.spec.metric_codes.some((code: string) => !missing.includes(code)
                && /较|增幅/.test(unique.get(code)!.dimension) && q.result.facts.some((fact: Obj) => fact.metric_code === code))), 'REPLAN_ALTERNATIVE_FORMAL_GROWTH_FACT');
              assert.ok(/缺|无有效|未取得|不足/.test(answer), 'MISSING_FACT_DISCLOSED');
            }
          }
        } catch (error) {failure = error instanceof Error ? error.message : String(error);}
        const errorCalls = receipts.filter((receipt: Obj) => receipt.is_error || ['ARGUMENT_ERROR', 'error', 'failed'].includes(String(object(receipt.details).status))).length;
        if (budget.state.exhausted) failure = 'MODEL_CALL_BUDGET_EXHAUSTED';
        const infrastructure = !!failure && infrastructureModelFailure(modelErrors, modelGenerated, calls.length);
        const turn = {repeat, scenario: scenario.name, category: scenario.category, turn: index + 1, session_id: hosted.sessionId,
          message: step.message, expected: expect, passed: !failure, failure,
          failure_class: failure ? budget.state.exhausted ? 'budget_error' : infrastructure ? 'infrastructure' : 'business_or_runtime' : null,
          model_generated: modelGenerated, model_errors: modelErrors,
          model_usage: modelUsage,
          tools: structuredClone(calls), receipts: structuredClone(receipts), query_calls: structuredClone(queries), calculation_specs: structuredClone(calculations),
          constraints: structuredClone(f.constraints), prepared: structuredClone(f.prepared.slice(before.prepared)), state, focus, frames: allFrames,
          analysis_task_state: analysisState, answer,
          measures: {tool_calls: calls.length, error_calls: errorCalls, query_count: queries.length, calculation_count: calculations.length,
            coverage_count: f.coverage.length - before.coverage, model_calls: modelCalls, provider_calls: budget.state.used - before.provider, elapsed_ms: Math.round(performance.now() - started)}};
        turns.push(turn); await save(); console.log(JSON.stringify({phase, repeat, scenario: scenario.name, turn: index + 1, passed: !failure, failure, measures: turn.measures}));
        if (budget.state.exhausted) break;
      }
      await host.closeSession(hosted.sessionId);
      if (budget.state.exhausted) break sampling;
    }
  } finally {
    sourceChangedDuringRun = canonical(sourceHashes) !== canonical(await sourceManifest(sourceRoot));
    await host.close(); await sessions.close();
    const archive = async (directory: string): Promise<void> => {
      for (const entry of await readdir(directory, {withFileTypes: true})) {
        const path = join(directory, entry.name);
        if (entry.isDirectory()) await archive(path);
        else if (entry.name.endsWith('.jsonl')) {
          const bytes = await readFile(path);
          // 保存实际原生记录且先检查模型密钥未被持久化，禁止脱敏改写原始调用后冒充原件。
          assert.ok(!bytes.includes(Buffer.from(config.model.apiKey)), 'SECRET_MUST_NOT_ENTER_NATIVE_ARCHIVE');
          const target = join(`${reportBase}-native`, entry.name);
          await mkdir(dirname(target), {recursive: true}); await writeFile(target, bytes);
          nativeRecordings.push({path: target, sha256: sha(bytes), bytes: bytes.length});
        }
      }
    };
    await archive(data); await save();
  }
  const result = report();
  await writeFile(`${reportBase}.md`, `# 自主分析真实模型验收：${phase}\n\n模型：${modelSignature.name}。每场景 ${repetitions} 次，temperature=0；保留全部失败。真实模型 API＋隔离合成机构和值，指标名称和编码来自用户工作簿；未验证真实数据湖、数据库或生产环境。没有模型生成的基础设施失败不能计作业务基线失败。\n\n${JSON.stringify(result.summary, null, 2)}\n\n|重复|场景|回合|结果|分类与说明|\n|---|---|---|---|---|\n${turns.map(t => `|${t.repeat}|${t.scenario}|${t.turn}|${t.passed ? '通过' : '失败'}|${t.failure_class ?? ''} ${(t.model_errors?.join('; ') || t.failure || '目标与正式执行参数一致').replaceAll('\n', ' ')}|`).join('\n')}\n\n完整原始工具参数、回执、执行条件、Frame 和回答保存在同名 JSON；未重写模型原始调用。分析准备由隔离桩验证固定机构日期、指标范围与正式引用，不代表后端实现已验收。\n`);
  console.log(JSON.stringify({phase, report: `${reportBase}.json`, summary: result.summary}));
  if (result.summary.failed || sourceChangedDuringRun) process.exitCode = 1;
}

await main();
