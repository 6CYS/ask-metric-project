"""只读提取用户提供的存款指标映射；保留源单元格，不推断可加总或计算公式。"""
import argparse
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

import openpyxl


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    source, output = Path(args.source), Path(args.output)
    workbook = openpyxl.load_workbook(source, read_only=True, data_only=False)
    sheets, rows, metrics, formulas = [], [], [], []
    code_uses = defaultdict(list)
    for sheet in workbook:
        sheets.append({"name": sheet.title, "rows": sheet.max_row, "columns": sheet.max_column})
        headers = [str(c.value or "").replace("\n", "") for c in next(sheet.iter_rows())]
        current_group = None
        for cells in sheet.iter_rows(min_row=2):
            values = [str(c.value).strip() if c.value is not None else "" for c in cells]
            source_ref = lambda col: {"sheet": sheet.title, "cell": cells[col - 1].coordinate}
            label = values[3] or values[2]
            numbering = re.match(r"^(\d+(?:\.\d+)*)(?:\.|(?=[^\d.]))", label)
            if values[2]:
                current_group = values[2]
            aliases = [v.strip() for v in values[4].split("|") if v.strip() not in ("", "—")]
            base_code = values[5] if re.fullmatch(r"[A-Z][A-Z0-9_]+", values[5]) else None
            row = {"source": source_ref(1), "original_excel_row": values[0], "sequence": values[1],
                   "heading": values[2], "child_label": values[3], "label": label,
                   "numbering": numbering.group(1) if numbering else None,
                   "context_heading": current_group, "aliases": aliases,
                   "base_code": base_code, "base_name": values[6], "data_source": values[7],
                   "source_cells": {"label": source_ref(4 if values[3] else 3), "aliases": source_ref(5),
                                    "base_code": source_ref(6), "base_name": source_ref(7), "data_source": source_ref(8)},
                   "dimensions": [], "calculation_formula": None,
                   "tree_semantics": "display hierarchy only; no verified additive/composition contract"}
            for index in range(8, len(values)):
                code = values[index]
                if not code:
                    continue
                dim = headers[index].removesuffix("指标编码")
                metric = {"code": code, "dimension": dim, "base_code": base_code,
                          "base_name": values[6], "business_label": label, "aliases": aliases,
                          "name": values[6] if dim == "当日数" else values[6] + dim,
                          "unit": "%" if "（%）" in label or "增幅" in dim or "完成率" in dim else "亿元",
                          "source": source_ref(index + 1), "row_source": source_ref(1)}
                row["dimensions"].append({"dimension": dim, "code": code, "source": metric["source"]})
                metrics.append(metric)
                code_uses[code].append({"source": metric["source"], "label": label, "dimension": dim})
            for cell in cells:
                if cell.data_type == "f":
                    formulas.append({"source": {"sheet": sheet.title, "cell": cell.coordinate}, "formula": cell.value})
            rows.append(row)
    duplicates = [{"code": code, "uses": uses} for code, uses in code_uses.items() if len(uses) > 1]
    conflicts = [{"kind": "different_business_scope_same_code", "code": item["code"], "uses": item["uses"]}
                 for item in duplicates if any("不含协定" in use["label"] for use in item["uses"])
                 and any("含协定" in use["label"] and "不含协定" not in use["label"] for use in item["uses"])]
    result = {"schema_version": 1, "source_file": str(source), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
              "read_only": True, "values_present": False, "formulas": formulas, "sheets": sheets,
              "summary": {"business_rows": len(rows), "coded_rows": sum(bool(r["base_code"]) for r in rows),
                          "calculation_rows_without_code_or_formula": sum(not r["base_code"] for r in rows),
                          "dimensions": len({m["dimension"] for m in metrics}), "metric_cells": len(metrics),
                          "unique_codes": len(code_uses), "duplicate_codes": len(duplicates), "conflicting_codes": len(conflicts)},
              "rows": rows, "metrics": metrics, "duplicate_codes": duplicates, "conflicts": conflicts,
              "warnings": ["Workbook contains mapping metadata, not observed lake values.",
                           "Do not import conflicting aliases until scope is verified against the authoritative catalog.",
                           "Eight calculation rows have neither metric codes nor formulas; labels alone do not authorize formula inference.",
                           "Units are displayed business units, not verified storage units; verify against the formal catalog."]}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps({"output": str(output), "source_sha256": result["source_sha256"], **result["summary"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
