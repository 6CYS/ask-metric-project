import {expect, it} from "vitest";
import {loadConfig} from "../src/config.js";

const model = {AGENT_MODEL_API_KEY: "synthetic", AGENT_MODEL_BASE_URL: "http://model.test/v1", AGENT_MODEL_NAME: "synthetic"};
it("回答流式开关默认关闭，显式开启与关闭可回退，非法值拒绝启动", () => {
  expect(loadConfig(model).answerStreaming).toBe(false);
  expect(loadConfig({...model, AGENT_ANSWER_STREAMING: "true"}).answerStreaming).toBe(true);
  expect(loadConfig({...model, AGENT_ANSWER_STREAMING: "false"}).answerStreaming).toBe(false);
  expect(() => loadConfig({...model, AGENT_ANSWER_STREAMING: "invalid"})).toThrow("AGENT_ANSWER_STREAMING");
});

it("精简参数默认关闭，显式开启与回滚生效，非法值拒绝启动", () => {
  expect(loadConfig(model).compactTurnArgs).toBe(false);
  expect(loadConfig({...model, AGENT_COMPACT_TURN_ARGS: "true"}).compactTurnArgs).toBe(true);
  expect(loadConfig({...model, AGENT_COMPACT_TURN_ARGS: "false"}).compactTurnArgs).toBe(false);
  expect(() => loadConfig({...model, AGENT_COMPACT_TURN_ARGS: "invalid"})).toThrow("AGENT_COMPACT_TURN_ARGS");
});

it("新契约和自主分析默认关闭，精准查询部署配置可以原样启动", () => {
  const config = loadConfig(model);
  expect(config.turnContractV2).toBe(false);
  expect(config.analysisPlanning).toBe(false);
  expect(loadConfig({...model, AGENT_TURN_CONTRACT_V2: "true"})).toMatchObject({turnContractV2: true, analysisPlanning: false});
});

it.each([undefined, "false", "0"])("自主分析开启但V2=%s时拒绝启动，不能发布无法执行的stepRef接口", value => {
  expect(() => loadConfig({...model, AGENT_ANALYSIS_PLANNING: "true", ...(value ? {AGENT_TURN_CONTRACT_V2: value} : {})})).toThrow("AGENT_TURN_CONTRACT_V2");
});

it("自主分析与V2成对开启，允许停接新分析但保留兼容契约回滚", () => {
  expect(loadConfig({...model, AGENT_TURN_CONTRACT_V2: "true", AGENT_ANALYSIS_PLANNING: "true"})).toMatchObject({turnContractV2: true, analysisPlanning: true});
  expect(loadConfig({...model, AGENT_TURN_CONTRACT_V2: "true", AGENT_ANALYSIS_PLANNING: "false"})).toMatchObject({turnContractV2: true, analysisPlanning: false});
});

it("只关闭新分析接纳时保留V2和既有分析协议，默认仍接纳新任务", () => {
  expect(loadConfig(model).analysisAcceptNew).toBe(true);
  expect(loadConfig({...model, AGENT_TURN_CONTRACT_V2: "true", AGENT_ANALYSIS_PLANNING: "true", AGENT_ANALYSIS_ACCEPT_NEW: "false"}))
    .toMatchObject({turnContractV2: true, analysisPlanning: true, analysisAcceptNew: false});
  expect(() => loadConfig({...model, AGENT_ANALYSIS_ACCEPT_NEW: "invalid"})).toThrow("AGENT_ANALYSIS_ACCEPT_NEW");
});

it.each(["AGENT_TURN_CONTRACT_V2", "AGENT_ANALYSIS_PLANNING"])("%s非法配置明确失败", name => {
  expect(() => loadConfig({...model, [name]: "invalid"})).toThrow(name);
});

it("模型首次响应与输出空闲时限分别默认 30 秒", () => {
  const config = loadConfig(model);
  expect(config.modelFirstResponseTimeoutMs).toBe(30_000);
  expect(config.modelStreamIdleTimeoutMs).toBe(30_000);
  expect(config).not.toHaveProperty("modelTimeoutMs");
});

it("模型输出空闲新配置优先，旧变量兼容后备，不影响首次响应时限", () => {
  expect(loadConfig({...model, AGENT_MODEL_TIMEOUT_MS: "45000"}).modelStreamIdleTimeoutMs).toBe(45_000);
  const config = loadConfig({...model, AGENT_MODEL_TIMEOUT_MS: "invalid",
    AGENT_MODEL_STREAM_IDLE_TIMEOUT_MS: "60000", AGENT_MODEL_FIRST_RESPONSE_TIMEOUT_MS: "12000"});
  expect(config.modelStreamIdleTimeoutMs).toBe(60_000);
  expect(config.modelFirstResponseTimeoutMs).toBe(12_000);
  expect(loadConfig({...model, AGENT_MODEL_STREAM_IDLE_TIMEOUT_MS: "  ",
    AGENT_MODEL_TIMEOUT_MS: "45000"}).modelStreamIdleTimeoutMs).toBe(45_000);
});

it.each(["0", "-1", "invalid"])("模型响应时限非法值 %s 拒绝启动", (value) => {
  expect(() => loadConfig({...model, AGENT_MODEL_FIRST_RESPONSE_TIMEOUT_MS: value})).toThrow("AGENT_MODEL_FIRST_RESPONSE_TIMEOUT_MS");
  expect(() => loadConfig({...model, AGENT_MODEL_STREAM_IDLE_TIMEOUT_MS: value,
    AGENT_MODEL_TIMEOUT_MS: "45000"})).toThrow("AGENT_MODEL_STREAM_IDLE_TIMEOUT_MS");
  expect(() => loadConfig({...model, AGENT_MODEL_TIMEOUT_MS: value})).toThrow("AGENT_MODEL_TIMEOUT_MS");
});
