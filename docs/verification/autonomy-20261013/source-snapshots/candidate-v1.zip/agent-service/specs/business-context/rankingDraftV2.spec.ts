import {mkdtempSync, rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, describe, expect, it, vi} from "vitest";
import {validateToolArguments} from "@earendil-works/pi-ai";
import {NativeSessionStore} from "../../src/nativeSessions.js";
import {NativeFrameStore} from "../../src/business-context/store.js";
import {createResolveBusinessTurnTool, createExecuteBusinessFrameTool} from "../../src/tools/businessContext.js";
import {v2ContextDelta} from "../../src/tools/businessTurnV2.js";
import {MemoryCommandBridge, receiptJson, runTool, testRequestContext} from "../../src/tools/testUtils.js";
import type {BackendClient, BasicQuerySpec} from "../../src/backendClient.js";

const cleanup: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of cleanup.splice(0)) await close(); vi.restoreAllMocks();});
const original = "查询机构甲2026-07-31总余额排名";
const first = (operation: Record<string, unknown>) => ({capability: "metric_query", base: null, mode: "execute",
  set: {metrics: {fromQuestion: true}, organizations: "机构甲", time: "2026-07-31", operation}});

async function fixture() {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const path = mkdtempSync(join(tmpdir(), "ranking-draft-v2-")), sessions = new NativeSessionStore(path), session = await sessions.create("user-1");
  cleanup.push(async () => {await sessions.close(); rmSync(path, {recursive: true, force: true});});
  const frames = new NativeFrameStore(session), backend = {
    resolveBusinessField: vi.fn(async (entity: string, names: string[]) => ({status: "resolved", value: entity === "date"
      ? {start: "2026-07-31", end: "2026-07-31"} : {codes: [entity === "metric" ? "M" : "A"], names}})),
    matchMetricQuestion: vi.fn(async (question: string) => ({mentions: question.includes("总余额")
      ? [{text: "总余额", start: question.indexOf("总余额"), end: question.indexOf("总余额") + 3, resolution: {status: "resolved", value: {codes: ["M"], names: ["总余额"]}}}] : []})),
    createAgentQueryContext: vi.fn(async () => ({conversation_id: "fixture-conversation"})),
    basicQueries: vi.fn(async (spec: BasicQuerySpec) => ({query: spec, result: {task_id: "fixture-task", status: "succeeded", rows: [], columns: [], row_count: 0}})),
    getTask: vi.fn(async () => ({version: 1, result: {result_id: "fixture-result"}})),
  };
  const request = testRequestContext(backend as unknown as BackendClient, new MemoryCommandBridge(), {sessionId: session.metadata.id, frames, originalMessage: original});
  const call = async (args: Record<string, unknown>, message = original, turn = "op-1", v2 = true) => {
    const current = {...request, originalMessage: message, operationId: turn, requestId: turn};
    delete current.metricMentions;
    const tool = createResolveBusinessTurnTool({turnContractV2: v2});
    const validated = validateToolArguments(tool, {type: "toolCall", id: turn, name: tool.name, arguments: args});
    const receipt = receiptJson(await runTool(tool, validated, current));
    return {receipt, frame: receipt.frameId ? await frames.get(String(receipt.frameId)) : undefined, request: current};
  };
  return {frames, backend, request, call};
}

describe("V2排名草案跨轮恢复", () => {
  it("仅给方向保存具体缺项问题，下一轮条数从草案继承方向并完整执行", async () => {
    const f = await fixture(), one = await f.call(first({kind: "ranking", position: "top"}), original + "，看前面的机构");
    expect(one.receipt.status).toBe("NEEDS_CLARIFICATION");
    expect(one.frame?.fields.operation).toMatchObject({resolutionStatus: "needs_confirmation", metadata: {rankingDraft: {kind: "ranking", position: "top"}}});
    expect(one.frame?.fields.operation?.metadata?.userClarificationQuestion).toMatch(/多少名/);
    expect(f.backend.basicQueries).not.toHaveBeenCalled();
    const next = await f.call({capability: "metric_query", base: "current", mode: "execute", set: {operation: {kind: "ranking", top_n: 5}}}, "列出5名，其他不变", "next");
    expect(next.receipt.status).toBe("READY");
    expect(next.frame?.fields.operation?.resolvedValue).toEqual({kind: "ranking", position: "top", top_n: 5});
    for (const name of ["metrics", "organizations", "time"]) expect(next.frame?.fields[name]?.resolvedValue).toEqual(one.frame?.fields[name]?.resolvedValue);
    expect(receiptJson(await runTool(createExecuteBusinessFrameTool(), {frameId: next.frame!.frameId}, next.request)).status).toBe("succeeded");
    expect(f.backend.basicQueries.mock.calls[0]![0]).toMatchObject({metric_codes: ["M"], org_codes: ["A"], time: {start: "2026-07-31", end: "2026-07-31"},
      selection: "exact", operation: {kind: "ranking", position: "top", top_n: 5}});
  });

  it("仅给数量等待方向，后几名回复保留原条数", async () => {
    const f = await fixture(), one = await f.call(first({kind: "ranking", top_n: 3}), original + "，列三家");
    expect(one.receipt.status).toBe("NEEDS_CLARIFICATION");
    expect(one.frame?.fields.operation?.metadata?.rankingDraft).toEqual({kind: "ranking", top_n: 3});
    const next = await f.call({capability: "metric_query", base: "current", mode: "execute", set: {operation: {kind: "ranking", position: "bottom"}}}, "看最后面的，原条数不变", "choose-bottom");
    expect(next.receipt.status).toBe("READY");
    expect(next.frame?.fields.operation?.resolvedValue).toEqual({kind: "ranking", position: "bottom", top_n: 3});
  });

  it("两个缺项分两轮补充时每次保存进度，不猜方向或默认条数", async () => {
    const f = await fixture(), one = await f.call(first({kind: "ranking"}));
    expect(one.receipt.status).toBe("NEEDS_CLARIFICATION");
    expect(one.frame?.fields.operation?.metadata?.rankingDraft).toEqual({kind: "ranking"});
    const two = await f.call({capability: "metric_query", base: "current", mode: "execute", set: {operation: {kind: "ranking", position: "top"}}}, "先看前面的", "direction");
    expect(two.receipt.status).toBe("NEEDS_CLARIFICATION");
    expect(two.frame?.fields.operation?.metadata?.rankingDraft).toEqual({kind: "ranking", position: "top"});
    const three = await f.call({capability: "metric_query", base: "current", mode: "execute", set: {operation: {kind: "ranking", top_n: 2}}}, "2名", "count");
    expect(three.receipt.status).toBe("READY"); expect(three.frame?.fields.operation?.resolvedValue).toEqual({kind: "ranking", position: "top", top_n: 2});
    expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });

  it("用户取消排名为value后清除草案，后续重新排名不得继承已取消方向", async () => {
    const f = await fixture(); await f.call(first({kind: "ranking", position: "bottom"}));
    const canceled = await f.call({capability: "metric_query", base: "current", mode: "execute", set: {operation: {kind: "value"}}}, "取消排名，只查值", "cancel");
    expect(canceled.receipt.status).toBe("READY"); expect(canceled.frame?.fields.operation?.resolvedValue).toEqual({kind: "value"});
    expect(canceled.frame?.fields.operation?.metadata ?? {}).not.toHaveProperty("rankingDraft");
    const restart = await f.call({capability: "metric_query", base: "current", mode: "execute", set: {operation: {kind: "ranking", top_n: 3}}}, "重新排名，列3名", "restart");
    expect(restart.receipt.status).toBe("NEEDS_CLARIFICATION");
    expect(restart.frame?.fields.operation?.metadata?.rankingDraft).toEqual({kind: "ranking", top_n: 3});
  });

  it.each([0, -1, 101, 1.5, "not-a-number", null])("非法count %j 原生Schema拒绝，不保存或取数", async top_n => {
    const f = await fixture(), state = await f.frames.state();
    await expect(f.call(first({kind: "ranking", top_n}))).rejects.toThrow();
    expect(await f.frames.state()).toEqual(state); expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });

  it("legacy仍拒绝partial ranking，不因新开关改变原严格契约", async () => {
    const f = await fixture(), delta = v2ContextDelta(first({kind: "ranking", position: "top"}), f.request), state = await f.frames.state();
    const result = receiptJson(await runTool(createResolveBusinessTurnTool(), delta, f.request));
    expect(result).toMatchObject({status: "ARGUMENT_ERROR", error_code: "FIELD_INPUT_SCHEMA_INVALID"});
    expect(await f.frames.state()).toEqual(state); expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });

  it.each([false, true])("完整排名原有参数保持READY，后续仅换条数保留可信方向：v2=%s", async v2 => {
    const f = await fixture(), args = first({kind: "ranking", position: "bottom", top_n: 4});
    const input = v2 ? args : v2ContextDelta(args, f.request) as unknown as Record<string, unknown>;
    const initial = await f.call(input, original + "后4名", "initial", v2);
    expect(initial.receipt.status).toBe("READY");
    expect(initial.frame?.fields.operation?.resolvedValue).toEqual({kind: "ranking", position: "bottom", top_n: 4});
    if (v2) {
      const next = await f.call({capability: "metric_query", base: "current", mode: "execute", set: {operation: {kind: "ranking", top_n: 2}}}, "改看2名，方向和其他条件不变", "change-count");
      expect(next.receipt.status).toBe("READY"); expect(next.frame?.fields.operation?.resolvedValue).toEqual({kind: "ranking", position: "bottom", top_n: 2});
    }
  });
});
