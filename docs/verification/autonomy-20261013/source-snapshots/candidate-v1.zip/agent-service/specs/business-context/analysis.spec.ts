import {mkdtempSync, rmSync, writeFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, describe, expect, it, vi} from "vitest";
import {NativeSessionStore} from "../../src/nativeSessions.js";
import {NativeAnalysisStore, type AnalysisAnchor} from "../../src/business-context/analysis.js";
import {NativeBusinessResultStore, NativeFrameStore} from "../../src/business-context/store.js";
import {BusinessContextService} from "../../src/business-context/service.js";
import {createCapabilities} from "../../src/business-context/capabilities.js";
import {createFieldResolvers} from "../../src/business-context/resolvers.js";
import {historicalOperations} from "../../src/business-context/core.js";
import {pendingBusinessAction} from "../../src/business-context/continuation.js";
import {clarificationBlocksTurn} from "../../src/harnessHost.js";
import {createExecuteBusinessFrameTool} from "../../src/tools/businessContext.js";
import {MemoryCommandBridge, receiptJson, runTool, testRequestContext} from "../../src/tools/testUtils.js";
import {BackendApiError, type BackendClient} from "../../src/backendClient.js";
import type {BusinessFrame, ResolvedField, ResolverContext} from "../../src/business-context/types.js";

const cleanups: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of cleanups.splice(0)) await close(); vi.restoreAllMocks();});
const resolved = (resolvedValue: unknown, resolver: string): ResolvedField => ({source: "resolved", resolutionStatus: "resolved", resolvedValue, resolver});
const anchor = (org = "org-a", start = "2026-03-31", end = start): AnalysisAnchor => ({fields: {
  organizations: resolved({codes: [org], names: [org]}, "organization"), time: resolved({start, end}, "date"),
}});
async function fixture() {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const path = mkdtempSync(join(tmpdir(), "analysis-state-"));
  const sessions = new NativeSessionStore(path); const session = await sessions.create("user-1");
  cleanups.push(async () => {await sessions.close(); rmSync(path, {recursive: true, force: true});});
  const backend = {
    createAgentQueryContext: vi.fn(async () => ({conversation_id: "conversation-a"})),
    registerAnalysisConstraints: vi.fn(async (_input: unknown) => ({constraint_ref: "constraint-a", constraint_version: 1})),
    createAnalysisCatalogReferences: vi.fn(async ({metric_codes}: {metric_codes: string[]}) => ({references: metric_codes.map(code => ({metric_code: code, catalog_ref: `signed:${code}`}))})),
    prepareAnalysisQuery: vi.fn(async (input: {prepare_key: string; query: unknown; step_id: string}) => ({prepared_query_ref: `prepared:${input.step_id}`,
      prepare_key: input.prepare_key, spec_hash: "hash-a", status: "prepared", query: input.query, task_id: "task-a", task_version: 1})),
    executeAnalysisQuery: vi.fn(async () => ({query: {}, result: {status: "succeeded", task_id: "task-a", columns: ["metric_value"],
      rows: [{metric_value: "120"}], row_count: 1, truncated: false,
      facts: [{fact_id: "fact:task-a:0:metric_value", task_id: "task-a", value: "120", unit: "元", metric_code: "metric-a", metric_name: "样本余额", org_code: "org-a", org_name: "样本行", date: "2026-03-31", field: "metric_value"}]}})),
    getTask: vi.fn(async () => ({task_id: "task-a", status: "SUCCEEDED", version: 1, result: {result_id: "result-a"}})),
    getTaskResult: vi.fn(async (_id: string, offset: number) => ({status: "succeeded", task_id: "task-a", result_id: "result-a", truncated: false,
      columns: ["metric_value"], rows: [{metric_value: offset ? "100" : "120"}], row_count: 1, offset, next_offset: null, has_more: false,
      facts: [{fact_id: `fact:task-a:${offset}:metric_value`, task_id: "task-a", value: offset ? "100" : "120", unit: "元", metric_code: "metric-a", metric_name: "样本余额", org_code: "org-a", org_name: "样本行", date: offset ? "2026-02-28" : "2026-03-31", field: "metric_value"}]})),
    getPreparedAnalysisQuery: vi.fn(async () => {throw new BackendApiError(404, "not found", "ANALYSIS_PREPARED_NOT_FOUND");}),
    calculate: vi.fn(async () => ({status: "succeeded", calculation_id: "calc-a", task_id: "task-a", results: [{value: "0.2"}],
      inputs: {a: {fact_id: "fact:task-a:0:metric_value", value: "120"}, b: {fact_id: "fact:task-a:1:metric_value", value: "100"}}, public_answer: "样本增长率 20%"})),
    basicQueries: vi.fn(),
  };
  const frames = new NativeFrameStore(session); const analysis = new NativeAnalysisStore(session);
  const request = testRequestContext(backend as unknown as BackendClient, new MemoryCommandBridge(), {sessionId: session.metadata.id,
    originalMessage: "分析样本行三月底的存款情况", frames, analysis, businessResults: new NativeBusinessResultStore(session)});
  const context: ResolverContext = {originalMessage: request.originalMessage, currentDate: "2026-10-13", turnId: request.operationId,
    resolveCatalog: async (_entity, values) => ({status: "resolved", value: {start: values[0]!, end: values[0]!}}),
    resolveFactBindings: async bindings => ({status: "resolved", value: bindings})};
  const catalogRef = await analysis.issueReference("catalog", {code: "metric-a", name: "样本余额", unit: "元"}, request);
  const create = (customAnchor = anchor()) => analysis.create({goal: "描述存款经营情况", requirements: [{id: "r1", text: "余额变化"}], anchor: customAnchor,
    steps: [{id: "s1", purpose: "取得正式余额", requirementIds: ["r1"], catalogRefs: [catalogRef]}]}, request);
  return {sessions, session, backend, frames, analysis, request, context, catalogRef, create};
}

describe("分析目标、引用与准备执行", () => {
  it("持久化任务和不可变步骤，重复create幂等且重装store恢复目标", async () => {
    const f = await fixture(); const first = await f.create(); const second = await f.create();
    expect(second.analysisId).toBe(first.analysisId);
    expect(await new NativeAnalysisStore(f.session).read(first.analysisId, f.request)).toEqual(first);
    expect((await f.frames.state()).currentContext).toEqual({kind: "analysis", analysisId: first.analysisId});
    expect((await f.analysis.modelContext(f.request)).analysis?.requirements).toHaveLength(1);
  });

  it("拒绝伪造或其他用户引用，不把自由目录名称当分析来源", async () => {
    const f = await fixture();
    await expect(f.analysis.create({goal: "分析", requirements: [{text: "余额"}], anchor: anchor(), steps: [{purpose: "查询", requirementIds: ["requirement-1"], catalogRefs: ["catalogRef:fake"]}]}, f.request)).rejects.toMatchObject({code: "ANALYSIS_REFERENCE_UNAVAILABLE"});
    await expect(f.analysis.reference(f.catalogRef, "catalog", {...f.request, actor: {...f.request.actor, id: "other-user"}})).rejects.toMatchObject({code: "ANALYSIS_REFERENCE_UNAVAILABLE"});
  });

  it("点名指标未决不会被目录探索覆盖，跨轮确认保留既定项及原始身份绑定", async () => {
    const f = await fixture(); const original = "分析样本行贷款余额当日数、存款余额";
    const fixedText = "贷款余额当日数"; const pendingText = "存款余额";
    const scope = anchor();
    scope.fields.metrics = {source: "explicit", resolver: "metric", resolutionStatus: "needs_confirmation", rawValue: {fromQuestion: true},
      resolvedValue: {codes: ["metric-old"], names: [fixedText]},
      candidates: [{value: "样本余额", code: "metric-a", metadata: {rawValueIndex: 1}}, {value: "另一余额", code: "metric-b", metadata: {rawValueIndex: 1}}],
      metadata: {questionText: original, pendingRawValues: [["metric-old"], pendingText], extractedRawValues: [fixedText, pendingText],
        mentionResolutions: [
          {text: fixedText, start: original.indexOf(fixedText), end: original.indexOf(fixedText) + fixedText.length, status: "resolved", value: {codes: ["metric-old"], names: [fixedText]}},
          {text: pendingText, start: original.indexOf(pendingText), end: original.indexOf(pendingText) + pendingText.length, status: "needs_confirmation",
            candidates: [{value: "样本余额", code: "metric-a"}, {value: "另一余额", code: "metric-b"}]},
        ]}};
    const request = {...f.request, originalMessage: original};
    const task = await f.analysis.create({goal: "比较", anchor: scope, requirements: [{id: "r1", text: "两个指标"}],
      steps: [{purpose: "取证", requirementIds: ["r1"], catalogRefs: [f.catalogRef]}]}, request);
    const blocked = await f.analysis.resolveStep(task.steps[0]!.stepRef, request, f.context);
    expect(blocked.status).toBe("clarifying"); expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled();
    await expect(f.analysis.resolveAnchorMetrics(task.analysisId, {confirm: true}, request, f.context)).rejects.toMatchObject({code: "CONFIRMATION_REQUIRES_USER_TURN"});
    const reply = {...request, originalMessage: "第一个", operationId: "reply-turn", requestId: "reply-request"};
    const confirmed = await f.analysis.resolveAnchorMetrics(task.analysisId, {confirm: true}, reply, {...f.context, originalMessage: reply.originalMessage, turnId: reply.operationId});
    expect(confirmed.fields.metrics?.resolvedValue).toEqual({codes: ["metric-old", "metric-a"], names: [fixedText, "样本余额"]});
    const revised = await f.analysis.revise(task.analysisId, 1, {anchor: confirmed}, reply);
    await f.analysis.resolveStep(revised.steps[0]!.stepRef, reply, {...f.context, turnId: reply.operationId});
    const constraints = f.backend.registerAnalysisConstraints.mock.calls[0]![0] as Record<string, unknown>;
    expect(constraints).toMatchObject({constraint_version: 2, source_question: "第一个", metric_source_question: original,
      source_metric_bindings: [{text: fixedText, codes: ["metric-old"]}, {text: pendingText, codes: ["metric-a"]}],
      fixed_metric_updates: [{target_id: "target-1", mode: "replace", codes: ["metric-old", "metric-a"], source_span: {text: "第一个"}}]});
    if (process.env.ANALYSIS_CONFIRMATION_FIXTURE) writeFileSync(process.env.ANALYSIS_CONFIRMATION_FIXTURE,
      JSON.stringify({provenance: "Actual NativeAnalysisStore pending-frame confirmation calls with synthetic candidate identities.", confirmed_constraints: constraints}, null, 2) + "\n");
  });

  it("从真实目录选择用户未点名指标，经新prepare执行且直接查询覆盖入口零调用", async () => {
    const f = await fixture(); const task = await f.create(); const step = task.steps[0]!;
    const frame = await f.analysis.resolveStep(step.stepRef, f.request, f.context);
    expect(frame.status).toBe("ready"); expect(frame.analysisRef?.preparedQueryRef).toBe("prepared:s1");
    expect(f.backend.registerAnalysisConstraints.mock.calls[0]![0]).toMatchObject({targets: [{org_codes: ["org-a"], metric_selection_policy: "catalog"}]});
    const output = await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    expect(receiptJson(output).status).toBe("succeeded");
    expect(f.backend.executeAnalysisQuery).toHaveBeenCalledTimes(1); expect(f.backend.basicQueries).not.toHaveBeenCalled();
    if (process.env.ANALYSIS_CONTRACT_FIXTURE) writeFileSync(process.env.ANALYSIS_CONTRACT_FIXTURE, JSON.stringify({
      provenance: "Generated from NativeAnalysisStore and BusinessToolRegistry actual calls with isolated synthetic backend fixtures; no production data.",
      constraints: f.backend.registerAnalysisConstraints.mock.calls[0]![0],
      catalog_references: f.backend.createAnalysisCatalogReferences.mock.calls[0]![0],
      prepare: f.backend.prepareAnalysisQuery.mock.calls[0]![0],
      execute: {prepared_query_ref: frame.analysisRef!.preparedQueryRef},
    }, null, 2) + "\n");
    expect((await f.frames.state()).focusFrameId).toBeUndefined();
    expect(historicalOperations(await f.frames.state(), await f.frames.list())).toEqual([]);
  });

  it("辅助步骤能自动接续，独立执行不依赖旧query焦点", async () => {
    const f = await fixture(); const task = await f.create(); const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    const action = await pendingBusinessAction([{role: "toolResult", toolName: "resolve_business_turn", toolCallId: "tc-a", content: [], isError: false,
      timestamp: 0, details: {kind: "business_context", status: "READY", frame_id: frame.frameId}}], f.request);
    expect(action).toEqual({name: "execute_business_frame", arguments: {frameId: frame.frameId}});
  });

  it("同轮回执丢失后仅在明确prepared状态使用原引用及原键恢复", async () => {
    const f = await fixture(); const task = await f.create();
    const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    f.backend.executeAnalysisQuery.mockRejectedValueOnce(new BackendApiError(503, "response lost", "TRANSPORT_ERROR"));
    expect(receiptJson(await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request)).status).toBe("error");
    const prepared = await f.backend.prepareAnalysisQuery.mock.results[0]!.value;
    f.backend.getPreparedAnalysisQuery.mockResolvedValueOnce({...prepared, status: "prepared"} as never);
    const recovered = await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    expect(receiptJson(recovered)).toMatchObject({status: "succeeded", result_id: "result-a", analysis_id: task.analysisId, step_id: "s1"});
    expect(f.backend.executeAnalysisQuery.mock.calls).toEqual([
      [prepared.prepared_query_ref, prepared.prepare_key, expect.anything()],
      [prepared.prepared_query_ref, prepared.prepare_key, expect.anything()],
    ]);
    expect(f.backend.prepareAnalysisQuery).toHaveBeenCalledTimes(1); expect(f.backend.basicQueries).not.toHaveBeenCalled();
    expect((await f.frames.get(recovered.details.frame_id))?.status).toBe("success");
  });

  it("已登记SQL超时用原键收敛失败，失败回执仍关联当前分析步骤", async () => {
    const f = await fixture(); const task = await f.create();
    const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    f.backend.executeAnalysisQuery.mockRejectedValueOnce(new BackendApiError(503, "response lost", "TRANSPORT_ERROR"));
    await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    const prepared = await f.backend.prepareAnalysisQuery.mock.results[0]!.value;
    f.backend.getPreparedAnalysisQuery.mockResolvedValueOnce({...prepared, status: "interrupted"} as never);
    f.backend.executeAnalysisQuery.mockResolvedValueOnce({result: {status: "failed", error_code: "QUERY_EXECUTION_INTERRUPTED"}} as never);
    f.backend.getTask.mockResolvedValueOnce({task_id: "task-a", status: "FAILED", error_code: "QUERY_EXECUTION_INTERRUPTED"} as never);
    const recovered = await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    expect(receiptJson(recovered)).toMatchObject({status: "failed", error_code: "QUERY_EXECUTION_INTERRUPTED", analysis_id: task.analysisId, step_id: "s1"});
    expect(f.backend.executeAnalysisQuery.mock.calls[1]).toEqual([prepared.prepared_query_ref, prepared.prepare_key, expect.anything()]);
    expect(f.backend.executeAnalysisQuery).toHaveBeenCalledTimes(2); expect(f.backend.prepareAnalysisQuery).toHaveBeenCalledTimes(1);
    const failed = (await f.frames.get(recovered.details.frame_id))!;
    await f.analysis.observeFrame(failed, receiptJson(recovered), f.request);
    expect((await f.analysis.read(task.analysisId, f.request))?.steps[0]?.status).toBe("failed");
    await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    expect(f.backend.executeAnalysisQuery).toHaveBeenCalledTimes(2);
  });

  it.each(["executing", "unknown", "network"])("同轮回查%s时保持executing且不重发", async status => {
    const f = await fixture(); const task = await f.create();
    const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    f.backend.executeAnalysisQuery.mockRejectedValueOnce(new BackendApiError(503, "response lost", "TRANSPORT_ERROR"));
    await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    const prepared = await f.backend.prepareAnalysisQuery.mock.results[0]!.value;
    if (status === "network") f.backend.getPreparedAnalysisQuery.mockRejectedValueOnce(new BackendApiError(503, "unavailable", "BACKEND_UNAVAILABLE"));
    else f.backend.getPreparedAnalysisQuery.mockResolvedValueOnce({...prepared, status} as never);
    const pending = await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    expect(receiptJson(pending)).toMatchObject({status: "error", error_code: "QUERY_ALREADY_RUNNING"});
    expect(f.backend.executeAnalysisQuery).toHaveBeenCalledTimes(1); expect(f.backend.getTask).not.toHaveBeenCalled();
    expect((await f.frames.list()).filter(item => item.operationFrameId === frame.operationFrameId).at(-1)?.status).toBe("executing");
  });

  it.each(["settled", "invalidated"])("同轮回查%s只回读终态或拒绝旧引用", async status => {
    const f = await fixture(); const task = await f.create();
    const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    f.backend.executeAnalysisQuery.mockRejectedValueOnce(new BackendApiError(503, "response lost", "TRANSPORT_ERROR"));
    await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    const prepared = await f.backend.prepareAnalysisQuery.mock.results[0]!.value;
    f.backend.getPreparedAnalysisQuery.mockResolvedValueOnce({...prepared, status} as never);
    const recovered = await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    expect(receiptJson(recovered)).toMatchObject(status === "settled" ? {status: "succeeded"} : {status: "failed", error_code: "ANALYSIS_STEP_STALE"});
    expect(f.backend.executeAnalysisQuery).toHaveBeenCalledTimes(1);
    expect(f.backend.getTask).toHaveBeenCalledTimes(status === "settled" ? 1 : 0);
  });

  it("辅助步骤不挤占旧ordinal，显式选择历史查询与分析都能恢复讨论焦点", async () => {
    const f = await fixture();
    const primary: BusinessFrame = {frameId: "primary", sessionId: f.request.sessionId, turnId: "old-turn", requestId: "old-request",
      capability: "metric_query", operationFrameId: "primary", fields: anchor().fields,
      delta: {baseReference: null, fieldChanges: [], executionMode: "execute"}, status: "success", resultRef: "query:old-task:old-result", issues: [], createdAt: new Date().toISOString()};
    await f.frames.save(primary, 0, "seed-primary");
    const task = await f.create(); await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    expect((await f.frames.state()).focusFrameId).toBe("primary");
    expect(historicalOperations(await f.frames.state(), await f.frames.list())).toEqual(["primary"]);
    await f.frames.setFocus("primary", (await f.frames.state()).version);
    expect((await f.analysis.modelContext(f.request)).currentContext).toEqual({kind: "frame", frameId: "primary"});
    await f.analysis.activate(task.analysisId, f.request);
    expect((await f.analysis.modelContext(f.request)).currentContext).toEqual({kind: "analysis", analysisId: task.analysisId});
  });

  it("分析讨论中current查询不会误继承此前焦点，明确新查询仍能切回frame", async () => {
    const f = await fixture(); await f.create();
    const service = new BusinessContextService(f.frames, createCapabilities(), createFieldResolvers());
    await expect(service.resolve({baseReference: "current", fieldChanges: [], executionMode: "execute"},
      {sessionId: f.request.sessionId, requestId: f.request.requestId, turnId: f.request.operationId}, f.context)).rejects.toMatchObject({code: "ANALYSIS_CONTEXT_ACTIVE"});
  });

  it("一步需澄清不阻断独立可执行分支，依赖分支不能提前执行", async () => {
    const f = await fixture(); const task = await f.analysis.create({goal: "两个独立时点", anchor: anchor("org-a", "2026-02-28", "2026-03-31"),
      requirements: [{id: "r1", text: "比较"}], steps: [
        {id: "pending", purpose: "待选择", requirementIds: ["r1"], catalogRefs: [f.catalogRef], time: "未定日期", selection: "exact"},
        {id: "independent", purpose: "已知日", requirementIds: ["r1"], catalogRefs: [f.catalogRef], time: "2026-03-31"},
        {id: "dependent", purpose: "等取证", requirementIds: ["r1"], catalogRefs: [f.catalogRef], dependsOn: ["pending"]},
      ]}, f.request);
    const pending = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, {...f.context,
      resolveCatalog: async (entity, values) => values[0] === "未定日期" ? {status: "ambiguous"} : f.context.resolveCatalog(entity, values)});
    expect(pending.status).toBe("clarifying");
    expect(await clarificationBlocksTurn({frame_id: pending.frameId}, f.request)).toBe(false);
    await expect(f.analysis.resolveStep(task.steps[2]!.stepRef, f.request, f.context)).rejects.toMatchObject({code: "ANALYSIS_DEPENDENCY_PENDING"});
  });

  it("分析范围缺取证方式是模型参数纠错，不默认最新日或转交用户", async () => {
    const f = await fixture(); const task = await f.create(anchor("org-a", "2026-02-28", "2026-03-31"));
    await expect(f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context)).rejects.toMatchObject({code: "ANALYSIS_STEP_ARGUMENTS_INVALID"});
    expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled();
    const next = await f.analysis.revise(task.analysisId, 1, {steps: [{id: "s1", purpose: "取得正式余额", requirementIds: ["r1"], catalogRefs: [f.catalogRef], selection: "all_in_range"}]}, f.request);
    expect((await f.analysis.resolveStep(next.steps[0]!.stepRef, f.request, f.context)).status).toBe("ready");
  });

  it("固定机构改变后递增constraint与step版本，旧引用不能执行", async () => {
    const f = await fixture(); const task = await f.create(); const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    const next = await f.analysis.revise(task.analysisId, 1, {anchor: anchor("org-b")}, {...f.request, operationId: "op-b", requestId: "req-b", originalMessage: "那乙行呢"});
    expect(next.constraintVersion).toBe(2); expect(next.steps[0]!.stepRevision).toBe(2);
    await expect(f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context)).rejects.toMatchObject({code: "ANALYSIS_STEP_STALE"});
    const service = new BusinessContextService(f.frames, createCapabilities(), createFieldResolvers());
    await expect(service.beginExecution(frame.frameId, {sessionId: f.request.sessionId, turnId: f.request.operationId, requestId: f.request.requestId})).rejects.toMatchObject({code: "ANALYSIS_STEP_STALE"});
  });

  it("计划其他分支改变保留未变步骤，要求不能静默删除", async () => {
    const f = await fixture(); const task = await f.create();
    const first = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    const next = await f.analysis.revise(task.analysisId, 1, {steps: [{id: "s1", purpose: "取得正式余额", requirementIds: ["r1"], catalogRefs: [f.catalogRef]},
      {id: "s2", purpose: "补证据", requirementIds: ["r1"], catalogRefs: [f.catalogRef]}]}, f.request);
    expect(next.steps[0]!.stepRef).toBe(task.steps[0]!.stepRef);
    expect(next.steps[0]!.preparedQueryRef).toBe(first.analysisRef!.preparedQueryRef); expect(next.steps[0]!.stepRevision).toBe(1);
    await expect(f.analysis.revise(task.analysisId, 2, {requirements: [{id: "r2", text: "另一个"}]}, f.request)).rejects.toMatchObject({code: "ANALYSIS_REQUIREMENTS_PRESERVED"});
  });

  it("多target保持机构日期绑定，缺targetId拒绝而非产生乘积", async () => {
    const f = await fixture(); const multi: AnalysisAnchor = {...anchor(), targets: [
      {targetId: "a", fields: anchor("org-a", "2026-02-28").fields}, {targetId: "b", fields: anchor("org-b", "2026-03-31").fields},
    ]};
    await expect(f.create(multi)).rejects.toMatchObject({code: "ANALYSIS_TARGET_REQUIRED"});
    const task = await f.analysis.create({goal: "分别查询", anchor: multi, requirements: [{id: "r1", text: "两个目标"}],
      steps: [{purpose: "只查乙", targetId: "b", requirementIds: ["r1"], catalogRefs: [f.catalogRef]}]}, f.request);
    const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    expect(frame.fields.organizations?.resolvedValue).toMatchObject({codes: ["org-b"]});
    expect(frame.fields.time?.resolvedValue).toMatchObject({start: "2026-03-31", end: "2026-03-31"});
  });

  it("prepare断连后按已持久化键回查，不再新建准备", async () => {
    const f = await fixture(); const task = await f.create();
    f.backend.prepareAnalysisQuery.mockRejectedValueOnce(new Error("network-lost"));
    await expect(f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context)).rejects.toThrow("network-lost");
    const stored = (await f.analysis.read(task.analysisId, f.request))!;
    expect(stored.steps[0]!.prepareKey).toBeTruthy();
    f.backend.getPreparedAnalysisQuery.mockResolvedValueOnce({prepared_query_ref: "recovered-ref", prepare_key: stored.steps[0]!.prepareKey!,
      spec_hash: "recovered-hash", status: "prepared", query: stored.steps[0]!.preparedSpec, task_id: "task-a", task_version: 1} as never);
    const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, {...f.request, operationId: "op-resume", requestId: "req-resume"}, f.context);
    expect(frame.analysisRef?.preparedQueryRef).toBe("recovered-ref"); expect(f.backend.prepareAnalysisQuery).toHaveBeenCalledTimes(1);
  });

  it("准备规范冻结相对日期，跨轮物化不按新的日历重新解释", async () => {
    const f = await fixture(); const task = await f.analysis.create({goal: "固定范围", anchor: anchor("org-a", "2026-02-28", "2026-04-30"),
      requirements: [{id: "r1", text: "月末值"}], steps: [{purpose: "取月末", requirementIds: ["r1"], catalogRefs: [f.catalogRef], time: "上月末"}]}, f.request);
    const resolve = vi.fn(async () => ({status: "resolved" as const, value: {start: "2026-03-31", end: "2026-03-31"}}));
    await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, {...f.context, resolveCatalog: resolve});
    const second = await f.analysis.resolveStep(task.steps[0]!.stepRef, {...f.request, operationId: "another-turn", requestId: "another-request"},
      {...f.context, resolveCatalog: async () => {throw new Error("must-not-reparse-frozen-date");}});
    expect(second.fields.time?.resolvedValue).toEqual({start: "2026-03-31", end: "2026-03-31"}); expect(resolve).toHaveBeenCalledTimes(1);
  });

  it("准备响应丢失后回查到invalidated不能恢复为READY", async () => {
    const f = await fixture(); const task = await f.create();
    f.backend.prepareAnalysisQuery.mockRejectedValueOnce(new Error("network-lost"));
    await expect(f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context)).rejects.toThrow("network-lost");
    const stored = (await f.analysis.read(task.analysisId, f.request))!;
    f.backend.getPreparedAnalysisQuery.mockResolvedValueOnce({prepared_query_ref: "old-ref", prepare_key: stored.steps[0]!.prepareKey!,
      spec_hash: "old-hash", status: "invalidated", query: stored.steps[0]!.preparedSpec, task_id: "task-a", task_version: 1} as never);
    await expect(f.analysis.resolveStep(task.steps[0]!.stepRef, {...f.request, operationId: "resume-turn", requestId: "resume-request"}, f.context)).rejects.toMatchObject({code: "ANALYSIS_STEP_STALE"});
  });
});

describe("分析证据和正式计算", () => {
  it("取数后只追加计算步骤，原查询与证据继续支持原要求", async () => {
    const f = await fixture(); const task = await f.create();
    const ready = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    const output = await runTool(createExecuteBusinessFrameTool(), {frameId: ready.frameId}, f.request);
    await f.analysis.observeFrame((await f.frames.get(output.details.frame_id))!, receiptJson(output), f.request);
    const before = (await f.analysis.read(task.analysisId, f.request))!;
    const methodRef = await f.analysis.issueReference("method", {id: "difference", expression: "a-b", display: "decimal"}, f.request);
    const revised = await f.analysis.revise(task.analysisId, 1, {requirements: [{id: "r1", text: "余额变化"}, {id: "r2", text: "计算差额", evidenceKind: "calculation"}],
      steps: [{kind: "calculation", purpose: "追加计算", requirementIds: ["r2"], methodRef,
        bindings: {a: {fact_id: "fact:task-a:0:metric_value"}, b: {fact_id: "fact:task-a:0:metric_value"}}}]}, f.request);
    expect(revised.steps).toHaveLength(2); expect(revised.steps[0]!.status).toBe("succeeded");
    expect(revised.steps[0]!.stepRef).toBe(before.steps[0]!.stepRef); expect(revised.evidence).toEqual(before.evidence);
    const partial = await f.analysis.complete(task.analysisId, 2, {partial: true, coverage: [{requirementId: "r1", evidenceRefs: before.steps[0]!.evidenceRefs}]}, f.request);
    expect(partial.requirements[0]!.status).toBe("satisfied"); expect(partial.requirements[1]!.status).toBe("pending");
  });
  it("未取证不能complete，截断结果只能partial并保留要求", async () => {
    const f = await fixture(); const task = await f.create();
    await expect(f.analysis.complete(task.analysisId, 1, {coverage: []}, f.request)).rejects.toMatchObject({code: "ANALYSIS_REQUIREMENTS_INCOMPLETE"});
    const partial = await f.analysis.complete(task.analysisId, 1, {coverage: [], partial: true}, f.request);
    expect(partial.status).toBe("partial"); expect(partial.gaps).toEqual(["余额变化"]);
  });

  it("执行正式方法并记录计算证据，不能用查询证据代替计算要求", async () => {
    const f = await fixture();
    await f.request.commands.setConversationId("conversation-a");
    const methodRef = await f.analysis.issueReference("method", {id: "growth_rate", expression: "(a-b)/abs(b)", display: "percent"}, f.request);
    const task = await f.analysis.create({goal: "比较增长", anchor: anchor("org-a", "2026-02-28", "2026-03-31"),
      requirements: [{id: "r1", text: "增长率", evidenceKind: "calculation"}], steps: [{id: "calc", kind: "calculation", purpose: "计算增长率",
        requirementIds: ["r1"], methodRef, bindings: {a: {fact_id: "fact:task-a:0:metric_value"}, b: {fact_id: "fact:task-a:1:metric_value"}}}]}, f.request);
    const frame = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    expect(frame.capability).toBe("metric_calculate"); expect(frame.fields.scope_policy?.resolvedValue).toBe("cross_date");
    const output = await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request);
    expect(receiptJson(output).status).toBe("succeeded"); expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled();
    const completeFrame = await f.frames.get(output.details.frame_id) as BusinessFrame;
    await f.analysis.observeFrame(completeFrame, receiptJson(output), f.request);
    const recorded = (await f.analysis.read(task.analysisId, f.request))!;
    expect(recorded.evidence[0]!.kind).toBe("calculation");
    const complete = await f.analysis.complete(task.analysisId, 1, {coverage: [{requirementId: "r1", evidenceRefs: [recorded.evidence[0]!.ref]}]}, f.request);
    expect(complete.status).toBe("complete");
  });

  it("拒绝方法引用改公式及不可比事实，不把同单位当完整业务关系", async () => {
    const f = await fixture(); const methodRef = await f.analysis.issueReference("method", {id: "difference", expression: "a+b", display: "decimal"}, f.request);
    const task = await f.analysis.create({goal: "比较", anchor: anchor(), requirements: [{id: "r1", text: "差额"}], steps: [{kind: "calculation", purpose: "算差额",
      requirementIds: ["r1"], methodRef, bindings: {a: {fact_id: "fact:task-a:0:metric_value"}, b: {fact_id: "fact:task-a:1:metric_value"}}}]}, f.request);
    await expect(f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context)).rejects.toMatchObject({code: "ANALYSIS_METHOD_INVALID"});
  });

  it("查询成功不能代替计算要求，空值和后续分页也不能发行完整证据", async () => {
    const f = await fixture(); const task = await f.analysis.create({goal: "需要计算", anchor: anchor(),
      requirements: [{id: "r1", text: "增长率", evidenceKind: "calculation"}],
      steps: [{purpose: "基础查询", requirementIds: ["r1"], catalogRefs: [f.catalogRef]}]}, f.request);
    const ready = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    const output = await runTool(createExecuteBusinessFrameTool(), {frameId: ready.frameId}, f.request);
    const frame = (await f.frames.get(output.details.frame_id))!;
    await f.analysis.observeFrame(frame, receiptJson(output), f.request);
    let recorded = (await f.analysis.read(task.analysisId, f.request))!;
    await expect(f.analysis.complete(task.analysisId, 1, {coverage: [{requirementId: "r1", evidenceRefs: recorded.evidence.map(item => item.ref)}]}, f.request)).rejects.toMatchObject({code: "ANALYSIS_EVIDENCE_INVALID"});
    const nullReceipt = {...receiptJson(output), facts: [{fact_id: "fact:task-a:0:metric_value", value: null}]};
    // 用独立正式resultRef模拟另一份有空值的回执，避免不可变证据引用被后续覆盖。
    await f.analysis.observeFrame({...frame, resultRef: "query:null-task:null-result"}, nullReceipt, f.request);
    await f.analysis.observeFrame({...frame, resultRef: "query:page-task:page-result"}, {...receiptJson(output), offset: 20}, f.request);
    recorded = (await f.analysis.read(task.analysisId, f.request))!;
    expect(recorded.evidence.slice(1).every(item => !item.complete)).toBe(true);
  });

  it.each(["missing_org", "missing_date"])("%s 不因同指标有一个值就完成整个步骤", async kind => {
    const f = await fixture(); const scope = anchor();
    if (kind === "missing_org") scope.fields.organizations = resolved({codes: ["org-a", "org-b"], names: ["样本甲", "样本乙"]}, "organization");
    else scope.fields.time = resolved({start: "2026-02-28", end: "2026-03-31", dates: ["2026-02-28", "2026-03-31"]}, "date");
    const task = await f.analysis.create({goal: "完整比较", anchor: scope, requirements: [{id: "r1", text: "全部目标"}],
      steps: [{purpose: "完整取数", requirementIds: ["r1"], catalogRefs: [f.catalogRef], selection: "exact"}]}, f.request);
    const ready = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    const output = await runTool(createExecuteBusinessFrameTool(), {frameId: ready.frameId}, f.request);
    await f.analysis.observeFrame((await f.frames.get(output.details.frame_id))!, receiptJson(output), f.request);
    const recorded = (await f.analysis.read(task.analysisId, f.request))!;
    expect(recorded.evidence[0]!.complete).toBe(false);
    await expect(f.analysis.complete(task.analysisId, 1, {coverage: [{requirementId: "r1", evidenceRefs: [recorded.evidence[0]!.ref]}]}, f.request)).rejects.toMatchObject({code: "ANALYSIS_EVIDENCE_INVALID"});
  });

  it("完整子步骤不能冒充全部固定离散日，多步证据可聚合覆盖原目标", async () => {
    const f = await fixture(); const scope = anchor();
    scope.fields.time = resolved({start: "2026-02-28", end: "2026-03-31", dates: ["2026-02-28", "2026-03-31"]}, "date");
    scope.fields.metrics = resolved({codes: ["metric-a"], names: ["样本余额"]}, "metric");
    const task = await f.analysis.create({goal: "两个固定时点", anchor: scope, requirements: [{id: "r1", text: "两期完整数据"}],
      steps: [{id: "march", purpose: "三月", requirementIds: ["r1"], catalogRefs: [f.catalogRef], time: "2026-03-31"},
        {id: "february", purpose: "二月", requirementIds: ["r1"], catalogRefs: [f.catalogRef], time: "2026-02-28"}]}, f.request);
    const march = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    const output = await runTool(createExecuteBusinessFrameTool(), {frameId: march.frameId}, f.request);
    await f.analysis.observeFrame((await f.frames.get(output.details.frame_id))!, receiptJson(output), f.request);
    let current = (await f.analysis.read(task.analysisId, f.request))!;
    expect(current.evidence[0]!.complete).toBe(true);
    await expect(f.analysis.complete(task.analysisId, 1, {coverage: [{requirementId: "r1", evidenceRefs: current.evidence.map(item => item.ref)}]}, f.request)).rejects.toMatchObject({code: "ANALYSIS_FIXED_TARGETS_INCOMPLETE"});
    f.backend.executeAnalysisQuery.mockResolvedValueOnce({query: {}, result: {status: "succeeded", task_id: "task-b", columns: ["metric_value"], rows: [{metric_value: "100"}], row_count: 1, truncated: false,
      facts: [{fact_id: "fact:task-b:0:metric_value", task_id: "task-b", field: "metric_value", value: "100", unit: "元", metric_code: "metric-a", metric_name: "样本余额", org_code: "org-a", org_name: "样本行", date: "2026-02-28"}]}});
    const february = await f.analysis.resolveStep(task.steps[1]!.stepRef, f.request, f.context);
    const second = await runTool(createExecuteBusinessFrameTool(), {frameId: february.frameId}, f.request);
    await f.analysis.observeFrame((await f.frames.get(second.details.frame_id))!, receiptJson(second), f.request);
    current = (await f.analysis.read(task.analysisId, f.request))!;
    expect((await f.analysis.complete(task.analysisId, 1, {coverage: [{requirementId: "r1", evidenceRefs: current.evidence.map(item => item.ref)}]}, f.request)).status).toBe("complete");
  });

  it("修订后的迟到结果保留审计且不能完成新要求，也不夺回焦点", async () => {
    const f = await fixture(); const task = await f.create(); const ready = await f.analysis.resolveStep(task.steps[0]!.stepRef, f.request, f.context);
    const service = new BusinessContextService(f.frames, createCapabilities(), createFieldResolvers());
    const executing = await service.beginExecution(ready.frameId, {sessionId: f.request.sessionId, turnId: f.request.operationId, requestId: f.request.requestId});
    await f.analysis.revise(task.analysisId, 1, {anchor: anchor("org-b")}, {...f.request, originalMessage: "那乙行呢"});
    const late = await service.finishExecution(executing, {status: "success", resultRef: "query:task-a:result-a"});
    await f.analysis.observeFrame(late, {facts: [{fact_id: "fact:task-a:0:metric_value", value: "120"}], row_count: 1}, f.request);
    const recorded = (await f.analysis.read(task.analysisId, f.request))!;
    expect(recorded.evidence).toHaveLength(1); expect(recorded.evidence[0]!.constraintVersion).toBe(1);
    expect(recorded.steps[0]!.status).toBe("planned"); expect((await f.frames.state()).focusFrameId).toBeUndefined();
    await expect(f.analysis.complete(task.analysisId, 2, {coverage: [{requirementId: "r1", evidenceRefs: [recorded.evidence[0]!.ref]}]}, f.request)).rejects.toMatchObject({code: "ANALYSIS_EVIDENCE_INVALID"});
  });
});
