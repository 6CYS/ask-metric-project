import {mkdtempSync, rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, describe, expect, it, vi} from "vitest";
import {validateToolArguments} from "@earendil-works/pi-ai";
import {NativeSessionStore} from "../../src/nativeSessions.js";
import {NativeFrameStore} from "../../src/business-context/store.js";
import {BusinessContextService} from "../../src/business-context/service.js";
import {createCapabilities} from "../../src/business-context/capabilities.js";
import {createFieldResolvers} from "../../src/business-context/resolvers.js";
import {createResolveBusinessTurnTool, createBusinessContextReadTool, createExecuteBusinessFrameTool} from "../../src/tools/businessContext.js";
import {MemoryCommandBridge, receiptJson, runTool, testRequestContext} from "../../src/tools/testUtils.js";
import type {BackendClient, BasicQuerySpec} from "../../src/backendClient.js";
import type {FieldResolution} from "../../src/business-context/types.js";

const cleanup: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of cleanup.splice(0)) await close(); vi.restoreAllMocks();});
const original = "把机构改为机构乙，日期改为2026年8月，取该月最后有数据日期，其余不变";
const wrong = {capability: "metric_query", base: "current", mode: "execute", set: {organizations: "机构乙", time: "2026年8月", selection: "exact"}};
const correction = (attemptRef: string) => ({capability: "metric_query", attemptRef, set: {selection: "latest_in_range"}});

async function fixture() {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const path = mkdtempSync(join(tmpdir(), "turn-attempt-v2-")), sessions = new NativeSessionStore(path), session = await sessions.create("user-1");
  cleanup.push(async () => {await sessions.close(); rmSync(path, {recursive: true, force: true});});
  const frames = new NativeFrameStore(session), service = new BusinessContextService(frames, createCapabilities(), createFieldResolvers());
  const orgs = new Map([["机构甲", "A"], ["机构乙", "B"], ["机构丙", "C"]]);
  const resolve = vi.fn(async (entity: string, names: string[]): Promise<FieldResolution> => {
    if (entity === "date") return {status: "resolved", value: names[0] === "2026年8月" ? {start: "2026-08-01", end: "2026-08-31"} : {start: names[0], end: names[0]}};
    if (entity === "metric") return {status: "resolved", value: {codes: [names[0] === "贷款余额" || names[0] === "L" ? "L" : "M"], names: [names[0] === "贷款余额" || names[0] === "L" ? "贷款余额" : "总余额"]}};
    const codes = names.map(name => orgs.get(name) ?? ([...orgs.values()].includes(name) ? name : undefined));
    return {status: "resolved", value: {codes, names: codes.map(code => [...orgs].find(([, value]) => value === code)![0])}};
  });
  const backend = {resolveBusinessField: resolve, createAgentQueryContext: vi.fn(async () => ({conversation_id: "fixture-conversation"})),
    basicQueries: vi.fn(async (spec: BasicQuerySpec) => ({query: spec, result: {task_id: "fixture-task", status: "succeeded", columns: [], rows: [], row_count: 0}})),
    getTask: vi.fn(async () => ({version: 1, result: {result_id: "fixture-result"}}))};
  const request = testRequestContext(backend as unknown as BackendClient, new MemoryCommandBridge(), {sessionId: session.metadata.id, frames,
    operationId: "accepted-operation", requestId: "accepted-request", promptFingerprint: "accepted-prompt-hash", originalMessage: original});
  const seed = async (org: string, metric: string, date: string, index: number) => {
    const identity = {sessionId: session.metadata.id, requestId: `seed-${index}`, turnId: `seed-${index}`};
    const ready = await service.resolve({capabilityHint: "metric_query", baseReference: null, executionMode: "execute", fieldChanges: [
      {fieldHint: "organizations", operation: "set", rawValue: org}, {fieldHint: "metrics", operation: "set", rawValue: metric},
      {fieldHint: "time", operation: "set", rawValue: date}, {fieldHint: "selection", operation: "set", rawValue: "exact"},
    ]}, identity, {originalMessage: `${org}${date}${metric}`, currentDate: "2026-10-14", turnId: identity.turnId, resolveCatalog: resolve});
    return service.finishExecution(await service.beginExecution(ready.frameId, identity), {status: "success", resultRef: `query:seed-${index}:result`});
  };
  const base = await seed("机构甲", "总余额", "2026-07-31", 1), other = await seed("机构丙", "贷款余额", "2026-06-30", 2);
  await runTool(createBusinessContextReadTool(), {frameId: base.frameId, setFocus: true}, request);
  const call = async (args: Record<string, unknown>, current = request) => {
    const tool = createResolveBusinessTurnTool({turnContractV2: true});
    const validated = validateToolArguments(tool, {type: "toolCall", id: "attempt-test", name: tool.name, arguments: args});
    return receiptJson(await runTool(tool, validated, current));
  };
  const fail = async () => {const receipt = await call(wrong); expect(receipt.status).toBe("ARGUMENT_ERROR"); expect(typeof receipt.attemptRef).toBe("string"); return String(receipt.attemptRef);};
  return {sessions, session, frames, request, backend, base, other, call, fail};
}

describe("V2失败提案不可变引用与字段纠错", () => {
  it("错误selection同时修改机构日期，纠正一个字段恢复其它本轮变化并正式执行", async () => {
    const f = await fixture(), before = {state: await f.frames.state(), frames: await f.frames.list()}, ref = await f.fail();
    expect({state: await f.frames.state(), frames: await f.frames.list()}).toEqual(before);
    expect(await f.frames.getTurnAttempt(ref)).toMatchObject({ownerId: f.request.actor.id, turnId: f.request.operationId,
      requestId: f.request.requestId, promptFingerprint: f.request.promptFingerprint, proposal: {...wrong, base: {frameId: f.base.frameId}}});
    const result = await f.call(correction(ref)); expect(result.status).toBe("READY");
    const frame = (await f.frames.get(String(result.frameId)))!;
    expect(frame.delta.executionMode).toBe("execute");
    expect(frame.fields).toMatchObject({organizations: {resolvedValue: {codes: ["B"]}}, metrics: {resolvedValue: {codes: ["M"]}},
      time: {resolvedValue: {start: "2026-08-01", end: "2026-08-31"}}, selection: {resolvedValue: "latest_in_range"}});
    expect(receiptJson(await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request)).status).toBe("succeeded");
    expect(f.backend.basicQueries.mock.calls[0]![0]).toMatchObject({metric_codes: ["M"], org_codes: ["B"], selection: "latest_in_range", time: {start: "2026-08-01", end: "2026-08-31"}});
  });

  it("失败后焦点切换仍使用原base，不把新焦点贷款指标带入纠错", async () => {
    const f = await fixture(), ref = await f.fail();
    await runTool(createBusinessContextReadTool(), {frameId: f.other.frameId, setFocus: true}, f.request);
    expect((await f.frames.state()).focusFrameId).toBe(f.other.frameId);
    const corrected = await f.call(correction(ref)), frame = (await f.frames.get(String(corrected.frameId)))!;
    expect(corrected.status).toBe("READY"); expect(frame.fields.metrics?.resolvedValue).toMatchObject({codes: ["M"]});
    expect(frame.fields.metrics?.sourceFrameId).toBe(f.base.frameId);
    expect(frame.delta.baseReference).toEqual({frameId: f.base.frameId});
  });

  it("重建store和同一已接纳operation恢复后仍可读取原提案并纠错", async () => {
    const f = await fixture(), ref = await f.fail(), frames = new NativeFrameStore(f.session);
    const restored = {...f.request, frames, commands: new MemoryCommandBridge()};
    expect((await frames.getTurnAttempt(ref))?.proposal.set).toEqual(wrong.set);
    const result = await f.call(correction(ref), restored);
    expect(result.status).toBe("READY"); expect((await frames.get(String(result.frameId)))?.fields.organizations?.resolvedValue).toMatchObject({codes: ["B"]});
  });

  it.each(["turn", "request", "user", "session", "fingerprint"])("%s改变不能复用纠错引用，拒绝且不改变业务状态", async boundary => {
    const f = await fixture(), ref = await f.fail(), before = {state: await f.frames.state(), frames: await f.frames.list()};
    const changed = {...f.request,
      ...(boundary === "turn" ? {operationId: "other-turn"} : {}), ...(boundary === "request" ? {requestId: "other-request"} : {}),
      ...(boundary === "user" ? {actor: {...f.request.actor, id: "other-owner"}} : {}), ...(boundary === "session" ? {sessionId: "other-session"} : {}),
      ...(boundary === "fingerprint" ? {promptFingerprint: "other-prompt"} : {})};
    expect(await f.call(correction(ref), changed)).toMatchObject({status: "ARGUMENT_ERROR", error_code: "TURN_ATTEMPT_UNAVAILABLE"});
    expect({state: await f.frames.state(), frames: await f.frames.list()}).toEqual(before); expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });

  it("伪造引用与更换业务能力均拒绝，不能借纠错获得另一执行入口", async () => {
    const f = await fixture(), ref = await f.fail();
    expect(await f.call(correction("attemptRef:forged"))).toMatchObject({status: "ARGUMENT_ERROR", error_code: "TURN_ATTEMPT_UNAVAILABLE"});
    expect(await f.call({capability: "data_availability", attemptRef: ref, set: {dimension: "metrics"}})).toMatchObject({status: "ARGUMENT_ERROR", error_code: "TURN_ATTEMPT_CAPABILITY_MISMATCH"});
    expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });

  it("同一纠错字段同时set和clear拒绝，不静默覆盖原提案", async () => {
    const f = await fixture(), ref = await f.fail(), saved = await f.frames.getTurnAttempt(ref);
    expect(await f.call({...correction(ref), clear: ["selection"]})).toMatchObject({status: "ARGUMENT_ERROR", error_code: "TURN_ATTEMPT_DUPLICATE_FIELD"});
    expect(await f.frames.getTurnAttempt(ref)).toEqual(saved); expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });

  it("空patch不能当成功重试；原proposal引用不可被后续保存改写", async () => {
    const f = await fixture(), ref = await f.fail(), saved = (await f.frames.getTurnAttempt(ref))!;
    expect(await f.call({capability: "metric_query", attemptRef: ref, set: {}})).toMatchObject({status: "ARGUMENT_ERROR", error_code: "TURN_ATTEMPT_CORRECTION_REQUIRED"});
    await f.frames.saveTurnAttempt({...saved, proposal: {capability: "data_availability"}});
    expect(await f.frames.getTurnAttempt(ref)).toEqual(saved);
  });

  it("legacy Schema不发布attemptRef分支，V2纠错也不能重填base或mode", async () => {
    const f = await fixture(), ref = await f.fail(), args = correction(ref);
    expect(() => validateToolArguments(createResolveBusinessTurnTool(), {type: "toolCall", id: "legacy", name: "resolve_business_turn", arguments: args})).toThrow();
    const typed = createResolveBusinessTurnTool({turnContractV2: true});
    expect(() => validateToolArguments(typed, {type: "toolCall", id: "v2", name: typed.name, arguments: {...args, base: null}})).toThrow();
    expect(() => validateToolArguments(typed, {type: "toolCall", id: "v2", name: typed.name, arguments: {...args, mode: "execute"}})).toThrow();
  });
});
