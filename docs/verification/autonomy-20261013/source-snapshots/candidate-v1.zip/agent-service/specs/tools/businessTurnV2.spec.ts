import {mkdtempSync, rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, describe, expect, it, vi} from "vitest";
import {validateToolArguments} from "@earendil-works/pi-ai";
import {NativeSessionStore} from "../../src/nativeSessions.js";
import {NativeFrameStore} from "../../src/business-context/store.js";
import {createCapabilities} from "../../src/business-context/capabilities.js";
import {BusinessContextService} from "../../src/business-context/service.js";
import {createFieldResolvers} from "../../src/business-context/resolvers.js";
import {validateFieldIntents} from "../../src/business-context/core.js";
import {v2ContextDelta, legacyAsV2} from "../../src/tools/businessTurnV2.js";
import {createResolveBusinessTurnTool} from "../../src/tools/businessContext.js";
import {createAskMetricTools} from "../../src/tools/index.js";
import {loadBusinessSkills} from "../../src/businessSkills.js";
import {createAnalysisTaskTool} from "../../src/tools/analysisTask.js";
import {MemoryCommandBridge, receiptJson, runTool, testRequestContext} from "../../src/tools/testUtils.js";
import type {BackendClient} from "../../src/backendClient.js";
import type {BusinessFrame, ContextDelta, FieldResolution} from "../../src/business-context/types.js";

const closes: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of closes.splice(0)) await close(); vi.restoreAllMocks();});
const query = (set: Record<string, unknown> = {}) => ({capability: "metric_query", base: "current", mode: "execute", set});
const tool = () => createResolveBusinessTurnTool({turnContractV2: true});
const validate = (arguments_: Record<string, unknown>) => validateToolArguments(tool(), {type: "toolCall", id: "test-v2", name: "resolve_business_turn", arguments: arguments_});
const req = (originalMessage: string) => testRequestContext({} as BackendClient, new MemoryCommandBridge(), {originalMessage});
const inherit = {mode: "inherit", sourceText: null, expectedCount: null};

/** 检查字段时解引用标准$defs，断言仍针对完整机器契约而不是序列化形状。 */
function expandLocalReferences(value: unknown, root: Record<string, unknown>): unknown {
  if (Array.isArray(value)) return value.map(item => expandLocalReferences(item, root));
  if (!value || typeof value !== "object") return value;
  const object = value as Record<string, unknown>, ref = object.$ref;
  if (typeof ref === "string") {
    if (!ref.startsWith("#/$defs/")) throw new Error("TEST_SCHEMA_REFERENCE_NOT_LOCAL");
    const name = ref.slice("#/$defs/".length).replaceAll("~1", "/").replaceAll("~0", "~");
    const definition = (root.$defs as Record<string, unknown> | undefined)?.[name];
    if (!definition) throw new Error("TEST_SCHEMA_REFERENCE_MISSING");
    return {...expandLocalReferences(definition, root) as object, ...Object.fromEntries(Object.entries(object)
      .filter(([key]) => key !== "$ref").map(([key, item]) => [key, expandLocalReferences(item, root)]))};
  }
  return Object.fromEntries(Object.entries(object).filter(([key]) => key !== "$defs").map(([key, item]) => [key, expandLocalReferences(item, root)]));
}

async function fixture() {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const path = mkdtempSync(join(tmpdir(), "typed-turn-v2-")), sessions = new NativeSessionStore(path), session = await sessions.create("user-1");
  closes.push(async () => {await sessions.close(); rmSync(path, {recursive: true, force: true});});
  const frames = new NativeFrameStore(session), service = new BusinessContextService(frames, createCapabilities(), createFieldResolvers());
  const organizations = new Map([["机构甲", "A"], ["机构乙", "B"], ["机构丙", "C"]]);
  const resolveCatalog = vi.fn(async (entity: string, values: string[]): Promise<FieldResolution> => {
    if (entity === "date") return {status: "resolved", value: {start: values[0]!, end: values[0]!}};
    if (entity === "metric") return {status: "resolved", value: {codes: ["M"], names: ["总余额"]}};
    const codes = values.map(name => organizations.get(name) ?? (Array.from(organizations.values()).includes(name) ? name : undefined));
    return codes.every(Boolean) ? {status: "resolved", value: {codes, names: codes.map(code => Array.from(organizations).find(([, value]) => value === code)![0])}} : {status: "not_found"};
  });
  const backend = {resolveBusinessField: resolveCatalog, matchMetricQuestion: vi.fn(async (question: string) => ({mentions: question.includes("总余额")
    ? [{text: "总余额", start: question.indexOf("总余额"), end: question.indexOf("总余额") + 3, resolution: {status: "resolved", value: {codes: ["M"], names: ["总余额"]}}}] : []})), basicQueries: vi.fn()};
  const request = testRequestContext(backend as unknown as BackendClient, new MemoryCommandBridge(), {sessionId: session.metadata.id, frames,
    originalMessage: "查询机构甲2026-07-31总余额"});
  const seed = async (names: string[], index: number) => {
    const id = {sessionId: session.metadata.id, turnId: `seed-${index}`, requestId: `seed-${index}`};
    const ready = await service.resolve({capabilityHint: "metric_query", baseReference: null, executionMode: "execute", fieldChanges: [
      {fieldHint: "metrics", operation: "set", rawValue: "总余额"}, {fieldHint: "organizations", operation: "set", rawValue: names},
      {fieldHint: "time", operation: "set", rawValue: "2026-07-31"}, {fieldHint: "selection", operation: "set", rawValue: "exact"},
    ]}, id, {originalMessage: `总余额 ${names.join("、")} 2026-07-31`, currentDate: "2026-10-14", turnId: id.turnId, resolveCatalog});
    return service.finishExecution(await service.beginExecution(ready.frameId, id), {status: "success", resultRef: `query:seed-${index}:result`});
  };
  return {sessions, session, frames, backend, request, seed};
}

describe("V2 typed tool contract", () => {
  const examples: Record<string, Record<string, unknown>> = {
    metric_query: {metrics: {fromQuestion: true}, organizations: ["机构甲", "机构乙"], comparison_organizations: {clarify: true, sourceText: "比较范围"},
      time: "2026-07-31", selection: "exact", operation: {kind: "rank_position"}},
    data_availability: {metrics: {fromQuestion: true}, organizations: "机构甲", time: "2026年7月", dimension: "dates", match: "all", page: 2, page_size: 30},
    metric_calculate: {expressions: [{name: "difference", label: "差额", expression: "a-b", decimal_places: 2}], bindings: {a: {fact_id: "fact:t:0:metric_value"}},
      constants: {b: {value: "2", source_text: "2"}}, scope_policy: "cross_org"},
  };

  it.each(createCapabilities().list().map(capability => capability.capability))("覆盖能力%s全部现有字段，保持有类型契约", capability => {
    const fields = createCapabilities().get(capability).fields;
    expect(Object.keys(examples[capability]!).sort()).toEqual(Object.keys(fields).sort());
    expect(() => validate({capability, base: null, mode: "resolve_more", set: examples[capability]})).not.toThrow();
    const shared = tool().parameters as unknown as Record<string, unknown>;
    const parameters = expandLocalReferences(shared, shared) as {anyOf: Array<{properties?: Record<string, unknown>}>};
    const branch = parameters.anyOf.find(item => (item.properties?.capability as {const?: string})?.const === capability)!;
    expect(Object.keys((branch.properties!.set as {properties: Record<string, unknown>}).properties)).toEqual(Object.keys(fields));
  });

  it.each([
    ["metric_query", {time: {start: "2026-07-31", end: "2026-07-31"}}],
    ["metric_query", {selection: "last"}],
    ["metric_query", {operation: {kind: "rank_position", top_n: 3}}], ["metric_query", {organizations: {codes: ["A"]}}],
    ["metric_query", {metrics: {catalogRef: "fake"}}], ["metric_query", {page: 1}],
    ["data_availability", {page: 0}], ["data_availability", {page_size: 51}], ["data_availability", {dimension: "tables"}],
    ["metric_calculate", {expressions: {expression: "a-b"}}], ["metric_calculate", {bindings: "fact:t:0:metric_value"}],
    ["metric_calculate", {constants: {a: "2"}}],
  ])("原生Schema拒绝非法字段输入 %s %j", (capability, set) => {
    expect(() => validate({capability, base: null, mode: "execute", set})).toThrow();
  });

  it("准备步骤与普通参数互斥，不能用stepRef覆盖固定指标或机构", () => {
    expect(() => validate({stepRef: "stepRef:signed"})).not.toThrow();
    expect(() => validate({stepRef: "stepRef:signed", ...query({organizations: "机构乙"})})).toThrow();
    expect(() => validate({...query(), fieldIntents: {organizations: inherit}})).toThrow();
  });

  it("只生成机械声明，省略机构保留inherit，用户原文不会被修改", () => {
    const input = query({time: "2026-08-31"}), original = structuredClone(input);
    const delta = v2ContextDelta(input, req("把日期改为2026-08-31，其余不变"));
    expect(delta).toEqual({capabilityHint: "metric_query", baseReference: "current", executionMode: "execute",
      fieldChanges: [{fieldHint: "time", operation: "set", rawValue: "2026-08-31"}],
      fieldIntents: {organizations: inherit, comparison_organizations: inherit}});
    expect(input).toEqual(original);
  });

  it("显式机构数量与来源原文完整保留，不与top_n混用", () => {
    const message = "查询机构甲和机构乙两家，列出前1名";
    const args = query({organizations: {text: ["机构甲", "机构乙"], expectedCount: {value: 2, sourceText: "机构甲和机构乙两家"}},
      operation: {kind: "ranking", position: "top", top_n: 1}});
    expect(() => validate(args)).not.toThrow();
    const delta = v2ContextDelta(args, req(message));
    expect(delta.fieldIntents?.organizations).toEqual({mode: "set", sourceText: "机构甲和机构乙两家", expectedCount: 2});
    expect(delta.fieldChanges[0]!.rawValue).toEqual(["机构甲", "机构乙"]);
    expect(() => validateFieldIntents(createCapabilities().get("metric_query"), delta, {originalMessage: message, requireFieldIntents: true} as never)).not.toThrow();
  });

  it("显式数量的来源仍由核心核验，typed包装不能伪造用户授权", () => {
    const originalMessage = "查询机构甲和机构乙";
    const delta = v2ContextDelta(query({organizations: {text: ["机构甲", "机构乙"], expectedCount: {value: 3, sourceText: "用户要求三家"}}}), req(originalMessage));
    expect(() => validateFieldIntents(createCapabilities().get("metric_query"), delta, {originalMessage, requireFieldIntents: true} as never)).toThrow("FIELD_INTENT_EVIDENCE_INVALID");
  });

  it("候选确认保留完整接受证据与否定转折，不替模型伪造evidence", () => {
    const sourceText = "不是原简称，可以按已列出的机构甲，同时改日期";
    const confirmation = {confirm: true, evidence: {decision: "accept", sourceText}};
    const delta = v2ContextDelta(query({organizations: confirmation}), req(sourceText));
    expect(delta.fieldChanges[0]!.rawValue).toEqual(confirmation);
    expect(delta.fieldIntents?.organizations).toEqual({mode: "confirm", sourceText, expectedCount: null});
    expect(v2ContextDelta(query({organizations: {confirm: true}}), req("机构甲")).fieldChanges[0]!.rawValue).toEqual({confirm: true});
  });

  it("兼容candidateIndex确认的机械意图必须与核心确认语义一致", () => {
    const delta = v2ContextDelta(query({organizations: {candidateIndex: 1, sourceText: "机构甲"}}), req("机构甲"));
    expect(delta.fieldIntents?.organizations?.mode).toBe("confirm");
    expect(() => validateFieldIntents(createCapabilities().get("metric_query"), delta, {originalMessage: "机构甲", requireFieldIntents: true} as never)).not.toThrow();
  });

  it("历史union的来源、完整数量、追加项、未决项恢复参数均保留", () => {
    const history = {fromHistory: true, sourceText: "前两笔共三家", sources: [{frame: {ordinal: 1}, field: "organizations"}, {frame: {ordinal: 2}, field: "organizations"}],
      combine: "union", expectedCount: 3, add: ["机构丙"], retainResolvedAdditions: true, replaceAdditions: [{index: 0, value: "机构丙"}]};
    const delta = v2ContextDelta(query({organizations: history}), req("前两笔共三家，未决项改为机构丙"));
    expect(delta.fieldChanges[0]!.rawValue).toEqual(history);
    expect(delta.fieldIntents?.organizations).toEqual({mode: "set", sourceText: "前两笔共三家，未决项改为机构丙", expectedCount: 3});
  });

  it("旧delta转为V2不丢弃确认证据、union和移除目标", () => {
    const confirmation = {confirm: true, evidence: {decision: "accept", sourceText: "可以"}};
    const legacy: ContextDelta = {capabilityHint: "metric_query", baseReference: {ordinal: 1}, executionMode: "resolve_more",
      fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: confirmation}, {fieldHint: "metrics", operation: "remove", rawValue: {mentionIndexes: [2]}}],
      fieldIntents: {organizations: {mode: "confirm", sourceText: "可以", expectedCount: null}}};
    expect(legacyAsV2(legacy)).toEqual({capability: "metric_query", base: {ordinal: 1}, mode: "resolve_more", set: {organizations: confirmation}, remove: {metrics: {mentionIndexes: [2]}}});
  });

  it("旧显式完整数量迁移到V2后仍约束目标，不能删除旧fieldIntents而丢数量", () => {
    const message = "机构甲和机构乙共三家，请继续";
    const legacy: ContextDelta = {capabilityHint: "metric_query", baseReference: "current", executionMode: "execute",
      fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: ["机构甲", "机构乙"]}],
      fieldIntents: {organizations: {mode: "set", sourceText: message, expectedCount: 3}}};
    const migrated = legacyAsV2(legacy);
    expect(() => validate(migrated)).not.toThrow();
    expect(v2ContextDelta(migrated, req(message)).fieldIntents?.organizations).toEqual(legacy.fieldIntents?.organizations);
  });

  it("旧历史union仅在意图声明的数量迁移后仍生效", () => {
    const message = "前两笔共三家，请继续";
    const raw = {fromHistory: true, sourceText: message, sources: [{frame: {ordinal: 1}, field: "organizations"}, {frame: {ordinal: 2}, field: "organizations"}], combine: "union"};
    const legacy: ContextDelta = {capabilityHint: "metric_query", baseReference: "current", executionMode: "execute",
      fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: raw}],
      fieldIntents: {organizations: {mode: "set", sourceText: message, expectedCount: 3}}};
    const migrated = legacyAsV2(legacy), delta = v2ContextDelta(migrated, req(message));
    expect(() => validate(migrated)).not.toThrow();
    expect(delta.fieldIntents?.organizations?.expectedCount).toBe(3);
    expect(delta.fieldChanges[0]?.rawValue).toMatchObject({sources: raw.sources, combine: "union", expectedCount: 3});
  });

  it("旧history raw与声明数量冲突迁移时拒绝，不能覆盖任何一方绕过旧约束", () => {
    const legacy: ContextDelta = {capabilityHint: "metric_query", baseReference: "current", executionMode: "execute",
      fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: {fromHistory: true, sourceText: "前两笔共三家", expectedCount: 2,
        sources: [{frame: {ordinal: 1}, field: "organizations"}], combine: "single"}}],
      fieldIntents: {organizations: {mode: "set", sourceText: "前两笔共三家", expectedCount: 3}}};
    expect(() => legacyAsV2(legacy)).toThrow("FIELD_INTENT_COUNT_CONFLICT");
    expect((legacy.fieldChanges[0]!.rawValue as {expectedCount: number}).expectedCount).toBe(2);
    expect(legacy.fieldIntents?.organizations?.expectedCount).toBe(3);
  });

  it.each([
    {changes: [{fieldHint: "organizations", operation: "set", rawValue: "机构甲"}], intent: inherit},
    {changes: [], intent: {mode: "set", sourceText: "机构甲", expectedCount: null}},
    {changes: [], intent: {mode: "inherit", sourceText: "机构甲", expectedCount: null}},
    {changes: [], intent: {mode: "inherit", sourceText: null, expectedCount: 2}},
  ])("旧mode不一致或非法inherit在转换前拒绝，不靠删除声明放宽约束：%j", ({changes, intent}) => {
    const legacy = {capabilityHint: "metric_query", baseReference: "current", executionMode: "execute", fieldChanges: changes, fieldIntents: {organizations: intent}};
    const snapshot = structuredClone(legacy);
    expect(() => legacyAsV2(legacy)).toThrow("FIELD_INTENT_MODE_MISMATCH"); expect(legacy).toEqual(snapshot);
  });

  it("默认flags保留旧Schema/工具集，只有analysis开关发布新增工具", () => {
    const old = createAskMetricTools(), typed = createAskMetricTools({turnContractV2: true}), analysis = createAskMetricTools({turnContractV2: true, analysisPlanning: true});
    expect(old.map(item => item.name)).toEqual(typed.map(item => item.name));
    expect(old.some(item => item.name === "analysis_task")).toBe(false);
    expect(analysis.some(item => item.name === "analysis_task")).toBe(true);
    expect(createResolveBusinessTurnTool().parameters).toHaveProperty("properties.fieldIntents");
  });

  it("默认知识目录维持原四Skill，analysis开关才发布新分析方法", async () => {
    const normal = await loadBusinessSkills(), analysis = await loadBusinessSkills(undefined, {analysisPlanning: true});
    expect(normal.map(skill => skill.name).sort()).toEqual(["analysis-boundary", "data-coverage", "metric-query", "result-calculation"]);
    expect(analysis.map(skill => skill.name).sort()).toEqual([...normal.map(skill => skill.name), "business-analysis"].sort());
  });
});

describe("JSON Schema结构共享保留完整原生校验", () => {
  const cases = [
    {name: "resolve_business_turn", factory: tool, valid: [query({metrics: {fromQuestion: true}, organizations: "机构甲", time: "2026-07-31"}),
      query({operation: {kind: "ranking", position: "top"}}),
      query({organizations: {text: ["机构甲", "机构乙"], expectedCount: {value: 2, sourceText: "两家"}}}),
      {stepRef: "stepRef:signed"}, {capability: "metric_query", attemptRef: "attemptRef:signed", set: {selection: "latest_in_range"}}],
      invalid: [query({time: {start: "2026-07-31"}}), query({operation: {kind: "ranking", top_n: 101}}),
        query({organizations: {codes: ["A"]}}), {stepRef: "stepRef:signed", set: {organizations: "机构乙"}}]},
    {name: "analysis_task", factory: createAnalysisTaskTool, valid: [{action: "methods"}, {action: "read", analysisId: "analysis-1"},
      {action: "create", goal: "描述存款", base: null, organizations: "机构甲", time: "2026-07-31", requirements: [{text: "存款总量"}]},
      {action: "revise", analysisId: "analysis-1", expectedRevision: 1, reason: "用户确认", metrics: {confirm: true}, metricMode: "replace"},
      {action: "complete", analysisId: "analysis-1", expectedRevision: 1, partial: true, coverage: []}],
      invalid: [{action: "create", goal: "描述存款", base: null, organizations: {codes: ["A"]}, requirements: [{text: "总量"}]},
        {action: "create", goal: "分析", base: null, requirements: []}, {action: "revise", analysisId: "analysis-1", expectedRevision: 0, reason: "修改"},
        {action: "complete", analysisId: "analysis-1", expectedRevision: 1, coverage: [{requirementId: "r", evidenceRefs: []}]}]},
  ];

  it.each(cases)("$name标准$ref与展开Schema的合法/非法判断完全一致且字符更少", ({name, factory, valid, invalid}) => {
    const shared = factory().parameters as unknown as Record<string, unknown>, expanded = expandLocalReferences(shared, shared);
    expect(shared).toHaveProperty("$defs");
    expect(JSON.stringify(shared)).toContain('"$ref":"#/$defs/');
    const sharedCharacters = JSON.stringify(shared).length, expandedCharacters = JSON.stringify(expanded).length;
    expect(sharedCharacters).toBeLessThan(expandedCharacters * 0.75);
    const validateSchema = (schema: unknown, args: Record<string, unknown>) => validateToolArguments({name, description: "相同业务契约",
      parameters: schema as ReturnType<typeof tool>["parameters"]}, {type: "toolCall", id: "schema-parity", name, arguments: structuredClone(args)});
    for (const input of valid) expect(validateSchema(shared, input)).toEqual(validateSchema(expanded, input));
    for (const input of invalid) {
      expect(() => validateSchema(shared, input)).toThrow(); expect(() => validateSchema(expanded, input)).toThrow();
    }
  });
});

describe("V2准确查询与历史上下文", () => {
  it.each([false, true])("旧精准查询与V2解析相同正式条件且不额外探索：v2=%s", async v2 => {
    const f = await fixture(), args = {capability: "metric_query", base: null, mode: "execute", set: {metrics: {fromQuestion: true}, organizations: "机构甲", time: "2026-07-31"}};
    const input = v2 ? args : {...v2ContextDelta(args, f.request), fieldIntents: {organizations: {mode: "set", sourceText: f.request.originalMessage, expectedCount: null}}};
    const receipt = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: v2}), input, f.request));
    expect(receipt.status).toBe("READY");
    const frame = (await f.frames.get(String(receipt.frameId)))!;
    expect(frame.fields.organizations?.resolvedValue).toEqual({codes: ["A"], names: ["机构甲"]});
    expect(frame.fields.metrics?.resolvedValue).toEqual({codes: ["M"], names: ["总余额"]});
    expect(frame.fields.time?.resolvedValue).toEqual({start: "2026-07-31", end: "2026-07-31"});
    expect(frame.fields.selection?.resolvedValue).toBe("exact");
    expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });

  it("只改日期保留历史机构指标且每字段引用来源仍是原Frame", async () => {
    const f = await fixture(), base = await f.seed(["机构甲"], 1);
    const request = {...f.request, originalMessage: "把日期改成2026-08-31，其他不变"};
    const receipt = receiptJson(await runTool(tool(), query({time: "2026-08-31"}), request));
    expect(receipt.status).toBe("READY");
    const frame = (await f.frames.get(String(receipt.frameId)))!;
    for (const name of ["metrics", "organizations"]) expect(frame.fields[name]?.sourceFrameId).toBe(base.frameId);
    expect(frame.fields.time?.resolvedValue).toEqual({start: "2026-08-31", end: "2026-08-31"});
  });

  it.each([3, 4])("真实保存历史union按编码合并去重，数量%i保存完整来源不截断", async expectedCount => {
    const f = await fixture(), saved: BusinessFrame[] = [await f.seed(["机构甲", "机构乙"], 1), await f.seed(["机构乙", "机构丙"], 2)];
    const sourceText = expectedCount === 3 ? "前两笔共三家" : "前两笔共四家";
    const raw = {fromHistory: true, sourceText, combine: "union", expectedCount,
      sources: saved.map(frame => ({frame: {frameId: frame.frameId}, field: "organizations"}))};
    const receipt = receiptJson(await runTool(tool(), query({organizations: raw}), {...f.request, originalMessage: `${sourceText}，其他不变`}));
    expect(receipt.status).toBe(expectedCount === 3 ? "READY" : "NEEDS_CLARIFICATION");
    const field = (await f.frames.get(String(receipt.frameId)))!.fields.organizations;
    expect(field?.rawValue).toMatchObject({sources: raw.sources, expectedCount});
    if (expectedCount === 3) expect(field?.resolvedValue).toEqual({codes: ["A", "B", "C"], names: ["机构甲", "机构乙", "机构丙"]});
    else expect(field?.metadata).toMatchObject({turnIntentExpectedCount: 4, referenceIssue: {actualCount: 3, expectedCount: 4}});
    expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });
});
