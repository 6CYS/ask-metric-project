import {mkdtempSync, rmSync, writeFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, describe, expect, it, vi} from "vitest";
import {validateToolArguments} from "@earendil-works/pi-ai";
import {loadAnalysisCatalog, exploreAnalysisCatalog} from "../src/analysisCatalog.js";
import {createCatalogTool} from "../src/tools/catalog.js";
import {NativeSessionStore} from "../src/nativeSessions.js";
import {NativeAnalysisStore} from "../src/business-context/analysis.js";
import {BackendApiError, type BackendClient} from "../src/backendClient.js";
import {MemoryCommandBridge, receiptJson, runTool, testRequestContext} from "../src/tools/testUtils.js";

const closes: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of closes.splice(0)) await close(); vi.restoreAllMocks();});
function profilePath() {
  const directory = mkdtempSync(join(tmpdir(), "analysis-profile-")), path = join(directory, "profile.json");
  closes.push(async () => {rmSync(directory, {recursive: true, force: true});});
  writeFileSync(path, JSON.stringify({schema_version: 1, source_sha256: "a".repeat(64), source_name: "隔离目录资源", relationships_verified: false,
    metrics: [{code: "M", dimension: "当日数", base_code: "M", base_name: "展示余额", business_label: "存款总量", aliases: ["存款余额"], name: "展示余额", source: {sheet: "指标", cell: "I2"}},
      {code: "UNAVAILABLE", dimension: "当日数", base_code: "UNAVAILABLE", base_name: "旧余额", business_label: "存款旧节点", aliases: [], name: "旧余额", source: {sheet: "指标", cell: "I3"}}],
    groups: [{label: "存款总量", base_code: "M", base_name: "展示余额", context_heading: "存款", source: {sheet: "指标", cell: "C2"}, calculation_formula: null}],
    warnings: ["同编码含协定与不含协定口径冲突，不能导入冲突别名。"]}));
  return path;
}
async function toolFixture() {
  const directory = mkdtempSync(join(tmpdir(), "analysis-catalog-state-")), sessions = new NativeSessionStore(directory), session = await sessions.create("user-1");
  closes.push(async () => {await sessions.close(); rmSync(directory, {recursive: true, force: true});});
  const analysis = new NativeAnalysisStore(session);
  const backend = {searchMetrics: vi.fn(async (code: string) => ({total: code === "M" ? 1 : 0,
    items: code === "M" ? [{metric_code: "M", metric_name: "正式启用余额", unit: "元", score: 1, match_type: "exact"}] : [], semantic_suggestions: []}))};
  const request = testRequestContext(backend as unknown as BackendClient, new MemoryCommandBridge(), {sessionId: session.metadata.id, analysis});
  const tool = createCatalogTool({analysisPlanning: true, analysisCatalogFile: profilePath()});
  return {analysis, backend, request, tool};
}

describe("只读指标树元数据", () => {
  it("完整导入440唯一编码，排除不含协定冲突别名，八计算节点仍无公式", async () => {
    const data = await loadAnalysisCatalog();
    expect(data.metrics).toHaveLength(440);
    expect(new Set(data.metrics.map(item => item.code)).size).toBe(440);
    expect(data.metrics.every(item => !item.business_label.includes("不含协定"))).toBe(true);
    expect(data.metrics.every(item => item.aliases.every(alias => !alias.includes("不含协定")))).toBe(true);
    expect(data.groups.filter(group => !group.base_code)).toHaveLength(8);
    expect(data.groups.every(group => group.calculation_formula === null)).toBe(true);
    expect(data.relationships_verified).toBe(false);
    expect(data.metrics.some(item => Object.hasOwn(item, "value") || Object.hasOwn(item, "metric_value"))).toBe(false);
  });

  it("按主题和basis筛选，has_more真实反映截断；只提供源单元格与口径", async () => {
    const result = await exploreAnalysisCatalog({keyword: "存款", basis: "当日数", limit: 2});
    expect(result.items).toHaveLength(2); expect(result.total).toBeGreaterThan(2); expect(result.has_more).toBe(true);
    expect(result.items.every(item => item.dimension === "当日数")).toBe(true);
    expect(result.items.every(item => !!item.source.cell && !!item.source.sheet)).toBe(true);
    expect(result.relationships_verified).toBe(false);
    expect(JSON.stringify(result)).not.toContain('"metric_value"');
  });

  it("探索回执保留资源口径冲突警示，不能只留树节点让模型猜", async () => {
    const result = await exploreAnalysisCatalog({keyword: "存款", limit: 2}, profilePath());
    expect(result).toMatchObject({warnings: [expect.stringContaining("口径冲突")]});
    expect(JSON.stringify(result)).not.toContain('"value"');
  });

  it("格式损坏直接失败，不能装成空目录", async () => {
    const directory = mkdtempSync(join(tmpdir(), "bad-analysis-profile-")), path = join(directory, "invalid.json");
    closes.push(async () => {rmSync(directory, {recursive: true, force: true});});
    writeFileSync(path, JSON.stringify({schema_version: 1, metrics: [{code: "M"}], groups: []}));
    await expect(loadAnalysisCatalog(path)).rejects.toThrow("ANALYSIS_CATALOG_INVALID");
  });
});

describe("catalog explore正式目录复核", () => {
  it("默认flags不发布explore，新能力显式启用后才有Schema入口", () => {
    const args = {action: "explore", keyword: "存款"};
    const call = {type: "toolCall" as const, id: "explore", name: "catalog", arguments: args};
    expect(() => validateToolArguments(createCatalogTool(), call)).toThrow();
    expect(() => validateToolArguments(createCatalogTool({analysisPlanning: true}), call)).not.toThrow();
  });

  it("实时启用目录的名称单位覆盖资源标签，未核验节点不发行catalogRef", async () => {
    const f = await toolFixture(), result = receiptJson(await runTool(f.tool, {action: "explore", keyword: "存款", limit: 2}, f.request));
    const items = result.items as Array<Record<string, unknown>>;
    const live = items.find(item => item.code === "M")!, unavailable = items.find(item => item.code === "UNAVAILABLE")!;
    expect(live).toMatchObject({name: "正式启用余额", unit: "元", status: "verified", source: {sheet: "指标", cell: "I2"}});
    expect(typeof live.catalogRef).toBe("string");
    expect((await f.analysis.reference(String(live.catalogRef), "catalog", f.request)).payload).toMatchObject({metric_code: "M", metric_name: "正式启用余额", unit: "元", source_sha256: "a".repeat(64)});
    expect(unavailable).toMatchObject({status: "unavailable"}); expect(unavailable).not.toHaveProperty("catalogRef");
    expect(JSON.stringify(result)).not.toContain('"metric_value"');
  });

  it("资源缓存不缓存实时校验，目录变更后发行对应新身份引用", async () => {
    const f = await toolFixture(), first = receiptJson(await runTool(f.tool, {action: "explore", keyword: "存款总量", limit: 1}, f.request));
    f.backend.searchMetrics.mockResolvedValueOnce({total: 1, items: [{metric_code: "M", metric_name: "正式新版本余额", unit: "万元", score: 1, match_type: "exact"}], semantic_suggestions: []});
    const second = receiptJson(await runTool(f.tool, {action: "explore", keyword: "存款总量", limit: 1}, f.request));
    const old = (first.items as Array<Record<string, unknown>>)[0]!, next = (second.items as Array<Record<string, unknown>>)[0]!;
    expect(f.backend.searchMetrics).toHaveBeenCalledTimes(2);
    expect(next).toMatchObject({name: "正式新版本余额", unit: "万元"}); expect(next.catalogRef).not.toBe(old.catalogRef);
  });

  it("目录鉴权失败整体传播，不能生成unavailable或伪空成功", async () => {
    const f = await toolFixture(); f.backend.searchMetrics.mockRejectedValueOnce(new BackendApiError(403, "denied", "ORG_SCOPE_DENIED"));
    await expect(runTool(f.tool, {action: "explore", keyword: "存款总量", limit: 1}, f.request)).rejects.toMatchObject({status: 403, code: "ORG_SCOPE_DENIED"});
  });
});
