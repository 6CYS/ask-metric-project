import { BACKGROUND_CONTEXT, setValue, value, type Session } from "@earendil-works/pi-agent-core";
import type { BusinessFrame, BusinessGoal, BusinessSessionState, FrameStore } from "./types.js";

export const BUSINESS_CONTEXT_NAMESPACE = "askmetric.business.v1";
const NS = BUSINESS_CONTEXT_NAMESPACE;
export const businessStateAddress = value<BusinessSessionState>(NS, "state");
const stateAddress = businessStateAddress;
const frameAddress = (id: string) => value<BusinessFrame>(NS, `frame/${id}`);
const commandAddress = (id: string) => value<string>(NS, `command/${id}`);
export class ContextConflict extends Error {
  constructor() { super("BUSINESS_CONTEXT_CONFLICT"); }
}
/** Pi Session 的事务屏障保证同进程并发串行；部署沿用数据根单写锁。 */
export class NativeFrameStore implements FrameStore {
  constructor(private readonly session: Session) {}
  async saveTurnAttempt(attempt: import("./turnAttempt.js").TurnAttempt): Promise<void> {
    if (attempt.sessionId !== this.session.metadata.id) throw new Error("TURN_ATTEMPT_UNAVAILABLE");
    const address = value<import("./turnAttempt.js").TurnAttempt>(NS, `attempt/${attempt.attemptRef}`);
    await this.session.mutate(async (tx, context) => {
      if (!await tx.getValue(address, context)) await tx.commit([setValue(address, structuredClone(attempt))], context);
    }, BACKGROUND_CONTEXT);
  }
  async getTurnAttempt(ref: string): Promise<import("./turnAttempt.js").TurnAttempt | undefined> {
    return structuredClone((await this.session.getValue(value<import("./turnAttempt.js").TurnAttempt>(NS, `attempt/${ref}`), BACKGROUND_CONTEXT))?.value);
  }
  async goal(turnId: string): Promise<BusinessGoal | undefined> {
    return structuredClone((await this.session.getValue(value<BusinessGoal>(NS, `goal/${turnId}`), BACKGROUND_CONTEXT))?.value);
  }
  async bindGoal(goal: BusinessGoal): Promise<BusinessGoal> {
    // 先于字段解析落盘；参数错误和进程恢复都不能使同一用户回合换掉目标。
    return this.session.mutate(async (tx, context) => {
      const address = value<BusinessGoal>(NS, `goal/${goal.turnId}`);
      const existing = await tx.getValue(address, context);
      if (existing) return structuredClone(existing.value);
      await tx.commit([setValue(address, goal)], context);
      return structuredClone(goal);
    }, BACKGROUND_CONTEXT);
  }
  private empty(): BusinessSessionState {
    return {sessionId: this.session.metadata.id, version: 0, frameOrder: [], operations: {}};
  }
  async state(): Promise<BusinessSessionState> {
    return structuredClone((await this.session.getValue(stateAddress, BACKGROUND_CONTEXT))?.value ?? this.empty());
  }
  async get(id: string): Promise<BusinessFrame | undefined> {
    return structuredClone((await this.session.getValue(frameAddress(id), BACKGROUND_CONTEXT))?.value);
  }
  async list(): Promise<BusinessFrame[]> {
    const state = await this.state();
    const frames = await Promise.all(state.frameOrder.map(id => this.get(id)));
    return frames.filter((frame): frame is BusinessFrame => !!frame);
  }
  async command(key: string): Promise<BusinessFrame | undefined> {
    const saved = await this.session.getValue(commandAddress(key), BACKGROUND_CONTEXT);
    return saved ? this.get(saved.value) : undefined;
  }
  async analysisFrameCurrent(frame: BusinessFrame): Promise<boolean> {
    if (!frame.analysisRef) return true;
    const ref = frame.analysisRef;
    const task = (await this.session.getValue(value<import("./analysis.js").AnalysisTask>("askmetric.analysis.v1", `task/${ref.analysisId}`), BACKGROUND_CONTEXT))?.value;
    return !!task && task.sessionId === frame.sessionId && task.constraintVersion === ref.constraintVersion
      && task.steps.some(step => step.stepRef === ref.stepRef && step.stepRevision === ref.stepRevision
        && step.preparedQueryRef === ref.preparedQueryRef && ["prepared", "executing", "succeeded"].includes(step.status));
  }
  async save(frame: BusinessFrame, expectedVersion: number, commandKey: string, focus = true): Promise<BusinessFrame> {
    return this.session.mutate(async (tx, context) => {
      const existing = await tx.getValue(commandAddress(commandKey), context);
      if (existing) {
        const stored = await tx.getValue(frameAddress(existing.value), context);
        if (!stored) throw new Error("FRAME_STORE_CORRUPT");
        return structuredClone(stored.value);
      }
      const state = (await tx.getValue(stateAddress, context))?.value ?? this.empty();
      if (state.version !== expectedVersion) throw new ContextConflict();
      if (frame.sessionId !== state.sessionId || await tx.getValue(frameAddress(frame.frameId), context)) throw new Error("FRAME_IMMUTABLE");
      if (frame.parentFrameId && !await tx.getValue(frameAddress(frame.parentFrameId), context)) throw new Error("FRAME_PARENT_NOT_FOUND");
      const next: BusinessSessionState = {...state, version: state.version + 1,
        frameOrder: [...state.frameOrder, frame.frameId], operations: {...state.operations, [frame.operationFrameId]: frame.frameId},
        ...(focus && frame.historyRole !== "supporting" && frame.status !== "failed"
          ? {focusFrameId: frame.frameId, currentContext: {kind: "frame" as const, frameId: frame.frameId}} : {})};
      // Frame、序号、焦点和幂等引用一次提交，崩溃不能留下半份状态。
      await tx.commit([setValue(frameAddress(frame.frameId), frame), setValue(stateAddress, next),
        setValue(commandAddress(commandKey), frame.frameId)], context);
      return structuredClone(frame);
    }, BACKGROUND_CONTEXT);
  }
  async setFocus(frameId: string, expectedVersion: number): Promise<void> {
    await this.session.mutate(async (tx, context) => {
      const state = (await tx.getValue(stateAddress, context))?.value ?? this.empty();
      const frame = (await tx.getValue(frameAddress(frameId), context))?.value;
      if (!frame || frame.status === "failed" || frame.historyRole === "supporting") throw new Error("INVALID_FOCUS_FRAME");
      if (state.version !== expectedVersion) throw new ContextConflict();
      await tx.commit([setValue(stateAddress, {...state, version: state.version + 1, focusFrameId: frameId,
        currentContext: {kind: "frame", frameId}})], context);
    }, BACKGROUND_CONTEXT);
  }
}

/** 执行前登记的后端关联：请求结果丢失（超时、断连、重启）后按幂等键只读回查真实状态。 */
export interface ExecutionLink {tool: string; idempotencyKey: string; conversationId: string}
const executionLinkAddress = (frameId: string) => value<ExecutionLink>(NS, `link/${frameId}`);

/** 非取数工具结果与 Frame 分离持久化；模型只看到引用，正文按需读取。 */
export class NativeBusinessResultStore {
  constructor(private readonly session: Session) {}
  async save(ref: string, result: import("@earendil-works/pi-agent-core").AgentToolResult<unknown>): Promise<void> {
    await this.session.mutate(async (tx, context) => {
      const address = value<import("@earendil-works/pi-agent-core").AgentToolResult<unknown>>(NS, `result/${ref}`);
      if (await tx.getValue(address, context)) return;
      await tx.commit([setValue(address, result)], context);
    }, BACKGROUND_CONTEXT);
  }
  async get(ref: string) {
    return structuredClone((await this.session.getValue(value<import("@earendil-works/pi-agent-core").AgentToolResult<unknown>>(NS, `result/${ref}`), BACKGROUND_CONTEXT))?.value);
  }
  /** 发送前落盘，同一执行 Frame 的重试使用同一幂等键，覆盖写入内容不变。 */
  async linkExecution(frameId: string, link: ExecutionLink): Promise<void> {
    await this.session.setValue(executionLinkAddress(frameId), link, BACKGROUND_CONTEXT);
  }
  async executionLink(frameId: string): Promise<ExecutionLink | undefined> {
    return structuredClone((await this.session.getValue(executionLinkAddress(frameId), BACKGROUND_CONTEXT))?.value);
  }
}
