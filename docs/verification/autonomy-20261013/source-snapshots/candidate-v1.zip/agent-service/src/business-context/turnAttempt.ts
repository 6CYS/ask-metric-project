import {createHash} from "node:crypto";
import {BusinessInputError} from "./inputError.js";

export interface TurnAttempt {
  attemptRef: string; ownerId: string; sessionId: string; turnId: string; requestId: string;
  promptFingerprint: string; proposal: Record<string, unknown>;
}

export function turnAttempt(input: Omit<TurnAttempt, "attemptRef">): TurnAttempt {
  const digest = createHash("sha256").update(JSON.stringify(input)).digest("hex");
  return {...structuredClone(input), attemptRef: `attemptRef:${digest}`};
}

/** 重试只替换明确纠正的字段，失败提案中其它变化和原来源从不可变快照恢复。 */
export function correctTurnAttempt(proposal: Record<string, unknown>, patch: Record<string, unknown>): Record<string, unknown> {
  if (proposal.capability !== patch.capability) throw new BusinessInputError("TURN_ATTEMPT_CAPABILITY_MISMATCH", "$attempt", "纠错必须保留原业务能力。");
  const changed = new Set<string>();
  for (const group of ["set", "remove", "clear", "retain"]) {
    const fields = Array.isArray(patch[group]) ? patch[group] as string[] : Object.keys((patch[group] ?? {}) as object);
    for (const name of fields) {
      if (changed.has(name)) throw new BusinessInputError("TURN_ATTEMPT_DUPLICATE_FIELD", name, "同一纠错字段只能声明一种操作。");
      changed.add(name);
    }
  }
  if (!changed.size) throw new BusinessInputError("TURN_ATTEMPT_CORRECTION_REQUIRED", "$attempt", "请只提交需要纠正的字段，已保存的其他变化无需重填。");
  const result = structuredClone(proposal);
  for (const group of ["set", "remove", "clear", "retain"]) {
    if (group === "clear" || group === "retain") {
      const prior = (result[group] ?? []) as string[];
      result[group] = [...prior.filter(name => !changed.has(name)), ...((patch[group] ?? []) as string[])];
    } else {
      const prior = (result[group] ?? {}) as Record<string, unknown>;
      result[group] = {...Object.fromEntries(Object.entries(prior).filter(([name]) => !changed.has(name))), ...((patch[group] ?? {}) as object)};
    }
    if (Object.keys(result[group] as object).length === 0) delete result[group];
  }
  return result;
}
