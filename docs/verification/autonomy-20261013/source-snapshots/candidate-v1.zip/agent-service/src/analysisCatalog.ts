import {readFile} from "node:fs/promises";
import {fileURLToPath} from "node:url";

export interface AnalysisCatalogMetric {
  code: string; dimension: string; base_code: string; base_name: string; business_label: string;
  aliases: string[]; name: string; source: {sheet: string; cell: string};
}
interface AnalysisCatalog {
  schema_version: 1; source_sha256: string; source_name: string; relationships_verified: boolean;
  metrics: AnalysisCatalogMetric[];
  groups: Array<{label: string; base_code: string | null; base_name: string | null; context_heading: string; source: {sheet: string; cell: string}; calculation_formula: null}>;
  warnings: unknown[];
  conflicted_codes?: string[];
}
const cache = new Map<string, Promise<AnalysisCatalog>>();
export function loadAnalysisCatalog(path = fileURLToPath(new URL("../config/metric-analysis-catalog.json", import.meta.url))): Promise<AnalysisCatalog> {
  let pending = cache.get(path);
  if (!pending) {
    pending = readFile(path, "utf8").then(text => {
      const data = JSON.parse(text) as AnalysisCatalog;
      if (data.schema_version !== 1 || !Array.isArray(data.metrics) || !Array.isArray(data.groups)
        || data.metrics.some(item => !item.code || !item.name || !item.dimension || !Array.isArray(item.aliases))) throw new Error("ANALYSIS_CATALOG_INVALID");
      return data;
    });
    cache.set(path, pending);
  }
  return pending;
}

function score(metric: AnalysisCatalogMetric, keyword: string): number {
  if (!keyword) return 1;
  const words = [metric.business_label, metric.base_name, metric.name, ...metric.aliases];
  if (words.some(word => word === keyword)) return 100;
  if (words.some(word => word.includes(keyword))) return 50;
  const grams = Array.from(keyword).slice(0, -1).map((char, i) => char + Array.from(keyword)[i + 1]);
  return grams.filter(gram => words.some(word => word.includes(gram))).length;
}

/** 树只提供分组与口径；可执行性、名称、单位仍由实时正式目录复核。 */
export async function exploreAnalysisCatalog(input: {keyword: string; basis?: string; limit?: number}, path?: string) {
  const data = await loadAnalysisCatalog(path);
  const matches = data.metrics.map(metric => ({metric, score: score(metric, input.keyword)}))
    .filter(item => item.score > 0 && (!input.basis || item.metric.dimension === input.basis))
    .sort((a, b) => b.score - a.score);
  const limit = Math.min(input.limit ?? 12, 30);
  return {source: {name: data.source_name, sha256: data.source_sha256},
    dimensions: [...new Set(matches.map(item => item.metric.dimension))],
    groups: data.groups.filter(group => group.label?.includes(input.keyword) || matches.some(item => item.metric.base_code === group.base_code))
      .map(group => ({...group, ...(group.base_code && data.conflicted_codes?.includes(group.base_code) ? {status: "definition_conflict"} : {})})),
    total: matches.length, has_more: matches.length > limit, items: matches.slice(0, limit).map(item => ({...item.metric,
      definition_conflict: data.conflicted_codes?.includes(item.metric.code) ?? false})),
    warnings: data.warnings,
    relationships_verified: data.relationships_verified,
    notice: "分组不证明可加总或因果关系；无公式节点不能自动计算。指标值及单位取正式工具回执。"};
}
