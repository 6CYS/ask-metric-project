import {Type} from "@earendil-works/pi-ai";
import {createCapabilities} from "../business-context/capabilities.js";
import {modelFieldInputSchema} from "../business-context/fieldClarification.js";
import {toContextDelta, toCompactTurnArgs} from "../business-context/turnArgs.js";
import type {AskMetricRequestContext} from "../requestContext.js";
import type {ContextDelta, FieldTurnIntent} from "../business-context/types.js";
import {BusinessInputError} from "../business-context/inputError.js";
import {shareSchemaDefinitions} from "./schemaReferences.js";

const labels: Record<string, string> = {
  metrics: "明确指标用 fromQuestion；候选确认引用保存状态。分析选指标使用 analysis_task 的步骤。",
  organizations: "本轮机构原文或明确历史字段引用。未改则省略，继承 base。",
  comparison_organizations: "位次的比较总体，独立于关注机构。",
  time: "本轮完整日期原文；未改则省略。",
  selection: "exact=单日/离散日；latest_in_range=范围最后有数据日；all_in_range=时间序列。",
  operation: "value=取值；ranking=前后N名；rank_position=关注机构在比较总体的位次。",
  expressions: "受控公式数组，变量来自 bindings/constants。",
  bindings: "变量到正式 fact_id 的映射。",
  constants: "用户明确常量及其原文，不得复制查询数值。",
  scope_policy: "计算的机构和日期范围。",
  dimension: "metrics=指标覆盖；dates=日期覆盖。",
  match: "any=任一记录；all=已确定目标的共同日期。",
};

/** Schema 只给一次；去掉旧文本投影，不改变字段机器契约。 */
function cleanSchema(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(cleanSchema);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value).filter(([key]) => key !== "description").map(([key, child]) => [key, cleanSchema(child)]));
}

export function businessTurnV2Parameters() {
  const base = {anyOf: [{type: "null"}, {const: "current"}, {type: "object", minProperties: 1,
    properties: {frameId: {type: "string"}, ordinal: {type: "integer", minimum: 1}, relativePosition: {type: "integer", maximum: 0},
      capability: {type: "string"}, businessConstraints: {type: "object"}, resultRequired: {type: "boolean"}}, additionalProperties: false}]};
  const branches = createCapabilities({partialRanking: true}).list().map(capability => {
    const fields = Object.fromEntries(Object.entries(capability.fields).map(([name, field]) => {
      const machine = modelFieldInputSchema(field) ?? (field.validation?.enum ? {enum: field.validation.enum}
        : field.resolver === "integer" ? {type: "integer", minimum: field.validation?.min, maximum: field.validation?.max} : {type: "string"});
      const schema = cleanSchema(machine) as Record<string, unknown>;
      const input = field.requireTurnIntent ? {anyOf: [schema, {type: "object", required: ["text", "expectedCount"],
        properties: {text: {anyOf: [{type: "string", minLength: 1}, {type: "array", minItems: 1, items: {type: "string"}}]},
          expectedCount: {type: "object", required: ["value", "sourceText"], properties: {value: {type: "integer", minimum: 1}, sourceText: {type: "string", minLength: 1}}, additionalProperties: false}}, additionalProperties: false}]} : schema;
      return [name, {...input, description: labels[name] ?? field.label}];
    }));
    return {type: "object", required: ["capability", "base", "mode"], properties: {
      capability: {const: capability.capability}, base,
      mode: {enum: ["execute", "resolve_more", "reuse_result"]},
      set: {type: "object", properties: fields, additionalProperties: false, maxProperties: 32},
      clear: {type: "array", items: {enum: Object.keys(fields)}, uniqueItems: true},
      retain: {type: "array", items: {enum: Object.keys(fields)}, uniqueItems: true},
      remove: {type: "object", properties: {metrics: {type: "object", required: ["mentionIndexes"], properties: {
        mentionIndexes: {type: "array", minItems: 1, items: {type: "integer", minimum: 1}}}, additionalProperties: false}}, additionalProperties: false},
    }, additionalProperties: false};
  });
  const corrections = branches.map(branch => {
    const {base: _base, mode: _mode, ...properties} = branch.properties;
    return {type: "object", required: ["capability", "attemptRef"], properties: {...properties,
      attemptRef: {type: "string", minLength: 1}}, additionalProperties: false, minProperties: 3};
  });
  return Type.Unsafe<Record<string, unknown>>(shareSchemaDefinitions({anyOf: [...branches, ...corrections,
    {type: "object", required: ["stepRef"], properties: {stepRef: {type: "string", minLength: 1}}, additionalProperties: false}]}));
}

export function isV2Turn(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value)
    && (("capability" in value && !Object.hasOwn(value, "fieldIntents")) || "stepRef" in value);
}

/** 只生成可机械确定的内部声明，数量与历史来源仍来自显式输入并由核心验证。 */
export function v2ContextDelta(input: Record<string, unknown>, request: AskMetricRequestContext): ContextDelta {
  const capability = createCapabilities().get(String(input.capability));
  const normalized = structuredClone(input);
  const set = (normalized.set ?? {}) as Record<string, unknown>;
  const counts = new Map<string, {value: number; sourceText: string}>();
  for (const [name, value] of Object.entries(set)) {
    if (value && typeof value === "object" && !Array.isArray(value) && "text" in value && "expectedCount" in value) {
      const wrapper = value as {text: unknown; expectedCount: {value: number; sourceText: string}};
      counts.set(name, wrapper.expectedCount);
      set[name] = wrapper.text;
    }
  }
  normalized.set = set;
  const delta = toContextDelta({...normalized, fieldIntents: {}});
  const intents: Record<string, FieldTurnIntent> = {};
  for (const [name, field] of Object.entries(capability.fields)) {
    if (!field.requireTurnIntent) continue;
    const change = delta.fieldChanges.find(item => item.fieldHint === name);
    const raw = change?.rawValue as Record<string, unknown> | undefined;
    const count = counts.get(name);
    const historyCount = raw && typeof raw === "object" && typeof raw.expectedCount === "number" ? raw.expectedCount : null;
    const mode = !change || change.operation === "retain" ? "inherit" : change.operation === "set" && (raw?.confirm === true || raw?.candidateIndex !== undefined) ? "confirm" : change.operation;
    intents[name] = {mode, sourceText: mode === "inherit" ? null : count?.sourceText ?? request.originalMessage,
      expectedCount: mode === "inherit" ? null : count?.value ?? historyCount};
  }
  delta.fieldIntents = intents;
  return delta;
}

export function legacyAsV2(args: unknown): Record<string, unknown> {
  const delta = toContextDelta(args);
  const compact = toCompactTurnArgs(delta) as Record<string, unknown>;
  const set = compact.set as Record<string, unknown> | undefined;
  for (const [name, intent] of Object.entries(delta.fieldIntents ?? {})) {
    const raw = set?.[name];
    const change = delta.fieldChanges.find(item => item.fieldHint === name);
    const confirming = raw && typeof raw === "object" && !Array.isArray(raw) && ("confirm" in raw || "candidateIndex" in raw);
    const mode = !change || change.operation === "retain" ? "inherit" : change.operation === "set" && confirming ? "confirm" : change.operation;
    if (intent.mode !== mode || mode === "inherit" && (intent.sourceText !== null || intent.expectedCount !== null)) {
      throw new BusinessInputError("FIELD_INTENT_MODE_MISMATCH", name, "旧目标声明与实际变化不一致，不能通过新协议转换删除该约束。");
    }
    if (set && intent.expectedCount !== null && (typeof raw === "string" || Array.isArray(raw))) {
      set[name] = {text: raw, expectedCount: {value: intent.expectedCount, sourceText: intent.sourceText}};
    } else if (set && intent.expectedCount !== null && raw && typeof raw === "object" && "fromHistory" in raw) {
      const history = raw as Record<string, unknown>;
      if (history.expectedCount !== undefined && history.expectedCount !== intent.expectedCount) {
        throw new BusinessInputError("FIELD_INTENT_COUNT_CONFLICT", name, "旧历史引用的数量与本轮目标声明冲突，请按原文修正，不能删除约束。");
      }
      set[name] = {...history, expectedCount: intent.expectedCount};
    }
  }
  delete compact.fieldIntents;
  delete compact.goal;
  delete compact.purpose;
  return compact;
}
