import {Type, type Static} from "@earendil-works/pi-ai";
import type {AgentHarnessTool} from "@earendil-works/pi-agent-core";
import type {AskMetricRequestContext} from "../requestContext.js";
import {BackendApiError} from "../backendClient.js";
import {createCapabilities} from "../business-context/capabilities.js";
import {createFieldResolvers} from "../business-context/resolvers.js";
import {resolveFrame} from "../business-context/core.js";
import {BusinessInputError} from "../business-context/inputError.js";
import type {AnalysisAnchor, AnalysisStepInput} from "../business-context/analysis.js";
import type {FieldSchema, ResolvedField, FrameSelector} from "../business-context/types.js";
import {resolverContext} from "./businessContext.js";
import {modelFieldInputSchema} from "../business-context/fieldClarification.js";
import {metricMentions, type MetricMention} from "../business-context/metricMentions.js";
import {shareSchemaDefinitions} from "./schemaReferences.js";

const ref = Type.String({minLength: 1});
const requirements = Type.Array(Type.Object({id: Type.Optional(ref), text: Type.String({minLength: 1}),
  evidenceKind: Type.Optional(Type.Union([Type.Literal("query"), Type.Literal("calculation")]))}, {additionalProperties: false}), {minItems: 1, maxItems: 32});
const step = Type.Object({id: Type.Optional(ref), kind: Type.Optional(Type.Union([Type.Literal("query"), Type.Literal("calculation")])),
  purpose: Type.String({minLength: 1}), requirementIds: Type.Array(ref, {minItems: 1}), targetId: Type.Optional(ref),
  catalogRefs: Type.Optional(Type.Array(ref, {minItems: 1, uniqueItems: true})), methodRef: Type.Optional(ref),
  bindings: Type.Optional(Type.Record(Type.String(), Type.Object({fact_id: ref}, {additionalProperties: false}))),
  time: Type.Optional(Type.String({description: "保持目标日期；只有原范围内有依据的取证步骤可调整。"})),
  selection: Type.Optional(Type.Union([Type.Literal("exact"), Type.Literal("latest_in_range"), Type.Literal("all_in_range")])),
  dependsOn: Type.Optional(Type.Array(ref, {uniqueItems: true})),
}, {additionalProperties: false});
const steps = Type.Array(step, {maxItems: 32});
const base = Type.Union([Type.Null(), Type.Literal("current"), Type.Object({frameId: Type.Optional(ref),
  ordinal: Type.Optional(Type.Integer({minimum: 1})), relativePosition: Type.Optional(Type.Integer({maximum: 0}))}, {additionalProperties: false, minProperties: 1})]);
const organization = Type.Unsafe<string | string[] | Record<string, unknown>>(createCapabilities().get("metric_query").fields.organizations!.inputSchema!);
const metricInput = Type.Unsafe<Record<string, unknown> | string | string[]>(modelFieldInputSchema(createCapabilities().get("metric_query").fields.metrics!)!);
const metricMode = Type.Union([Type.Literal("add"), Type.Literal("replace")]);
const target = Type.Object({targetId: ref, organizations: organization, time: Type.String({minLength: 1}),
  metrics: Type.Optional(metricInput),
  requirementIds: Type.Optional(Type.Array(ref, {minItems: 1}))}, {additionalProperties: false});
const parameters = Type.Union([
  Type.Object({action: Type.Literal("methods")}, {additionalProperties: false}),
  Type.Object({action: Type.Literal("create"), goal: Type.String({minLength: 1}), base, requirements,
    organizations: Type.Optional(organization), time: Type.Optional(Type.String({minLength: 1})),
    metrics: Type.Optional(metricInput),
    targets: Type.Optional(Type.Array(target, {minItems: 1, maxItems: 16})), steps: Type.Optional(steps)}, {additionalProperties: false}),
  Type.Object({action: Type.Literal("read"), analysisId: Type.Optional(ref), setFocus: Type.Optional(Type.Boolean())}, {additionalProperties: false}),
  Type.Object({action: Type.Literal("revise"), analysisId: ref, expectedRevision: Type.Integer({minimum: 1}),
    reason: Type.String({minLength: 1}), requirements: Type.Optional(requirements), steps: Type.Optional(steps),
    organizations: Type.Optional(organization), time: Type.Optional(Type.String({minLength: 1})),
    metrics: Type.Optional(metricInput), metricMode: Type.Optional(metricMode),
    targets: Type.Optional(Type.Array(target, {minItems: 1, maxItems: 16}))}, {additionalProperties: false}),
  Type.Object({action: Type.Literal("complete"), analysisId: ref, expectedRevision: Type.Integer({minimum: 1}), partial: Type.Optional(Type.Boolean()),
    coverage: Type.Array(Type.Object({requirementId: ref, evidenceRefs: Type.Array(ref, {minItems: 1})}, {additionalProperties: false})),
    gaps: Type.Optional(Type.Array(Type.String({minLength: 1})))}, {additionalProperties: false}),
]);

async function resolveAnchorField(name: string, raw: unknown, previous: ResolvedField | undefined, request: AskMetricRequestContext, signal?: AbortSignal): Promise<ResolvedField> {
  const schema = createCapabilities().get("metric_query").fields[name]!;
  const context = {...resolverContext(request, signal), fieldName: name, ...(previous ? {previous} : {})};
  const resolver = createFieldResolvers().getResolver(schema);
  const result = await resolver.resolve(raw, schema as FieldSchema, context);
  return {rawValue: raw, resolvedValue: result.value, resolutionStatus: result.status, source: "explicit", resolver: schema.resolver,
    ...(result.candidates ? {candidates: result.candidates} : {}), ...(result.metadata ? {metadata: result.metadata} : {})};
}

async function anchorFrom(baseRef: FrameSelector | "current" | null, request: AskMetricRequestContext): Promise<AnalysisAnchor> {
  if (!request.frames) throw new Error("BUSINESS_CONTEXT_NOT_BOUND");
  if (baseRef === null) return {fields: {}};
  const state = await request.frames.state();
  const id = baseRef === "current" ? state.focusFrameId : resolveFrame(baseRef, state, await request.frames.list(), request.operationId).frameId;
  if (!id) throw new BusinessInputError("ANALYSIS_BASE_UNRESOLVED", "$base", "无法唯一确定继承来源，请选择明确历史查询或用null新建。");
  const frame = await request.frames.get(id);
  if (!frame || frame.sessionId !== request.sessionId || frame.status === "executing") throw new Error("ANALYSIS_BASE_UNAVAILABLE");
  return {baseFrameId: frame.frameId, fields: structuredClone(frame.fields)};
}

async function updateAnchor(anchor: AnalysisAnchor, input: {organizations?: unknown; time?: string; targets?: Static<typeof target>[]}, request: AskMetricRequestContext, signal?: AbortSignal) {
  const result = structuredClone(anchor);
  for (const [name, raw] of [["organizations", input.organizations], ["time", input.time]] as const) {
    if (raw !== undefined) result.fields[name] = await resolveAnchorField(name, raw, result.fields[name], request, signal);
  }
  if (input.targets) {
    const fixed = (result.fields.metrics?.resolvedValue as {codes?: string[]} | undefined)?.codes ?? [];
    if (input.targets.length > 1 && fixed.length > 1 && input.targets.some(item => item.metrics === undefined)) {
      throw new BusinessInputError("ANALYSIS_TARGET_METRICS_REQUIRED", "metrics", "多目标涉及多个明确指标，请逐target指定本轮指标片段或可信继承，不能将所有指标交叉套到所有机构日期。");
    }
    result.targets = await Promise.all(input.targets.map(async item => ({targetId: item.targetId,
      fields: {...structuredClone(result.fields), organizations: await resolveAnchorField("organizations", item.organizations, undefined, request, signal),
        time: await resolveAnchorField("time", item.time, undefined, request, signal),
        ...(item.metrics !== undefined ? {metrics: await resolveAnchorField("metrics", item.metrics, result.fields.metrics, request, signal)} : {})},
      ...(item.requirementIds ? {requirementIds: item.requirementIds} : {})})));
    const covered = new Set(result.targets.flatMap(target => (target.fields.metrics?.resolvedValue as {codes?: string[]} | undefined)?.codes ?? []));
    if (fixed.some(code => !covered.has(code))) throw new BusinessInputError("ANALYSIS_FIXED_TARGETS_INCOMPLETE", "metrics", "逐target绑定遗漏了明确指标，请保留全部用户目标。");
    result.fields = structuredClone(result.targets[0]!.fields);
  }
  return result;
}

/** 基础家族未指定统计口径时可由分析选取；多义正式名称仍必须保留候选。 */
function topicMention(mention: MetricMention): boolean {
  const issue = mention.resolution.metadata?.issue;
  return issue === "missing_value_basis" || issue === "base_uncertain" && !!mention.resolution.candidates?.length
    && mention.resolution.candidates.every(candidate => candidate.metadata?.kind === "base_only");
}

async function captureExplicitMetrics(anchor: AnalysisAnchor, request: AskMetricRequestContext): Promise<AnalysisAnchor> {
  if (typeof request.backend.matchMetricQuestion !== "function") return anchor;
  const matched = await metricMentions(request);
  if (matched.status === "temporary_error") throw new BusinessInputError("METRIC_MATCH_UNAVAILABLE", "metrics", "指标识别暂不可用，请保留目标重试，不能把未知指标当作开放主题。");
  const topics = matched.mentions.filter(topicMention), mentions = matched.mentions.filter(item => !topicMention(item));
  if (!mentions.length && !topics.length) return anchor;
  const previous = anchor.fields.metrics;
  const previousValue = previous?.resolvedValue as {codes?: string[]; names?: string[]} | undefined;
  const values = new Map((previousValue?.codes ?? []).map((code, index) => [code, previousValue?.names?.[index] ?? code]));
  for (const mention of mentions.filter(item => item.resolution.status === "resolved")) {
    const resolved = mention.resolution.value as {codes: string[]; names: string[]};
    resolved.codes.forEach((code, index) => values.set(code, resolved.names[index]!));
  }
  const pending = mentions.filter(item => item.resolution.status !== "resolved");
  const snapshots = mentions.map(item => ({text: item.text, start: item.start, end: item.end, status: item.resolution.status,
    ...(item.resolution.value ? {value: item.resolution.value} : {}), ...(item.resolution.candidates ? {candidates: item.resolution.candidates} : {}),
    ...(item.group ? {group: item.group} : {})}));
  const metadata = {...previous?.metadata, topicMentions: topics, ...(mentions.length ? {
    questionText: request.originalMessage, mentionResolutions: snapshots, extractedRawValues: mentions.map(item => item.text),
    pendingRawValues: mentions.map(item => item.resolution.status === "resolved" ? (item.resolution.value as {codes: string[]}).codes : item.text),
  } : {})};
  const metrics: ResolvedField = {source: "explicit", resolver: "metric", rawValue: {fromQuestion: true},
    resolutionStatus: pending.length ? pending.some(item => item.resolution.status === "ambiguous") ? "ambiguous" : "needs_confirmation"
      : previous && previous.resolutionStatus !== "resolved" ? previous.resolutionStatus : "resolved",
    resolvedValue: {codes: [...values.keys()], names: [...values.values()]}, metadata,
    ...(pending.length ? {candidates: snapshots.flatMap((item, index) => item.status === "resolved" ? []
      : (item.candidates ?? []).map(candidate => ({...candidate, metadata: {...candidate.metadata, rawValueIndex: index}})))}
      : previous?.candidates ? {candidates: previous.candidates} : {})};
  const result = {...anchor, fields: {...anchor.fields, metrics}};
  if (result.targets) result.targets = result.targets.map(target => ({...target, fields: {...target.fields, metrics: structuredClone(metrics)}}));
  return result;
}

export function createAnalysisTaskTool(options: {acceptNew?: boolean | undefined} = {}): AgentHarnessTool<AskMetricRequestContext, typeof parameters> {
  return {name: "analysis_task", label: "管理分析目标与证据", parameters: shareSchemaDefinitions(parameters),
    description: "用户授权分析时登记目标、固定机构日期和逐项要求。revise.steps按id追加或更新，未提交分支保留；返回stepRef供resolve_business_turn执行。结果后可修订计划。read恢复当前分析，methods取标准方法。complete必须逐项引用正式证据；partial保存未完成缺口。明确查询直接用原查询工具。",
    execute: async (_id, input, _update, request, _invocation, context) => {
      try {
        const store = request.analysis;
        if (!store) throw new Error("ANALYSIS_CONTEXT_NOT_BOUND");
        if (input.action === "methods") {
          const methods = await Promise.all([
            {id: "difference", name: "差额", expression: "a-b", display: "decimal", preconditions: "正式事实、同单位、用户授权的比较范围"},
            {id: "growth_rate", name: "增长率", expression: "(a-b)/abs(b)", display: "percent", preconditions: "同指标同机构可比基期、基数非零；口径不明不能代算正式指标"},
          ].map(async method => ({...method, methodRef: await store.issueReference("method", method, request)})));
          return {content: [{type: "text", text: JSON.stringify({status: "ok", methods})}], details: {kind: "analysis_task", status: "ok"}};
        }
        let task;
        if (input.action === "create") {
          if (options.acceptNew === false) throw new BusinessInputError("ANALYSIS_ADMISSION_PAUSED", "$analysis", "当前暂停创建新分析；已有任务仍可读取、恢复和保存完成状态。");
          let anchor = await captureExplicitMetrics(await anchorFrom(input.base, request), request);
          if (input.metrics !== undefined) {
            anchor.fields.metrics = await resolveAnchorField("metrics", input.metrics, anchor.fields.metrics, request, context.abortSignal);
            if (anchor.targets) anchor.targets = anchor.targets.map(target => ({...target, fields: {...target.fields, metrics: structuredClone(anchor.fields.metrics!)}}));
          }
          anchor = await updateAnchor(anchor, input, request, context.abortSignal);
          task = await store.create({goal: input.goal, requirements: input.requirements, anchor,
            ...(input.steps ? {steps: input.steps as AnalysisStepInput[]} : {})}, request);
        } else if (input.action === "read") {
          task = await store.read(input.analysisId, request);
          if (task && input.analysisId && input.setFocus !== false) await store.activate(task.analysisId, request);
        }
        else if (input.action === "revise") {
          const previous = await store.read(input.analysisId, request);
          if (!previous) throw new Error("ANALYSIS_NOT_FOUND");
          const changes = input.organizations !== undefined || input.time !== undefined || input.targets !== undefined || input.metrics !== undefined;
          let revisedAnchor = await updateAnchor(previous.anchor, input, request, context.abortSignal);
          if (input.metrics !== undefined) {
            const resolved = await store.resolveAnchorMetrics(input.analysisId, input.metrics, request,
              resolverContext(request, context.abortSignal), input.metricMode ?? "replace");
            revisedAnchor = {...revisedAnchor, ...(resolved.metricUpdate ? {metricUpdate: resolved.metricUpdate} : {}),
              fields: {...revisedAnchor.fields, metrics: resolved.fields.metrics!},
              ...(revisedAnchor.targets ? {targets: revisedAnchor.targets.map(target => ({...target,
                fields: {...target.fields, metrics: structuredClone(resolved.fields.metrics!)}}))} : {})};
          }
          task = await store.revise(input.analysisId, input.expectedRevision, {reason: input.reason,
            ...(input.requirements ? {requirements: input.requirements} : {}), ...(input.steps ? {steps: input.steps as AnalysisStepInput[]} : {}),
            ...(changes ? {anchor: revisedAnchor} : {})}, request);
        } else task = await store.complete(input.analysisId, input.expectedRevision, {
          coverage: input.coverage, ...(input.partial !== undefined ? {partial: input.partial} : {}), ...(input.gaps ? {gaps: input.gaps} : {})}, request);
        return {content: [{type: "text", text: JSON.stringify({status: task ? "ok" : "not_found", task})}],
          details: {kind: "analysis_task", status: task?.status ?? "not_found", ...(input.action === "read" && (!input.analysisId || input.setFocus === false) ? {read_only: true} : {}),
            ...(task ? {analysis_id: task.analysisId, plan_revision: task.planRevision} : {})}};
      } catch (error) {
        const code = error instanceof BackendApiError ? error.code : error instanceof Error ? error.message : undefined;
        const known = error instanceof BusinessInputError;
        const message = known ? error.correction : "分析任务未完成，请保留已知条件并按错误修正或说明缺口。";
        return {content: [{type: "text", text: JSON.stringify({status: "ARGUMENT_ERROR", error_code: known ? error.code : /^[A-Z_]+$/.test(code ?? "") ? code : "ANALYSIS_FAILED", message})}],
          details: {kind: "analysis_task", status: "ARGUMENT_ERROR", retryable: true}};
      }
    }};
}
