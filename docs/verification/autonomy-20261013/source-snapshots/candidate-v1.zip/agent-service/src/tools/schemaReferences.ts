/** JSON Schema的重复子结构只发送一次；$defs/$ref保留相同机器校验，不缩减合法字段。 */
export function shareSchemaDefinitions<T>(schema: T): T {
  const entries = new Map<string, {value: Record<string, unknown>; count: number; name: string}>();
  const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);
  function scan(value: unknown, path: string[]) {
    if (Array.isArray(value)) {value.forEach(item => scan(item, path)); return;}
    if (!object(value)) return;
    const key = JSON.stringify(value);
    if (key.length >= 160 && ("type" in value || "anyOf" in value || "oneOf" in value || "enum" in value)) {
      const previous = entries.get(key);
      entries.set(key, previous ? {...previous, count: previous.count + 1}
        : {value, count: 1, name: (path.filter(part => !["properties", "anyOf", "oneOf", "items"].includes(part)).at(-1) ?? "value") + "Input"});
    }
    for (const [name, item] of Object.entries(value)) scan(item, [...path, name]);
  }
  scan(schema, []);
  const names = new Map<string, string>();
  const used = new Set<string>();
  for (const [key, entry] of entries) if (entry.count > 1) {
    let name = entry.name, suffix = 1;
    while (used.has(name)) name = `${entry.name}${suffix++}`;
    used.add(name); names.set(key, name);
  }
  function project(value: unknown, definitionKey?: string): unknown {
    if (Array.isArray(value)) return value.map(item => project(item));
    if (!object(value)) return value;
    const key = JSON.stringify(value), name = names.get(key);
    if (name && key !== definitionKey) return {$ref: `#/$defs/${name}`};
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, project(item)]));
  }
  const output = project(schema) as Record<string, unknown>;
  if (names.size) output.$defs = Object.fromEntries([...names].map(([key, name]) => [name, project(entries.get(key)!.value, key)]));
  return output as T;
}
