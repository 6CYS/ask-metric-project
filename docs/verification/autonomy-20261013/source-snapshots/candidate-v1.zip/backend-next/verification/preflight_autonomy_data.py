"""自主分析验收的数据前置核查；只执行 SELECT，不改库、不查模型、不输出凭据或数值。"""

from __future__ import annotations

import argparse
import ipaddress
import json
import re
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sqlalchemy import bindparam, create_engine, make_url, text

PROJECT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_DIR / "src"))

from ask_metric.core.config import get_settings  # noqa: E402
from ask_metric.infrastructure.query.sql_safety import validate_readonly_sql  # noqa: E402


def address_scope(host: str | None) -> str:
    if host in {"localhost", "127.0.0.1", "::1"}:
        return "loopback"
    try:
        address = ipaddress.ip_address(host or "")
        return "private_address" if address.is_private else "public_address"
    except ValueError:
        return "hostname_redacted"


def safe_error(exc: Exception) -> dict[str, object]:
    original = getattr(exc, "orig", exc)
    args = getattr(original, "args", ())
    code = args[0] if args and isinstance(args[0], int) else None
    result: dict[str, object] = {"type": type(exc).__name__, "driver_code": code}
    # 不写入异常字符串，驱动错误可能包含账号、主机、SQL 或连接 URL。
    if code in {2002, 2003, 2005, 2013}:
        result["category"] = "connection_unavailable"
    elif code in {1044, 1045, 1142}:
        result["category"] = "access_denied"
    elif code in {1049, 1146}:
        result["category"] = "schema_or_table_unavailable"
    else:
        result["category"] = "read_failed"
    return result


def select_rows(connection, sql: str, parameters: dict | None = None) -> list[dict[str, Any]]:
    validate_readonly_sql(sql)
    statement = text(sql)
    parameters = parameters or {}
    for key, value in parameters.items():
        if isinstance(value, list) and key in statement._bindparams:
            statement = statement.bindparams(bindparam(key, expanding=True))
    return [dict(row) for row in connection.execute(statement, parameters).mappings()]


def engine_for(url: str):
    parsed = make_url(url)
    options = {}
    if parsed.get_driver_name() in {"pymysql", "mysqldb"}:
        options = {"connect_timeout": 5, "read_timeout": 30, "write_timeout": 5}
    return create_engine(url, connect_args=options, echo=False, pool_pre_ping=False)


def table_info(connection, table: str) -> dict:
    metadata = select_rows(
        connection,
        "SELECT TABLE_TYPE AS table_type, TABLE_ROWS AS estimated_rows "
        "FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table",
        {"table": table},
    )
    columns = select_rows(
        connection,
        "SELECT COLUMN_NAME AS name, DATA_TYPE AS data_type "
        "FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table "
        "ORDER BY ORDINAL_POSITION",
        {"table": table},
    )
    result = {"exists": bool(metadata), "metadata": metadata, "columns": columns}
    if metadata and metadata[0]["table_type"] == "VIEW":
        view = select_rows(
            connection,
            "SELECT VIEW_DEFINITION AS definition FROM information_schema.VIEWS "
            "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table",
            {"table": table},
        )
        definition = str(view[0].get("definition") or "") if view else ""
        # 仅记录源关系标识，不保存完整视图正文或潜在连接信息。
        result["view_definition_visible"] = bool(definition)
        result["view_source_relations"] = sorted(
            set(
                re.findall(
                    r"(?:from|join)\s+([`a-zA-Z0-9_.]+)",
                    definition,
                    re.IGNORECASE,
                )
            )
        )
    return result


def inspect_catalog(connection, codes: list[str], workbook: dict) -> dict:
    info = table_info(connection, "metric_terms")
    if not info["exists"]:
        return {"table": info, "status": "missing_catalog"}
    fields = {column["name"] for column in info["columns"]}
    selected = ["metric_code", "metric_name", "unit", "enabled"]
    selected.extend(
        name for name in ("source_metric_code", "base_name", "value_basis") if name in fields
    )
    rows = select_rows(
        connection,
        f"SELECT {', '.join(selected)} FROM metric_terms WHERE metric_code IN :codes "
        "ORDER BY metric_code",
        {"codes": codes},
    )
    stats = select_rows(
        connection,
        "SELECT COUNT(*) AS total, SUM(CASE WHEN enabled = 1 THEN 1 ELSE 0 END) AS enabled "
        "FROM metric_terms",
    )[0]
    by_code: dict[str, list[dict]] = {}
    for row in rows:
        by_code.setdefault(row["metric_code"], []).append(row)
    source_by_code: dict[str, list[dict]] = {}
    for item in workbook["metrics"]:
        source_by_code.setdefault(item["code"], []).append(item)
    conflict_codes = {item["code"] for item in workbook.get("conflicts", [])}
    matches = []
    for code in codes:
        items = by_code.get(code, [])
        enabled = [item for item in items if item["enabled"]]
        names = sorted({item["name"] for item in source_by_code[code]})
        matches.append(
            {
                "metric_code": code,
                "status": "enabled"
                if len(enabled) == 1
                else "missing"
                if not items
                else "disabled"
                if not enabled
                else "duplicate_enabled_code",
                "workbook_names": names,
                "official_items": items,
                "exact_name_match": len(enabled) == 1 and enabled[0]["metric_name"] in names,
                "workbook_scope_conflict": code in conflict_codes,
            }
        )
    return {
        "status": "read_ok",
        "table": info,
        "catalog_counts": stats,
        "workbook_unique_codes": len(codes),
        "enabled_match_count": sum(item["status"] == "enabled" for item in matches),
        "missing_count": sum(item["status"] == "missing" for item in matches),
        "disabled_count": sum(item["status"] == "disabled" for item in matches),
        "duplicate_enabled_code_count": sum(
            item["status"] == "duplicate_enabled_code" for item in matches
        ),
        "exact_name_match_count": sum(item["exact_name_match"] for item in matches),
        "workbook_scope_conflict_count": len(conflict_codes),
        "name_differences_are_not_automatically_business_conflicts": True,
        "matches": matches,
    }


def inspect_facts(connection, codes: list[str], result: dict, *, full_scan: bool = False) -> dict:
    info = table_info(connection, "metric_values")
    result.update(status="partial", table=info)
    if not info["exists"]:
        return {"status": "missing_mysql_fact_relation", "table": info}
    fields = {column["name"] for column in info["columns"]}
    required = {"metric_code", "org_code", "stat_date", "metric_value"}
    if not required <= fields:
        return {"status": "incompatible_mysql_fact_relation", "table": info}
    indexes = select_rows(
        connection,
        "SELECT INDEX_NAME AS name, COLUMN_NAME AS column_name, SEQ_IN_INDEX AS ordinal "
        "FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() "
        "AND TABLE_NAME = 'metric_values' ORDER BY INDEX_NAME, SEQ_IN_INDEX",
    )
    info["indexes"] = indexes
    metric_index = next(
        (
            item["name"]
            for item in indexes
            if item["column_name"] == "metric_code"
            and item["ordinal"] == 1
            and re.fullmatch(r"[A-Za-z0-9_]+", item["name"])
        ),
        None,
    )
    # 日期 GROUP/ORDER 查询可能被优化器改走全日期索引；本核查只读 Excel 子集。
    scoped_source = (
        f"metric_values FORCE INDEX (`{metric_index}`)" if metric_index else "metric_values"
    )
    result["workbook_scan_index"] = metric_index
    grouped = select_rows(
        connection,
        "SELECT metric_code, COUNT(*) AS rows_total, "
        "SUM(CASE WHEN metric_value IS NOT NULL THEN 1 ELSE 0 END) AS nonnull_rows, "
        "COUNT(DISTINCT CASE WHEN metric_value IS NOT NULL THEN org_code END) AS organizations, "
        "COUNT(DISTINCT CASE WHEN metric_value IS NOT NULL THEN stat_date END) AS dates, "
        "MIN(CASE WHEN metric_value IS NOT NULL THEN stat_date END) AS earliest_valid_date, "
        "MAX(CASE WHEN metric_value IS NOT NULL THEN stat_date END) AS latest_valid_date "
        f"FROM {scoped_source} WHERE metric_code IN :codes "
        "GROUP BY metric_code ORDER BY metric_code",
        {"codes": codes},
    )
    result["coverage"] = grouped
    present = {item["metric_code"] for item in grouped if item["nonnull_rows"] > 0}
    result.update(
        workbook_codes_with_nonnull_values=len(present),
        workbook_codes_without_nonnull_values=sorted(set(codes) - present),
    )
    dates = select_rows(
        connection,
        "SELECT stat_date, COUNT(DISTINCT metric_code) AS metrics, "
        "COUNT(DISTINCT org_code) AS organizations, COUNT(*) AS nonnull_rows "
        f"FROM {scoped_source} WHERE metric_code IN :codes AND metric_value IS NOT NULL "
        "GROUP BY stat_date ORDER BY stat_date DESC LIMIT 12",
        {"codes": codes},
    )
    result["recent_valid_date_groups"] = dates
    samples = select_rows(
        connection,
        "SELECT metric_code, org_code, MAX(stat_date) AS latest_valid_date, "
        "COUNT(*) AS nonnull_rows "
        f"FROM {scoped_source} WHERE metric_code IN :codes AND metric_value IS NOT NULL "
        "GROUP BY metric_code, org_code ORDER BY metric_code, org_code LIMIT 12",
        {"codes": codes},
    )
    result["queryable_metric_organization_samples"] = samples
    result["organization_samples_are_data_presence_not_actor_authorization"] = True
    batches = None
    workbook_batches = []
    if "source_batch_id" in fields:
        batch_sql = (
            "SELECT CASE WHEN source_batch_id IS NULL OR source_batch_id = '' THEN 'missing' "
            "WHEN LOWER(source_batch_id) REGEXP "
            "'(^|[^a-z0-9])(synthetic|fixture|mock|demo|seed|seeded|test)([^a-z0-9]|$)' "
            "THEN 'contains_test_marker' ELSE 'other_redacted' END AS category, "
            "COUNT(*) AS rows_total FROM metric_values "
        )
        workbook_batches = select_rows(
            connection,
            batch_sql.replace("FROM metric_values ", f"FROM {scoped_source} ")
            + "WHERE metric_code IN :codes GROUP BY category",
            {"codes": codes},
        )
    result["workbook_source_batch_marker_categories"] = workbook_batches
    result["source_batch_marker_categories"] = batches
    result["full_source_scan_requested"] = full_scan
    if full_scan:
        result["overall_counts"] = select_rows(
            connection,
            "SELECT COUNT(*) AS rows_total, COUNT(DISTINCT metric_code) AS metrics_total, "
            "COUNT(DISTINCT org_code) AS organizations_total, MIN(stat_date) AS earliest_date, "
            "MAX(stat_date) AS latest_date FROM metric_values",
        )[0]
        if "source_batch_id" in fields:
            result["source_batch_marker_categories"] = select_rows(
                connection,
                batch_sql + "GROUP BY category",
            )
    result["validity_semantics"] = (
        "Current mysql runtime: metric_value IS NOT NULL; zero retained. "
        "No claim about external lake sentinel/latest-batch cleaning."
    )
    result["status"] = "read_ok"
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--workbook",
        type=Path,
        default=PROJECT_DIR.parent / "docs/verification/autonomy-20261013/workbook-normalized.json",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--only-markers",
        action="store_true",
        help="仅重新核查已保存报告中Excel事实的来源标记，保留其他成功证据。",
    )
    parser.add_argument(
        "--full-scan", action="store_true", help="额外扫描全事实表；默认只核查Excel编码以控制负载。"
    )
    args = parser.parse_args()
    workbook = json.loads(args.workbook.read_text(encoding="utf-8"))
    codes = sorted({item["code"] for item in workbook["metrics"]})
    settings = get_settings()
    if args.only_markers:
        report = json.loads(args.output.read_text(encoding="utf-8"))
        facts = report["query_source"]["facts"]
        index = facts.get("workbook_scan_index")
        source = (
            f"metric_values FORCE INDEX (`{index}`)"
            if isinstance(index, str) and re.fullmatch(r"[A-Za-z0-9_]+", index)
            else "metric_values"
        )
        engine = engine_for(settings.query_database_url)
        try:
            with engine.connect() as connection:
                categories = select_rows(
                    connection,
                    "SELECT CASE WHEN source_batch_id IS NULL OR source_batch_id = '' "
                    "THEN 'missing' "
                    "WHEN LOWER(source_batch_id) REGEXP "
                    "'(^|[^a-z0-9])(synthetic|fixture|mock|demo|seed|seeded|test)([^a-z0-9]|$)' "
                    "THEN 'contains_test_marker' ELSE 'other_redacted' END AS category, "
                    f"COUNT(*) AS rows_total FROM {source} "
                    "WHERE metric_code IN :codes GROUP BY category",
                    {"codes": codes},
                )
        except Exception as exc:
            raise SystemExit(json.dumps({"marker_recheck_error": safe_error(exc)})) from None
        finally:
            engine.dispose()
        facts["workbook_source_batch_marker_categories"] = categories
        facts["source_marker_match_rule"] = (
            "case-insensitive whole token; latest does not match test"
        )
        report["provenance_rechecked_at_utc"] = datetime.now(UTC).isoformat()
        assessment = report["data_provenance_assessment"]
        assessment["test_marker_rows"] = sum(
            item["rows_total"] for item in categories if item["category"] == "contains_test_marker"
        )
        assessment["test_marker_scope"] = "workbook_codes"
        assessment["classification"] = (
            "local_fact_store_with_test_markers"
            if assessment["test_marker_rows"]
            else "unverified_local_fact_store"
        )
        args.output.write_text(
            json.dumps(report, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8"
        )
        print(
            json.dumps(
                {
                    "output": str(args.output),
                    "marker_categories": categories,
                    "assessment": assessment,
                },
                ensure_ascii=False,
                default=str,
            )
        )
        return
    app_url, query_url = make_url(settings.app_database_url), make_url(settings.query_database_url)
    report = {
        "checked_at_utc": datetime.now(UTC).isoformat(),
        "read_only": True,
        "executed_statement_types": ["SELECT"],
        "business_values_saved": False,
        "workbook_sha256": workbook["source_sha256"],
        "workbook_unique_codes": len(codes),
        "configuration": {
            "app_env": settings.app_env,
            "app_dialect": settings.app_database_dialect,
            "query_dialect": settings.query_database_dialect,
            "app_address_scope": address_scope(app_url.host),
            "query_address_scope": address_scope(query_url.host),
            "same_endpoint_and_schema": (app_url.host, app_url.port, app_url.database)
            == (query_url.host, query_url.port, query_url.database),
            "query_runtime_relation": "metric_values"
            if settings.query_database_dialect == "mysql"
            else "configured_inceptor_relation",
        },
    }
    for role, configured_url in (
        ("application", settings.app_database_url),
        ("query_source", settings.query_database_url),
    ):
        engine = None
        try:
            engine = engine_for(configured_url)
            with engine.connect() as connection:
                version = select_rows(connection, "SELECT VERSION() AS version")[0]["version"]
                result = {"connected": True, "server_version": version}
                report[role] = result
                if role == "application":
                    result["catalog"] = inspect_catalog(connection, codes, workbook)
                    orgs = select_rows(
                        connection,
                        "SELECT org_code, org_name FROM org_terms WHERE enabled = 1 "
                        "ORDER BY org_code LIMIT 8",
                    )
                    result["enabled_organization_samples"] = orgs
                elif settings.query_database_dialect == "mysql":
                    result["facts"] = {}
                    inspect_facts(connection, codes, result["facts"], full_scan=args.full_scan)
                else:
                    result["status"] = "non_mysql_runtime_requires_governed_source_preflight"
                report[role] = result
        except Exception as exc:
            if role in report:
                report[role]["inspection_complete"] = False
                report[role]["read_error"] = safe_error(exc)
            else:
                report[role] = {"connected": False, "error": safe_error(exc)}
        finally:
            if engine is not None:
                engine.dispose()
    facts = report.get("query_source", {}).get("facts", {})
    table_types = [item.get("table_type") for item in facts.get("table", {}).get("metadata", [])]
    markers = facts.get("source_batch_marker_categories")
    marker_scope = "full_source" if markers is not None else "workbook_codes"
    if markers is None:
        markers = facts.get("workbook_source_batch_marker_categories")
    test_marker_rows = (
        sum(item["rows_total"] for item in markers if item["category"] == "contains_test_marker")
        if markers is not None
        else None
    )
    catalog = report.get("application", {}).get("catalog", {})
    enabled = {
        item["metric_code"] for item in catalog.get("matches", []) if item["status"] == "enabled"
    }
    with_values = {
        item["metric_code"] for item in facts.get("coverage", []) if item["nonnull_rows"] > 0
    }
    report["usable_current_runtime_codes"] = {
        "enabled_and_nonnull": len(enabled & with_values) if "coverage" in facts else None,
        "enabled_but_without_nonnull": sorted(enabled - with_values)
        if "coverage" in facts
        else None,
        "enabled_local_lineage_codes": sum(
            any(
                str(row.get("source_metric_code") or "").startswith("LOCAL:")
                for row in item["official_items"]
                if row["enabled"]
            )
            for item in catalog.get("matches", [])
            if item["status"] == "enabled"
        ),
    }
    report["data_provenance_assessment"] = {
        "classification": "local_fact_store_with_test_markers"
        if test_marker_rows
        else "unverified_local_fact_store"
        if "BASE TABLE" in table_types
        else "view_source_requires_provenance_confirmation"
        if "VIEW" in table_types
        else "unavailable",
        "test_marker_rows": test_marker_rows,
        "test_marker_scope": marker_scope,
        "real_lake_acceptance_proven": False,
        "reason": "Database name, localhost address, official catalog codes and nonnull values "
        "do not by themselves prove upstream lake provenance or freshness.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "output": str(args.output),
                "configuration": report["configuration"],
                "application_connected": report.get("application", {}).get("connected"),
                "query_connected": report.get("query_source", {}).get("connected"),
                "data_provenance_assessment": report["data_provenance_assessment"],
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
