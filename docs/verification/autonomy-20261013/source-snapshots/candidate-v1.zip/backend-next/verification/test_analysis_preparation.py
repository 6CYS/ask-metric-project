"""分析约束、准备与执行契约回归；仅临时 SQLite 和合成只读数据源。"""

import hashlib
import json
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import ValidationError
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from ask_metric.api.dependencies import require_actor
from ask_metric.api.query_readiness import require_query_ready
from ask_metric.api.routes.analysis import get_analysis_service, router
from ask_metric.application.analysis_service import AnalysisApplicationService, query_spec_hash
from ask_metric.application.commands import ExecuteQueryCommand, SubmitQuestionCommand
from ask_metric.application.ports import ScopedOrganizationPermissionService
from ask_metric.application.query_execution_service import QueryExecutionApplicationService
from ask_metric.application.requests import ActorContext, IncomingRequest
from ask_metric.application.task_service import QueryTaskApplicationService
from ask_metric.core.errors import ApplicationError, install_exception_handlers
from ask_metric.domain.analysis import (
    AnalysisConstraintRequest,
    AnalysisPrepareRequest,
    CatalogReferenceRequest,
)
from ask_metric.domain.basic_query import BasicQuerySpec
from ask_metric.domain.query_execution import QueryPlanner
from ask_metric.domain.task import QueryTaskState
from ask_metric.infrastructure.db.base import Base
from ask_metric.infrastructure.db.models import (
    AnalysisConstraintSnapshot,
    ChatConversation,
    MetricSynonym,
    MetricTerm,
    OrgTerm,
    QueryRun,
    QueryTask,
)
from ask_metric.infrastructure.db.schema_governance import MANAGED_TABLES
from ask_metric.infrastructure.db.unit_of_work import SqlAlchemyUnitOfWork

DAY = {"start": "2026-04-30", "end": "2026-04-30"}
TOKEN = "isolated-test-service-token"


def test_analysis_snapshot_is_in_governed_schema_inventory():
    assert AnalysisConstraintSnapshot.__tablename__ in MANAGED_TABLES


@pytest.fixture
def env(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'analysis.db'}")
    Base.metadata.create_all(engine)
    sessions = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    with sessions() as session:
        session.add_all(
            [
                ChatConversation(id="c", owner_user_id="u", title="合成会话"),
                ChatConversation(id="other", owner_user_id="v", title="另一合成会话"),
                MetricTerm(metric_code="M1", metric_name="合成存款余额", unit="元"),
                MetricTerm(metric_code="M2", metric_name="合成客户数量", unit="户"),
                MetricTerm(metric_code="M3", metric_name="合成存款增幅", unit="%"),
                OrgTerm(org_code="A", org_name="合成甲行"),
                OrgTerm(org_code="B", org_name="合成乙行"),
            ]
        )
        session.commit()
    actor = ActorContext(
        subject="synthetic",
        user_id="u",
        org_id="A",
        role_code="SYSTEM_ADMIN",
        authentication_method="test",
        trust_level="authenticated",
    )
    source = Mock()
    source.execute_readonly.return_value = SimpleNamespace(
        rows=[
            {
                "metric_code": "M1",
                "metric_name": "合成存款余额",
                "org_code": "A",
                "org_name": "合成甲行",
                "stat_date": "2026-04-30",
                "metric_value": Decimal("12.5"),
                "unit": "元",
            }
        ],
        latency_ms=1,
    )

    def uow_factory():
        return SqlAlchemyUnitOfWork(sessions)

    execution = QueryExecutionApplicationService(
        planner=QueryPlanner(dialect="mysql"),
        data_source=source,
        permission_service=ScopedOrganizationPermissionService(),
        uow_factory=uow_factory,
    )
    service = AnalysisApplicationService(
        execution=execution, service_token=TOKEN, uow_factory=uow_factory
    )
    yield SimpleNamespace(
        service=service,
        execution=execution,
        actor=actor,
        source=source,
        sessions=sessions,
        uow_factory=uow_factory,
    )
    engine.dispose()


def constraints(**changes):
    question = changes.pop("source_question", "分析合成甲行的经营情况")
    value = {
        "conversation_id": "c",
        "analysis_id": "a",
        "constraint_version": 1,
        "source_question": question,
        "source_question_sha256": hashlib.sha256(question.encode()).hexdigest(),
        "targets": [
            {
                "target_id": "t",
                "org_codes": ["A"],
                "time": DAY,
                "allowed_metric_codes": ["M1", "M2"],
            }
        ],
        "requirements": [
            {"requirement_id": "r", "target_ids": ["t"], "description": "按正式证据描述经营表现"}
        ],
        **changes,
    }
    return AnalysisConstraintRequest.model_validate(value)


def prepare(env, *, constraint=None, metrics=("M1",), **changes):
    if constraint is None:
        constraint = env.service.register_constraints(constraints(), env.actor)
    refs = env.service.catalog_references(
        CatalogReferenceRequest(
            conversation_id="c",
            metric_codes=list(metrics),
        ),
        env.actor,
    ).references
    return AnalysisPrepareRequest.model_validate(
        {
            "constraint_ref": constraint.constraint_ref,
            "prepare_key": "pk",
            "step_id": "s",
            "step_revision": 1,
            "target_id": "t",
            "requirement_ids": ["r"],
            "query": {
                "metric_codes": list(metrics),
                "org_codes": ["A"],
                "time": DAY,
                "selection": "exact",
            },
            "catalog_refs": [ref.model_dump() for ref in refs],
            **changes,
        }
    )


def assert_error(code, action):
    with pytest.raises(ApplicationError) as captured:
        action()
    assert captured.value.code == code


def test_prepare_is_persistent_immutable_and_does_not_execute_sql(env):
    payload = prepare(env)
    result = env.service.prepare(payload, env.actor)
    assert result.status == "prepared"
    assert result.spec_hash == query_spec_hash(payload.query)
    assert env.service.prepare(payload, env.actor) == result
    assert env.service.find_prepared("pk", "c", env.actor) == result
    with env.sessions() as session:
        task = session.get(QueryTask, result.task_id)
        assert task.status == "PREPARED"
        assert task.current_stage == "ANALYSIS_PREPARED"
        assert session.execute(select(QueryRun)).scalars().all() == []
    env.source.execute_readonly.assert_not_called()
    assert_error(
        "ANALYSIS_PREPARE_CONFLICT",
        lambda: env.service.prepare(
            payload.model_copy(update={"step_id": "different"}),
            env.actor,
        ),
    )


def test_prepared_execute_reuses_existing_query_engine_and_full_result_replay(env):
    result = env.service.prepare(prepare(env), env.actor)
    query, first = env.service.execute(result.prepared_query_ref, "pk", env.actor)
    assert query.metric_codes == ["M1"]
    assert first.status == "succeeded"
    assert first.row_count == 1
    assert first.rows[0]["metric_value"] == "12.5"
    _, replay = env.service.execute(result.prepared_query_ref, "pk", env.actor)
    assert replay.idempotent_replay is True
    assert replay.rows == first.rows
    assert env.service.find_prepared("pk", "c", env.actor).status == "settled"
    env.source.execute_readonly.assert_called_once()


def test_ordinary_execute_cannot_bypass_prepared_service_boundary(env):
    result = env.service.prepare(prepare(env), env.actor)
    assert_error(
        "ANALYSIS_EXECUTION_REQUIRED",
        lambda: env.execution.execute(
            ExecuteQueryCommand(
                task_id=result.task_id,
                expected_version=result.task_version,
                request_id="bypass",
                actor=env.actor,
            )
        ),
    )
    assert_error(
        "ANALYSIS_EXECUTION_KEY_MISMATCH",
        lambda: env.service.execute(
            result.prepared_query_ref,
            "new-key",
            env.actor,
        ),
    )
    env.source.execute_readonly.assert_not_called()


def test_same_constraint_version_cannot_redefine_fixed_targets(env):
    original = constraints()
    first = env.service.register_constraints(original, env.actor)
    assert env.service.register_constraints(original, env.actor) == first
    edited = original.model_dump(mode="json")
    edited["targets"][0]["org_codes"] = ["B"]
    assert_error(
        "ANALYSIS_CONSTRAINT_CONFLICT",
        lambda: env.service.register_constraints(
            AnalysisConstraintRequest.model_validate(edited),
            env.actor,
        ),
    )


def test_hash_and_constraint_version_are_checked(env):
    assert_error(
        "ANALYSIS_SOURCE_MISMATCH",
        lambda: env.service.register_constraints(
            constraints(source_question_sha256="0" * 64),
            env.actor,
        ),
    )
    first = env.service.register_constraints(constraints(constraint_version=2), env.actor)
    assert first.constraint_version == 2
    assert_error(
        "ANALYSIS_CONSTRAINT_VERSION",
        lambda: env.service.register_constraints(
            constraints(constraint_version=4, prior_constraint_ref=first.constraint_ref),
            env.actor,
        ),
    )
    payload = prepare(env, constraint=first, spec_hash="0" * 64)
    assert_error("ANALYSIS_SPEC_HASH_MISMATCH", lambda: env.service.prepare(payload, env.actor))


@pytest.mark.parametrize(
    "change",
    [
        {"org_codes": ["B"]},
        {"time": {"start": "2026-05-01", "end": "2026-05-01"}},
    ],
)
def test_query_cannot_expand_bound_target(env, change):
    payload = prepare(env)
    query = payload.query.model_dump(mode="json")
    query.update(change)
    payload = payload.model_copy(update={"query": BasicQuerySpec.model_validate(query)})
    assert_error("ANALYSIS_TARGET_MISMATCH", lambda: env.service.prepare(payload, env.actor))
    env.source.execute_readonly.assert_not_called()


def test_allowlist_and_catalog_selection_are_distinct(env):
    assert_error(
        "ANALYSIS_TARGET_MISMATCH",
        lambda: env.service.prepare(
            prepare(env, metrics=("M3",)),
            env.actor,
        ),
    )
    broader = constraints(
        analysis_id="catalog",
        targets=[
            {
                "target_id": "t",
                "org_codes": ["A"],
                "time": DAY,
                "metric_selection_policy": "catalog",
                "allowed_metric_codes": [],
            }
        ],
    )
    snapshot = env.service.register_constraints(broader, env.actor)
    result = env.service.prepare(prepare(env, constraint=snapshot, metrics=("M3",)), env.actor)
    assert result.query.metric_codes == ["M3"]
    with pytest.raises(ValidationError):
        constraints(targets=[{"target_id": "t", "org_codes": ["A"], "time": DAY}])


def test_formal_named_metrics_cannot_disappear_but_can_be_split_across_steps(env):
    targets = [
        {"target_id": "t", "org_codes": ["A"], "time": DAY, "fixed_metric_codes": ["M1", "M2"]}
    ]
    payload = constraints(source_question="分析合成存款余额和合成客户数量", targets=targets)
    snapshot = env.service.register_constraints(payload, env.actor)
    result = env.service.prepare(prepare(env, constraint=snapshot, metrics=("M1",)), env.actor)
    assert result.query.metric_codes == ["M1"]
    assert_error(
        "ANALYSIS_EXPLICIT_TARGET_MISSING",
        lambda: env.service.register_constraints(
            constraints(analysis_id="missing", source_question="分析合成存款余额"),
            env.actor,
        ),
    )
    assert_error(
        "ANALYSIS_FIXED_METRIC_SOURCE",
        lambda: env.service.register_constraints(
            constraints(analysis_id="fabricated", targets=targets),
            env.actor,
        ),
    )


def test_target_binding_does_not_create_cross_product(env):
    payload = constraints(
        targets=[
            {"target_id": "t", "org_codes": ["A"], "time": DAY, "allowed_metric_codes": ["M1"]},
            {
                "target_id": "u",
                "org_codes": ["B"],
                "time": {"start": "2026-05-31", "end": "2026-05-31"},
                "allowed_metric_codes": ["M2"],
            },
        ],
        requirements=[{"requirement_id": "r", "target_ids": ["t", "u"], "description": "分别比较"}],
    )
    snapshot = env.service.register_constraints(payload, env.actor)
    assert_error(
        "ANALYSIS_TARGET_MISMATCH",
        lambda: env.service.prepare(
            prepare(env, constraint=snapshot, metrics=("M2",)),
            env.actor,
        ),
    )


def test_discrete_date_target_cannot_be_widened_to_continuous_series(env):
    snapshot = env.service.register_constraints(
        constraints(
            targets=[
                {
                    "target_id": "t",
                    "org_codes": ["A"],
                    "allowed_metric_codes": ["M1"],
                    "time": {
                        "start": "2026-03-31",
                        "end": "2026-04-30",
                        "dates": ["2026-03-31", "2026-04-30"],
                    },
                }
            ]
        ),
        env.actor,
    )
    payload = prepare(env, constraint=snapshot)
    query = BasicQuerySpec(
        metric_codes=["M1"],
        org_codes=["A"],
        time={"start": "2026-03-31", "end": "2026-04-30"},
        selection="all_in_range",
    )
    assert_error(
        "ANALYSIS_TARGET_MISMATCH",
        lambda: env.service.prepare(
            payload.model_copy(update={"query": query}),
            env.actor,
        ),
    )


def test_refs_cannot_be_forged_swapped_or_reused_across_conversations(env):
    payload = prepare(env)
    for ref in ("catalog.v1.bad.bad", payload.catalog_refs[0].catalog_ref.replace("v1", "v2")):
        forged = payload.model_dump(mode="json")
        forged["catalog_refs"][0]["catalog_ref"] = ref
        assert_error(
            "ANALYSIS_PROVENANCE_INVALID",
            lambda forged=forged: env.service.prepare(
                AnalysisPrepareRequest.model_validate(forged),
                env.actor,
            ),
        )
    wrong_code = payload.model_dump(mode="json")
    wrong_code["catalog_refs"][0]["metric_code"] = "M2"
    assert_error(
        "ANALYSIS_PROVENANCE_INVALID",
        lambda: env.service.prepare(
            AnalysisPrepareRequest.model_validate(wrong_code),
            env.actor,
        ),
    )


def test_prepared_refs_and_reads_require_current_owner(env):
    result = env.service.prepare(prepare(env), env.actor)
    other = env.actor.model_copy(update={"user_id": "v"})
    assert_error("CONVERSATION_NOT_FOUND", lambda: env.service.find_prepared("pk", "c", other))
    assert_error(
        "ANALYSIS_PREPARED_NOT_FOUND",
        lambda: env.service.execute(
            result.prepared_query_ref,
            "pk",
            other,
        ),
    )
    assert_error(
        "CONVERSATION_NOT_FOUND",
        lambda: env.service.register_constraints(
            constraints(conversation_id="other"),
            env.actor,
        ),
    )


def test_permission_revocation_is_checked_again_at_execute(env):
    snapshot = env.service.register_constraints(
        constraints(
            targets=[
                {
                    "target_id": "t",
                    "org_codes": ["B"],
                    "time": DAY,
                    "allowed_metric_codes": ["M1"],
                }
            ]
        ),
        env.actor,
    )
    payload = prepare(env, constraint=snapshot)
    payload.query.org_codes = ["B"]
    result = env.service.prepare(payload, env.actor)
    limited = env.actor.model_copy(update={"role_code": "USER"})
    assert_error(
        "ORG_SCOPE_FORBIDDEN",
        lambda: env.service.execute(
            result.prepared_query_ref,
            "pk",
            limited,
        ),
    )
    env.source.execute_readonly.assert_not_called()


def test_metadata_change_invalidates_signed_catalog_reference(env):
    result = env.service.prepare(prepare(env), env.actor)
    with env.sessions() as session:
        metric = session.execute(
            select(MetricTerm).where(MetricTerm.metric_code == "M1")
        ).scalar_one()
        metric.unit = "亿元"
        metric.updated_at = datetime.now(UTC) + timedelta(seconds=2)
        session.commit()
    assert_error(
        "ANALYSIS_PROVENANCE_INVALID",
        lambda: env.service.execute(
            result.prepared_query_ref,
            "pk",
            env.actor,
        ),
    )
    env.source.execute_readonly.assert_not_called()


def test_revision_invalidates_old_step_and_preserves_true_followup_source(env):
    first = env.service.register_constraints(
        constraints(
            source_question="分析合成存款余额",
            targets=[
                {
                    "target_id": "t",
                    "org_codes": ["A"],
                    "time": DAY,
                    "fixed_metric_codes": ["M1"],
                }
            ],
        ),
        env.actor,
    )
    prepared = env.service.prepare(prepare(env, constraint=first), env.actor)
    second = env.service.register_constraints(
        constraints(
            constraint_version=2,
            source_question="那合成乙行呢",
            prior_constraint_ref=first.constraint_ref,
            targets=[
                {"target_id": "t", "org_codes": ["B"], "time": DAY, "fixed_metric_codes": ["M1"]}
            ],
        ),
        env.actor,
    )
    assert second.constraint_version == 2
    assert env.service.find_prepared("pk", "c", env.actor).status == "invalidated"
    assert_error(
        "ANALYSIS_CONSTRAINT_STALE",
        lambda: env.service.execute(
            prepared.prepared_query_ref,
            "pk",
            env.actor,
        ),
    )
    with env.sessions() as session:
        row = session.get(AnalysisConstraintSnapshot, second.constraint_ref)
        assert row.snapshot_json["source_question"] == "那合成乙行呢"
        assert row.snapshot_json["prior_constraint_ref"] == first.constraint_ref


def test_history_query_can_anchor_initial_analysis_without_fabricated_question(env):
    tasks = QueryTaskApplicationService(env.uow_factory)
    created = tasks.submit_question(
        SubmitQuestionCommand(
            request=IncomingRequest(
                request_id="q", channel="basic_query", conversation_id="c", text="合成存款余额"
            ),
            actor=env.actor,
            idempotency_key="direct",
            basic_query=BasicQuerySpec(
                metric_codes=["M1"], org_codes=["A"], time=DAY, selection="exact"
            ),
        )
    )
    snapshot = env.service.register_constraints(
        constraints(
            source_question="分析一下",
            prior_query_task_id=created.task_id,
            targets=[
                {"target_id": "t", "org_codes": ["A"], "time": DAY, "fixed_metric_codes": ["M1"]}
            ],
        ),
        env.actor,
    )
    assert snapshot.constraint_version == 1


def test_same_step_revision_cannot_be_reprepared_with_another_key(env):
    payload = prepare(env)
    env.service.prepare(payload, env.actor)
    assert_error(
        "ANALYSIS_STEP_CONFLICT",
        lambda: env.service.prepare(
            payload.model_copy(update={"prepare_key": "different"}),
            env.actor,
        ),
    )


def source_message(question):
    return {
        "source_question": question,
        "source_question_sha256": hashlib.sha256(question.encode()).hexdigest(),
    }


def source_span(question):
    return {"start": 0, "end": len(question), "text": question}


def test_revision_preserves_fixed_metrics_and_requires_latest_prior(env):
    first = env.service.register_constraints(
        constraints(
            source_question="分析合成存款余额和合成客户数量",
            targets=[
                {
                    "target_id": "t",
                    "org_codes": ["A"],
                    "time": DAY,
                    "fixed_metric_codes": ["M1", "M2"],
                }
            ],
        ),
        env.actor,
    )
    revised = constraints(
        constraint_version=2,
        prior_constraint_ref=first.constraint_ref,
        source_question="那合成乙行呢",
        targets=[
            {
                "target_id": "t",
                "org_codes": ["B"],
                "time": DAY,
                "fixed_metric_codes": ["M1"],
            }
        ],
    )
    assert_error(
        "ANALYSIS_FIXED_TARGETS_PRESERVED",
        lambda: env.service.register_constraints(
            revised,
            env.actor,
        ),
    )
    assert_error(
        "ANALYSIS_SOURCE_MISMATCH",
        lambda: env.service.register_constraints(
            revised.model_copy(update={"prior_constraint_ref": None}),
            env.actor,
        ),
    )
    valid = revised.model_dump(mode="json")
    valid["targets"][0]["fixed_metric_codes"] = ["M1", "M2"]
    valid["targets"][0]["time"] = {"start": "2026-05-31", "end": "2026-05-31"}
    second = env.service.register_constraints(
        AnalysisConstraintRequest.model_validate(valid), env.actor
    )
    assert second.constraint_version == 2


def test_user_metric_replacement_addition_and_removal_have_exact_update_contract(env):
    first = env.service.register_constraints(
        constraints(
            source_question="分析合成存款余额",
            targets=[
                {
                    "target_id": "t",
                    "org_codes": ["A"],
                    "time": DAY,
                    "fixed_metric_codes": ["M1"],
                }
            ],
        ),
        env.actor,
    )
    question = "再加合成客户数量"
    second = env.service.register_constraints(
        constraints(
            constraint_version=2,
            prior_constraint_ref=first.constraint_ref,
            source_question=question,
            targets=[
                {
                    "target_id": "t",
                    "org_codes": ["A"],
                    "time": DAY,
                    "fixed_metric_codes": ["M1", "M2"],
                }
            ],
            fixed_metric_updates=[
                {
                    "target_id": "t",
                    "mode": "add",
                    "codes": ["M2"],
                    "source_span": source_span(question),
                }
            ],
        ),
        env.actor,
    )
    question = "改为合成客户数量"
    third = env.service.register_constraints(
        constraints(
            constraint_version=3,
            prior_constraint_ref=second.constraint_ref,
            source_question=question,
            targets=[
                {"target_id": "t", "org_codes": ["A"], "time": DAY, "fixed_metric_codes": ["M2"]}
            ],
            fixed_metric_updates=[
                {
                    "target_id": "t",
                    "mode": "replace",
                    "codes": ["M2"],
                    "source_span": source_span(question),
                }
            ],
        ),
        env.actor,
    )
    question = "不要合成客户数量"
    fourth = env.service.register_constraints(
        constraints(
            constraint_version=4,
            prior_constraint_ref=third.constraint_ref,
            source_question=question,
            targets=[
                {
                    "target_id": "t",
                    "org_codes": ["A"],
                    "time": DAY,
                    "metric_selection_policy": "catalog",
                    "fixed_metric_codes": [],
                }
            ],
            fixed_metric_updates=[
                {
                    "target_id": "t",
                    "mode": "remove",
                    "codes": ["M2"],
                    "source_span": source_span(question),
                }
            ],
        ),
        env.actor,
    )
    assert fourth.constraint_version == 4


def test_metric_update_cannot_lie_about_delta_or_source_span(env):
    first = env.service.register_constraints(
        constraints(
            source_question="分析合成存款余额",
            targets=[
                {
                    "target_id": "t",
                    "org_codes": ["A"],
                    "time": DAY,
                    "fixed_metric_codes": ["M1"],
                }
            ],
        ),
        env.actor,
    )
    question = "改为合成客户数量"
    request = constraints(
        constraint_version=2,
        prior_constraint_ref=first.constraint_ref,
        source_question=question,
        targets=[
            {"target_id": "t", "org_codes": ["A"], "time": DAY, "fixed_metric_codes": ["M1", "M2"]}
        ],
        fixed_metric_updates=[
            {
                "target_id": "t",
                "mode": "replace",
                "codes": ["M2"],
                "source_span": source_span(question),
            }
        ],
    )
    assert_error(
        "ANALYSIS_METRIC_UPDATE_MISMATCH",
        lambda: env.service.register_constraints(
            request,
            env.actor,
        ),
    )
    raw = request.model_dump(mode="json")
    raw["fixed_metric_updates"][0]["source_span"]["text"] = "不是本轮原文"
    assert_error(
        "ANALYSIS_SOURCE_MISMATCH",
        lambda: env.service.register_constraints(
            AnalysisConstraintRequest.model_validate(raw),
            env.actor,
        ),
    )


def test_first_snapshot_after_real_pending_confirmation_can_start_at_later_version(env):
    with env.sessions() as session:
        session.add_all(
            [
                MetricSynonym(metric_code="M1", synonym="合成指标"),
                MetricSynonym(metric_code="M2", synonym="合成指标"),
            ]
        )
        session.commit()
    original = "分析合成指标"
    payload = constraints(
        constraint_version=2,
        source_question="第一个",
        source_history=[source_message(original)],
        metric_source_question=original,
        source_metric_bindings=[{"start": 2, "end": 6, "text": "合成指标", "codes": ["M1"]}],
        targets=[{"target_id": "t", "org_codes": ["A"], "time": DAY, "fixed_metric_codes": ["M1"]}],
    )
    snapshot = env.service.register_constraints(payload, env.actor)
    assert snapshot.constraint_version == 2
    bad = payload.model_dump(mode="json")
    bad["analysis_id"] = "wrong-candidate"
    bad["source_metric_bindings"][0]["codes"] = ["M3"]
    bad["targets"][0]["fixed_metric_codes"] = ["M3"]
    assert_error(
        "METRIC_TARGETS_UNRESOLVED",
        lambda: env.service.register_constraints(
            AnalysisConstraintRequest.model_validate(bad),
            env.actor,
        ),
    )
    bad = payload.model_dump(mode="json")
    bad["analysis_id"] = "unknown-original"
    bad["source_history"] = []
    assert_error(
        "ANALYSIS_SOURCE_MISMATCH",
        lambda: env.service.register_constraints(
            AnalysisConstraintRequest.model_validate(bad),
            env.actor,
        ),
    )


def test_prepared_response_loss_can_be_recovered_after_service_restart(env):
    payload = prepare(env)
    first = env.service.prepare(payload, env.actor)
    restarted = AnalysisApplicationService(
        execution=env.execution,
        service_token=TOKEN,
        uow_factory=env.uow_factory,
    )
    recovered = restarted.find_prepared("pk", "c", env.actor)
    assert recovered == first
    assert restarted.prepare(payload, env.actor).task_id == first.task_id
    restarted.execute(recovered.prepared_query_ref, recovered.prepare_key, env.actor)
    restarted_again = AnalysisApplicationService(
        execution=env.execution,
        service_token=TOKEN,
        uow_factory=env.uow_factory,
    )
    _, replay = restarted_again.execute(first.prepared_query_ref, "pk", env.actor)
    assert replay.idempotent_replay is True
    env.source.execute_readonly.assert_called_once()


def test_crash_before_engine_registration_keeps_prepared_state(env):
    first = env.service.prepare(prepare(env), env.actor)
    original = env.execution.execute
    env.execution.execute = Mock(side_effect=RuntimeError("isolated crash before engine"))
    with pytest.raises(RuntimeError):
        env.service.execute(first.prepared_query_ref, "pk", env.actor)
    with env.sessions() as session:
        task = session.get(QueryTask, first.task_id)
        assert task.status == "PREPARED"
        assert task.version == 0
    assert env.service.find_prepared("pk", "c", env.actor).status == "prepared"
    env.execution.execute = original
    _, result = env.service.execute(first.prepared_query_ref, "pk", env.actor)
    assert result.status == "succeeded"
    env.source.execute_readonly.assert_called_once()


def test_legacy_running_gap_without_queryrun_can_resume_original_key(env):
    first = env.service.prepare(prepare(env), env.actor)
    with env.sessions() as session:
        task = session.get(QueryTask, first.task_id)
        state = QueryTaskState.model_validate(task.state_json)
        state.analysis_execution_v1.status = "executing"
        task.state_json = state.model_dump(mode="json")
        task.status = "RUNNING"
        task.current_stage = "LOGICAL_DSL"
        task.version = 1
        session.commit()
    assert env.service.find_prepared("pk", "c", env.actor).status == "prepared"
    _, result = env.service.execute(first.prepared_query_ref, "pk", env.actor)
    assert result.status == "succeeded"
    env.source.execute_readonly.assert_called_once()


def test_stale_registered_execution_is_read_as_interrupted_and_reclaimed_without_sql(env):
    first = env.service.prepare(prepare(env), env.actor)
    with env.sessions() as session:
        run = QueryRun(
            task_id=first.task_id,
            conversation_id="c",
            user_message="合成原文",
            intent="metric_query",
            query_shape="metric_value",
            status="running",
        )
        session.add(run)
        session.flush()
        task = session.get(QueryTask, first.task_id)
        state = QueryTaskState.model_validate(task.state_json)
        state.analysis_execution_v1.status = "executing"
        state.execution = {
            "request_id": "analysis:pk",
            "run_id": run.id,
            "status": "running",
            "started_at": (datetime.now(UTC) - timedelta(hours=1)).isoformat(),
        }
        task.state_json = state.model_dump(mode="json")
        task.status = "RUNNING"
        task.current_stage = "EXECUTION"
        task.version = 1
        session.commit()
    assert env.service.find_prepared("pk", "c", env.actor).status == "interrupted"
    _, result = env.service.execute(first.prepared_query_ref, "pk", env.actor)
    assert result.status == "failed"
    assert result.error_code == "QUERY_EXECUTION_INTERRUPTED"
    assert env.service.find_prepared("pk", "c", env.actor).status == "settled"
    env.source.execute_readonly.assert_not_called()


def test_catalog_ref_is_bound_to_exact_conversation(env):
    refs = env.service.catalog_references(
        CatalogReferenceRequest(conversation_id="c", metric_codes=["M1"]),
        env.actor,
    ).references
    with env.sessions() as session:
        session.add(ChatConversation(id="c2", owner_user_id="u", title="另一个本人会话"))
        session.commit()
    snapshot = env.service.register_constraints(constraints(conversation_id="c2"), env.actor)
    payload = AnalysisPrepareRequest(
        constraint_ref=snapshot.constraint_ref,
        prepare_key="pk",
        step_id="s",
        step_revision=1,
        target_id="t",
        requirement_ids=["r"],
        query=BasicQuerySpec(metric_codes=["M1"], org_codes=["A"], time=DAY, selection="exact"),
        catalog_refs=refs,
    )
    assert_error("ANALYSIS_PROVENANCE_INVALID", lambda: env.service.prepare(payload, env.actor))


def test_unknown_organization_returns_recognizable_error_without_preparation(env):
    assert_error(
        "ANALYSIS_CATALOG_INVALID",
        lambda: env.service.register_constraints(
            constraints(
                targets=[
                    {
                        "target_id": "t",
                        "org_codes": ["UNKNOWN"],
                        "time": DAY,
                        "allowed_metric_codes": ["M1"],
                    }
                ]
            ),
            env.actor,
        ),
    )
    env.source.execute_readonly.assert_not_called()


def test_step_cannot_claim_unrelated_requirement_or_runtime_authority(env):
    payload = prepare(env)
    assert_error(
        "ANALYSIS_REQUIREMENT_MISMATCH",
        lambda: env.service.prepare(
            payload.model_copy(update={"requirement_ids": ["unregistered"]}),
            env.actor,
        ),
    )
    with pytest.raises(ValidationError):
        AnalysisPrepareRequest.model_validate(
            {**payload.model_dump(), "source": "analysis_selected"}
        )


def test_execution_rejects_mutated_task_spec_before_sql(env):
    result = env.service.prepare(prepare(env), env.actor)
    with env.sessions() as session:
        task = session.get(QueryTask, result.task_id)
        state = QueryTaskState.model_validate(task.state_json)
        state.logical_dsl["metrics"] = ["M2"]
        task.state_json = state.model_dump(mode="json")
        session.commit()
    assert_error(
        "ANALYSIS_SPEC_HASH_MISMATCH",
        lambda: env.service.execute(
            result.prepared_query_ref,
            "pk",
            env.actor,
        ),
    )
    env.source.execute_readonly.assert_not_called()


def test_http_analysis_requires_separate_service_token_and_user_auth(env):
    app = FastAPI()
    app.state.settings = SimpleNamespace(agent_service_token=TOKEN)
    app.include_router(router)
    install_exception_handlers(app)
    app.dependency_overrides[require_actor] = lambda: env.actor
    app.dependency_overrides[get_analysis_service] = lambda: env.service
    app.dependency_overrides[require_query_ready] = lambda: None
    with TestClient(app) as client:
        body = constraints().model_dump(mode="json")
        assert client.post("/api/v1/analysis/constraints", json=body).status_code == 403
        assert (
            client.post(
                "/api/v1/analysis/constraints",
                json=body,
                headers={"X-Agent-Service-Token": "wrong"},
            ).status_code
            == 403
        )
        assert (
            client.post(
                "/api/v1/analysis/constraints", json=body, headers={"X-Agent-Service-Token": TOKEN}
            ).status_code
            == 200
        )
        app.state.settings.agent_service_token = ""
        assert (
            client.post(
                "/api/v1/analysis/constraints", json=body, headers={"X-Agent-Service-Token": TOKEN}
            ).status_code
            == 503
        )
        app.state.settings.agent_service_token = TOKEN
        del app.dependency_overrides[require_actor]
        assert (
            client.post(
                "/api/v1/analysis/constraints",
                json=body,
                headers={"X-Agent-Service-Token": TOKEN},
            ).status_code
            == 401
        )


def test_unmigrated_analysis_table_does_not_block_basic_precise_query(env):
    """旧库未迁移 0006 且分析默认关闭时，既有精准入口仍执行并重放正式结果。"""
    from sqlalchemy import inspect

    from ask_metric.api.dependencies import (
        get_query_execution_service,
        get_query_task_service,
    )
    from ask_metric.api.routes.tasks import router as tasks_router
    from ask_metric.infrastructure.db.readiness import SqlAlchemyDatabaseReadiness
    from ask_metric.infrastructure.model.query_initialization import QueryInitialization

    with env.sessions() as session:
        engine = session.get_bind()
    # 只删除本测试临时 SQLite 中的分析新增表，模拟未应用 0006 的应用库。
    AnalysisConstraintSnapshot.__table__.drop(engine)
    assert not inspect(engine).has_table("analysis_constraint_snapshots")
    assert SqlAlchemyDatabaseReadiness(engine).is_ready() is True

    app = FastAPI()
    app.state.settings = SimpleNamespace(agent_service_token="")
    app.state.query_initialization = QueryInitialization(enabled=False)
    app.include_router(tasks_router)
    app.include_router(router)
    install_exception_handlers(app)
    app.dependency_overrides[require_actor] = lambda: env.actor
    app.dependency_overrides[get_query_execution_service] = lambda: env.execution
    app.dependency_overrides[get_query_task_service] = lambda: QueryTaskApplicationService(
        env.uow_factory
    )

    @app.middleware("http")
    async def request_identity(request, call_next):
        request.state.request_id = "legacy-precise-test"
        return await call_next(request)

    payload = {
        "conversation_id": "c",
        "source_question": "查询合成甲行2026年4月30日的合成存款余额",
        "metric_codes": ["M1"],
        "org_codes": ["A"],
        "time": DAY,
        "selection": "exact",
    }
    with TestClient(app) as client:
        disabled = client.post(
            "/api/v1/analysis/constraints", json=constraints().model_dump(mode="json")
        )
        assert disabled.status_code == 503
        assert disabled.json()["code"] == "ANALYSIS_DISABLED"
        precise = client.post(
            "/api/v1/basic-queries", json=payload, headers={"Idempotency-Key": "legacy-precise"}
        )
        assert precise.status_code == 200, precise.json()
        result = precise.json()["result"]
        assert result["status"] == "succeeded"
        assert result["facts"][0]["metric_code"] == "M1"
        assert result["facts"][0]["value"] == "12.5"
        replay = client.post(
            "/api/v1/basic-queries", json=payload, headers={"Idempotency-Key": "legacy-precise"}
        )
        assert replay.status_code == 200, replay.json()
        assert replay.json()["result"]["idempotent_replay"] is True
        assert replay.json()["result"]["facts"] == result["facts"]
    env.source.execute_readonly.assert_called_once()
    with env.sessions() as session:
        task = session.get(QueryTask, result["task_id"])
        assert QueryTaskState.model_validate(task.state_json).analysis_execution_v1 is None
        assert len(session.execute(select(QueryRun)).scalars().all()) == 1


def test_actual_typescript_runtime_payload_through_real_python_api_and_service(env):
    """消费 actual NativeAnalysisStore 导出请求，仅替换后端动态签发引用。

    两侧各自桩曾漏掉 query extras / string catalog_refs；此处真正经过 Pydantic、
    API、SQLite 约束持久化、只读规划、执行器和正式结果快照，外部事实源仍是明确合成桩。
    """
    fixture_path = Path(__file__).resolve().parents[2] / (
        "docs/verification/autonomy-20261013/runtime-analysis-contract-fixture.json"
    )
    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    assert "NativeAnalysisStore" in fixture["provenance"]
    with env.sessions() as session:
        session.add_all(
            [
                ChatConversation(id="conversation-a", owner_user_id="u", title="跨语言合成会话"),
                MetricTerm(metric_code="metric-a", metric_name="合成对照指标", unit="元"),
                OrgTerm(org_code="org-a", org_name="样本行"),
            ]
        )
        session.commit()
    env.source.execute_readonly.return_value = SimpleNamespace(
        rows=[
            {
                "metric_code": "metric-a",
                "metric_name": "合成对照指标",
                "org_code": "org-a",
                "org_name": "样本行",
                "stat_date": "2026-03-31",
                "metric_value": Decimal("7.25"),
                "unit": "元",
            }
        ],
        latency_ms=1,
    )
    app = FastAPI()
    app.state.settings = SimpleNamespace(agent_service_token=TOKEN)
    app.include_router(router)
    install_exception_handlers(app)
    app.dependency_overrides[require_actor] = lambda: env.actor
    app.dependency_overrides[get_analysis_service] = lambda: env.service
    app.dependency_overrides[require_query_ready] = lambda: None
    headers = {"X-Agent-Service-Token": TOKEN}
    with TestClient(app) as client:
        registered = client.post(
            "/api/v1/analysis/constraints", json=fixture["constraints"], headers=headers
        )
        assert registered.status_code == 200, registered.json()
        references = client.post(
            "/api/v1/analysis/catalog-references",
            json=fixture["catalog_references"],
            headers=headers,
        )
        assert references.status_code == 200, references.json()
        real_refs = {
            item["metric_code"]: item["catalog_ref"] for item in references.json()["references"]
        }
        payload = json.loads(json.dumps(fixture["prepare"]))
        payload["constraint_ref"] = registered.json()["constraint_ref"]
        for entry in payload["catalog_refs"]:
            assert set(entry) == {"metric_code", "catalog_ref"}
            entry["catalog_ref"] = real_refs[entry["metric_code"]]
        assert "conversation_id" not in payload["query"]
        assert "calculation_context" not in payload["query"]
        prepared = client.post("/api/v1/analysis/prepare", json=payload, headers=headers)
        assert prepared.status_code == 200, prepared.json()
        assert prepared.json()["query"]["time"] == payload["query"]["time"]
        env.source.execute_readonly.assert_not_called()
        execute_body = dict(fixture["execute"])
        execute_body["prepared_query_ref"] = prepared.json()["prepared_query_ref"]
        execute_headers = {**headers, "Idempotency-Key": payload["prepare_key"]}
        executed = client.post(
            "/api/v1/analysis/execute", json=execute_body, headers=execute_headers
        )
        assert executed.status_code == 200, executed.json()
        assert executed.json()["result"]["status"] == "succeeded"
        assert executed.json()["result"]["rows"][0]["metric_value"] == "7.25"
        assert executed.json()["result"]["facts"][0]["metric_code"] == "metric-a"
        replay = client.post("/api/v1/analysis/execute", json=execute_body, headers=execute_headers)
        assert replay.status_code == 200, replay.json()
        assert replay.json()["result"]["idempotent_replay"] is True
        assert replay.json()["result"]["facts"] == executed.json()["result"]["facts"]
        env.source.execute_readonly.assert_called_once()
        # 固化曾漏过的跨语言形状错误：不能由兼容兜底静默丢弃。
        wrong_query = json.loads(json.dumps(payload))
        wrong_query["query"]["conversation_id"] = "conversation-a"
        assert (
            client.post("/api/v1/analysis/prepare", json=wrong_query, headers=headers).status_code
            == 422
        )
        wrong_refs = json.loads(json.dumps(payload))
        wrong_refs["catalog_refs"] = [item["catalog_ref"] for item in wrong_refs["catalog_refs"]]
        assert (
            client.post("/api/v1/analysis/prepare", json=wrong_refs, headers=headers).status_code
            == 422
        )


def test_actual_typescript_confirmation_payload_through_python_api(env):
    fixture_path = Path(__file__).resolve().parents[2] / (
        "docs/verification/autonomy-20261013/runtime-analysis-confirmation-fixture.json"
    )
    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    with env.sessions() as session:
        session.add_all(
            [
                ChatConversation(id="conversation-a", owner_user_id="u", title="确认合同合成会话"),
                OrgTerm(org_code="org-a", org_name="样本行"),
                MetricTerm(metric_code="metric-old", metric_name="贷款余额当日数", unit="元"),
                MetricTerm(metric_code="metric-a", metric_name="样本余额", unit="元"),
                MetricTerm(metric_code="metric-b", metric_name="另一余额", unit="元"),
                MetricSynonym(metric_code="metric-a", synonym="存款余额"),
                MetricSynonym(metric_code="metric-b", synonym="存款余额"),
            ]
        )
        session.commit()
    app = FastAPI()
    app.state.settings = SimpleNamespace(agent_service_token=TOKEN)
    app.include_router(router)
    install_exception_handlers(app)
    app.dependency_overrides[require_actor] = lambda: env.actor
    app.dependency_overrides[get_analysis_service] = lambda: env.service
    app.dependency_overrides[require_query_ready] = lambda: None
    headers = {"X-Agent-Service-Token": TOKEN}
    with TestClient(app) as client:
        body = fixture["confirmed_constraints"]
        registered = client.post("/api/v1/analysis/constraints", json=body, headers=headers)
        assert registered.status_code == 200, registered.json()
        assert registered.json()["constraint_version"] == 2
        wrong = json.loads(json.dumps(body))
        wrong["analysis_id"] = "wrong-confirmed-code"
        wrong["source_metric_bindings"][1]["codes"] = ["M1"]
        wrong["targets"][0]["fixed_metric_codes"] = ["metric-old", "M1"]
        wrong["fixed_metric_updates"][0]["codes"] = ["metric-old", "M1"]
        response = client.post("/api/v1/analysis/constraints", json=wrong, headers=headers)
        assert response.status_code == 409
        assert response.json()["code"] == "METRIC_TARGETS_UNRESOLVED"
        env.source.execute_readonly.assert_not_called()
