"""冻结同一只读目录，枚举 Excel 正式名称；独立进程比较基线与当前识别器。"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from collections import Counter, defaultdict
from datetime import UTC, datetime
from pathlib import Path
from zipfile import ZipFile

PROJECT_DIR = Path(__file__).resolve().parents[1]
ROOT = PROJECT_DIR.parent
VERIFICATION = ROOT / "docs/verification/autonomy-20261013"
SOURCE_FILES = [
    "ask_metric/application/metric_candidates.py",
    "ask_metric/application/field_resolution.py",
    "ask_metric/application/metric_alias_structure.py",
    "ask_metric/domain/metric_matching.py",
]


def read_json(path: Path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == ".gz" else data)


def capture_catalog(path: Path):
    if path.exists():
        return read_json(path), 0
    sys.path.insert(0, str(PROJECT_DIR / "src"))
    from preflight_autonomy_data import engine_for, select_rows

    from ask_metric.core.config import get_settings

    engine = engine_for(get_settings().app_database_url)
    try:
        with engine.connect() as connection:
            terms = select_rows(
                connection,
                "SELECT metric_code, metric_name, unit, description, metric_explanation, "
                "source_metric_code, base_name, value_basis FROM metric_terms "
                "WHERE enabled = 1 ORDER BY metric_code",
            )
            synonyms = select_rows(
                connection,
                "SELECT metric_code, synonym FROM metric_synonyms WHERE enabled = 1 "
                "ORDER BY metric_code, weight DESC, synonym",
            )
    finally:
        engine.dispose()
    aliases = defaultdict(list)
    for synonym in synonyms:
        if synonym["synonym"] not in aliases[synonym["metric_code"]]:
            aliases[synonym["metric_code"]].append(synonym["synonym"])
    snapshot = {
        "captured_at_utc": datetime.now(UTC).isoformat(),
        "source": "existing configured app catalog; enabled metadata only, no fact values",
        "metrics": [
            {
                "code": term["metric_code"],
                "name": term["metric_name"],
                "aliases": aliases[term["metric_code"]],
                "description": term["description"],
                "explanation": term["metric_explanation"],
                "unit": term["unit"],
                "source_metric_code": term["source_metric_code"],
                "base_name": term["base_name"],
                "value_basis": term["value_basis"],
            }
            for term in terms
        ],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(snapshot, ensure_ascii=False, sort_keys=True).encode()
    path.write_bytes(gzip.compress(payload, mtime=0))
    return snapshot, 2


def classify(expected: str, codes: list[str], uncertain: bool, found: bool) -> str:
    if uncertain:
        return "ambiguous"
    if set(codes) == {expected}:
        return "resolved"
    return "mismatch" if found else "not_found"


def worker(input_path: Path, output: Path):
    # 此分支不加载配置或数据库；PYTHONPATH 由父进程指向独立基线/候选源码。
    from ask_metric.application.field_resolution import resolve_catalog_field
    from ask_metric.application.metric_candidates import metric_candidate_index
    from ask_metric.domain.semantics import MetricCatalogItem

    data = read_json(input_path)
    catalog = [MetricCatalogItem.model_validate(item) for item in data["metrics"]]
    index = metric_candidate_index(catalog)
    cases = []
    for item in catalog:
        if item.code not in data["target_codes"]:
            continue
        resolution = resolve_catalog_field("metric", [item.name], catalog)
        codes = resolution.get("value", {}).get("codes", [])
        cases.append(
            {
                "case_id": f"{item.code}:formal_field",
                "kind": "formal_field",
                "expected_code": item.code,
                "name": item.name,
                "input": item.name,
                "status": classify(
                    item.code, codes, resolution["status"] != "resolved", bool(codes)
                ),
                "resolved_codes": codes,
                "resolution": resolution,
            }
        )
        for kind, question in (
            ("formal_name", item.name),
            ("full_question", f"查询无锡农商银行2026年7月31日的{item.name}是多少？"),
        ):
            mentions = index.mentions(question)
            codes = sorted(
                {
                    code
                    for mention in mentions
                    for code in mention["resolution"].get("value", {}).get("codes", [])
                }
            )
            uncertain = any(
                mention["resolution"]["status"] != "resolved" for mention in mentions
            )
            cases.append(
                {
                    "case_id": f"{item.code}:{kind}",
                    "kind": kind,
                    "expected_code": item.code,
                    "name": item.name,
                    "input": question,
                    "status": classify(item.code, codes, uncertain, bool(mentions)),
                    "resolved_codes": codes,
                    "mentions": mentions,
                }
            )
    result = {
        "counts": {
            kind: dict(Counter(case["status"] for case in cases if case["kind"] == kind))
            for kind in ("formal_field", "formal_name", "full_question")
        },
        "cases": cases,
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2))


def execute_worker(source: Path, payload: Path, output: Path):
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(source)
    result = subprocess.run(
        [sys.executable, str(Path(__file__).resolve()), "--worker", str(payload), str(output)],
        cwd=output.parent,
        env=environment,
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
    )
    if result.returncode:
        # 子进程无连接配置；仍只保存错误类型，避免异常误带目录或环境内容。
        raise RuntimeError(f"MATCHER_WORKER_EXIT_{result.returncode}")
    return read_json(output)


def run(snapshot_path: Path, baseline_zip: Path, output: Path):
    snapshot, select_count = capture_catalog(snapshot_path)
    workbook = read_json(VERIFICATION / "workbook-normalized.json")
    workbook_codes = {item["code"] for item in workbook["metrics"]}
    target_codes = sorted(workbook_codes & {item["code"] for item in snapshot["metrics"]})
    payload = {**snapshot, "target_codes": target_codes}
    with tempfile.TemporaryDirectory(prefix="metric-identity-") as temporary:
        directory = Path(temporary)
        input_path = directory / "input.json"
        input_path.write_text(json.dumps(payload, ensure_ascii=False))
        baseline_source = directory / "baseline/src"
        with ZipFile(baseline_zip) as archive:
            for name in archive.namelist():
                prefix = "backend-next/src/"
                if not name.startswith(prefix) or not name.endswith(".py"):
                    continue
                relative = Path(name.removeprefix(prefix))
                if ".." in relative.parts or relative.is_absolute():
                    raise RuntimeError("INVALID_BASELINE_ARCHIVE_PATH")
                target = baseline_source / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
        baseline = execute_worker(baseline_source, input_path, directory / "baseline.json")
        candidate = execute_worker(PROJECT_DIR / "src", input_path, directory / "candidate.json")
        source_hashes = {
            name: {
                "baseline": hashlib.sha256((baseline_source / name).read_bytes()).hexdigest(),
                "candidate": hashlib.sha256((PROJECT_DIR / "src" / name).read_bytes()).hexdigest(),
            }
            for name in SOURCE_FILES
        }
    baseline_cases = {case["case_id"]: case for case in baseline["cases"]}
    differences = [
        {"case_id": case["case_id"], "baseline": baseline_cases.get(case["case_id"]),
         "candidate": case}
        for case in candidate["cases"]
        if case != baseline_cases.get(case["case_id"])
    ]
    failures = [case for case in candidate["cases"] if case["status"] != "resolved"]
    report = {
        "checked_at_utc": datetime.now(UTC).isoformat(),
        "scope": "actual backend deterministic matcher; no model, SQL values, or API execution",
        "catalog_select_count_this_run": select_count,
        "business_value_sql_count": 0,
        "existing_database_writes": False,
        "catalog_snapshot_file": str(snapshot_path.relative_to(ROOT)),
        "catalog_snapshot_sha256": hashlib.sha256(snapshot_path.read_bytes()).hexdigest(),
        "catalog_captured_at_utc": snapshot["captured_at_utc"],
        "enabled_catalog_size": len(snapshot["metrics"]),
        "workbook_unique_codes": len(workbook_codes),
        "enabled_workbook_targets": len(target_codes),
        "baseline_archive_sha256": hashlib.sha256(baseline_zip.read_bytes()).hexdigest(),
        "same_catalog_and_inputs_for_both": True,
        "independent_processes": True,
        "source_hashes": source_hashes,
        "baseline_counts": baseline["counts"],
        "candidate_counts": candidate["counts"],
        "changed_case_count": len(differences),
        "differences": differences,
        "nonresolved_case_count": len(failures),
        "nonresolved_cases": failures,
        "candidate_cases": candidate["cases"],
        "limits": [
            "Only the workbook codes enabled in this current catalog snapshot are enumerated.",
            "Formal field, formal name and institution/date sentence are deterministic cases.",
            "Does not verify model intent, multi-turn planning, authorization or database values.",
            "Catalog ambiguities are reported without changing catalog or legacy semantics.",
        ],
    }
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    summary = [
        "# Excel 启用指标名称与编码保护枚举",
        "",
        f"正式启用目录 {len(snapshot['metrics'])} 项；Excel 440 编码中当前启用 "
        f"{len(target_codes)} 项。两版本使用同一目录快照、相同输入，在独立 Python 进程运行。",
        "",
        "| 输入 | 基线 | 当前 |",
        "|---|---|---|",
    ]
    for kind in candidate["counts"]:
        summary.append(f"| {kind} | {baseline['counts'][kind]} | {candidate['counts'][kind]} |")
    summary += [
        "",
        f"输出变化 {len(differences)} 项；当前非 resolved {len(failures)} 项。"
        "完整名称、字段解析和带机构日期原句分别计数，未将三类输入合并冒充更多独立指标。",
        "",
        f"本次仅 {select_count} 次启用目录元数据 SELECT；指标值 SQL 0 次，现库写入 0 次，"
        "模型调用 0 次。目录、别名和识别语义均未修改。",
        "",
        "此检查只证明固定名称的编码识别及基线差异，不证明模型灵活问答、多轮规划、"
        "当前用户权限或上游数据湖真实性。完整结果和源码哈希见同名 JSON。",
    ]
    output.with_suffix(".md").write_text("\n".join(summary) + "\n")
    print(json.dumps({key: report[key] for key in (
        "enabled_catalog_size", "enabled_workbook_targets", "baseline_counts", "candidate_counts",
        "changed_case_count", "nonresolved_case_count", "catalog_select_count_this_run",
    )}, ensure_ascii=False))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--worker":
        worker(Path(sys.argv[2]), Path(sys.argv[3]))
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument("--snapshot", type=Path,
                            default=VERIFICATION / "metric-matcher-catalog-snapshot.json.gz")
        parser.add_argument("--baseline", type=Path,
                            default=VERIFICATION / "source-snapshots/baseline.zip")
        parser.add_argument("--output", type=Path,
                            default=VERIFICATION / "workbook-metric-identity-comparison.json")
        arguments = parser.parse_args()
        try:
            run(arguments.snapshot.resolve(), arguments.baseline.resolve(),
                arguments.output.resolve())
        except Exception as exc:
            original = getattr(exc, "orig", exc)
            details = getattr(original, "args", ())
            print(json.dumps({"status": "failed", "error_type": type(exc).__name__,
                              "driver_code": details[0]
                              if details and isinstance(details[0], int) else None}))
            raise SystemExit(1) from None
