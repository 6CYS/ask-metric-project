"""真实 metric_values 只读验收；应用状态、授权用户和分析凭据完全隔离在临时测试环境。"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import re
import secrets
import sys
import tempfile
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

PROJECT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_DIR / "src"))

from preflight_autonomy_data import engine_for, safe_error, select_rows  # noqa: E402

from ask_metric.api.dependencies import (  # noqa: E402
    get_query_execution_service,
    get_query_task_service,
    require_actor,
)
from ask_metric.api.query_readiness import require_query_ready  # noqa: E402
from ask_metric.api.routes.analysis import get_analysis_service  # noqa: E402
from ask_metric.api.routes.analysis import router as analysis_router  # noqa: E402
from ask_metric.api.routes.tasks import router as tasks_router  # noqa: E402
from ask_metric.application.analysis_service import AnalysisApplicationService  # noqa: E402
from ask_metric.application.ports import ScopedOrganizationPermissionService  # noqa: E402
from ask_metric.application.query_execution_service import (  # noqa: E402
    QueryExecutionApplicationService,
)
from ask_metric.application.requests import ActorContext  # noqa: E402
from ask_metric.application.task_service import QueryTaskApplicationService  # noqa: E402
from ask_metric.core.config import get_settings  # noqa: E402
from ask_metric.core.errors import install_exception_handlers  # noqa: E402
from ask_metric.domain.query_execution import QueryPlanner  # noqa: E402
from ask_metric.infrastructure.db.base import Base  # noqa: E402
from ask_metric.infrastructure.db.models import (  # noqa: E402
    AppUser,
    ChatConversation,
    MetricTerm,
    OrgTerm,
)
from ask_metric.infrastructure.db.unit_of_work import SqlAlchemyUnitOfWork  # noqa: E402
from ask_metric.infrastructure.query.factory import create_data_source_adapter  # noqa: E402
from ask_metric.infrastructure.query.sql_builder import sql_builder_from_settings  # noqa: E402

PREFERRED = "ORG_PSON_DEPT_BAL_CMPBGNYR_INCRRNG"


class ObservedSource:
    def __init__(self, adapter):
        self.adapter = adapter
        self.executions = []

    def execute_readonly(self, *, sql, parameters):
        result = self.adapter.execute_readonly(sql=sql, parameters=parameters)
        self.executions.append(
            {"sql": sql, "parameters": parameters, "row_count": len(result.rows)}
        )
        return result


def require_response(response):
    if response.status_code != 200:
        body = response.json()
        raise RuntimeError(f"HTTP_{response.status_code}:{body.get('code', 'UNKNOWN')}")
    return response.json()


def raw_sample(engine, code, org, day):
    with engine.connect() as connection:
        rows = select_rows(
            connection,
            "SELECT metric_code, org_code, stat_date, metric_value, source_batch_id "
            "FROM metric_values WHERE metric_code = :metric AND org_code = :org "
            "AND stat_date = :day AND metric_value IS NOT NULL ORDER BY id",
            {"metric": code, "org": org, "day": day},
        )
    if len(rows) != 1:
        raise RuntimeError("INDEPENDENT_SAMPLE_NOT_UNIQUE")
    row = rows[0]
    return {
        "metric_code": code,
        "org_code": org,
        "date": day,
        "value": str(row["metric_value"]),
        "has_test_source_marker": bool(
            re.search(
                r"(^|[^a-z0-9])(synthetic|fixture|mock|demo|seed|seeded|test)([^a-z0-9]|$)",
                str(row["source_batch_id"] or "").lower(),
            )
        ),
    }


def assert_matches(result, expected):
    if result["status"] != "succeeded" or result["row_count"] != 1 or result["truncated"]:
        raise RuntimeError("ACTUAL_QUERY_NOT_COMPLETE")
    row = result["rows"][0]
    fact = result["facts"][0]
    if (
        row["metric_code"] != expected["metric_code"]
        or row["org_code"] != expected["org_code"]
        or str(row["stat_date"]) != expected["date"]
        or Decimal(str(row["metric_value"])) != Decimal(expected["value"])
        or Decimal(fact["value"]) != Decimal(expected["value"])
    ):
        raise RuntimeError("INDEPENDENT_VALUE_MISMATCH")


def run(output: Path):
    settings = get_settings()
    if settings.query_database_dialect != "mysql":
        raise RuntimeError("METRIC_VALUES_MYSQL_REQUIRED")
    source_engine = engine_for(settings.query_database_url)
    catalog_engine = engine_for(settings.app_database_url)
    try:
        with catalog_engine.connect() as connection:
            metrics = select_rows(
                connection,
                "SELECT metric_code, metric_name, unit, source_metric_code, base_name, value_basis "
                "FROM metric_terms WHERE metric_code = :code AND enabled = 1",
                {"code": PREFERRED},
            )
            orgs = select_rows(
                connection,
                "SELECT org_code, org_name FROM org_terms WHERE enabled = 1 "
                "AND org_code IN :codes ORDER BY org_code",
                {"codes": ["01", "070667800"]},
            )
        if len(metrics) != 1 or len(orgs) != 2:
            raise RuntimeError("OFFICIAL_ACCEPTANCE_TARGET_UNAVAILABLE")
        metric = metrics[0]
        scenarios = [
            ("precise_query", orgs[0], "2026-07-31"),
            ("change_organization", orgs[1], "2026-07-31"),
            ("change_date", orgs[1], "2026-06-30"),
        ]
        expected = [
            raw_sample(source_engine, metric["metric_code"], org["org_code"], day)
            for _, org, day in scenarios
        ]
        report = {
            "checked_at_utc": datetime.now(UTC).isoformat(),
            "query_source": "unchanged configured QUERY_DATABASE_URL / metric_values",
            "existing_database_writes": False,
            "models_called": False,
            "app_state": "dedicated temporary SQLite, removed after run",
            "authentication_scope": "synthetic test actor and service token only; "
            "does not certify the currently logged-in user's permissions",
            "upstream_lake_provenance_verified": False,
            "metric": metric,
            "precise_scenarios": [],
        }
        with tempfile.TemporaryDirectory(prefix="metric-values-acceptance-") as temporary:
            app_engine = create_engine(f"sqlite:///{Path(temporary) / 'state.sqlite'}")
            Base.metadata.create_all(app_engine)
            sessions = sessionmaker(bind=app_engine, autoflush=False, expire_on_commit=False)
            user_id = f"fixture-{uuid4()}"
            conversation = f"readonly-acceptance:{uuid4()}"
            with sessions() as session:
                session.add_all(
                    [OrgTerm(org_code=org["org_code"], org_name=org["org_name"]) for org in orgs]
                )
                session.add(MetricTerm(**metric))
                session.add(
                    AppUser(
                        id=user_id,
                        username="isolated-acceptance",
                        display_name="仅测试授权fixture",
                        password_hash="not-for-login",
                        org_code=orgs[0]["org_code"],
                        role_code="SYSTEM_ADMIN",
                    )
                )
                session.add(
                    ChatConversation(id=conversation, owner_user_id=user_id, title="隔离只读验收")
                )
                session.commit()

            def uow():
                return SqlAlchemyUnitOfWork(sessions)

            actor = ActorContext(
                subject="isolated-acceptance",
                user_id=user_id,
                org_id=orgs[0]["org_code"],
                role_code="SYSTEM_ADMIN",
                authentication_method="isolated_fixture",
                trust_level="authenticated",
            )
            permission = ScopedOrganizationPermissionService()
            source = ObservedSource(
                create_data_source_adapter(
                    settings.query_database_dialect,
                    source_engine,
                    statement_timeout_ms=settings.query_statement_timeout_ms,
                )
            )
            execution = QueryExecutionApplicationService(
                planner=QueryPlanner(dialect="mysql", max_limit=settings.query_result_limit),
                data_source=source,
                permission_service=permission,
                uow_factory=uow,
                sql_builder=sql_builder_from_settings(settings),
            )
            tasks = QueryTaskApplicationService(uow, permission_service=permission)
            token = secrets.token_urlsafe(32)
            analysis = AnalysisApplicationService(
                execution=execution, service_token=token, uow_factory=uow
            )
            app = FastAPI()
            app.state.settings = SimpleNamespace(agent_service_token=token)
            app.include_router(tasks_router)
            app.include_router(analysis_router)
            install_exception_handlers(app)
            app.dependency_overrides[require_actor] = lambda: actor
            app.dependency_overrides[require_query_ready] = lambda: None
            app.dependency_overrides[get_query_execution_service] = lambda: execution
            app.dependency_overrides[get_query_task_service] = lambda: tasks
            app.dependency_overrides[get_analysis_service] = lambda: analysis

            @app.middleware("http")
            async def request_identity(request, call_next):
                request.state.request_id = str(uuid4())
                return await call_next(request)

            with TestClient(app) as client:
                specs = []
                for (label, org, day), sample in zip(scenarios, expected, strict=True):
                    question = f"查询{org['org_name']}{day}的{metric['metric_name']}"
                    spec = {
                        "schema_version": 2,
                        "metric_codes": [metric["metric_code"]],
                        "org_codes": [org["org_code"]],
                        "time": {"start": day, "end": day},
                        "selection": "exact",
                        "operation": {"kind": "value"},
                    }
                    specs.append(spec)
                    body = {**spec, "conversation_id": conversation, "source_question": question}
                    result = require_response(
                        client.post(
                            "/api/v1/basic-queries", json=body, headers={"Idempotency-Key": label}
                        )
                    )["result"]
                    assert_matches(result, sample)
                    report["precise_scenarios"].append(
                        {
                            "scenario": label,
                            "query": spec,
                            "independent_select": sample,
                            "actual_value": result["rows"][0]["metric_value"],
                            "fact_value": result["facts"][0]["value"],
                            "unit": metric["unit"],
                            "independent_match": True,
                            "task_id": result["task_id"],
                        }
                    )
                spec = specs[-1]
                question = f"分析{orgs[1]['org_name']}2026-06-30的{metric['metric_name']}"
                headers = {"X-Agent-Service-Token": token}
                constraint = require_response(
                    client.post(
                        "/api/v1/analysis/constraints",
                        headers=headers,
                        json={
                            "schema_version": 1,
                            "conversation_id": conversation,
                            "analysis_id": "actual-readonly-analysis",
                            "constraint_version": 1,
                            "source_question": question,
                            "source_question_sha256": hashlib.sha256(question.encode()).hexdigest(),
                            "targets": [
                                {
                                    "target_id": "target",
                                    "org_codes": spec["org_codes"],
                                    "time": spec["time"],
                                    "fixed_metric_codes": [metric["metric_code"]],
                                    "metric_selection_policy": "catalog",
                                }
                            ],
                            "requirements": [
                                {
                                    "requirement_id": "r",
                                    "target_ids": ["target"],
                                    "description": "正式指标原值取证",
                                }
                            ],
                        },
                    )
                )
                refs = require_response(
                    client.post(
                        "/api/v1/analysis/catalog-references",
                        headers=headers,
                        json={
                            "conversation_id": conversation,
                            "metric_codes": spec["metric_codes"],
                        },
                    )
                )
                before_prepare = len(source.executions)
                prepared = require_response(
                    client.post(
                        "/api/v1/analysis/prepare",
                        headers=headers,
                        json={
                            "constraint_ref": constraint["constraint_ref"],
                            "prepare_key": "analysis-readonly",
                            "step_id": "step",
                            "step_revision": 1,
                            "target_id": "target",
                            "requirement_ids": ["r"],
                            "query": spec,
                            "catalog_refs": refs["references"],
                        },
                    )
                )
                if len(source.executions) != before_prepare:
                    raise RuntimeError("PREPARE_EXECUTED_BUSINESS_SQL")
                execute_body = {"prepared_query_ref": prepared["prepared_query_ref"]}
                execute_headers = {**headers, "Idempotency-Key": "analysis-readonly"}
                result = require_response(
                    client.post(
                        "/api/v1/analysis/execute", json=execute_body, headers=execute_headers
                    )
                )["result"]
                assert_matches(result, expected[-1])
                replay = require_response(
                    client.post(
                        "/api/v1/analysis/execute", json=execute_body, headers=execute_headers
                    )
                )["result"]
                if not replay["idempotent_replay"] or len(source.executions) != before_prepare + 1:
                    raise RuntimeError("ANALYSIS_REPLAY_EXECUTED_AGAIN")
                report["analysis_scenario"] = {
                    "query": prepared["query"],
                    "actual_value": result["rows"][0]["metric_value"],
                    "unit": metric["unit"],
                    "independent_match": True,
                    "prepare_business_sql_count": 0,
                    "execute_business_sql_count": 1,
                    "replay_business_sql_count": 0,
                }
                report["business_sql_execution_count"] = len(source.executions)
                report["actual_sql_templates"] = [item["sql"] for item in source.executions]
                report["status"] = "passed"
            app_engine.dispose()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(report, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8"
        )
        print(
            json.dumps(
                {
                    "status": report["status"],
                    "output": str(output),
                    "precision_scenarios": report["precise_scenarios"],
                    "analysis_scenario": report["analysis_scenario"],
                },
                ensure_ascii=False,
            )
        )
    finally:
        source_engine.dispose()
        catalog_engine.dispose()


if __name__ == "__main__":
    logging.disable(logging.CRITICAL)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        run(args.output)
    except Exception as exc:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "error": safe_error(exc),
                    "contract_error": str(exc) if isinstance(exc, RuntimeError) else None,
                }
            )
        )
        raise SystemExit(1) from None
