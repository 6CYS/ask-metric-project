"""可信宿主分析入口：用户权限和服务间凭据同时验证，模型不能直接提交授权。"""

import hmac
from typing import Annotated

from fastapi import APIRouter, Depends, Header, Path, Query, Request

from ask_metric.api.dependencies import get_query_execution_service, require_actor
from ask_metric.api.query_readiness import require_query_ready
from ask_metric.api.routes.tasks import BasicQueryResponse
from ask_metric.application.analysis_service import AnalysisApplicationService
from ask_metric.application.query_execution_service import QueryExecutionApplicationService
from ask_metric.application.requests import ActorContext
from ask_metric.core.errors import ApplicationError
from ask_metric.domain.analysis import (
    AnalysisConstraintRequest,
    AnalysisConstraintResponse,
    AnalysisExecuteRequest,
    AnalysisPreparedResponse,
    AnalysisPrepareRequest,
    CatalogReferenceRequest,
    CatalogReferenceResponse,
)


def require_agent_service(
    request: Request,
    token: Annotated[str | None, Header(alias="X-Agent-Service-Token")] = None,
) -> None:
    expected = request.app.state.settings.agent_service_token
    if not expected:
        raise ApplicationError("ANALYSIS_DISABLED", "分析准备能力尚未配置。", status_code=503)
    if token is None or not hmac.compare_digest(token.encode(), expected.encode()):
        raise ApplicationError(
            "AGENT_SERVICE_FORBIDDEN", "分析接口仅允许可信宿主调用。", status_code=403
        )


router = APIRouter(
    prefix="/api/v1/analysis",
    tags=["analysis"],
    dependencies=[Depends(require_actor), Depends(require_agent_service)],
)


def get_analysis_service(
    request: Request,
    execution: Annotated[QueryExecutionApplicationService, Depends(get_query_execution_service)],
) -> AnalysisApplicationService:
    return AnalysisApplicationService(
        execution=execution,
        service_token=request.app.state.settings.agent_service_token,
        uow_factory=execution.uow_factory,
    )


Actor = Annotated[ActorContext, Depends(require_actor)]
Service = Annotated[AnalysisApplicationService, Depends(get_analysis_service)]


@router.post("/catalog-references", response_model=CatalogReferenceResponse)
def catalog_references(
    payload: CatalogReferenceRequest, actor: Actor, service: Service
) -> CatalogReferenceResponse:
    return service.catalog_references(payload, actor)


@router.post("/constraints", response_model=AnalysisConstraintResponse)
def register_constraints(
    payload: AnalysisConstraintRequest, actor: Actor, service: Service
) -> AnalysisConstraintResponse:
    # (actor, conversation, analysis_id, constraint_version) 本身就是不可变登记幂等键。
    return service.register_constraints(payload, actor)


@router.post(
    "/prepare",
    response_model=AnalysisPreparedResponse,
    response_model_exclude_none=True,
    dependencies=[Depends(require_query_ready)],
)
def prepare(
    payload: AnalysisPrepareRequest, actor: Actor, service: Service
) -> AnalysisPreparedResponse:
    return service.prepare(payload, actor)


@router.get(
    "/prepared/{prepare_key}",
    response_model=AnalysisPreparedResponse,
    response_model_exclude_none=True,
)
def find_prepared(
    prepare_key: Annotated[str, Path(min_length=1, max_length=128)],
    conversation_id: Annotated[str, Query(min_length=1, max_length=128)],
    actor: Actor,
    service: Service,
) -> AnalysisPreparedResponse:
    return service.find_prepared(prepare_key, conversation_id, actor)


@router.post(
    "/execute",
    response_model=BasicQueryResponse,
    response_model_exclude_none=True,
    dependencies=[Depends(require_query_ready)],
)
def execute(
    payload: AnalysisExecuteRequest,
    actor: Actor,
    service: Service,
    idempotency_key: Annotated[str, Header(alias="Idempotency-Key", min_length=1, max_length=128)],
) -> BasicQueryResponse:
    query, result = service.execute(payload.prepared_query_ref, idempotency_key, actor)
    return BasicQueryResponse(query=query, result=result)
