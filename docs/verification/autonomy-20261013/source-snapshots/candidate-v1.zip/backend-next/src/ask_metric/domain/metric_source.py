"""原文指标身份契约；基础查询与分析确认共用相同片段边界。"""

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ask_metric.domain.basic_query import CatalogCode
from ask_metric.domain.query_execution import MAX_METRIC_CODES


class SourceMetricSpan(BaseModel):
    """宿主保存的完整指标原文片段；位置按 Unicode 码点计数。"""

    model_config = ConfigDict(extra="forbid", strict=True)

    start: int = Field(ge=0)
    end: int = Field(gt=0)
    text: str = Field(min_length=1, max_length=1000)

    @model_validator(mode="after")
    def validate_span(self):
        if self.start >= self.end:
            raise ValueError("指标绑定必须使用非空原文片段")
        return self


class SourceMetricBinding(SourceMetricSpan):
    """宿主保存的原文指标身份，不接受模型补写字段。"""

    codes: list[CatalogCode] = Field(min_length=1, max_length=MAX_METRIC_CODES)

    @model_validator(mode="after")
    def validate_codes(self):
        if len(set(self.codes)) != len(self.codes):
            raise ValueError("指标绑定编码不能重复")
        return self
