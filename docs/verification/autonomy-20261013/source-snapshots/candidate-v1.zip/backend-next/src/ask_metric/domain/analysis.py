"""分析准备契约：固定目标由可信宿主登记，目录选择必须携带后端签发的引用。"""

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

from ask_metric.domain.basic_query import BasicQuerySpec, BasicQueryTime, CatalogCode
from ask_metric.domain.metric_source import SourceMetricBinding, SourceMetricSpan
from ask_metric.domain.query_execution import MAX_METRIC_CODES, MAX_ORG_CODES

Reference = Annotated[str, StringConstraints(strict=True, min_length=1, max_length=4096)]
Identifier = Annotated[str, StringConstraints(strict=True, min_length=1, max_length=128)]
Digest = Annotated[str, StringConstraints(strict=True, pattern=r"^[a-f0-9]{64}$")]


class AnalysisTarget(BaseModel):
    model_config = ConfigDict(extra="forbid")

    target_id: Identifier
    org_codes: list[CatalogCode] = Field(min_length=1, max_length=MAX_ORG_CODES)
    time: BasicQueryTime
    fixed_metric_codes: list[CatalogCode] = Field(default_factory=list, max_length=MAX_METRIC_CODES)
    metric_selection_policy: Literal["allowlist", "catalog"] = "allowlist"
    # 可信宿主根据用户授权的分析范围和正式目录登记，不接受任意 source 字符串扩权。
    allowed_metric_codes: list[CatalogCode] = Field(default_factory=list, max_length=10_000)

    @model_validator(mode="after")
    def validate_codes(self):
        for values in (self.org_codes, self.fixed_metric_codes, self.allowed_metric_codes):
            if len(values) != len(set(values)):
                raise ValueError("分析约束的编码不能重复")
        if (
            self.metric_selection_policy == "allowlist"
            and not self.fixed_metric_codes
            and not self.allowed_metric_codes
        ):
            raise ValueError("分析目标必须登记固定指标或允许选择的正式指标")
        return self


class AnalysisRequirement(BaseModel):
    model_config = ConfigDict(extra="forbid")

    requirement_id: Identifier
    target_ids: list[Identifier] = Field(min_length=1, max_length=100)
    description: str = Field(min_length=1, max_length=2000)


class AnalysisSourceMessage(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_question: str = Field(min_length=1, max_length=20_000)
    source_question_sha256: Digest


class AnalysisChangeSpan(SourceMetricSpan):
    text: str = Field(min_length=1, max_length=20_000)


class AnalysisMetricUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target_id: Identifier
    mode: Literal["replace", "add", "remove"]
    codes: list[CatalogCode] = Field(min_length=1, max_length=MAX_METRIC_CODES)
    source_span: AnalysisChangeSpan


class AnalysisConstraintRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: Literal[1] = 1
    conversation_id: Identifier
    analysis_id: Identifier
    constraint_version: int = Field(ge=1, strict=True)
    source_question: str = Field(min_length=1, max_length=20_000)
    source_question_sha256: Digest
    prior_constraint_ref: Identifier | None = None
    prior_query_task_id: Identifier | None = None
    source_history: list[AnalysisSourceMessage] = Field(default_factory=list, max_length=100)
    metric_source_question: str | None = Field(default=None, min_length=1, max_length=20_000)
    source_metric_bindings: list[SourceMetricBinding] | None = None
    source_metric_exclusions: list[SourceMetricSpan] | None = None
    fixed_metric_updates: list[AnalysisMetricUpdate] = Field(default_factory=list, max_length=100)
    targets: list[AnalysisTarget] = Field(min_length=1, max_length=100)
    requirements: list[AnalysisRequirement] = Field(min_length=1, max_length=100)

    @model_validator(mode="after")
    def validate_bindings(self):
        targets = {target.target_id for target in self.targets}
        requirements = {item.requirement_id for item in self.requirements}
        if len(targets) != len(self.targets) or len(requirements) != len(self.requirements):
            raise ValueError("分析目标和要求的标识不能重复")
        if any(not set(item.target_ids).issubset(targets) for item in self.requirements):
            raise ValueError("分析要求引用了未登记目标")
        if set().union(*(set(item.target_ids) for item in self.requirements)) != targets:
            raise ValueError("每个分析目标都必须关联分析要求")
        if (
            self.source_metric_bindings is not None or self.source_metric_exclusions is not None
        ) and self.metric_source_question is None:
            raise ValueError("分析指标绑定必须关联原始指标问题")
        if len({item.target_id for item in self.fixed_metric_updates}) != len(
            self.fixed_metric_updates
        ):
            raise ValueError("同一目标一次只能声明一份指标更新")
        return self


class AnalysisConstraintResponse(BaseModel):
    constraint_ref: str
    analysis_id: str
    constraint_version: int


class CatalogReferenceRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    conversation_id: Identifier
    metric_codes: list[CatalogCode] = Field(min_length=1, max_length=1000)


class CatalogReference(BaseModel):
    model_config = ConfigDict(extra="forbid")
    metric_code: CatalogCode
    catalog_ref: Reference


class CatalogReferenceResponse(BaseModel):
    references: list[CatalogReference]


class AnalysisPrepareRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    constraint_ref: Identifier
    prepare_key: Identifier
    step_id: Identifier
    step_revision: int = Field(ge=1, strict=True)
    target_id: Identifier
    requirement_ids: list[Identifier] = Field(min_length=1, max_length=100)
    query: BasicQuerySpec
    catalog_refs: list[CatalogReference] = Field(min_length=1, max_length=MAX_METRIC_CODES)
    spec_hash: Digest | None = None


class AnalysisExecuteRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    prepared_query_ref: Identifier


class AnalysisExecutionRecord(BaseModel):
    """只保存在 QueryTask，独立于会被兼容解码丢弃的旧 query_spec 字段。"""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal[1] = 1
    constraint_ref: Identifier
    constraint_version: int
    analysis_id: Identifier
    prepare_key: Identifier
    prepared_query_ref: Identifier
    step_id: Identifier
    step_revision: int
    target_id: Identifier
    requirement_ids: list[Identifier]
    spec_hash: Digest
    request_hash: Digest
    query: BasicQuerySpec
    catalog_refs: list[CatalogReference]
    status: Literal["prepared", "executing", "settled", "invalidated"] = "prepared"


class AnalysisPreparedResponse(BaseModel):
    prepared_query_ref: str
    prepare_key: str
    spec_hash: str
    status: Literal["prepared", "executing", "settled", "invalidated", "interrupted"]
    query: BasicQuerySpec
    task_id: str
    task_version: int
