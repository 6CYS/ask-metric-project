"""冻结分析范围，纯准备，再复用现有执行链；不在后端调度分析计划。"""

import base64
import hashlib
import hmac
import json
from collections.abc import Callable
from datetime import UTC, datetime
from uuid import uuid4

from sqlalchemy import select

from ask_metric.application.commands import ExecuteQueryCommand
from ask_metric.application.metric_candidates import metric_candidate_index
from ask_metric.application.metric_coverage import verify_metric_bindings
from ask_metric.application.ports import PermissionDeniedError
from ask_metric.application.query_execution_service import QueryExecutionApplicationService
from ask_metric.application.requests import ActorContext
from ask_metric.core.errors import ApplicationError
from ask_metric.domain.analysis import (
    AnalysisConstraintRequest,
    AnalysisConstraintResponse,
    AnalysisExecutionRecord,
    AnalysisPreparedResponse,
    AnalysisPrepareRequest,
    AnalysisTarget,
    CatalogReference,
    CatalogReferenceRequest,
    CatalogReferenceResponse,
)
from ask_metric.domain.basic_query import BasicQuerySpec
from ask_metric.domain.query_execution import (
    QueryExecutionResult,
    QueryPlanError,
    UnsupportedQueryError,
)
from ask_metric.domain.semantics import MetricCatalogItem
from ask_metric.domain.task import (
    QueryTaskStage,
    QueryTaskState,
    QueryTaskStatus,
    running_execution_is_stale,
)
from ask_metric.infrastructure.db.models import AnalysisConstraintSnapshot, QueryTask
from ask_metric.infrastructure.db.unit_of_work import SqlAlchemyUnitOfWork


def canonical_hash(value: object) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )
    return hashlib.sha256(encoded).hexdigest()


def query_spec_hash(query: BasicQuerySpec) -> str:
    return canonical_hash(query.model_dump(mode="json", exclude_none=True))


def _error(code: str, message: str, status_code: int = 409) -> ApplicationError:
    return ApplicationError(code, message, status_code=status_code)


class AnalysisApplicationService:
    def __init__(
        self,
        *,
        execution: QueryExecutionApplicationService,
        service_token: str,
        uow_factory: Callable[[], SqlAlchemyUnitOfWork] = SqlAlchemyUnitOfWork,
    ):
        self.execution = execution
        self.service_token = service_token
        self.uow_factory = uow_factory

    def _conversation(self, uow, conversation_id: str, actor: ActorContext):
        conversation = uow.conversations.get_owned_for_update(
            conversation_id,
            actor.user_id or "",
        )
        if conversation is None:
            raise _error("CONVERSATION_NOT_FOUND", "会话不存在。", 404)
        return conversation

    def catalog_references(
        self, payload: CatalogReferenceRequest, actor: ActorContext
    ) -> CatalogReferenceResponse:
        with self.uow_factory() as uow:
            self._conversation(uow, payload.conversation_id, actor)
            catalog = {item.code: item for item in uow.metric_catalog.list_enabled()}
            refs = []
            for code in dict.fromkeys(payload.metric_codes):
                item = catalog.get(code)
                if item is None:
                    raise _error("ANALYSIS_CATALOG_INVALID", "选择的指标不在正式启用目录中。", 422)
                value = {
                    "v": 1,
                    "user_id": actor.user_id,
                    "conversation_id": payload.conversation_id,
                    "metric_code": code,
                    "catalog_hash": canonical_hash(item.model_dump(mode="json")),
                }
                encoded = (
                    base64.urlsafe_b64encode(
                        json.dumps(
                            value,
                            ensure_ascii=False,
                            sort_keys=True,
                            separators=(",", ":"),
                        ).encode()
                    )
                    .decode()
                    .rstrip("=")
                )
                signature = hmac.new(
                    self.service_token.encode(), encoded.encode(), hashlib.sha256
                ).hexdigest()
                refs.append(
                    CatalogReference(
                        metric_code=code, catalog_ref=f"catalog.v1.{encoded}.{signature}"
                    )
                )
            return CatalogReferenceResponse(references=refs)

    def _verify_catalog_refs(
        self,
        refs: list[CatalogReference],
        query: BasicQuerySpec,
        catalog: list[MetricCatalogItem],
        actor: ActorContext,
        conversation_id: str,
    ) -> None:
        if len(refs) != len({ref.metric_code for ref in refs}) or {
            ref.metric_code for ref in refs
        } != set(query.metric_codes):
            raise _error("ANALYSIS_PROVENANCE_INVALID", "目录引用必须逐一对应本步骤指标。", 422)
        items = {item.code: item for item in catalog}
        for ref in refs:
            try:
                prefix, version, encoded, signature = ref.catalog_ref.split(".")
                expected = hmac.new(
                    self.service_token.encode(), encoded.encode(), hashlib.sha256
                ).hexdigest()
                if (
                    prefix != "catalog"
                    or version != "v1"
                    or not hmac.compare_digest(
                        signature,
                        expected,
                    )
                ):
                    raise ValueError("invalid signature")
                value = json.loads(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)))
                item = items.get(ref.metric_code)
                if item is None or value != {
                    "v": 1,
                    "user_id": actor.user_id,
                    "conversation_id": conversation_id,
                    "metric_code": ref.metric_code,
                    "catalog_hash": canonical_hash(item.model_dump(mode="json")),
                }:
                    raise ValueError("catalog or owner changed")
            except (ValueError, TypeError, UnicodeError) as exc:
                raise _error(
                    "ANALYSIS_PROVENANCE_INVALID",
                    "目录引用无效、归属不同或目录已变化，请重新探索。",
                    409,
                ) from exc

    def register_constraints(
        self, payload: AnalysisConstraintRequest, actor: ActorContext
    ) -> AnalysisConstraintResponse:
        if hashlib.sha256(payload.source_question.encode()).hexdigest() != (
            payload.source_question_sha256
        ):
            raise _error("ANALYSIS_SOURCE_MISMATCH", "分析原文校验不一致。", 422)
        digest = canonical_hash(payload.model_dump(mode="json"))
        with self.uow_factory() as uow:
            # 同一会话登记/准备均锁住会话，序列化同版本和步骤幂等竞争。
            self._conversation(uow, payload.conversation_id, actor)
            versions = list(
                uow.session.execute(
                    select(AnalysisConstraintSnapshot)
                    .where(
                        AnalysisConstraintSnapshot.conversation_id == payload.conversation_id,
                        AnalysisConstraintSnapshot.analysis_id == payload.analysis_id,
                    )
                    .order_by(AnalysisConstraintSnapshot.constraint_version)
                ).scalars()
            )
            existing = next(
                (
                    item
                    for item in versions
                    if item.constraint_version == payload.constraint_version
                ),
                None,
            )
            if existing is not None:
                if existing.snapshot_hash != digest:
                    raise _error("ANALYSIS_CONSTRAINT_CONFLICT", "同版本分析约束不能被重新定义。")
                return AnalysisConstraintResponse(
                    constraint_ref=existing.id,
                    analysis_id=existing.analysis_id,
                    constraint_version=existing.constraint_version,
                )
            latest = versions[-1] if versions else None
            expected = latest.constraint_version + 1 if latest else payload.constraint_version
            if payload.constraint_version != expected:
                raise _error("ANALYSIS_CONSTRAINT_VERSION", "请从当前分析约束版本继续修订。")
            if latest is not None and payload.prior_constraint_ref != latest.id:
                raise _error(
                    "ANALYSIS_SOURCE_MISMATCH", "修订必须绑定当前版本的固定约束来源。", 422
                )
            previous = None
            if payload.prior_constraint_ref is not None:
                previous = uow.session.get(AnalysisConstraintSnapshot, payload.prior_constraint_ref)
                if (
                    previous is None
                    or previous.owner_user_id != actor.user_id
                    or previous.conversation_id != payload.conversation_id
                    or (latest is not None and previous.id != latest.id)
                ):
                    raise _error(
                        "ANALYSIS_SOURCE_MISMATCH", "历史分析约束不属于当前续接来源。", 422
                    )
            prior_query = None
            prior_query_question = None
            if payload.prior_query_task_id is not None:
                source_task = uow.tasks.get_owned_for_update(
                    payload.prior_query_task_id, actor.user_id or ""
                )
                if source_task is None or source_task.conversation_id != payload.conversation_id:
                    raise _error("ANALYSIS_SOURCE_MISMATCH", "历史查询不属于当前续接来源。", 422)
                source_state = QueryTaskState.model_validate(source_task.state_json)
                raw_query = source_state.debug.get("basic_query")
                if raw_query is None:
                    raise _error("ANALYSIS_SOURCE_MISMATCH", "历史查询缺少可信结构化条件。", 422)
                prior_query = BasicQuerySpec.model_validate(raw_query)
                prior_query_question = (
                    source_state.channel_context.get("calculation_context", {}).get(
                        "user_question",
                    )
                    or source_task.original_question
                )
            catalog = uow.metric_catalog.list_enabled()
            known = {item.code for item in catalog}
            if not known:
                raise _error(
                    "ANALYSIS_CATALOG_INVALID", "正式指标目录为空，无法登记分析范围。", 422
                )
            for target in payload.targets:
                if not (set(target.fixed_metric_codes) | set(target.allowed_metric_codes)) <= known:
                    raise _error(
                        "ANALYSIS_CATALOG_INVALID", "分析范围引用了非正式或停用指标。", 422
                    )
                # 仅检查正式范围和权限；不会访问业务数据源。
                check = BasicQuerySpec(
                    metric_codes=[
                        next(
                            iter(
                                target.fixed_metric_codes
                                or target.allowed_metric_codes
                                or sorted(known),
                            )
                        )
                    ],
                    org_codes=target.org_codes,
                    time=target.time,
                    selection="exact"
                    if target.time.start == target.time.end
                    else "latest_in_range"
                    if target.time.dates
                    else "all_in_range",
                )
                self._authorize(uow, actor, check)
            self._verify_explicit_metrics(
                payload, catalog, previous, prior_query, prior_query_question
            )
            for item in versions:
                item.status = "superseded"
            snapshot = AnalysisConstraintSnapshot(
                id=f"constraint:{uuid4()}",
                conversation_id=payload.conversation_id,
                owner_user_id=actor.user_id or "",
                analysis_id=payload.analysis_id,
                constraint_version=payload.constraint_version,
                snapshot_hash=digest,
                snapshot_json=payload.model_dump(mode="json"),
                status="active",
                created_at=datetime.now(UTC),
            )
            uow.session.add(snapshot)
            uow.commit()
            return AnalysisConstraintResponse(
                constraint_ref=snapshot.id,
                analysis_id=snapshot.analysis_id,
                constraint_version=snapshot.constraint_version,
            )

    @staticmethod
    def _verify_explicit_metrics(payload, catalog, previous, prior_query, prior_query_question):
        index = metric_candidate_index(catalog)
        mentions = index.mentions(payload.source_question)
        resolved = {
            code
            for mention in mentions
            if mention["resolution"]["status"] == "resolved"
            for code in mention["resolution"]["value"]["codes"]
        }
        inherited = set()
        old = AnalysisConstraintRequest.model_validate(previous.snapshot_json) if previous else None
        allowed_questions = {payload.source_question}
        for message in payload.source_history:
            if (
                hashlib.sha256(message.source_question.encode()).hexdigest()
                != message.source_question_sha256
            ):
                raise _error("ANALYSIS_SOURCE_MISMATCH", "历史原文摘要不一致。", 422)
            allowed_questions.add(message.source_question)
        if previous:
            inherited = {code for target in old.targets for code in target.fixed_metric_codes}
            allowed_questions.add(old.source_question)
            if old.metric_source_question:
                allowed_questions.add(old.metric_source_question)
            allowed_questions.update(message.source_question for message in old.source_history)
            if old.analysis_id == payload.analysis_id and any(
                not any(
                    item.requirement_id == prior.requirement_id
                    and item.description == prior.description
                    for item in payload.requirements
                )
                for prior in old.requirements
            ):
                raise _error(
                    "ANALYSIS_REQUIREMENTS_PRESERVED", "不能静默删除或改写原始分析要求。", 422
                )
        if prior_query is not None:
            inherited.update(prior_query.metric_codes)
            if prior_query_question:
                allowed_questions.add(prior_query_question)
        bound = set()
        if payload.metric_source_question is not None:
            if payload.metric_source_question not in allowed_questions:
                raise _error("ANALYSIS_SOURCE_MISMATCH", "指标原题缺少当前或可信历史来源。", 422)
            if payload.source_metric_bindings is not None:
                bound = verify_metric_bindings(
                    payload.metric_source_question,
                    index.mentions(payload.metric_source_question),
                    payload.source_metric_bindings,
                    payload.source_metric_exclusions or [],
                    index,
                    allow_empty_bindings=True,
                )
        fixed = {code for target in payload.targets for code in target.fixed_metric_codes}
        if not fixed <= resolved | inherited | bound:
            raise _error(
                "ANALYSIS_FIXED_METRIC_SOURCE", "固定指标缺少已确定的原文或历史来源。", 422
            )
        # 只把原文正式完整名称的确定命中作为强制固定项；泛称和模糊基础词不反推口径。
        explicit = {
            code
            for mention in mentions
            if mention["source"]["kind"] == "catalog_name"
            and mention["resolution"]["status"] == "resolved"
            and mention["resolution"].get("metadata", {}).get("match") == "exact"
            for code in mention["resolution"]["value"]["codes"]
        }
        removed = {
            code
            for update in payload.fixed_metric_updates
            if update.mode == "remove"
            for code in update.codes
        }
        if not explicit - removed <= fixed:
            raise _error(
                "ANALYSIS_EXPLICIT_TARGET_MISSING", "用户明确的正式指标必须保留为固定目标。", 422
            )
        prior_targets = (
            {target.target_id: set(target.fixed_metric_codes) for target in old.targets}
            if old
            else {}
        )
        if old is not None and not set(prior_targets) <= {
            target.target_id for target in payload.targets
        }:
            raise _error("ANALYSIS_TARGETS_PRESERVED", "不能静默删除已登记的固定目标。", 422)
        updates = {item.target_id: item for item in payload.fixed_metric_updates}
        if not set(updates) <= {target.target_id for target in payload.targets}:
            raise _error("ANALYSIS_TARGET_MISMATCH", "指标更新引用了未登记目标。", 422)
        for target in payload.targets:
            before = prior_targets.get(
                target.target_id, set(prior_query.metric_codes) if prior_query else set()
            )
            after = set(target.fixed_metric_codes)
            update = updates.get(target.target_id)
            if update is None:
                if not before <= after:
                    raise _error(
                        "ANALYSIS_FIXED_TARGETS_PRESERVED", "固定指标不能在修订中静默丢失。", 422
                    )
                continue
            span = update.source_span
            if (
                span.end > len(payload.source_question)
                or payload.source_question[span.start : span.end] != span.text
                or len(update.codes) != len(set(update.codes))
            ):
                raise _error("ANALYSIS_SOURCE_MISMATCH", "指标更新片段不属于本轮真实原文。", 422)
            changed = set(update.codes)
            if update.mode == "remove":
                if not changed <= before or not changed <= resolved | inherited:
                    raise _error("ANALYSIS_FIXED_METRIC_SOURCE", "移除项缺少已登记指标身份。", 422)
                expected = before - changed
            else:
                if not changed <= resolved | inherited | bound:
                    raise _error(
                        "ANALYSIS_FIXED_METRIC_SOURCE", "更新项缺少已确定的指标身份。", 422
                    )
                expected = changed if update.mode == "replace" else before | changed
            if after != expected:
                raise _error(
                    "ANALYSIS_METRIC_UPDATE_MISMATCH", "固定指标集合与声明的更新操作不一致。", 422
                )

    def _authorize(self, uow, actor, query):
        try:
            dsl, _, _ = self.execution._authorize_query(
                uow=uow,
                actor=actor,
                logical_dsl=query.to_logical_dsl().model_dump(mode="json"),
                strict_codes=True,
            )
        except PermissionDeniedError as exc:
            raise _error("ORG_SCOPE_FORBIDDEN", "分析目标超出当前机构权限。", 403) from exc
        except UnsupportedQueryError as exc:
            raise _error("ANALYSIS_CATALOG_INVALID", "分析目标不在正式启用目录中。", 422) from exc
        if set(dsl.orgs) != set(query.org_codes):
            raise _error("ORG_SCOPE_FORBIDDEN", "分析目标机构必须完整位于当前权限内。", 403)

    @staticmethod
    def _target_query(target: AnalysisTarget, query: BasicQuerySpec):
        if (
            query.organization_scope is not None
            or query.comparison_scope is not None
            or query.operation.kind != "value"
        ):
            raise _error(
                "ANALYSIS_QUERY_UNSUPPORTED",
                "当前分析步骤支持显式机构原值取数，排名请使用正式查询能力。",
                422,
            )
        if not set(query.org_codes) <= set(target.org_codes):
            raise _error("ANALYSIS_TARGET_MISMATCH", "步骤机构超出了绑定目标。", 422)
        if target.metric_selection_policy == "allowlist" and not set(query.metric_codes) <= set(
            target.fixed_metric_codes + target.allowed_metric_codes
        ):
            raise _error("ANALYSIS_TARGET_MISMATCH", "步骤指标超出了绑定目标。", 422)
        if query.time.start < target.time.start or query.time.end > target.time.end:
            raise _error("ANALYSIS_TARGET_MISMATCH", "步骤日期超出了绑定目标。", 422)
        if target.time.dates:
            dates = query.time.dates or (
                [query.time.start] if query.time.start == query.time.end else []
            )
            if not dates or not set(dates) <= set(target.time.dates):
                raise _error("ANALYSIS_TARGET_MISMATCH", "离散日期目标不能被扩展为连续范围。", 422)

    def _snapshot(self, uow, constraint_ref, actor):
        snapshot = uow.session.get(AnalysisConstraintSnapshot, constraint_ref)
        if snapshot is None or snapshot.owner_user_id != actor.user_id:
            raise _error("ANALYSIS_CONSTRAINT_NOT_FOUND", "分析约束不存在。", 404)
        self._conversation(uow, snapshot.conversation_id, actor)
        # 会话锁等待期间可能发生修订；锁后使用当前读刷新，不沿用 MVCC 旧快照。
        snapshot = uow.session.execute(
            select(AnalysisConstraintSnapshot)
            .where(
                AnalysisConstraintSnapshot.id == constraint_ref,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        ).scalar_one()
        if snapshot.status != "active":
            raise _error("ANALYSIS_CONSTRAINT_STALE", "分析约束已修订，请准备当前版本步骤。")
        return snapshot

    def prepare(
        self, payload: AnalysisPrepareRequest, actor: ActorContext
    ) -> AnalysisPreparedResponse:
        spec_hash = query_spec_hash(payload.query)
        if payload.spec_hash is not None and payload.spec_hash != spec_hash:
            raise _error("ANALYSIS_SPEC_HASH_MISMATCH", "步骤规范摘要不一致。", 422)
        request_hash = canonical_hash(payload.model_dump(mode="json", exclude={"spec_hash"}))
        with self.uow_factory() as uow:
            snapshot = self._snapshot(uow, payload.constraint_ref, actor)
            existing = uow.tasks.find_by_idempotency_key(
                snapshot.conversation_id, payload.prepare_key
            )
            if existing is not None:
                record = QueryTaskState.model_validate(existing.state_json).analysis_execution_v1
                if record is None or record.request_hash != request_hash:
                    raise _error("ANALYSIS_PREPARE_CONFLICT", "同一个准备键不能对应不同步骤规范。")
                self._validate_record(uow, snapshot, record, actor)
                return self._response(existing, record)
            constraint = AnalysisConstraintRequest.model_validate(snapshot.snapshot_json)
            self._validate_step(
                constraint, payload.target_id, payload.requirement_ids, payload.query
            )
            self._verify_catalog_refs(
                payload.catalog_refs,
                payload.query,
                uow.metric_catalog.list_enabled(),
                actor,
                snapshot.conversation_id,
            )
            self._authorize(uow, actor, payload.query)
            # 使用现有规划器和 SQL builder 验证组合；这里只生成 SQL，不访问数据源。
            try:
                self.execution._build_governed_plan(
                    uow=uow,
                    actor=actor,
                    logical_dsl=payload.query.to_logical_dsl().model_dump(mode="json"),
                    query_shape=payload.query.query_shape,
                    strict_codes=True,
                )
            except QueryPlanError as exc:
                raise _error(
                    "ANALYSIS_QUERY_UNSUPPORTED",
                    "当前步骤组合无法执行，请保留目标后调整分析步骤。",
                    422,
                ) from exc
            task_id = str(uuid4())
            record = AnalysisExecutionRecord(
                constraint_ref=snapshot.id,
                constraint_version=snapshot.constraint_version,
                analysis_id=snapshot.analysis_id,
                prepare_key=payload.prepare_key,
                prepared_query_ref=f"prepared:{task_id}",
                step_id=payload.step_id,
                step_revision=payload.step_revision,
                target_id=payload.target_id,
                requirement_ids=payload.requirement_ids,
                spec_hash=spec_hash,
                request_hash=request_hash,
                query=payload.query,
                catalog_refs=payload.catalog_refs,
            )
            # 步骤修订不能重用同一 analysis/step/revision 另造一个准备键。
            for other in uow.tasks.list_for_conversation(snapshot.conversation_id):
                saved = QueryTaskState.model_validate(other.state_json).analysis_execution_v1
                if saved and (
                    saved.analysis_id,
                    saved.constraint_version,
                    saved.step_id,
                    saved.step_revision,
                ) == (
                    record.analysis_id,
                    record.constraint_version,
                    record.step_id,
                    record.step_revision,
                ):
                    raise _error("ANALYSIS_STEP_CONFLICT", "步骤版本已经准备，请按原准备键回查。")
            state = QueryTaskState(
                logical_dsl=payload.query.to_logical_dsl().model_dump(mode="json"),
                actor_context=actor.model_dump(mode="json"),
                channel_context={"channel": "analysis_query"},
                analysis_execution_v1=record,
                debug={"basic_query": payload.query.model_dump(mode="json")},
            )
            task = QueryTask(
                id=task_id,
                conversation_id=snapshot.conversation_id,
                original_question=constraint.source_question,
                status=QueryTaskStatus.PREPARED.value,
                current_stage=QueryTaskStage.ANALYSIS_PREPARED.value,
                intent="metric_query",
                query_shape=payload.query.query_shape,
                state_json=state.model_dump(mode="json"),
                version=0,
                idempotency_key=payload.prepare_key,
                created_at=datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
            uow.tasks.add(task)
            uow.commit()
            return self._response(task, record)

    def _validate_step(self, constraint, target_id, requirement_ids, query):
        target = next((item for item in constraint.targets if item.target_id == target_id), None)
        if target is None:
            raise _error("ANALYSIS_TARGET_MISMATCH", "步骤引用了未登记目标。", 422)
        requirements = {item.requirement_id: item for item in constraint.requirements}
        if len(requirement_ids) != len(set(requirement_ids)) or any(
            key not in requirements or target_id not in requirements[key].target_ids
            for key in requirement_ids
        ):
            raise _error("ANALYSIS_REQUIREMENT_MISMATCH", "步骤必须绑定该目标的正式要求。", 422)
        self._target_query(target, query)

    def _validate_record(self, uow, snapshot, record, actor):
        if query_spec_hash(record.query) != record.spec_hash:
            raise _error("ANALYSIS_SPEC_HASH_MISMATCH", "准备规范已损坏，不能执行。")
        self._validate_step(
            AnalysisConstraintRequest.model_validate(snapshot.snapshot_json),
            record.target_id,
            record.requirement_ids,
            record.query,
        )
        self._verify_catalog_refs(
            record.catalog_refs,
            record.query,
            uow.metric_catalog.list_enabled(),
            actor,
            snapshot.conversation_id,
        )
        self._authorize(uow, actor, record.query)

    def _response(self, task, record, *, invalidated=False):
        status = (
            "invalidated"
            if invalidated
            else (
                "settled"
                if task.status in {"SUCCEEDED", "FAILED", "CANCELLED", "EXPIRED"}
                else record.status
            )
        )
        if not invalidated and task.status == QueryTaskStatus.RUNNING.value:
            state = QueryTaskState.model_validate(task.state_json)
            if state.execution is None:
                # 兼容旧版 execute 接线窗口：未登记 QueryRun，原键可安全首次执行。
                status = "prepared"
            elif running_execution_is_stale(task.status, state, self.execution.running_stale_after):
                # GET 保持只读；下一次原键 execute 负责原子回收，不重新跑业务 SQL。
                status = "interrupted"
        return AnalysisPreparedResponse(
            prepared_query_ref=record.prepared_query_ref,
            prepare_key=record.prepare_key,
            spec_hash=record.spec_hash,
            status=status,
            query=record.query,
            task_id=task.id,
            task_version=task.version,
        )

    def find_prepared(
        self, prepare_key: str, conversation_id: str, actor: ActorContext
    ) -> AnalysisPreparedResponse:
        with self.uow_factory() as uow:
            self._conversation(uow, conversation_id, actor)
            task = uow.tasks.find_by_idempotency_key(conversation_id, prepare_key)
            record = (
                QueryTaskState.model_validate(task.state_json).analysis_execution_v1
                if task
                else None
            )
            if record is None:
                raise _error("ANALYSIS_PREPARED_NOT_FOUND", "准备记录不存在。", 404)
            snapshot = uow.session.get(AnalysisConstraintSnapshot, record.constraint_ref)
            if snapshot is None:
                raise _error("ANALYSIS_CONSTRAINT_NOT_FOUND", "分析约束不存在。", 404)
            self._authorize(uow, actor, record.query)
            return self._response(task, record, invalidated=snapshot.status != "active")

    def execute(
        self, prepared_ref: str, idempotency_key: str, actor: ActorContext
    ) -> tuple[BasicQuerySpec, QueryExecutionResult]:
        if not prepared_ref.startswith("prepared:"):
            raise _error("ANALYSIS_PREPARED_NOT_FOUND", "准备记录不存在。", 404)
        with self.uow_factory() as uow:
            task_id = prepared_ref.removeprefix("prepared:")
            task = uow.tasks.get_owned(task_id, actor.user_id or "")
            record = (
                QueryTaskState.model_validate(task.state_json).analysis_execution_v1
                if task
                else None
            )
            if record is None or record.prepared_query_ref != prepared_ref:
                raise _error("ANALYSIS_PREPARED_NOT_FOUND", "准备记录不存在。", 404)
            if idempotency_key != record.prepare_key:
                raise _error("ANALYSIS_EXECUTION_KEY_MISMATCH", "执行必须沿用原准备幂等键。", 422)
            # 与 register/prepare 保持会话 -> snapshot -> task 的锁顺序，避免互相等待。
            snapshot = self._snapshot(uow, record.constraint_ref, actor)
            task = uow.tasks.get_owned_for_update(task_id, actor.user_id or "")
            uow.session.refresh(task)
            record = QueryTaskState.model_validate(task.state_json).analysis_execution_v1
            self._validate_record(uow, snapshot, record, actor)
            state = QueryTaskState.model_validate(task.state_json)
            if state.logical_dsl != record.query.to_logical_dsl().model_dump(mode="json"):
                # 执行后 DSL 会物化当前授权机构，显式机构 value 路径参数仍应完全相等。
                raise _error("ANALYSIS_SPEC_HASH_MISMATCH", "执行参数与准备规范不同。")
            command = ExecuteQueryCommand(
                task_id=task.id,
                expected_version=task.version,
                request_id=f"analysis:{record.prepare_key}",
                actor=actor,
                analysis_prepared_ref=prepared_ref,
            )
            query = record.query
        return query, self.execution.execute(command)
