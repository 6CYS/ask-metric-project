from dataclasses import dataclass

from ask_metric.application.requests import ActorContext, IncomingRequest
from ask_metric.domain.basic_query import BasicQuerySpec


@dataclass(frozen=True)
class SubmitQuestionCommand:
    request: IncomingRequest
    actor: ActorContext
    idempotency_key: str
    basic_query: BasicQuerySpec | None = None


@dataclass(frozen=True)
class ExecuteQueryCommand:
    task_id: str
    expected_version: int
    request_id: str
    actor: ActorContext
    # 仅由服务间鉴权的分析执行入口填入；普通任务执行不能绕过准备态。
    analysis_prepared_ref: str | None = None
