"""按完整原句核对正式指标身份，不以查询参数反推用户选择。"""

from typing import NoReturn

from ask_metric.application.metric_candidates import MetricCandidateIndex, metric_candidate_index
from ask_metric.core.errors import ApplicationError
from ask_metric.domain.metric_source import SourceMetricBinding, SourceMetricSpan
from ask_metric.domain.semantics import MetricCatalogItem


def verify_metric_coverage(
    question: str,
    requested: list[str],
    catalog: list[MetricCatalogItem],
    bindings: list[SourceMetricBinding] | None = None,
    exclusions: list[SourceMetricSpan] | None = None,
) -> None:
    """宿主原句的所有目录目标必须进入独立新任务；无法确定时不部分取数。"""
    index = metric_candidate_index(catalog)
    mentions = index.mentions(question)
    if bindings is None:
        # 兼容旧调用方：没有已确认身份时，仍要求原句自身能唯一确定全部指标。
        if (
            exclusions is not None
            or not mentions
            or any(item["resolution"]["status"] != "resolved" for item in mentions)
        ):
            raise ApplicationError(
                "METRIC_TARGETS_UNRESOLVED",
                "本轮指标目标未全部确定，请核对指标名称。",
                status_code=409,
            )
        expected = {code for item in mentions for code in item["resolution"]["value"]["codes"]}
    else:
        expected = verify_metric_bindings(question, mentions, bindings, exclusions or [], index)
    if expected != set(requested):
        raise ApplicationError(
            "METRIC_TARGETS_INCOMPLETE",
            "本轮指标未全部进入查询，请重新解析原问题。",
            status_code=409,
        )


def verify_metric_bindings(
    question: str,
    mentions: list[dict],
    bindings: list[SourceMetricBinding],
    exclusions: list[SourceMetricSpan],
    index: MetricCandidateIndex,
    *,
    allow_empty_bindings: bool = False,
) -> set[str]:
    """原文完整扫描与逐片段身份双向核对；不能拿 requested 反推歧义选择。"""

    def unresolved() -> NoReturn:
        raise ApplicationError(
            "METRIC_TARGETS_UNRESOLVED",
            "本轮指标目标未全部确定，请核对指标名称。",
            status_code=409,
        )

    spans: list[SourceMetricSpan] = [*bindings, *exclusions]
    if not mentions or (not bindings and not allow_empty_bindings) or len(mentions) != len(spans):
        unresolved()
    by_span: dict[tuple[int, int, str], SourceMetricSpan] = {}
    previous_end = 0
    for span in sorted(spans, key=lambda item: (item.start, item.end)):
        # 保留完整原文再标记放弃项，避免删除共享基础名或拼接出用户未表达的新名称。
        if (
            span.start < previous_end
            or span.end > len(question)
            or question[span.start : span.end] != span.text
        ):
            unresolved()
        previous_end = span.end
        by_span[(span.start, span.end, span.text)] = span
    expected: set[str] = set()
    for mention in mentions:
        binding = by_span.pop((mention["start"], mention["end"], mention["text"]), None)
        if binding is None:
            unresolved()
        if not isinstance(binding, SourceMetricBinding):
            # 用户可以明确放弃未决目标；只有精确覆盖扫描所得完整片段才可排除。
            continue
        resolution = mention["resolution"]
        codes = set(binding.codes)
        if not codes.issubset(index.items):
            unresolved()
        if resolution["status"] == "resolved":
            if codes != set(resolution["value"]["codes"]):
                unresolved()
        elif resolution["status"] in {"ambiguous", "needs_confirmation"}:
            candidates = {candidate.get("code") for candidate in resolution.get("candidates", [])}
            # 模糊基础名需要先确认基础、再确认口径；候选自身不带最终编码。
            # 只从当前索引已验证的来源结构扩展可选变体，不从 requested 反推选择。
            for candidate in resolution.get("candidates", []):
                metadata = candidate.get("metadata", {})
                if metadata.get("kind") == "base_only":
                    variants = index.variants.get(metadata.get("source_metric_code"), {})
                    candidates.update(
                        code for variant_codes in variants.values() for code in variant_codes
                    )
            if len(codes) != 1 or not codes.issubset(candidates):
                unresolved()
        else:
            unresolved()
        expected.update(codes)
    if by_span:
        unresolved()
    return expected
