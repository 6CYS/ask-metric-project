"""持久化不可变分析约束版本；不修改旧查询或旧分析检查点。"""

import sqlalchemy as sa
from alembic import op

from ask_metric.core.config import get_settings
from ask_metric.infrastructure.db.schema_governance import assert_schema_change_allowed

revision = "0006_analysis_constraints"
down_revision = "0005_metric_source_structure"
branch_labels = None
depends_on = None


def _guard() -> None:
    settings = get_settings()
    assert_schema_change_allowed(
        settings.app_database_url,
        allow_schema_changes=settings.backend_next_allow_schema_changes,
        allow_non_test_database=settings.backend_next_allow_non_test_database,
    )


def upgrade() -> None:
    _guard()
    op.create_table(
        "analysis_constraint_snapshots",
        sa.Column("id", sa.String(128), primary_key=True),
        sa.Column("conversation_id", sa.String(128), nullable=False),
        sa.Column("owner_user_id", sa.String(128), nullable=False),
        sa.Column("analysis_id", sa.String(128), nullable=False),
        sa.Column("constraint_version", sa.Integer(), nullable=False),
        sa.Column("snapshot_hash", sa.String(64), nullable=False),
        sa.Column("snapshot_json", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.ForeignKeyConstraint(["conversation_id"], ["chat_conversations.id"], ondelete="CASCADE"),
        sa.UniqueConstraint(
            "conversation_id",
            "analysis_id",
            "constraint_version",
            name="uq_analysis_constraint_version",
        ),
        sa.CheckConstraint("constraint_version >= 1", name="analysis_constraint_version_check"),
    )
    op.create_index(
        "ix_analysis_constraints_owner",
        "analysis_constraint_snapshots",
        ["owner_user_id", "conversation_id"],
    )


def downgrade() -> None:
    _guard()
    # 已保存准备任务必须先通过兼容版本收敛；迁移不会自动删除 QueryTask 审计证据。
    op.drop_table("analysis_constraint_snapshots")
