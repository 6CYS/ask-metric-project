import {mkdtempSync, rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, expect, it, vi} from "vitest";
import {validateToolArguments} from "@earendil-works/pi-ai";
import {NativeSessionStore} from "../../src/nativeSessions.js";
import {NativeFrameStore} from "../../src/business-context/store.js";
import {BusinessContextService} from "../../src/business-context/service.js";
import {createCapabilities} from "../../src/business-context/capabilities.js";
import {createFieldResolvers} from "../../src/business-context/resolvers.js";
import {applyFieldIntentConstraints, validateFieldIntents} from "../../src/business-context/core.js";
import {toCompactTurnArgs, toContextDelta} from "../../src/business-context/turnArgs.js";
import {createResolveBusinessTurnTool} from "../../src/tools/businessContext.js";
import {MemoryCommandBridge, receiptJson, runTool, testRequestContext} from "../../src/tools/testUtils.js";
import type {BackendClient} from "../../src/backendClient.js";
import type {BusinessFrame, CapabilitySchema, ContextDelta, FieldResolution, FieldTurnIntent, ResolverContext} from "../../src/business-context/types.js";

const cleanup: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of cleanup.splice(0)) await close(); vi.restoreAllMocks();});
const inherited: FieldTurnIntent = {mode: "inherit", sourceText: null, expectedCount: null};
const explicit = (sourceText: string, expectedCount: number | null = null): FieldTurnIntent => ({mode: "set", sourceText, expectedCount});

async function fixture() {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const path = mkdtempSync(join(tmpdir(), "field-intents-"));
  const sessions = new NativeSessionStore(path);
  const session = await sessions.create("synthetic-field-intents");
  cleanup.push(async () => {await sessions.close(); rmSync(path, {recursive: true, force: true});});
  const store = new NativeFrameStore(session);
  const service = new BusinessContextService(store, createCapabilities(), createFieldResolvers());
  const names = new Map([["A", "合成机构甲"], ["B", "合成机构乙"], ["C", "合成机构丙"], ["D", "合成机构丁"]]);
  const resolveCatalog = vi.fn(async (entity: string, values: string[]): Promise<FieldResolution> => {
    if (entity === "date") return {status: "resolved", value: {start: "2026-04-30", end: "2026-04-30"}};
    if (entity === "metric") return {status: "resolved", value: {codes: ["M"], names: ["合成指标"]}};
    if (values[0] === "近似机构") return {status: "needs_confirmation", candidates: [{code: "D", value: "合成机构丁"}]};
    const codes = values.map(value => names.has(value) ? value : [...names].find(([, name]) => name === value)?.[0]);
    return codes.every((code): code is string => !!code)
      ? {status: "resolved", value: {codes, names: codes.map(code => names.get(code)!)}} : {status: "not_found"};
  });
  const saved: BusinessFrame[] = [];
  for (const [index, organizations] of [["合成机构甲"], ["合成机构乙", "合成机构丙"]].entries()) {
    const id = {sessionId: session.metadata.id, turnId: `seed-${index}`, requestId: `seed-${index}`};
    const delta: ContextDelta = {capabilityHint: "metric_query", baseReference: null, executionMode: "execute", fieldChanges: [
      {fieldHint: "metrics", operation: "set", rawValue: "合成指标"},
      {fieldHint: "organizations", operation: "set", rawValue: organizations},
      {fieldHint: "time", operation: "set", rawValue: "2026年4月末"},
      {fieldHint: "selection", operation: "set", rawValue: "exact"},
    ]};
    const ready = await service.resolve(delta, id, {originalMessage: `合成指标 ${organizations.join(" ")} 2026年4月末`,
      currentDate: "2026-10-13", turnId: id.turnId, resolveCatalog});
    saved.push(await service.finishExecution(await service.beginExecution(ready.frameId, id), {status: "success", resultRef: `query:${index}:result`}));
  }
  const basicQueries = vi.fn();
  const request = testRequestContext({resolveBusinessField: resolveCatalog, basicQueries} as unknown as BackendClient,
    new MemoryCommandBridge(), {sessionId: session.metadata.id, operationId: "current", requestId: "current", frames: store,
      originalMessage: "对以上三家机构进行排名"});
  const delta: ContextDelta = {capabilityHint: "metric_query", baseReference: "current", executionMode: "resolve_more", fieldChanges: []};
  const reference = {fromHistory: true, sourceText: "以上三家机构", combine: "union", sources: saved.map(frame => ({frame: {frameId: frame.frameId}, field: "organizations"}))};
  return {store, service, saved, resolveCatalog, request, delta, reference, basicQueries};
}

it.each([false, true])("模型Schema强制目标声明且不能靠prepareArguments补继承：compact=%s", compactTurnArgs => {
  const tool = createResolveBusinessTurnTool({compactTurnArgs});
  const args = compactTurnArgs ? {capability: "metric_query", base: "current", mode: "execute"}
    : {capabilityHint: "metric_query", baseReference: "current", executionMode: "execute", fieldChanges: []};
  const call = {type: "toolCall" as const, name: tool.name, id: "missing", arguments: args};
  expect(() => validateToolArguments(tool, call)).toThrow();
  expect(tool.prepareArguments?.(args)).not.toHaveProperty("fieldIntents");
  expect(() => validateToolArguments(tool, {...call, arguments: {...args, fieldIntents: {organizations: inherited}}})).not.toThrow();
  expect(() => validateToolArguments(tool, {...call, arguments: {...args, fieldIntents: {organizations: {mode: "inherit"}}}})).toThrow();
  expect(() => validateToolArguments(tool, {...call, arguments: {...args, fieldIntents: {organizations: inherited}, requireFieldIntents: false}})).toThrow();
});

it.each([undefined, {}])("工具执行入口也拒绝缺少机构声明，不落盘、不执行：%j", async fieldIntents => {
  const f = await fixture();
  const before = await f.store.state();
  const result = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta, ...(fieldIntents ? {fieldIntents} : {})}, f.request));
  expect(result).toMatchObject({status: "ARGUMENT_ERROR", error_code: "FIELD_INTENT_REQUIRED"});
  expect(await f.store.state()).toEqual(before);
  expect(f.basicQueries).not.toHaveBeenCalled();
});

it("声明以上三家发生变化却给空修改，不能误查焦点两家", async () => {
  const f = await fixture();
  const before = await f.store.state();
  const result = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta, executionMode: "execute",
    fieldIntents: {organizations: explicit("以上三家机构", 3)}}, f.request));
  expect(result).toMatchObject({status: "ARGUMENT_ERROR", error_code: "FIELD_INTENT_MODE_MISMATCH"});
  expect(await f.store.state()).toEqual(before);
  expect(f.basicQueries).not.toHaveBeenCalled();
});

it.each([false, true])("普通续接显式inherit保留焦点全量条件：compact=%s", async compact => {
  const f = await fixture();
  const delta = {...f.delta, fieldIntents: {organizations: inherited}};
  const result = receiptJson(await runTool(createResolveBusinessTurnTool({compactTurnArgs: compact}), compact ? toCompactTurnArgs(delta) : delta,
    {...f.request, originalMessage: "再查一次"}));
  expect(result.status).toBe("READY");
  const frame = (await f.store.get(String(result.frameId)))!;
  expect(frame.fields.organizations?.resolvedValue).toEqual(f.saved[1]!.fields.organizations?.resolvedValue);
  expect(frame.fields.time?.resolvedValue).toEqual(f.saved[1]!.fields.time?.resolvedValue);
});

it.each([2, 3, 4])("数量声明约束历史完整并集，不截断为%i家且与top_n分离", async expectedCount => {
  const f = await fixture();
  const delta = {...f.delta, fieldIntents: {organizations: explicit("以上三家机构", expectedCount)}, fieldChanges: [
    {fieldHint: "organizations", operation: "set" as const, rawValue: f.reference},
    {fieldHint: "operation", operation: "set" as const, rawValue: {kind: "ranking", position: "top", top_n: 2}},
  ]};
  const result = receiptJson(await runTool(createResolveBusinessTurnTool(), delta, f.request));
  const frame = (await f.store.get(String(result.frameId)))!;
  expect(frame.fields.organizations?.resolvedValue).toEqual({codes: ["A", "B", "C"], names: ["合成机构甲", "合成机构乙", "合成机构丙"]});
  expect(frame.fields.operation?.resolvedValue).toEqual({kind: "ranking", position: "top", top_n: 2});
  if (expectedCount === 3) expect(result.status).toBe("READY");
  else {
    expect(result.status).toBe("NEEDS_CLARIFICATION");
    expect(frame.fields.organizations).toMatchObject({resolutionStatus: "not_found", metadata: {referenceIssue: {
      code: "FIELD_INTENT_COUNT_MISMATCH", expectedCount, actualCount: 3}}});
    expect(frame.fields.time?.resolvedValue).toEqual(f.saved[1]!.fields.time?.resolvedValue);
  }
  expect(f.basicQueries).not.toHaveBeenCalled();
});

it("历史raw与目标声明数量冲突是参数错误，不能删掉任一约束绕过", async () => {
  const f = await fixture();
  const before = await f.store.state();
  const result = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta, fieldIntents: {organizations: explicit("以上三家机构", 3)},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: {...f.reference, expectedCount: 2}}]}, f.request));
  expect(result).toMatchObject({status: "ARGUMENT_ERROR", error_code: "FIELD_INTENT_COUNT_CONFLICT"});
  expect(await f.store.state()).toEqual(before);
});

it("确认候选保留初次目标数量，不能把两家目标确认成一家", async () => {
  const f = await fixture();
  const first = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta, fieldIntents: {organizations: explicit("近似机构", 2)},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: "近似机构"}]}, {...f.request, originalMessage: "查询近似机构这两家"}));
  expect(first.status).toBe("NEEDS_CLARIFICATION");
  const confirmed = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta,
    fieldIntents: {organizations: {mode: "confirm", sourceText: "是", expectedCount: null}},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: {confirm: true}}]},
    {...f.request, originalMessage: "是", operationId: "confirm", requestId: "confirm"}));
  expect(confirmed.status).toBe("NEEDS_CLARIFICATION");
  expect((await f.store.get(String(confirmed.frameId)))?.fields.organizations).toMatchObject({resolvedValue: {codes: ["D"]},
    metadata: {turnIntentExpectedCount: 2, referenceIssue: {actualCount: 1}}});
});

it("确认声明不能把保存的两家数量改成一家以绕过校验", async () => {
  const f = await fixture();
  const first = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta, fieldIntents: {organizations: explicit("近似机构", 2)},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: "近似机构"}]}, {...f.request, originalMessage: "查询近似机构这两家"}));
  expect(first.status).toBe("NEEDS_CLARIFICATION");
  const before = {state: await f.store.state(), frames: await f.store.list()};
  const confirmed = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta,
    fieldIntents: {organizations: {mode: "confirm", sourceText: "是", expectedCount: 1}},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: {confirm: true}}]},
    {...f.request, originalMessage: "是", operationId: "confirm-conflicting-count", requestId: "confirm-conflicting-count"}));
  expect(confirmed).toMatchObject({status: "ARGUMENT_ERROR", error_code: "FIELD_INTENT_COUNT_CONFLICT"});
  expect({state: await f.store.state(), frames: await f.store.list()}).toEqual(before);
  expect(f.basicQueries).not.toHaveBeenCalled();
});

it.each([null, 2])("同一历史组合续补保留原数量，null不清除且冲突%j不落盘", async expectedCount => {
  const f = await fixture();
  const source = {frame: {frameId: f.saved[0]!.frameId}, field: "organizations"};
  const first = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta,
    fieldIntents: {organizations: explicit("这家和合成机构乙、未知机构共三家", 3)},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: {fromHistory: true, sourceText: "这家", combine: "union",
      sources: [source], expectedCount: 3, add: ["合成机构乙", "未知机构"]}}]},
    {...f.request, originalMessage: "这家和合成机构乙、未知机构共三家"}));
  expect(first.status).toBe("NEEDS_CLARIFICATION");
  const before = {state: await f.store.state(), frames: await f.store.list()};
  const supplemented = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta,
    fieldIntents: {organizations: explicit("原组合", expectedCount)},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: {fromHistory: true, sourceText: "原组合", combine: "union",
      sources: [source], retainResolvedAdditions: true, replaceAdditions: [{index: 2, value: "合成机构甲"}]}}]},
    {...f.request, originalMessage: "原组合，未知机构改为合成机构甲，其余不变", operationId: "supplement-count", requestId: "supplement-count"}));
  if (expectedCount === null) {
    expect(supplemented.status).toBe("NEEDS_CLARIFICATION");
    expect((await f.store.get(String(supplemented.frameId)))?.fields.organizations).toMatchObject({resolutionStatus: "not_found",
      rawValue: {expectedCount: 3, sources: [source]}, metadata: {turnIntentExpectedCount: 3,
        referenceSourceFrames: [f.saved[0]!.frameId], referenceResolvedAdditions: {codes: expect.arrayContaining(["B"])},
        referenceIssue: {expectedCount: 3, actualCount: 2}}});
  } else {
    expect(supplemented).toMatchObject({status: "ARGUMENT_ERROR", error_code: "FIELD_INTENT_COUNT_CONFLICT"});
    expect({state: await f.store.state(), frames: await f.store.list()}).toEqual(before);
  }
  expect(f.basicQueries).not.toHaveBeenCalled();
});

it.each([null, 1])("完整新set可明确更换目标，使用新数量%j而不锁住旧目标", async expectedCount => {
  const f = await fixture();
  const first = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta, fieldIntents: {organizations: explicit("近似机构", 2)},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: "近似机构"}]}, {...f.request, originalMessage: "查询近似机构这两家"}));
  expect(first.status).toBe("NEEDS_CLARIFICATION");
  const replaced = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta,
    fieldIntents: {organizations: explicit("改为合成机构甲", expectedCount)},
    fieldChanges: [{fieldHint: "organizations", operation: "set", rawValue: "合成机构甲"}]},
    {...f.request, originalMessage: "改为合成机构甲", operationId: "replace-target", requestId: "replace-target"}));
  expect(replaced.status).toBe("READY");
  const organizations = (await f.store.get(String(replaced.frameId)))?.fields.organizations;
  expect(organizations).toMatchObject({resolvedValue: {codes: ["A"]}});
  if (expectedCount === null) expect(organizations?.metadata).not.toHaveProperty("turnIntentExpectedCount");
  else expect(organizations?.metadata).toMatchObject({turnIntentExpectedCount: 1});
  expect(f.basicQueries).not.toHaveBeenCalled();
});

it.each([
  {mode: "inherit", sourceText: "以上三家机构", expectedCount: null},
  {mode: "inherit", sourceText: null, expectedCount: 3},
  {mode: "set", sourceText: "并非本轮原文", expectedCount: 3},
])("拒绝无原文依据或伪装继承的声明：%j", async intent => {
  const f = await fixture();
  const changes = intent.mode === "set" ? [{fieldHint: "organizations", operation: "set", rawValue: f.reference}] : [];
  const result = receiptJson(await runTool(createResolveBusinessTurnTool(), {...f.delta, fieldIntents: {organizations: intent}, fieldChanges: changes}, f.request));
  expect(result.status).toBe("ARGUMENT_ERROR");
  expect(f.basicQueries).not.toHaveBeenCalled();
});

it("旧内部Delta兼容，提供的新声明在legacy/compact之间无损", async () => {
  const f = await fixture();
  const id = {sessionId: f.request.sessionId, requestId: "internal", turnId: "internal"};
  const context = {originalMessage: "再查一次", turnId: id.turnId, currentDate: "2026-10-13", resolveCatalog: f.resolveCatalog};
  expect((await f.service.resolve(f.delta, id, context)).status).toBe("ready");
  const delta = {...f.delta, fieldIntents: {organizations: inherited}};
  expect(toContextDelta(toCompactTurnArgs(delta))).toEqual(delta);
  expect(toContextDelta(delta)).toEqual(delta);
});

it("目标字段和集合属性由能力声明，集中校验不硬编码机构名称或字段名", () => {
  const schema: CapabilitySchema = {capability: "synthetic", tool: "synthetic", fields: {targets: {label: "合成目标", resolver: "synthetic",
    required: true, inheritable: true, requireTurnIntent: true, turnIntentCollection: "members"}}};
  const delta: ContextDelta = {executionMode: "resolve_more", fieldChanges: [{fieldHint: "targets", operation: "set", rawValue: "这四项"}],
    fieldIntents: {targets: explicit("这四项", 4)}};
  const context = {originalMessage: "用这四项", requireFieldIntents: true} as ResolverContext;
  expect(() => validateFieldIntents(schema, {...delta, fieldIntents: {}}, context)).toThrow("FIELD_INTENT_REQUIRED");
  expect(() => validateFieldIntents(schema, delta, context)).not.toThrow();
  const fields = {targets: {source: "explicit" as const, resolutionStatus: "resolved" as const, resolvedValue: {members: [1, 2, 3]}}};
  applyFieldIntentConstraints(schema, fields, delta);
  expect(fields.targets).toMatchObject({resolutionStatus: "not_found", resolvedValue: {members: [1, 2, 3]}, metadata: {referenceIssue: {expectedCount: 4, actualCount: 3}}});
});
