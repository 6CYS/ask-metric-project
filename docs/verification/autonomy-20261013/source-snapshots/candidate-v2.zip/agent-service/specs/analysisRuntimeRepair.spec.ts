/**
 * 脚本模型只决定测试步骤，不能证明模型自主理解。真实 HarnessHost、工具和原生会话负责
 * 登记、准备、受控执行、证据归账及多轮关联；后端完全隔离，不访问模型或业务网络。
 */
import assert from "node:assert/strict";
import {mkdtempSync, rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, expect, it, vi} from "vitest";
import {createAssistantMessageEventStream, createModels, createProvider,
  type AssistantMessage, type Model, type ProviderStreams} from "@earendil-works/pi-ai";
import {BACKGROUND_CONTEXT} from "@earendil-works/pi-agent-core";
import {HarnessHost} from "../src/harnessHost.js";
import {NativeSessionStore} from "../src/nativeSessions.js";
import {NativeAnalysisStore, type AnalysisTask} from "../src/business-context/analysis.js";
import {NativeFrameStore} from "../src/business-context/store.js";
import {historicalOperations} from "../src/business-context/core.js";
import {createAskMetricTools} from "../src/tools/index.js";
import {projectEntries} from "../src/sessionProjection.js";
import type {AgentServiceConfig} from "../src/config.js";
import {BackendApiError, type AnalysisConstraintRequest, type AnalysisPrepareRequest, type AnalysisPreparedQuery,
  type BackendClient, type BackendUser, type CalculationFact, type QueryExecutionResult} from "../src/backendClient.js";
import type {AskMetricRequestContext} from "../src/requestContext.js";

const ACTOR: BackendUser = {id: "repair-synthetic-user", username: "synthetic", display_name: "隔离测试",
  org_code: "A", org_name: "机构甲", role_code: "USER"};
const DATE = "2026-07-31";
const METRICS = [
  {metric_code: "TOTAL", metric_name: "总余额", unit: "元", value: "120"},
  {metric_code: "PERSON", metric_name: "个人余额", unit: "元", value: "60"},
  {metric_code: "GROWTH", metric_name: "年初增幅", unit: "%", value: "0.2"},
  {metric_code: "SHARE", metric_name: "个人占比", unit: "%", value: "0.5"},
  {metric_code: "ALT_GROWTH", metric_name: "同比增幅", unit: "%", value: "0.1"},
];
type Receipt = {task?: AnalysisTask; status?: string; results?: Array<{items?: Array<{metric_code: string; catalogRef: string}>}>;
  evidence_refs?: string[]; [key: string]: unknown};
type ScriptContext = Parameters<ProviderStreams["streamSimple"]>[1];
type Reply = {call: string; args: Record<string, unknown>} | {text: string};
type Decision = (receipts: Receipt[]) => Reply;

function receiptsIn(context: ScriptContext): Receipt[] {
  let start = context.messages.length - 1;
  while (start >= 0 && context.messages[start]?.role !== "user") start--;
  return context.messages.slice(start + 1).flatMap(message => message.role === "toolResult"
    ? message.content.flatMap(block => {
      if (block.type !== "text") return [];
      try {return [JSON.parse(block.text) as Receipt];} catch {return [];}
    }) : []);
}
function taskIn(receipts: Receipt[]): AnalysisTask {
  const task = [...receipts].reverse().find(receipt => receipt.task)?.task;
  assert.ok(task, "SCRIPT_REQUIRES_ACTUAL_TASK_RECEIPT");
  return task;
}
function selection(receipts: Receipt[], code: string) {
  const item = receipts.flatMap(receipt => receipt.results?.flatMap(result => result.items ?? []) ?? [])
    .find(item => item.metric_code === code);
  assert.ok(item?.catalogRef, "SCRIPT_REQUIRES_ACTUAL_CATALOG_REFERENCE");
  return {catalogRef: item.catalogRef, metricCode: code};
}
const read: Decision = () => ({call: "analysis_task", args: {action: "read"}});
const execute = (stepId: string): Decision => receipts => ({call: "analysis_task",
  args: {action: "execute", expectedRevision: taskIn(receipts).planRevision, stepId}});
const catalog: Decision = () => ({call: "catalog", args: {action: "search", queries: [{entity: "metric", keyword: "存款"}]}});
const requirement = (id: string, text: string, code: string) => ({id, text, evidenceKind: "query" as const, expectedMetricCodes: [code]});

function scriptedModel(script: Decision[]) {
  const record = {calls: 0, forcedExecutions: 0, errors: [] as string[]};
  let scriptIndex = 0;
  const model: Model<"openai-completions"> = {id: "repair-script", name: "repair-script", api: "openai-completions", provider: "repair-script",
    baseUrl: "http://script.invalid", reasoning: false, input: ["text"], contextWindow: 128_000, maxTokens: 8192,
    cost: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0}};
  const respond: ProviderStreams["streamSimple"] = (_model, context, options) => {
    const index = record.calls++;
    const stream = createAssistantMessageEventStream();
    queueMicrotask(() => {void (async () => {
      const receipts = receiptsIn(context);
      const sent = await options?.onPayload?.({tools: context.tools?.map(tool => ({type: "function", function: tool})) ?? []}, model) as
        {tool_choice?: {function?: {name?: string}}} | undefined;
      let reply: Reply;
      if (sent?.tool_choice?.function?.name === "execute_business_frame") {
        // 模拟模型遵守宿主确定性 tool_choice；业务步骤仍来自实际 READY 回执，脚本不额外规划。
        const ready = [...receipts].reverse().find(receipt => receipt.status === "READY"); assert.ok(ready);
        reply = {call: "execute_business_frame", args: {frameId: String(ready.frameId ?? ready.frame_id)}}; record.forcedExecutions++;
      } else {
        const decide = script[scriptIndex++]; assert.ok(decide, "SCRIPT_EXHAUSTED"); reply = decide(receipts);
      }
      const message: AssistantMessage = {role: "assistant", api: model.api, provider: model.provider, model: model.id,
        content: "text" in reply ? [{type: "text", text: reply.text}]
          : [{type: "toolCall", id: `script-${index + 1}`, name: reply.call, arguments: reply.args}],
        stopReason: "text" in reply ? "stop" : "toolUse", timestamp: Date.now(),
        usage: {input: 10, output: 5, cacheRead: 0, cacheWrite: 0, totalTokens: 15,
          cost: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0}}};
      stream.push({type: "start", partial: message});
      stream.push({type: "done", reason: message.stopReason === "toolUse" ? "toolUse" : "stop", message}); stream.end(message);
    })().catch(error => {
      record.errors.push(String(error));
      const message: AssistantMessage = {role: "assistant", content: [], api: model.api, provider: model.provider, model: model.id,
        timestamp: Date.now(), stopReason: "error", errorMessage: String(error),
        usage: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0,
          cost: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0}}};
      stream.push({type: "error", reason: "error", error: message}); stream.end(message);
    });});
    return stream;
  };
  const models = createModels(); models.setProvider(createProvider({id: model.provider, name: model.provider,
    auth: {apiKey: {name: model.provider, resolve: async () => ({auth: {}})}}, models: [model], api: {stream: respond, streamSimple: respond}}));
  return {models, model, record};
}

const cleanups: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of cleanups.splice(0)) await close(); vi.restoreAllMocks();});

async function fixture(script: Decision[], missingCodes: string[] = [], landingFault = false) {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const directory = mkdtempSync(join(tmpdir(), "analysis-host-repair-")), sessions = new NativeSessionStore(directory);
  const faux = scriptedModel(script);
  const config = {host: "127.0.0.1", port: 0, backendBaseUrl: "http://backend.invalid", backendTimeoutMs: 1000, dataDir: directory,
    turnContractV2: true, analysisPlanning: true, analysisAcceptNew: true,
    model: {baseUrl: "http://script.invalid", name: faux.model.id, apiKey: "", authHeader: "Authorization", authPrefix: "Bearer",
      userMessageSuffix: "", extraBody: {}, contextWindow: 128_000, maxTokens: 8192},
    compaction: {enabled: false, reserveTokens: 16_384, keepRecentTokens: 20_000}, modelRetry: {enabled: false, maxRetries: 0, baseDelayMs: 1}} as AgentServiceConfig;
  const host = new HarnessHost(config, () => ({models: faux.models, model: faux.model}), sessions,
    createAskMetricTools({turnContractV2: true, analysisPlanning: true}));
  let suppressedLandings = 0;
  if (landingFault) {
    const target = host as unknown as {landValidatedAction: (event: {toolName: string; details?: {status?: string}},
      request: AskMetricRequestContext, context: unknown) => Promise<unknown>};
    const original = target.landValidatedAction.bind(host);
    vi.spyOn(target, "landValidatedAction").mockImplementation(async (...args) => {
      if (!suppressedLandings && args[0].toolName === "analysis_task" && args[0].details?.status === "READY") {
        suppressedLandings++; return undefined;
      }
      return original(...args);
    });
  }
  cleanups.push(async () => {await host.close(); await sessions.close(); rmSync(directory, {recursive: true, force: true});});
  const hosted = await host.createSession(ACTOR), analysis = new NativeAnalysisStore(hosted.session), frames = new NativeFrameStore(hosted.session);
  let request: AskMetricRequestContext;
  const constraints = new Map<string, AnalysisConstraintRequest>();
  const prepared = new Map<string, {receipt: AnalysisPreparedQuery; result?: QueryExecutionResult}>();
  const queries: Array<{query: AnalysisPreparedQuery["query"]; key: string; taskId: string}> = [];
  const backend = {
    matchMetricQuestion: vi.fn(async (question: string) => ({mentions: METRICS.filter(metric => question.includes(metric.metric_name)).map(metric => ({
      text: metric.metric_name, start: question.indexOf(metric.metric_name), end: question.indexOf(metric.metric_name) + metric.metric_name.length,
      resolution: {status: "resolved", value: {codes: [metric.metric_code], names: [metric.metric_name]}}}))})),
    resolveBusinessField: vi.fn(async (entity: string, values: string[]) => ({status: "resolved", value: entity === "date"
      ? {start: values[0], end: values[0]} : {codes: values.map(value => value === "机构甲" || value === "A" ? "A" : "B"),
        names: values.map(value => value === "机构甲" || value === "A" ? "机构甲" : "机构乙")}})),
    searchMetrics: vi.fn(async () => ({total: METRICS.length, items: METRICS.map(metric => ({metric_code: metric.metric_code,
      metric_name: metric.metric_name, unit: metric.unit, score: 1, match_type: "exact"}))})),
    createAgentQueryContext: vi.fn(async () => ({conversation_id: "synthetic-conversation"})),
    registerAnalysisConstraints: vi.fn(async (input: AnalysisConstraintRequest) => {
      assert.equal(input.source_question, request.originalMessage, "CONSTRAINT_MUST_USE_ACTUAL_USER_MESSAGE");
      assert.equal(input.targets.length, 1); assert.equal(input.targets[0]!.metric_selection_policy, "catalog");
      const ref = `constraint:${input.constraint_version}`; constraints.set(ref, structuredClone(input));
      return {constraint_ref: ref, analysis_id: input.analysis_id, constraint_version: input.constraint_version};
    }),
    createAnalysisCatalogReferences: vi.fn(async ({metric_codes}: {metric_codes: string[]}) => ({references: metric_codes.map(code => ({metric_code: code, catalog_ref: `signed:${code}`}))})),
    prepareAnalysisQuery: vi.fn(async (input: AnalysisPrepareRequest, key: string): Promise<AnalysisPreparedQuery> => {
      const task = await analysis.read(undefined, request), step = task?.steps.find(item => item.id === input.step_id);
      assert.equal(step?.status, "preparing", "DURABLE_PREPARING_BEFORE_BACKEND"); assert.equal(step.prepareKey, key);
      const target = constraints.get(input.constraint_ref)?.targets.find(item => item.target_id === input.target_id);
      assert.ok(target, "REGISTERED_TARGET_REQUIRED"); assert.deepEqual(input.query.org_codes, target.org_codes);
      assert.deepEqual(input.query.time, target.time); assert.equal(input.query.operation?.kind, "value");
      assert.equal(input.query.selection, "exact"); assert.equal(Object.hasOwn(input.query, "conversation_id"), false);
      assert.deepEqual(input.catalog_refs.map(item => item.metric_code).sort(), [...input.query.metric_codes].sort());
      for (const ref of input.catalog_refs) assert.equal(ref.catalog_ref, `signed:${ref.metric_code}`);
      const receipt: AnalysisPreparedQuery = {prepared_query_ref: `prepared:${prepared.size + 1}`, prepare_key: key, spec_hash: `spec-${prepared.size + 1}`,
        status: "prepared", query: structuredClone(input.query), task_id: `task-${prepared.size + 1}`, task_version: 1};
      prepared.set(receipt.prepared_query_ref, {receipt}); return structuredClone(receipt);
    }),
    getPreparedAnalysisQuery: vi.fn(async () => {throw new BackendApiError(404, "not prepared", "ANALYSIS_PREPARED_NOT_FOUND");}),
    executeAnalysisQuery: vi.fn(async (reference: string, key: string) => {
      const item = prepared.get(reference); assert.ok(item, "ACTUAL_PREPARED_REFERENCE_REQUIRED");
      assert.equal(key, item.receipt.prepare_key, "PREPARE_KEY_REUSED_FOR_EXECUTION");
      if (!item.result) {
        const spec = item.receipt.query, facts: CalculationFact[] = [];
        const rows = (spec.org_codes ?? []).flatMap(org => spec.metric_codes.map(code => {
          const metric = METRICS.find(metric => metric.metric_code === code); assert.ok(metric);
          const row = {metric_code: code, metric_name: metric.metric_name, org_code: org, org_name: org === "A" ? "机构甲" : "机构乙",
            date: spec.time.end, metric_value: missingCodes.includes(code) ? null : metric.value, unit: metric.unit};
          if (row.metric_value !== null) facts.push({fact_id: `fact:${item.receipt.task_id}:${facts.length}:metric_value`, task_id: item.receipt.task_id,
            field: "metric_value", value: row.metric_value, unit: metric.unit, metric_code: code, metric_name: metric.metric_name,
            org_code: org, org_name: row.org_name, date: spec.time.end});
          return row;
        }));
        item.result = {task_id: item.receipt.task_id, status: "succeeded", rows, facts, columns: ["metric_name", "metric_value"], row_count: rows.length, truncated: false};
        item.receipt.status = "settled"; queries.push({query: structuredClone(spec), key, taskId: item.receipt.task_id});
      }
      return {query: item.receipt.query, result: structuredClone(item.result)};
    }),
    getTask: vi.fn(async (taskId: string) => ({task_id: taskId, conversation_id: "synthetic-conversation", version: 1, status: "SUCCEEDED", result: {result_id: `result-${taskId}`}})),
    getTaskResult: vi.fn(async (taskId: string, offset: number, limit: number) => {
      const item = [...prepared.values()].find(item => item.receipt.task_id === taskId); assert.ok(item?.result);
      return {...structuredClone(item.result), result_id: `result-${taskId}`, comparisons: [], offset, limit, next_offset: null, has_more: false};
    }),
    basicQueries: vi.fn(), calculate: vi.fn(),
  };
  const ask = async (id: string, message: string) => {
    const admitted = await host.admitPrompt(hosted, {protocol_version: 3, request_id: id, message}, {actor: ACTOR, backend: backend as unknown as BackendClient});
    assert.ok(admitted.ok); request = admitted.request;
    return host.drivePrompt(hosted, admitted);
  };
  const task = () => analysis.read(undefined, request);
  return {host, hosted, frames, analysis, backend, faux, ask, task, queries, constraints, suppressedLandings: () => suppressedLandings};
}

const fixedRequirements = [requirement("total", "总余额", "TOTAL"), requirement("personal", "个人余额", "PERSON"),
  requirement("growth", "增长正式指标", "GROWTH"), requirement("structure", "结构正式指标", "SHARE")];
const initialFixedScript = (): Decision[] => [catalog, receipts => ({call: "analysis_task", args: {action: "create", base: null,
  goal: "固定指标加增长及结构的描述分析", organizations: "机构甲", time: DATE, requirements: fixedRequirements,
  steps: [{id: "all", purpose: "取得全部正式指标", requirementIds: fixedRequirements.map(item => item.id),
    selections: ["TOTAL", "PERSON", "GROWTH", "SHARE"].map(code => selection(receipts, code))}]}}), execute("all"), read,
  receipts => {const task = taskIn(receipts); assert.equal(task.evidence.length, 1); assert.equal(task.evidence[0]!.complete, true);
    return {call: "analysis_task", args: {action: "complete", analysisId: task.analysisId, expectedRevision: task.planRevision,
      coverage: task.requirements.map(item => ({requirementId: item.id, evidenceRefs: [task.evidence[0]!.ref]}))}};},
  () => ({text: "已取得全部要求的正式证据并完成描述性分析。"})];

it.each([false, true])("完整分析及机构追问保持关联；就地落地故障=%s时原步骤确定性接续且不重复查询", async landingFault => {
  const script: Decision[] = [...initialFixedScript(), read,
    receipts => {const task = taskIn(receipts); return {call: "analysis_task", args: {action: "revise", analysisId: task.analysisId,
      expectedRevision: task.planRevision, reason: "用户只替换机构", organizations: "机构乙"}};}, execute("all"), read,
    receipts => {const task = taskIn(receipts), evidence = task.evidence.filter(item => item.constraintVersion === task.constraintVersion);
      assert.equal(evidence.length, 1); return {call: "analysis_task", args: {action: "complete", analysisId: task.analysisId,
        expectedRevision: task.planRevision, coverage: task.requirements.map(item => ({requirementId: item.id, evidenceRefs: evidence.map(item => item.ref)}))}};},
    () => ({text: "已按新机构完成同一分析，日期与指标要求沿用。"})];
  const f = await fixture(script, [], landingFault);
  expect(await f.ask("fixed", `分析机构甲${DATE}的总余额和个人余额，另外从正式目录自主选择增长与结构指标。`))
    .toMatchObject({ok: true, outcome: {kind: "settled", outcome: {status: "completed"}}});
  const first = (await f.task())!;
  expect(first.status).toBe("complete"); expect(first.requirements.every(item => item.status === "satisfied")).toBe(true);
  expect(first.evidence[0]!.metricCodes.sort()).toEqual(["GROWTH", "PERSON", "SHARE", "TOTAL"]);
  expect(first.evidence[0]!.factRefs).toHaveLength(4); expect(first.evidence[0]!.resultRef).toBe("query:task-1:result-task-1");
  expect(await f.ask("followup", "那机构乙呢？其他沿用。"))
    .toMatchObject({ok: true, outcome: {kind: "settled", outcome: {status: "completed"}}});
  const next = (await f.task())!;
  expect(next.analysisId).toBe(first.analysisId); expect(next.status).toBe("complete"); expect(next.constraintVersion).toBe(2);
  expect(next.requirements.map(item => item.id)).toEqual(first.requirements.map(item => item.id)); expect(next.evidence).toHaveLength(2);
  expect(f.queries.map(item => item.query.org_codes)).toEqual([["A"], ["B"]]);
  expect(f.queries.every(item => JSON.stringify(item.query.time) === JSON.stringify({start: DATE, end: DATE}))).toBe(true);
  expect(f.queries.map(item => [...item.query.metric_codes].sort())).toEqual(Array(2).fill(["GROWTH", "PERSON", "SHARE", "TOTAL"]));
  const state = await f.frames.state(); expect(state.currentContext).toEqual({kind: "analysis", analysisId: first.analysisId});
  expect(state.focusFrameId).toBeUndefined(); expect(historicalOperations(state, await f.frames.list())).toEqual([]);
  expect(f.backend.basicQueries).not.toHaveBeenCalled(); expect(f.backend.calculate).not.toHaveBeenCalled(); expect(f.faux.record.errors).toEqual([]);
  expect(f.suppressedLandings()).toBe(landingFault ? 1 : 0); expect(f.faux.record.forcedExecutions).toBe(landingFault ? 1 : 0);
  expect(f.backend.prepareAnalysisQuery).toHaveBeenCalledTimes(2); expect(f.backend.executeAnalysisQuery).toHaveBeenCalledTimes(2);
});

it("混合取数保留总量有效证据，增长缺值后追加另一正式指标并partial保留原缺口", async () => {
  const originals = [requirement("total", "总余额", "TOTAL"), requirement("growth", "年初增长取证", "GROWTH")];
  const script: Decision[] = [catalog, receipts => ({call: "analysis_task", args: {action: "create", base: null,
    goal: "总量与增长，缺值后补证并保留缺口", organizations: "机构甲", time: DATE, requirements: originals,
    steps: [{id: "initial", purpose: "总量与年初增长", requirementIds: ["total", "growth"],
      selections: ["TOTAL", "GROWTH"].map(code => selection(receipts, code))}]}}), execute("initial"), read,
    receipts => {
      const task = taskIn(receipts); assert.equal(task.evidence.length, 1); assert.equal(task.evidence[0]!.complete, false);
      assert.ok(task.evidence[0]!.missingMetricCodes?.includes("GROWTH"));
      assert.ok(task.evidence[0]!.usableCoverage?.some(item => item.metricCode === "TOTAL"));
      return {call: "analysis_task", args: {action: "revise", analysisId: task.analysisId, expectedRevision: task.planRevision,
        reason: "原增长指标无有效值，选择另一个正式增长指标补充", requirements: [...originals, requirement("alternate", "同比增长补证", "ALT_GROWTH")],
        steps: [{id: "alternative", purpose: "同比增幅补证", requirementIds: ["alternate"], selections: [selection(receipts, "ALT_GROWTH")]}]}};
    }, execute("alternative"), read,
    receipts => {const task = taskIn(receipts); assert.equal(task.evidence.length, 2); assert.equal(task.steps.length, 2);
      const initial = task.evidence.find(item => item.stepId === "initial")!, alternate = task.evidence.find(item => item.stepId === "alternative")!;
      assert.equal(alternate.complete, true); assert.ok(alternate.metricCodes.includes("ALT_GROWTH"));
      return {call: "analysis_task", args: {action: "complete", analysisId: task.analysisId, expectedRevision: task.planRevision, partial: true,
        coverage: [{requirementId: "total", evidenceRefs: [initial.ref]}, {requirementId: "alternate", evidenceRefs: [alternate.ref]}],
        gaps: ["年初增幅在固定机构日期无有效值；已取得同比增幅补充证据，原缺口保留。"]}};
    }, () => ({text: "已取得总量和另一增长指标的正式证据；原增长指标无有效值，保留缺口，分析部分完成。"})];
  const f = await fixture(script, ["GROWTH"]);
  expect(await f.ask("missing", `描述机构甲${DATE}的总余额与增长情况，请自主选择正式增长指标，缺值时同机构同日期选择其他正式指标补证，保留缺口。`))
    .toMatchObject({ok: true, outcome: {kind: "settled", outcome: {status: "completed"}}});
  const task = (await f.task())!;
  expect(task.status).toBe("partial"); expect(task.requirements.map(item => [item.id, item.status])).toEqual([
    ["total", "satisfied"], ["growth", "pending"], ["alternate", "satisfied"]]);
  expect(task.gaps.some(gap => gap.includes("GROWTH") || gap.includes("年初增幅"))).toBe(true);
  expect(task.evidence[0]!.factRefs).toHaveLength(1); expect(task.evidence[0]!.usableCoverage?.map(item => item.metricCode)).toEqual(["TOTAL"]);
  expect(f.queries.map(item => item.query.metric_codes)).toEqual([["TOTAL", "GROWTH"], ["ALT_GROWTH"]]);
  expect(f.queries.every(item => item.query.org_codes?.join() === "A" && item.query.time.start === DATE && item.query.time.end === DATE)).toBe(true);
  expect(f.backend.prepareAnalysisQuery).toHaveBeenCalledTimes(2); expect(f.backend.executeAnalysisQuery).toHaveBeenCalledTimes(2);
  expect(f.backend.basicQueries).not.toHaveBeenCalled(); expect(f.backend.calculate).not.toHaveBeenCalled(); expect(f.faux.record.errors).toEqual([]);
});

it("analysis_task execute保存澄清后终止，正文非空且关闭重开仍可展示", async () => {
  const script: Decision[] = [catalog, receipts => ({call: "analysis_task", args: {action: "create", base: null,
    goal: "已知机构指标，日期待补", organizations: "机构甲", requirements: [requirement("total", "总余额", "TOTAL")],
    steps: [{id: "pending-date", purpose: "日期明确后取数", requirementIds: ["total"], selection: "exact", selections: [selection(receipts, "TOTAL")]}]}}), execute("pending-date")];
  const f = await fixture(script);
  const outcome = await f.ask("clarifying", "请分析机构甲的总余额，取精确单日，日期稍后补充。");
  const entries = await f.hosted.lane.findEntries({order: "oldestFirst"}, BACKGROUND_CONTEXT), projected = projectEntries(entries);
  expect(outcome, JSON.stringify({outcome, scriptErrors: f.faux.record.errors}))
    .toMatchObject({ok: true, outcome: {kind: "settled", outcome: {status: "completed"}}});
  expect(projected.at(-1)).toMatchObject({role: "assistant", business_protocol: "frame_v1", text: expect.stringContaining("日期")});
  expect(f.faux.record.calls).toBe(3); expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled(); expect(f.queries).toEqual([]);
  expect((await f.task())!.status).toBe("waiting_user");
  await f.host.closeSession(f.hosted.sessionId);
  const reopened = await f.host.openSession(ACTOR, f.hosted.sessionId); assert.ok(reopened);
  expect(projectEntries(await reopened.lane.findEntries({order: "oldestFirst"}, BACKGROUND_CONTEXT))).toEqual(projected);
});
