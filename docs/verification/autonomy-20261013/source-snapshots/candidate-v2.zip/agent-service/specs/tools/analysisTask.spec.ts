import assert from "node:assert/strict";
import {mkdtempSync, rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, describe, expect, it, vi} from "vitest";
import {validateToolArguments} from "@earendil-works/pi-ai";
import {NativeSessionStore} from "../../src/nativeSessions.js";
import {NativeAnalysisStore} from "../../src/business-context/analysis.js";
import {NativeBusinessResultStore, NativeFrameStore} from "../../src/business-context/store.js";
import {createAnalysisTaskTool} from "../../src/tools/analysisTask.js";
import {createResolveBusinessTurnTool, createExecuteBusinessFrameTool} from "../../src/tools/businessContext.js";
import {MemoryCommandBridge, receiptJson, runTool, testRequestContext} from "../../src/tools/testUtils.js";
import {BackendApiError, type BackendClient, type BasicQuerySpec} from "../../src/backendClient.js";
import {analysisAttemptSource, turnAttempt} from "../../src/business-context/turnAttempt.js";

const closes: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of closes.splice(0)) await close(); vi.restoreAllMocks();});
const validated = (input: Record<string, unknown>) => validateToolArguments(createAnalysisTaskTool(), {type: "toolCall", id: "analysis-test", name: "analysis_task", arguments: input});
const createInput = {action: "create", goal: "描述存款经营情况", base: null, organizations: "机构甲", time: "2026-07-31", requirements: [{id: "total", text: "存款总量"}]};

async function fixture(originalMessage = "请分析机构甲2026-07-31的存款经营情况") {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const path = mkdtempSync(join(tmpdir(), "analysis-tool-")), sessions = new NativeSessionStore(path), session = await sessions.create("user-1");
  closes.push(async () => {await sessions.close(); rmSync(path, {recursive: true, force: true});});
  const frames = new NativeFrameStore(session), analysis = new NativeAnalysisStore(session);
  const constraints = new Map<string, Record<string, any>>(), prepared = new Map<string, Record<string, any>>();
  const organizations = new Map([["机构甲", "A"], ["机构乙", "B"]]);
  const backend = {
    resolveBusinessField: vi.fn(async (entity: string, values: string[]) => ({status: "resolved", value: entity === "date"
      ? {start: values[0], end: values[0]} : {codes: values.map(name => organizations.get(name)), names: values}})),
    matchMetricQuestion: vi.fn(async (question: string) => ({mentions: question.includes("总余额") ? [{text: "总余额", start: question.indexOf("总余额"),
      end: question.indexOf("总余额") + 3, resolution: {status: "resolved", value: {codes: ["M"], names: ["总余额"]}}}] : []})),
    createAgentQueryContext: vi.fn(async () => ({conversation_id: "conversation-1"})),
    registerAnalysisConstraints: vi.fn(async (input: Record<string, any>) => {
      const ref = `constraint:${input.analysis_id}:${input.constraint_version}`; constraints.set(ref, structuredClone(input));
      return {constraint_ref: ref, constraint_version: input.constraint_version};
    }),
    createAnalysisCatalogReferences: vi.fn(async ({metric_codes}: {metric_codes: string[]}) => ({references: metric_codes.map(code => ({metric_code: code, catalog_ref: `formal:${code}`}))})),
    prepareAnalysisQuery: vi.fn(async (input: Record<string, any>) => {
      const saved = await analysis.read(undefined, request), step = saved?.steps.find(item => item.id === input.step_id);
      assert.equal(step?.status, "preparing", "PREPARE_MUST_FOLLOW_DURABLE_PREPARING");
      assert.equal(step.prepareKey, input.prepare_key, "PREPARE_KEY_PERSISTED_BEFORE_SEND");
      const snapshot = constraints.get(input.constraint_ref), target = snapshot?.targets.find((item: Record<string, any>) => item.target_id === input.target_id);
      assert.ok(target, "CURRENT_TARGET_IN_FROZEN_CONSTRAINT");
      assert.deepEqual(input.query.org_codes, target.org_codes, "PREPARE_CURRENT_TARGET_ORGANIZATIONS");
      assert.deepEqual(input.query.time, target.time, "PREPARE_CURRENT_TARGET_DATE");
      for (const code of input.query.metric_codes) assert.ok(input.catalog_refs.some((reference: {metric_code: string; catalog_ref: string}) =>
        reference.metric_code === code && reference.catalog_ref === `formal:${code}`), "PREPARE_REAL_CATALOG_REFERENCE");
      const receipt = {prepared_query_ref: `prepared:${input.step_id}:${input.step_revision}`, prepare_key: input.prepare_key, spec_hash: "fixed-spec-hash",
        status: "prepared", query: structuredClone(input.query), task_id: "task-1", task_version: 1};
      prepared.set(receipt.prepared_query_ref, {receipt, spec: structuredClone(input.query)}); return receipt;
    }),
    getPreparedAnalysisQuery: vi.fn(async () => {throw new BackendApiError(404, "not found", "ANALYSIS_PREPARED_NOT_FOUND");}),
    executeAnalysisQuery: vi.fn(async (reference: string) => {
      const item = prepared.get(reference); assert.ok(item, "EXECUTION_MUST_USE_ACTUAL_PREPARATION");
      const spec = item.spec as BasicQuerySpec;
      const facts = (spec.org_codes ?? []).flatMap(org => spec.metric_codes.map(code => ({fact_id: `fact:task-1:0:metric_value`, task_id: "task-1", field: "metric_value",
        value: "120", unit: "元", metric_code: code, metric_name: "总余额", org_code: org, org_name: org, date: spec.time.end})));
      return {query: spec, result: {task_id: "task-1", status: "succeeded", rows: facts.map(fact => ({...fact, metric_value: fact.value})), facts,
        columns: ["metric_value"], row_count: facts.length, truncated: false}};
    }),
    getTask: vi.fn(async () => ({version: 1, result: {result_id: "result-1"}})), basicQueries: vi.fn(),
  };
  const request = testRequestContext(backend as unknown as BackendClient, new MemoryCommandBridge(), {sessionId: session.metadata.id,
    frames, analysis, businessResults: new NativeBusinessResultStore(session), originalMessage});
  const catalogRef = await analysis.issueReference("catalog", {metric_code: "M", metric_name: "总余额", unit: "元"}, request);
  const call = async (input: Record<string, unknown>, currentRequest = request) => receiptJson(await runTool(createAnalysisTaskTool(), validated(input), currentRequest));
  return {session, frames, analysis, backend, request, catalogRef, call};
}

describe("analysis_task真实状态与工具边界", () => {
  it("旧交接未固定current来源时拒绝按后来焦点继承", async () => {
    const f = await fixture(), proposal = {capability: "metric_query", base: "current", mode: "execute", set: {metrics: ["错误目录选择"]}};
    const attempt = turnAttempt({ownerId: f.request.actor.id, sessionId: f.request.sessionId, turnId: f.request.operationId,
      requestId: f.request.requestId, promptFingerprint: f.request.promptFingerprint, proposal,
      analysisHandoff: analysisAttemptSource(f.request.originalMessage, proposal)});
    await f.frames.saveTurnAttempt(attempt);
    expect(await f.call({action: "create", fromAttemptRef: attempt.attemptRef, goal: "不能漂移", requirements: [{text: "原范围"}]}))
      .toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_HANDOFF_UNAVAILABLE"});
    expect(await f.analysis.list()).toEqual([]);
  });
  it("公开接口为单object，动作必要字段仍由内部机器契约拒绝且不落任务", async () => {
    expect(createAnalysisTaskTool().parameters.type).toBe("object");
    const f = await fixture();
    expect(await f.call({action: "create", requirements: [{text: "总量"}]})).toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_ARGUMENT_INVALID"});
    expect(await f.analysis.list()).toEqual([]);
  });

  it("按当前计划stepId执行，先准备；旧revision和未知step不触发准备", async () => {
    const f = await fixture();
    await f.call({...createInput, steps: [{id: "total-step", purpose: "取得总量", requirementIds: ["total"],
      selections: [{catalogRef: f.catalogRef, metricCode: "M"}]}]});
    expect(await f.call({action: "execute", expectedRevision: 2, stepId: "total-step"})).toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_PLAN_STALE"});
    expect(await f.call({action: "execute", expectedRevision: 1, stepId: "unknown"})).toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_STEP_UNAVAILABLE"});
    expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled();
    const ready = await f.call({action: "execute", expectedRevision: 1, stepId: "total-step"});
    expect(ready.status).toBe("READY");
    expect(f.backend.prepareAnalysisQuery).toHaveBeenCalledTimes(1);
    expect(f.backend.prepareAnalysisQuery.mock.calls[0]![0]).toMatchObject({query: {metric_codes: ["M"], org_codes: ["A"], time: {end: "2026-07-31"}}});
    expect(f.backend.executeAnalysisQuery).not.toHaveBeenCalled();
  });

  it("精准来源错误交接分析时原机构数量/日期保留，错误指标不变固定指标", async () => {
    const f = await fixture();
    const rejected = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true, analysisPlanning: true}),
      {capability: "metric_query", base: null, mode: "execute", set: {metrics: {fromQuestion: true, mentionIndexes: [99]},
        organizations: {text: "机构甲", expectedCount: {value: 1, sourceText: "机构甲"}}, time: "2026-07-31", selection: "exact"}}, f.request));
    expect(rejected).toMatchObject({status: "ARGUMENT_ERROR", next_operation: {tool: "analysis_task", action: "create"}});
    const created = await f.call({action: "create", fromAttemptRef: rejected.attemptRef, goal: "分析原范围", requirements: [{id: "total", text: "总量"}]});
    expect(created).toMatchObject({status: "ok", task: {anchor: {fields: {organizations: {resolvedValue: {codes: ["A"]},
      metadata: {turnIntentExpectedCount: 1}}, time: {resolvedValue: {end: "2026-07-31"}}, selection: {resolvedValue: "exact"}}}}});
    expect((created.task as any).anchor.fields.metrics?.resolvedValue?.codes ?? []).toEqual([]);
    expect(await f.call({action: "create", fromAttemptRef: rejected.attemptRef, base: null, goal: "改写", requirements: [{text: "总量"}]}))
      .toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_HANDOFF_SCOPE_CONFLICT"});
    expect(f.backend.basicQueries).not.toHaveBeenCalled(); expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled();
  });

  it("交接的已知数量不足保留未决状态，不丢数量后执行", async () => {
    const f = await fixture("请分析两家机构甲2026-07-31的经营情况");
    const rejected = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true, analysisPlanning: true}),
      {capability: "metric_query", base: null, mode: "execute", set: {metrics: {fromQuestion: true, mentionIndexes: [99]},
        organizations: {text: "机构甲", expectedCount: {value: 2, sourceText: "两家"}}, time: "2026-07-31"}}, f.request));
    const created = await f.call({action: "create", fromAttemptRef: rejected.attemptRef, goal: "分析原范围", requirements: [{text: "总量"}]});
    expect(created).toMatchObject({status: "ok", task: {anchor: {fields: {organizations: {metadata: {turnIntentExpectedCount: 2}}}}}});
    expect((created.task as any).anchor.fields.organizations.resolutionStatus).not.toBe("resolved");
    expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled();
  });

  it.each([
    {...createInput, actor: "forged-user"}, {...createInput, organizations: {codes: ["A"]}},
    {action: "create", goal: "分析", base: null, requirements: []},
    {action: "revise", analysisId: "a", expectedRevision: 0, reason: "修改"},
    {action: "complete", analysisId: "a", expectedRevision: 1, coverage: [{requirementId: "r", evidenceRefs: []}]},
  ])("Schema拒绝客户端注入身份、编码和不完整引用 %j", input => {
    expect(() => validated(input)).toThrow();
  });

  it("创建、read和重新装载store恢复同一固定目标，不预先查询", async () => {
    const f = await fixture(), created = await f.call(createInput), task = created.task as {analysisId: string};
    expect(created.status).toBe("ok");
    const restored = await f.call({action: "read"});
    expect(restored.task).toEqual(created.task);
    expect(await new NativeAnalysisStore(f.session).read(task.analysisId, f.request)).toEqual(created.task);
    expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled(); expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });

  it("当前原文明示指标记为固定条件，模型不用重抄指标编码", async () => {
    const f = await fixture("请分析机构甲2026-07-31的总余额和增长情况"), result = await f.call(createInput);
    expect(result.task).toMatchObject({anchor: {fields: {metrics: {resolvedValue: {codes: ["M"], names: ["总余额"]}}}}});
  });

  it("methods发行宿主可信引用与固定表达式，不允许自由改写方法", async () => {
    const f = await fixture(), result = await f.call({action: "methods"});
    const methods = result.methods as Array<{id: string; methodRef: string; expression: string}>;
    expect(methods.map(item => item.id)).toEqual(["difference", "growth_rate"]);
    for (const method of methods) expect((await f.analysis.reference(method.methodRef, "method", f.request)).payload.expression).toBe(method.expression);
  });

  it("准备先持久化preparing且绑定当前target；执行仅使用实际prepare回执", async () => {
    const f = await fixture(), created = await f.call({...createInput, steps: [{id: "q1", purpose: "取得总量", requirementIds: ["total"], catalogRefs: [f.catalogRef]}]});
    const task = created.task as {steps: Array<{stepRef: string}>};
    const resolved = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true}), {stepRef: task.steps[0]!.stepRef}, f.request));
    expect(resolved.status).toBe("READY");
    const prepared = (await f.analysis.read(undefined, f.request))!.steps[0]!;
    expect(prepared.status).toBe("prepared"); expect(prepared.prepareKey).toBeTruthy();
    const frame = (await f.frames.get(String(resolved.frameId)))!;
    expect(frame.historyRole).toBe("supporting"); expect(frame.analysisRef?.preparedQueryRef).toBe("prepared:q1:1");
    const executed = receiptJson(await runTool(createExecuteBusinessFrameTool(), {frameId: frame.frameId}, f.request));
    expect(executed.status).toBe("succeeded"); expect(f.backend.executeAnalysisQuery).toHaveBeenCalledWith("prepared:q1:1", expect.any(String), expect.anything());
    expect(f.backend.basicQueries).not.toHaveBeenCalled();
    expect((await f.frames.state()).focusFrameId).toBeUndefined();
  });

  it("多目标工具输入保持不同机构日期绑定，执行乙目标不交叉组合", async () => {
    const f = await fixture("分别分析机构甲2026-07-31与机构乙2026-08-31的存款"), created = await f.call({...createInput,
      targets: [{targetId: "a", organizations: "机构甲", time: "2026-07-31", requirementIds: ["total"]},
        {targetId: "b", organizations: "机构乙", time: "2026-08-31", requirementIds: ["total"]}],
      steps: [{id: "only-b", targetId: "b", purpose: "取乙目标总量", requirementIds: ["total"], catalogRefs: [f.catalogRef]}]});
    const stepRef = (created.task as {steps: Array<{stepRef: string}>}).steps[0]!.stepRef;
    const result = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true}), {stepRef}, f.request));
    expect(result.status).toBe("READY");
    expect(f.backend.prepareAnalysisQuery.mock.calls[0]![0]).toMatchObject({target_id: "b", query: {org_codes: ["B"], time: {start: "2026-08-31", end: "2026-08-31"}}});
  });

  it("补充机构修订后沿用要求与步骤并失效旧stepRef", async () => {
    const f = await fixture(), first = await f.call({...createInput, steps: [{id: "q1", purpose: "总量", requirementIds: ["total"], catalogRefs: [f.catalogRef]}]});
    const task = first.task as {analysisId: string; steps: Array<{stepRef: string}>};
    const request = {...f.request, operationId: "followup-op", requestId: "followup-req", originalMessage: "那机构乙呢？其他沿用"};
    const revised = await f.call({action: "revise", analysisId: task.analysisId, expectedRevision: 1, reason: "用户替换机构", organizations: "机构乙"}, request);
    expect(revised.task).toMatchObject({constraintVersion: 2, requirements: [{id: "total", text: "存款总量"}], anchor: {fields: {organizations: {resolvedValue: {codes: ["B"]}}, time: {resolvedValue: {end: "2026-07-31"}}}}});
    expect((revised.task as {steps: Array<{stepRef: string}>}).steps[0]!.stepRef).not.toBe(task.steps[0]!.stepRef);
    const stale = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true}), {stepRef: task.steps[0]!.stepRef}, request));
    expect(stale).toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_STEP_STALE"});
  });

  it("空证据不能宣称全部完成，partial明确记录缺口", async () => {
    const f = await fixture(), created = await f.call(createInput), analysisId = (created.task as {analysisId: string}).analysisId;
    expect(await f.call({action: "complete", analysisId, expectedRevision: 1, coverage: []})).toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_REQUIREMENTS_INCOMPLETE"});
    const partial = await f.call({action: "complete", analysisId, expectedRevision: 1, coverage: [], partial: true});
    expect(partial.task).toMatchObject({status: "partial", gaps: ["存款总量"]});
  });

  it("回滚停止接纳新分析时，既有任务仍能read和partial收敛", async () => {
    const f = await fixture(), created = await f.call(createInput), analysisId = (created.task as {analysisId: string}).analysisId;
    const disabled = createAnalysisTaskTool({acceptNew: false});
    const blocked = receiptJson(await runTool(disabled, createInput, {...f.request, requestId: "new-request", operationId: "new-operation"}));
    expect(blocked.status).toBe("ARGUMENT_ERROR"); expect(blocked.error_code).toMatch(/DISABLED|PAUSED/);
    const restored = receiptJson(await runTool(disabled, {action: "read", analysisId}, f.request));
    expect(restored).toMatchObject({status: "ok", task: {analysisId}});
    const partial = receiptJson(await runTool(disabled, {action: "complete", analysisId, expectedRevision: 1, partial: true, coverage: []}, f.request));
    expect(partial).toMatchObject({status: "ok", task: {analysisId, status: "partial", gaps: ["存款总量"]}});
    expect(f.backend.basicQueries).not.toHaveBeenCalled();
  });
});

describe("分析主题、正式歧义与跨轮指标确认", () => {
  const mention = (question: string, text: string, resolution: Record<string, unknown>) => ({text,
    start: question.indexOf(text), end: question.indexOf(text) + text.length, resolution});

  it("泛主题missing_value_basis允许目录选择口径，仍保存原始主题证据", async () => {
    const original = "分析机构甲2026-07-31的各项存款经营情况", f = await fixture(original);
    f.backend.matchMetricQuestion.mockResolvedValueOnce({mentions: [mention(original, "各项存款", {status: "needs_confirmation",
      candidates: [{code: "M", value: "总余额当日数", metadata: {value_basis: "当日数"}}, {code: "M_GROWTH", value: "总余额较年初", metadata: {value_basis: "较年初"}}],
      metadata: {issue: "missing_value_basis"}})]} as never);
    const created = await f.call({...createInput, steps: [{id: "q1", purpose: "选择正式当日口径", requirementIds: ["total"], catalogRefs: [f.catalogRef]}]});
    expect(created.status).toBe("ok");
    expect(created.task).toMatchObject({anchor: {fields: {metrics: {metadata: {topicMentions: [{text: "各项存款", resolution: {metadata: {issue: "missing_value_basis"}}}]}}}}});
    const stepRef = (created.task as {steps: Array<{stepRef: string}>}).steps[0]!.stepRef;
    const resolved = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true}), {stepRef}, f.request));
    expect(resolved.status).toBe("READY");
    expect(f.backend.prepareAnalysisQuery).toHaveBeenCalledTimes(1);
    expect(f.backend.prepareAnalysisQuery.mock.calls[0]![0]).toMatchObject({query: {metric_codes: ["M"]}});
  });

  it("正式名称ambiguous必须保存候选，catalogRef不能覆盖歧义并偷换目标", async () => {
    const original = "分析机构甲2026-07-31的净余额", f = await fixture(original);
    f.backend.matchMetricQuestion.mockResolvedValueOnce({mentions: [mention(original, "净余额", {status: "ambiguous",
      candidates: [{code: "NET_A", value: "口径甲净余额"}, {code: "NET_B", value: "口径乙净余额"}], metadata: {issue: "ambiguous"}})]} as never);
    const created = await f.call({...createInput, steps: [{id: "q1", purpose: "目录辅助总量", requirementIds: ["total"], catalogRefs: [f.catalogRef]}]});
    const stepRef = (created.task as {steps: Array<{stepRef: string}>}).steps[0]!.stepRef;
    const resolved = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true}), {stepRef}, f.request));
    expect(resolved.status).toBe("NEEDS_CLARIFICATION");
    const frame = (await f.frames.get(String(resolved.frameId)))!;
    expect(frame.fields.metrics).toMatchObject({resolutionStatus: "ambiguous", candidates: [{code: "NET_A"}, {code: "NET_B"}],
      metadata: {questionText: original, extractedRawValues: ["净余额"]}});
    expect(f.backend.prepareAnalysisQuery).not.toHaveBeenCalled(); expect(f.backend.executeAnalysisQuery).not.toHaveBeenCalled();
  });

  it("跨轮第一个确认依托保存候选并保留原问题和mention来源", async () => {
    const original = "分析机构甲2026-07-31的净余额", f = await fixture(original);
    f.backend.matchMetricQuestion.mockResolvedValueOnce({mentions: [mention(original, "净余额", {status: "ambiguous",
      candidates: [{code: "NET_A", value: "口径甲净余额"}, {code: "NET_B", value: "口径乙净余额"}], metadata: {issue: "ambiguous"}})]} as never);
    const first = await f.call(createInput), task = first.task as {analysisId: string};
    const reply = {...f.request, requestId: "metric-confirm-req", operationId: "metric-confirm-turn", originalMessage: "第一个"};
    delete reply.metricMentions;
    const confirmed = await f.call({action: "revise", analysisId: task.analysisId, expectedRevision: 1, reason: "用户选择首个候选", metrics: {confirm: true}, metricMode: "replace"}, reply);
    expect(confirmed.status).toBe("ok");
    expect(confirmed.task).toMatchObject({constraintVersion: 2, anchor: {fields: {metrics: {resolutionStatus: "resolved",
      resolvedValue: {codes: ["NET_A"], names: ["口径甲净余额"]}, metadata: {questionText: original,
        mentionResolutions: [{text: "净余额", start: original.indexOf("净余额"), status: "resolved", value: {codes: ["NET_A"]}}]}}}}});
    expect(f.backend.matchMetricQuestion.mock.calls.every(([question]) => question === original || question === "第一个")).toBe(true);
  });

  it("继承base时合并本轮新增明确指标，不能因旧metrics已有值而漏新项", async () => {
    const f = await fixture("查询机构甲2026-07-31总余额");
    const base = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true}), {capability: "metric_query", base: null, mode: "resolve_more",
      set: {metrics: {fromQuestion: true}, organizations: "机构甲", time: "2026-07-31"}}, f.request));
    expect(base.status).toBe("READY");
    const original = "基于刚才的查询继续分析，还必须查询个人余额", current = {...f.request, requestId: "analysis-add-explicit", operationId: "analysis-add-explicit", originalMessage: original};
    delete current.metricMentions;
    f.backend.matchMetricQuestion.mockResolvedValueOnce({mentions: [mention(original, "个人余额", {status: "resolved", value: {codes: ["PSON"], names: ["个人余额"]}})]} as never);
    const created = await f.call({action: "create", goal: "继续分析总量与个人结构", base: {frameId: String(base.frameId)}, requirements: [{id: "total", text: "总量与个人结构"}]}, current);
    expect(created.status).toBe("ok");
    expect(created.task).toMatchObject({anchor: {baseFrameId: base.frameId, fields: {metrics: {resolutionStatus: "resolved",
      resolvedValue: {codes: ["M", "PSON"], names: ["总余额", "个人余额"]}}}}});
  });

  async function multiMetricFixture() {
    const original = "分别分析机构甲2026-07-31总余额与机构乙2026-08-31个人余额", f = await fixture(original);
    f.backend.matchMetricQuestion.mockResolvedValueOnce({mentions: [mention(original, "总余额", {status: "resolved", value: {codes: ["M"], names: ["总余额"]}}),
      mention(original, "个人余额", {status: "resolved", value: {codes: ["PSON"], names: ["个人余额"]}})]} as never);
    const personalRef = await f.analysis.issueReference("catalog", {metric_code: "PSON", metric_name: "个人余额", unit: "元"}, f.request);
    const targets = [{targetId: "a", organizations: "机构甲", time: "2026-07-31", metrics: {fromQuestion: true, mentionIndexes: [1]}, requirementIds: ["total"]},
      {targetId: "b", organizations: "机构乙", time: "2026-08-31", metrics: {fromQuestion: true, mentionIndexes: [2]}, requirementIds: ["total"]}];
    return {...f, targets, personalRef};
  }

  it("双target逐项绑定不同机构日期指标，prepare只执行乙目标个人余额", async () => {
    const f = await multiMetricFixture(), result = await f.call({...createInput, targets: f.targets,
      steps: [{id: "q-personal", targetId: "b", purpose: "查询乙目标个人余额", requirementIds: ["total"], catalogRefs: [f.personalRef]}]});
    expect(result.status).toBe("ok");
    expect(result.task).toMatchObject({anchor: {targets: [
      {targetId: "a", fields: {organizations: {resolvedValue: {codes: ["A"]}}, time: {resolvedValue: {end: "2026-07-31"}}, metrics: {resolvedValue: {codes: ["M"]}}}},
      {targetId: "b", fields: {organizations: {resolvedValue: {codes: ["B"]}}, time: {resolvedValue: {end: "2026-08-31"}}, metrics: {resolvedValue: {codes: ["PSON"]}}}},
    ]}});
    const stepRef = (result.task as {steps: Array<{stepRef: string}>}).steps[0]!.stepRef;
    const resolved = receiptJson(await runTool(createResolveBusinessTurnTool({turnContractV2: true}), {stepRef}, f.request));
    expect(resolved.status).toBe("READY");
    expect(f.backend.prepareAnalysisQuery.mock.calls[0]![0]).toMatchObject({target_id: "b", query: {metric_codes: ["PSON"], org_codes: ["B"], time: {start: "2026-08-31", end: "2026-08-31"}}});
    expect(f.backend.registerAnalysisConstraints.mock.calls[0]![0]).toMatchObject({targets: [
      {target_id: "a", fixed_metric_codes: ["M"]}, {target_id: "b", fixed_metric_codes: ["PSON"]},
    ]});
  });

  it("多target多个明确指标未逐target指定时拒绝，不能生成机构日期指标乘积", async () => {
    const f = await multiMetricFixture(), targets = f.targets.map(({metrics: _metrics, ...target}) => target);
    const result = await f.call({...createInput, targets});
    expect(result).toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_TARGET_METRICS_REQUIRED"});
    expect(await f.analysis.list(f.request)).toEqual([]);
    expect(f.backend.registerAnalysisConstraints).not.toHaveBeenCalled();
  });

  it("逐target显式绑定遗漏一个原文指标拒绝，不接受只查总余额的半个目标", async () => {
    const f = await multiMetricFixture(), targets = f.targets.map(target => ({...target, metrics: {fromQuestion: true, mentionIndexes: [1]}}));
    const result = await f.call({...createInput, targets});
    expect(result).toMatchObject({status: "ARGUMENT_ERROR", error_code: "ANALYSIS_FIXED_TARGETS_INCOMPLETE"});
    expect(await f.analysis.list(f.request)).toEqual([]);
    expect(f.backend.registerAnalysisConstraints).not.toHaveBeenCalled();
  });
});
