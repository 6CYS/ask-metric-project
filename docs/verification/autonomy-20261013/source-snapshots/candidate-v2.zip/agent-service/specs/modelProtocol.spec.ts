import {expect, it, vi} from "vitest";
import {createAssistantMessageEventStream, Type, type AssistantMessage, type Model, type ProviderStreams} from "@earendil-works/pi-ai";
import * as openAICompletions from "@earendil-works/pi-ai/api/openai-completions";
import {wrapStreamsWithAuthorization} from "../src/models.js";
import {createModelStreamDiagnostics, type ModelStreamDiagnostic} from "../src/modelStreamDiagnostics.js";

it("网关泄漏工具协议时返回原生错误，不展示伪调用也不执行工具", async () => {
  const model = {id: "test", api: "openai-completions", provider: "test"} as Model<"openai-completions">;
  const message: AssistantMessage = {role: "assistant", content: [{type: "text", text: '我继续处理。\n<｜DSML｜tool_calls.\n<｜DSML｜invoking name="business_context_read">'}],
    api: model.api, provider: model.provider, model: model.id, stopReason: "stop", timestamp: 1,
    usage: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, cost: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0}}};
  const response = () => {const stream = createAssistantMessageEventStream();
    queueMicrotask(() => {stream.push({type: "done", reason: "stop", message}); stream.end(message);}); return stream;};
  const inner: ProviderStreams = {stream: response, streamSimple: response};
  const stream = wrapStreamsWithAuthorization(inner, () => true).streamSimple(model, {messages: []});
  const events = []; for await (const event of stream) events.push(event);
  expect(events.at(-1)).toMatchObject({type: "error", reason: "error"});
  expect(await stream.result()).toMatchObject({content: [], stopReason: "error", errorMessage: expect.stringContaining("MODEL_TOOL_PROTOCOL_ERROR")});
});


it("模型失败在历史和刷新投影中保持失败标识，不泄漏网关内部错误", async () => {
  const {projectEntries} = await import("../src/sessionProjection.js");
  const entries = [
    {id: "u", type: "message", message: {role: "user", content: "继续", timestamp: 1, businessProtocol: "frame_v1"}},
    {id: "a", type: "message", message: {role: "assistant", content: [{type: "text", text: "让我重新发起一次完整查询"}], stopReason: "error", errorMessage: "private gateway response", timestamp: 2}},
  ];
  const projected = projectEntries(entries as unknown as import("@earendil-works/pi-agent-core").Entry[]);
  expect(projected.at(-1)).toMatchObject({role: "assistant", business_protocol: "frame_v1", error: expect.stringContaining("未完成")});
  expect(projected.at(-1)).toMatchObject({text: expect.stringContaining("未完成")});
  expect(JSON.stringify(projected)).not.toContain("让我重新发起一次完整查询");
  expect(JSON.stringify(projected)).not.toContain("private gateway response");
});

it.each([
  ["MODEL_STREAM_IDLE_EXCEEDED", "模型输出长时间没有进展，本轮未完成。已确认的查询条件仍保留，无需重复输入。"],
  ["MODEL_FIRST_RESPONSE_TIMEOUT", "模型服务响应超时，请稍后重试。已确认的查询条件仍保留，无需重复输入。"],
  ["MODEL_DEADLINE_EXCEEDED", "模型服务响应超时，请稍后重试。已确认的查询条件仍保留，无需重复输入。"],
])("模型超时码 %s 在历史投影中显示对应说明", async (code, notice) => {
  const {projectEntries} = await import("../src/sessionProjection.js");
  const entries = [
    {id: "u", type: "message", message: {role: "user", content: "继续", timestamp: 1, businessProtocol: "frame_v1"}},
    {id: "a", type: "message", message: {role: "assistant", content: [{type: "text", text: "未完成的临时回答"}],
      stopReason: "error", errorMessage: `${code}: private gateway response`, timestamp: 2}},
  ];
  const projected = projectEntries(entries as unknown as import("@earendil-works/pi-agent-core").Entry[]);
  expect(projected.at(-1)).toMatchObject({role: "assistant", business_protocol: "frame_v1", text: notice, error: notice});
  expect(JSON.stringify(projected)).not.toContain("private gateway response");
  expect(JSON.stringify(projected)).not.toContain("未完成的临时回答");
});

it.each([
  {name: "完整终止", finish: true, done: true, stop: "toolUse", incomplete: 0},
  {name: "缺少 finish_reason", finish: false, done: true, stop: "error", incomplete: 0},
  {name: "终止原因已到但连接悬挂", finish: true, done: false, stop: "error", incomplete: 1},
  {name: "仅完整工具JSON和用量但无终止", finish: false, done: false, stop: "error", incomplete: 1},
])("实际 SDK 工具流：$name，诊断终止而不补造成功", async variant => {
  const model: Model<"openai-completions"> = {id: "synthetic", name: "synthetic", api: "openai-completions",
    provider: "synthetic", baseUrl: "https://synthetic.invalid/v1", reasoning: false, input: ["text"],
    cost: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0}, contextWindow: 128_000, maxTokens: 8192};
  const summaries: ModelStreamDiagnostic[] = [];
  let writer!: ReadableStreamDefaultController<Uint8Array>;
  const body = new ReadableStream<Uint8Array>({start(controller) {writer = controller;}});
  const encoder = new TextEncoder();
  const fetch = vi.fn(async () => {
    queueMicrotask(() => {
      const data = (value: unknown) => encoder.encode(`data: ${JSON.stringify(value)}\n\n`);
      writer.enqueue(data({id: "private-response-id", choices: [{index: 0, finish_reason: null,
        delta: {tool_calls: [{index: 0, id: "private-call-id", type: "function", function: {name: "synthetic_tool", arguments: '{"private_argument":"secret-value"}'}}]}}]}));
      writer.enqueue(data({id: "private-response-id", choices: variant.finish ? [{index: 0, delta: {}, finish_reason: "tool_calls"}] : [],
        usage: {prompt_tokens: 100, completion_tokens: 8, total_tokens: 108}}));
      if (variant.done) {writer.enqueue(encoder.encode("data: [DONE]\n\n")); writer.close();}
    });
    return new Response(body, {headers: {"content-type": "text/event-stream"}});
  });
  const streams = wrapStreamsWithAuthorization(openAICompletions, () => true, 100, 1000, summary => summaries.push(summary));
  const output = streams.streamSimple(model, {messages: [{role: "user", content: "private-question", timestamp: 0}],
    tools: [{name: "synthetic_tool", description: "合成工具", parameters: Type.Object({private_argument: Type.String()})}]},
    {apiKey: "private-key", sessionId: "private-session-id", fetch});
  try {
    const events = []; for await (const event of output) events.push(event);
    const result = await output.result();
    expect(result.stopReason).toBe(variant.stop);
    expect(fetch).toHaveBeenCalledTimes(1);
    expect(result.usage.totalTokens).toBe(108);
    expect(summaries).toHaveLength(1);
    expect(summaries[0]).toMatchObject({raw_stop_reason: variant.finish ? "tool_calls" : null,
      incomplete_tool_count: variant.incomplete, toolcall_start_count: 1, toolcall_end_count: variant.incomplete ? 0 : 1,
      sse: {observed: true, finish_reason_count: variant.finish ? 1 : 0, done_count: variant.done ? 1 : 0, parse_error_count: 0}});
    expect(result.diagnostics?.at(-1)).toMatchObject({type: "model_stream_termination", details: summaries[0]});
    const diagnosticText = JSON.stringify(summaries);
    for (const secret of ["private-key", "secret-value", "private-question", "private-response-id", "private-session-id", "private_argument", "synthetic.invalid"]) {
      expect(diagnosticText).not.toContain(secret);
    }
    // 即便参数已完整、用量已到，只有最终成功工具响应才有资格进入后续执行阶段。
    const executableResponses = events.filter(event => event.type === "done" && event.message.stopReason === "toolUse");
    expect(executableResponses).toHaveLength(variant.stop === "toolUse" ? 1 : 0);
    if (!variant.done) expect(result.errorMessage).toContain("MODEL_STREAM_IDLE_EXCEEDED");
    else if (!variant.finish) expect(result.errorMessage).toContain("finish_reason");
  } finally {try {writer.close();} catch { /* 已关闭的合成流无需重复关闭 */ }}
});

it("SSE诊断按请求隔离、原样传递字节，只记录解析计数和白名单终止原因", async () => {
  const one = createModelStreamDiagnostics("private-session-one"), two = createModelStreamDiagnostics("private-session-two");
  const encoder = new TextEncoder();
  const raw = 'data: {"choices":[{"delta":{"content":"敏感正文"},"finish_reason":"private-stop-value"}]}\r\n\r\n'
    + 'data: invalid private payload\n\n' + 'data: [DONE]\n\n';
  const bytes = encoder.encode(raw);
  const source = new ReadableStream<Uint8Array>({start(controller) {
    for (let index = 0; index < bytes.length; index += 3) controller.enqueue(bytes.slice(index, index + 3));
    controller.close();
  }});
  const original = new Response(source, {headers: {"content-type": "text/event-stream"}});
  const response = await one.fetch(async () => original)("https://private.invalid", {headers: {Authorization: "private-token"}});
  expect(await response.text()).toBe(raw);
  const message = {content: [], role: "assistant", responseId: "private-id"} as unknown as AssistantMessage;
  const first = one.complete(message), second = two.complete({...message, diagnostics: []});
  expect(first.sse).toMatchObject({observed: true, event_count: 3, finish_reason_count: 1, finish_reasons: {other: 1},
    done_count: 1, eof_count: 1, parse_error_count: 1, over_limit_count: 0});
  expect(second.sse).toMatchObject({observed: false, event_count: 0, finish_reason_count: 0});
  expect(first.session_ref).not.toBe(second.session_ref);
  for (const secret of ["敏感正文", "private", "private-session-one", "private-session-two"]) expect(JSON.stringify(first)).not.toContain(secret);
});

it("过大SSE事件只增加上限计数且不影响原字节和后续DONE", async () => {
  const diagnostic = createModelStreamDiagnostics();
  const raw = `data: ${"x".repeat(70_000)}\n\n` + "data: [DONE]\n\n";
  const response = await diagnostic.fetch(async () => new Response(raw, {headers: {"content-type": "text/event-stream"}}))("https://synthetic.invalid");
  expect(await response.text()).toBe(raw);
  const summary = diagnostic.complete({content: []} as unknown as AssistantMessage);
  expect(summary.sse).toMatchObject({over_limit_count: 1, done_count: 1, parse_error_count: 0});
});

it.each(["\n", "\r\n", "\r"])("SSE行分隔%j跨字节块时正确记录DONE", async newline => {
  const diagnostic = createModelStreamDiagnostics();
  const raw = `data: [DONE]${newline}${newline}`;
  const source = new ReadableStream<Uint8Array>({start(controller) {
    for (const byte of new TextEncoder().encode(raw)) controller.enqueue(new Uint8Array([byte]));
    controller.close();
  }});
  const response = await diagnostic.fetch(async () => new Response(source, {headers: {"content-type": "text/event-stream"}}))("https://synthetic.invalid");
  expect(await response.text()).toBe(raw);
  expect(diagnostic.complete({content: []} as unknown as AssistantMessage).sse).toMatchObject({event_count: 1, done_count: 1, eof_count: 1});
});
