import { Type } from "@earendil-works/pi-ai";
import type { AgentHarnessTool } from "@earendil-works/pi-agent-core";
import type { AskMetricRequestContext } from "../requestContext.js";
import { BackendApiError } from "../backendClient.js";
import { createMetricCatalogSearchTool } from "./metricCatalogSearch.js";
import { createOrgCatalogSearchTool } from "./orgCatalogSearch.js";
import { createMetricCatalogOverviewTool } from "./metricCatalogOverview.js";
import { catalogSearchParameters } from "./shared.js";
import {exploreAnalysisCatalog} from "../analysisCatalog.js";

const parameters = Type.Union([
  Type.Object({action: Type.Literal("search"), queries: Type.Array(Type.Object({
    entity: Type.Union([Type.Literal("metric"), Type.Literal("organization")]),
    ...catalogSearchParameters.properties,
  }, {additionalProperties: false}), {minItems: 1, maxItems: 4,
    description: "独立检索可合批；保留用户完整名称和限定词，各项单独返回命中与截断信息"})}, {additionalProperties: false}),
  Type.Object({action: Type.Literal("overview")}, {additionalProperties: false,
    description: "启用指标总数、单位分组和名称示例；不支持机构总览"}),
]);

/** 只合并模型入口，匹配规则与鉴权继续复用原有实现；最多四项只读检索并发。 */
export function createCatalogTool(options: {analysisPlanning?: boolean | undefined; analysisCatalogFile?: string | undefined} = {}): AgentHarnessTool<AskMetricRequestContext> {
  const metric = createMetricCatalogSearchTool();
  const organization = createOrgCatalogSearchTool();
  const overview = createMetricCatalogOverviewTool();
  return {
    name: "catalog", label: "目录查询", parameters: options.analysisPlanning ? Type.Union([parameters,
      Type.Object({action: Type.Literal("explore"), keyword: Type.String({minLength: 1}), basis: Type.Optional(Type.String()),
        page: Type.Optional(Type.Integer({minimum: 1})),
        limit: Type.Optional(Type.Integer({minimum: 1, maximum: 30}))}, {additionalProperties: false})]) : parameters,
    description: options.analysisPlanning ? "搜索正式指标/机构或overview目录。explore按业务主题和basis统计口径浏览已导入指标树，返回实时目录核验后的catalogRef用于分析步骤；分组不证明可加总，目录不证明有值。明确精准查询直接resolve_business_turn，无需探索。" : "搜索正式指标/机构编码，或介绍指标目录。search 可同时检索指标与机构；各项返回 total、items、has_more，指标另有近似推荐。exact 只证明命中检索词，须核对原文；近似推荐不能锁定编码，空结果不证明对象不存在。不查询数值或证明有数据，实际记录范围用 data_availability。业务查询用 resolve_business_turn 解析原文名称，无需先查目录。",
    execute: async (id, params, update, request, invocation, context) => {
      const args = params as {action: "search" | "overview" | "explore"; keyword?: string; basis?: string; limit?: number; page?: number;
        queries?: Array<{entity: "metric" | "organization"; keyword: string; limit?: number}>};
      if (args.action === "explore") {
        if (!request.analysis) throw new Error("ANALYSIS_CONTEXT_NOT_BOUND");
        const profile = await exploreAnalysisCatalog({keyword: args.keyword!, ...(args.basis ? {basis: args.basis} : {}),
          ...(args.limit !== undefined ? {limit: args.limit} : {}), ...(args.page !== undefined ? {page: args.page} : {})}, options.analysisCatalogFile);
        const items = [];
        // 限定并发，正式目录的身份与单位覆盖资源表的展示值。
        for (let offset = 0; offset < profile.items.length; offset += 4) {
          items.push(...await Promise.all(profile.items.slice(offset, offset + 4).map(async item => {
            if (item.definition_conflict) return {...item, status: "definition_conflict", reason: "资源表同码存在相反口径，未签发分析引用；请核对正式定义"};
            const found = await request.backend.searchMetrics(item.code, 5, {signal: context.abortSignal});
            const formal = found.items.find(hit => hit.metric_code === item.code);
            if (!formal) return {...item, status: "unavailable", reason: "正式启用目录未核验通过"};
            const catalogRef = await request.analysis!.issueReference("catalog", {...formal, dimension: item.dimension,
              base_code: item.base_code, source: item.source, source_sha256: profile.source.sha256}, request);
            return {...item, name: formal.metric_name, unit: formal.unit, catalogRef, status: "verified",
              identity: {catalogRef, metricCode: formal.metric_code, metricName: formal.metric_name,
                unit: formal.unit ?? null, basis: item.dimension}};
          })));
        }
        return {content: [{type: "text", text: JSON.stringify({...profile, items})}], details: {kind: "catalog", action: "explore", status: "succeeded"}};
      }
      const query = args as {action: "search" | "overview"; queries: Array<{entity: "metric" | "organization"; keyword: string; limit?: number}>};
      if (query.action === "overview") return overview.execute(id, {}, update, request, invocation, context);
      const results = await Promise.all(query.queries.map(async (query) => {
        const tool = query.entity === "metric" ? metric : organization;
        try {
          const result = await tool.execute(id, query, update, request, invocation, context);
          const text = result.content.find(block => block.type === "text");
          if (!text || text.type !== "text") throw new Error("CATALOG_RESULT_INVALID");
          const {usage_hint: _hint, ...payload} = JSON.parse(text.text);
          if (options.analysisPlanning && request.analysis && query.entity === "metric" && Array.isArray(payload.items)) {
            payload.items = await Promise.all(payload.items.map(async (item: {metric_code: string; metric_name: string}) =>
              ({...item, catalogRef: await request.analysis!.issueReference("catalog", item, request)})));
          }
          return {...payload, entity: query.entity, keyword: query.keyword, status: "succeeded"};
        } catch (error) {
          // 取消和鉴权失败必须整体传播；可识别的单项业务失败保留，不能冒充空结果。
          if (context.abortSignal?.aborted || !(error instanceof BackendApiError)
            || error.status === 401 || error.status === 403) throw error;
          return {entity: query.entity, keyword: query.keyword, status: "error", error_code: error.code ?? "BACKEND_ERROR",
            message: "目录检索失败，请重试该项；不能据此认定目录无匹配。"};
        }
      }));
      const status = results.every(item => item.status === "succeeded") ? "succeeded"
        : results.every(item => item.status === "error") ? "error" : "partial";
      return {content: [{type: "text", text: JSON.stringify({status, results,
        usage_hint: options.analysisPlanning && request.analysis ? "用户点名指标仍走原文解析/确认；分析选择使用正式catalogRef。推荐不证明口径等价，has_more不代表完整集合。" : "仅确定性命中可确认编码，须核对完整名称；semantic_suggestions 不可锁定。has_more 时不能认定候选齐全，缺项或失败不能省略后执行部分取数。"})}],
        details: {kind: "catalog", action: "search", status}};
    },
  };
}
