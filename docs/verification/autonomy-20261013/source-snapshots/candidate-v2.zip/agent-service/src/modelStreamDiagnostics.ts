import {createHash, randomUUID} from "node:crypto";
import type {AssistantMessage, AssistantMessageEvent, FetchFunction} from "@earendil-works/pi-ai";

const MAX_EVENT_CHARS = 65_536;
const STOP_REASONS = new Set(["stop", "length", "tool_calls", "function_call", "content_filter", "network_error"]);
const stopReason = (value: unknown): string | null => typeof value === "string" ? STOP_REASONS.has(value) ? value : "other" : null;
const reference = (value: string | undefined): string | null => value
  ? createHash("sha256").update(value).digest("hex").slice(0, 16) : null;

export interface ModelStreamDiagnostic {
  call_ref: string;
  session_ref: string | null;
  response_ref: string | null;
  raw_stop_reason: string | null;
  event_count: number;
  progress_event_count: number;
  toolcall_start_count: number;
  toolcall_end_count: number;
  incomplete_tool_count: number;
  sse: {
    observed: boolean;
    event_count: number;
    finish_reason_count: number;
    finish_reasons: Record<string, number>;
    done_count: number;
    eof_count: number;
    parse_error_count: number;
    over_limit_count: number;
  };
}

/** 每个模型请求独享诊断；只保存计数和白名单终止码，不保存正文、参数或连接信息。 */
export function createModelStreamDiagnostics(sessionId?: string) {
  const value: ModelStreamDiagnostic = {
    call_ref: randomUUID(), session_ref: reference(sessionId), response_ref: null, raw_stop_reason: null,
    event_count: 0, progress_event_count: 0, toolcall_start_count: 0, toolcall_end_count: 0, incomplete_tool_count: 0,
    sse: {observed: false, event_count: 0, finish_reason_count: 0, finish_reasons: {}, done_count: 0,
      eof_count: 0, parse_error_count: 0, over_limit_count: 0},
  };
  const started = new Set<number>(), ended = new Set<number>();
  const clearTransportBuffers = new Set<() => void>();
  let completed = false;
  return {
    event(event: AssistantMessageEvent, progress: boolean) {
      if (completed) return;
      value.event_count += 1;
      if (progress) value.progress_event_count += 1;
      if (event.type === "toolcall_start") {value.toolcall_start_count += 1; started.add(event.contentIndex);}
      if (event.type === "toolcall_end") {value.toolcall_end_count += 1; ended.add(event.contentIndex);}
    },
    fetch(inner: FetchFunction = globalThis.fetch): FetchFunction {
      return async (input, init) => {
        const response = await inner(input, init);
        if (completed || !response.body || !response.headers.get("content-type")?.includes("text/event-stream")) return response;
        value.sse.observed = true;
        // 在同一消费链上观察原字节；不 tee、不提前读流，不改变 SDK 对终止及取消的判断。
        const decoder = new TextDecoder();
        let line = "", data: string[] = [], dataChars = 0, oversized = false, skipLf = false;
        const clearBuffers = () => {line = ""; data = [];};
        clearTransportBuffers.add(clearBuffers);
        const dispatch = () => {
          if (completed) return;
          if (oversized) {value.sse.over_limit_count += 1;}
          else if (data.length) {
            value.sse.event_count += 1;
            const payload = data.join("\n");
            if (payload.trim() === "[DONE]") value.sse.done_count += 1;
            else {
              try {
                const parsed: unknown = JSON.parse(payload);
                const choices = parsed && typeof parsed === "object" && "choices" in parsed ? parsed.choices : undefined;
                if (Array.isArray(choices)) for (const choice of choices) {
                  const reason = stopReason(choice && typeof choice === "object" ? choice.finish_reason : undefined);
                  if (reason !== null) {
                    value.sse.finish_reason_count += 1;
                    value.sse.finish_reasons[reason] = (value.sse.finish_reasons[reason] ?? 0) + 1;
                  }
                }
              } catch {value.sse.parse_error_count += 1;}
            }
          }
          data = []; dataChars = 0; oversized = false;
        };
        const acceptLine = () => {
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line) dispatch();
          else if (!oversized && line.startsWith("data:")) {
            const next = line.slice(line[5] === " " ? 6 : 5);
            dataChars += next.length;
            if (dataChars > MAX_EVENT_CHARS) {oversized = true; data = [];}
            else data.push(next);
          }
          line = "";
        };
        const acceptText = (text: string) => {
          for (const char of text) {
            // SSE允许LF、CRLF或CR；跨字节块的CRLF只能结束一次行。
            if (skipLf && char === "\n") {skipLf = false; continue;}
            skipLf = false;
            if (char === "\n" || char === "\r") {acceptLine(); skipLf = char === "\r";}
            else if (line.length < MAX_EVENT_CHARS) line += char;
            else {oversized = true; line = ""; data = [];}
          }
        };
        const body = response.body.pipeThrough(new TransformStream<Uint8Array, Uint8Array>({
          transform(chunk, controller) {
            if (!completed) acceptText(decoder.decode(chunk, {stream: true}));
            controller.enqueue(chunk);
          },
          flush() {
            if (!completed) {acceptText(decoder.decode()); value.sse.eof_count += 1;}
            clearBuffers(); clearTransportBuffers.delete(clearBuffers);
          },
        }));
        return new Response(body, {status: response.status, statusText: response.statusText, headers: response.headers});
      };
    },
    complete(message: AssistantMessage): ModelStreamDiagnostic {
      if (!completed) {
        completed = true;
        for (const clear of clearTransportBuffers) clear();
        clearTransportBuffers.clear();
        value.response_ref = reference(message.responseId);
        value.raw_stop_reason = stopReason(message.rawStopReason);
        value.incomplete_tool_count = [...started].filter(index => !ended.has(index)).length;
        (message.diagnostics ??= []).push({type: "model_stream_termination", timestamp: Date.now(), details: structuredClone(value) as unknown as Record<string, unknown>});
      }
      return structuredClone(value);
    },
  };
}
