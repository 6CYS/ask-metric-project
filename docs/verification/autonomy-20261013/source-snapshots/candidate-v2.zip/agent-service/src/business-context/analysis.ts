import {randomUUID, createHash} from "node:crypto";
import {BACKGROUND_CONTEXT, setValue, value, type Session} from "@earendil-works/pi-agent-core";
import type {AskMetricRequestContext} from "../requestContext.js";
import {BackendApiError, type BasicQuerySpec} from "../backendClient.js";
import {businessStateAddress, NativeFrameStore, ContextConflict} from "./store.js";
import {businessKey} from "./service.js";
import {createCapabilities} from "./capabilities.js";
import {validateFrame, missingField, mergeFields} from "./core.js";
import {createFieldResolvers} from "./resolvers.js";
import {BusinessInputError} from "./inputError.js";
import type {BusinessFrame, BusinessSessionState, QueryOperation, ResolvedField, ResolverContext} from "./types.js";

const NS = "askmetric.analysis.v1";
const indexAddress = value<string[]>(NS, "index");
const taskAddress = (id: string) => value<AnalysisTask>(NS, `task/${id}`);
const referenceAddress = (id: string) => value<TrustedReference>(NS, `reference/${id}`);
const commandAddress = (key: string) => value<string>(NS, `command/${key}`);

export type ReferenceKind = "catalog" | "availability" | "method" | "step";
export interface TrustedReference {
  ref: string; kind: ReferenceKind; ownerId: string; sessionId: string; issuedTurnId: string;
  payload: Record<string, unknown>; createdAt: string;
}
export interface AnalysisAnchor {
  baseFrameId?: string;
  targetId?: string;
  /** 仅宿主解析或继承后提交；模型不能直接填入编码和已解析状态。 */
  fields: Record<string, ResolvedField>;
  targets?: Array<{targetId: string; fields: Record<string, ResolvedField>; requirementIds?: string[]}>;
  metricUpdate?: {mode: "add" | "replace"; codes: string[]};
}
export interface AnalysisRequirement {
  id: string; text: string; evidenceKind?: "query" | "calculation"; expectedMetricCodes?: string[];
  status: "pending" | "satisfied"; evidenceRefs: string[];
}
export interface AnalysisMetricSelection {catalogRef: string; metricCode: string; metricName?: string; unit?: string | null; basis?: string | null}
export interface AnalysisMetricIdentity extends AnalysisMetricSelection {metricName: string; unit: string | null; basis: string | null}
export interface AnalysisStepInput {
  id?: string; purpose: string; requirementIds: string[]; catalogRefs?: string[];
  selections?: AnalysisMetricSelection[];
  kind?: "query" | "calculation"; methodRef?: string; bindings?: Record<string, {fact_id: string}>;
  targetId?: string;
  time?: string; selection?: BasicQuerySpec["selection"]; operation?: QueryOperation; dependsOn?: string[];
}
export interface AnalysisStep extends AnalysisStepInput {
  id: string; stepRef: string; stepRevision: number; constraintVersion: number;
  /** 由可信目录引用物化；purpose只是取证理由，不能改写指标身份。 */
  metricIdentities?: AnalysisMetricIdentity[];
  status: "planned" | "preparing" | "prepared" | "clarifying" | "executing" | "succeeded" | "failed" | "invalidated";
  prepareKey?: string; specHash?: string; preparedQueryRef?: string; frameId?: string;
  preparedSpec?: BasicQuerySpec;
  resultRef?: string; evidenceRefs: string[]; issues?: Array<{field: string; reason: string}>; errorCode?: string;
}
export interface AnalysisEvidence {
  ref: string; stepId: string; stepRevision: number; constraintVersion: number; frameId: string;
  kind: "query" | "calculation";
  targetId: string; metricCodes: string[];
  coverage: Array<{metricCode: string; orgCode: string; date: string}>;
  /** 完整步骤与合法局部事实分开；缺值、截断或翻页不能产生虚假覆盖。 */
  usableCoverage?: Array<{metricCode: string; orgCode: string; date: string}>;
  missingMetricCodes?: string[];
  resultRef: string; factRefs: string[]; complete: boolean;
}
export interface AnalysisTask {
  analysisId: string; ownerId: string; sessionId: string; originTurnId: string; sourceQuestion: string;
  goal: string; planRevision: number; constraintVersion: number; anchor: AnalysisAnchor;
  sourceHistory?: string[];
  fixedMetricUpdates?: Array<{target_id: string; mode: "replace" | "add" | "remove"; codes: string[]; source_span: {start: number; end: number; text: string}}>;
  requirements: AnalysisRequirement[]; steps: AnalysisStep[]; evidence: AnalysisEvidence[]; gaps: string[];
  constraintRef?: string; conversationId?: string;
  priorConstraintRef?: string;
  status: "active" | "waiting_user" | "complete" | "partial";
  createdAt: string; updatedAt: string;
}
export interface AnalysisCreateInput {
  goal: string; requirements: Array<{id?: string; text: string; evidenceKind?: "query" | "calculation"; expectedMetricCodes?: string[]}>; anchor: AnalysisAnchor; steps?: AnalysisStepInput[];
}
export interface AnalysisRevisionInput {
  reason?: string; anchor?: AnalysisAnchor; steps?: AnalysisStepInput[]; requirements?: AnalysisCreateInput["requirements"];
}
export interface AnalysisCompletionInput {
  partial?: boolean; coverage: Array<{requirementId: string; evidenceRefs: string[]}>; gaps?: string[];
}

function inputError(code: string, message: string): never {
  throw new BusinessInputError(code, "$analysis", message);
}
function nonEmpty(text: unknown): text is string {return typeof text === "string" && !!text.trim();}
function unique(values: string[]): boolean {return new Set(values).size === values.length;}
function now() {return new Date().toISOString();}
function owner(request: AskMetricRequestContext) {return request.actor.id;}
function analysisIdentity(request: AskMetricRequestContext) {
  return {ownerId: owner(request), sessionId: request.sessionId, issuedTurnId: request.operationId};
}
function assertOwner(task: {ownerId: string; sessionId: string}, request: AskMetricRequestContext) {
  if (task.ownerId !== owner(request) || task.sessionId !== request.sessionId) inputError("ANALYSIS_REFERENCE_UNAVAILABLE", "分析引用不属于当前用户和会话。");
}
function metrics(fields: Record<string, ResolvedField>): string[] {
  const codes = (fields.metrics?.resolvedValue as {codes?: string[]} | undefined)?.codes;
  if (Array.isArray(codes)) return codes;
  const mentions = fields.metrics?.metadata?.mentionResolutions;
  return Array.isArray(mentions) ? [...new Set(mentions.flatMap(item => item && typeof item === "object"
    && item.status === "resolved" && Array.isArray(item.value?.codes) ? item.value.codes as string[] : []))] : [];
}
function stepInput(step: AnalysisStep): AnalysisStepInput {
  return {id: step.id, purpose: step.purpose, requirementIds: step.requirementIds,
    ...(step.catalogRefs ? {catalogRefs: step.catalogRefs} : {}), ...(step.time ? {time: step.time} : {}),
    ...(step.selections ? {selections: step.selections} : {}),
    ...(step.kind ? {kind: step.kind} : {}), ...(step.methodRef ? {methodRef: step.methodRef} : {}), ...(step.bindings ? {bindings: step.bindings} : {}),
    ...(step.targetId ? {targetId: step.targetId} : {}), ...(step.selection ? {selection: step.selection} : {}),
    ...(step.operation ? {operation: step.operation} : {}), ...(step.dependsOn ? {dependsOn: step.dependsOn} : {})};
}

/** 分析只登记目标、计划和证据；执行仍使用原生循环及现有 Frame/后端适配器。 */
export class NativeAnalysisStore {
  constructor(private readonly session: Session) {}

  async issueReference(kind: ReferenceKind, payload: Record<string, unknown>, request: AskMetricRequestContext): Promise<string> {
    if (request.sessionId !== this.session.metadata.id) inputError("ANALYSIS_SESSION_INVALID", "当前会话身份不匹配。");
    if (kind === "catalog" && (!nonEmpty(payload.metric_code ?? payload.code) || !nonEmpty(payload.metric_name ?? payload.name))) {
      inputError("CATALOG_REFERENCE_INVALID", "正式目录引用必须包含真实编码和名称。");
    }
    const digest = businessKey({kind, payload, owner: owner(request), session: request.sessionId});
    const fullRef = `${kind}Ref:${digest}`;
    const readableRef = kind === "catalog" ? `catalogRef:${encodeURIComponent(String(payload.metric_code ?? payload.code))}:${digest.slice(0, 16)}` : fullRef;
    return this.session.mutate(async (tx, context) => {
      let ref = readableRef;
      let address = referenceAddress(ref);
      let prior = (await tx.getValue(address, context))?.value;
      const same = (entry: TrustedReference) => entry.kind === kind && entry.ownerId === owner(request)
        && entry.sessionId === request.sessionId && businessKey(entry.payload) === businessKey(payload);
      // 短引用碰撞回退完整hash；已有引用永不覆盖，旧opaque引用仍按原地址读取。
      if (prior && !same(prior)) {
        ref = fullRef; address = referenceAddress(ref);
        prior = (await tx.getValue(address, context))?.value;
      }
      if (prior) {
        if (!same(prior)) inputError("ANALYSIS_REFERENCE_COLLISION", "目录引用身份冲突，请重新读取正式目录。");
        return ref;
      }
      await tx.commit([setValue(address, {ref, kind, ...analysisIdentity(request), payload: structuredClone(payload), createdAt: now()})], context);
      return ref;
    }, BACKGROUND_CONTEXT);
  }

  async reference(ref: string, kind: ReferenceKind, request: AskMetricRequestContext): Promise<TrustedReference> {
    const entry = (await this.session.getValue(referenceAddress(ref), BACKGROUND_CONTEXT))?.value;
    if (!entry || entry.kind !== kind) inputError("ANALYSIS_REFERENCE_UNAVAILABLE", "引用不存在、类型不符或已经失效，请读取真实工具回执。");
    assertOwner(entry, request);
    return structuredClone(entry);
  }

  async read(analysisId?: string, request?: AskMetricRequestContext): Promise<AnalysisTask | undefined> {
    const state = (await this.session.getValue(businessStateAddress, BACKGROUND_CONTEXT))?.value;
    const id = analysisId ?? (state?.currentContext?.kind === "analysis" ? state.currentContext.analysisId : undefined);
    if (!id) return undefined;
    const task = (await this.session.getValue(taskAddress(id), BACKGROUND_CONTEXT))?.value;
    if (task && request) assertOwner(task, request);
    return task ? structuredClone(task) : undefined;
  }

  async list(request?: AskMetricRequestContext): Promise<AnalysisTask[]> {
    const ids = (await this.session.getValue(indexAddress, BACKGROUND_CONTEXT))?.value ?? [];
    const entries = await Promise.all(ids.map(id => this.read(id, request)));
    return entries.filter((task): task is AnalysisTask => !!task);
  }

  async activate(id: string, request: AskMetricRequestContext): Promise<AnalysisTask> {
    return this.session.mutate(async (tx, context) => {
      const task = (await tx.getValue(taskAddress(id), context))?.value;
      if (!task) inputError("ANALYSIS_NOT_FOUND", "分析任务不存在。");
      assertOwner(task, request);
      const state = (await tx.getValue(businessStateAddress, context))?.value!;
      await tx.commit([setValue(businessStateAddress, {...state, version: state.version + 1,
        activeAnalysisRef: id, currentContext: {kind: "analysis", analysisId: id}})], context);
      return structuredClone(task);
    }, BACKGROUND_CONTEXT);
  }

  /** 候选确认复用已保存的真实 Frame 和统一确认器，不从模型传入的编码构造事实。 */
  async resolveAnchorMetrics(id: string, raw: unknown, request: AskMetricRequestContext,
    context: ResolverContext, mode: "add" | "replace" | "remove" = "replace"): Promise<AnalysisAnchor> {
    const task = await this.read(id, request);
    if (!task) inputError("ANALYSIS_NOT_FOUND", "分析任务不存在。");
    if (mode === "remove") inputError("ANALYSIS_GOAL_CHANGE_REQUIRED", "移除固定指标会改变原分析要求，请登记变更后的新分析目标；原任务及未完成要求保留。准确查询的指标移除仍走原查询入口。");
    const frames = request.frames ?? new NativeFrameStore(this.session);
    let base: BusinessFrame | undefined;
    for (const step of task.steps) {
      if (!step.frameId) continue;
      const candidate = await frames.get(step.frameId);
      if (candidate?.status === "clarifying" && candidate.fields.metrics?.candidates?.length) {base = candidate; break;}
    }
    if (!base) {
      base = {frameId: task.anchor.baseFrameId ?? `analysis-anchor:${task.analysisId}`, sessionId: task.sessionId,
        turnId: task.originTurnId, requestId: task.originTurnId, capability: "metric_query", operationFrameId: task.analysisId,
        fields: structuredClone(task.anchor.fields), delta: {baseReference: null, fieldChanges: [], executionMode: "resolve_more"},
        issues: [], status: "clarifying", createdAt: task.createdAt};
    }
    const merged = await mergeFields(createCapabilities().get("metric_query"), base,
      {capabilityHint: "metric_query", baseReference: {frameId: base.frameId}, fieldChanges: [{fieldHint: "metrics", operation: "set", rawValue: raw}], executionMode: "resolve_more"},
      createFieldResolvers(), context);
    let field = merged.fields.metrics;
    if (!field) inputError("ANALYSIS_METRICS_UNAVAILABLE", "未能保存指标选择，请读取原待确认状态。");
    const selectedCodes = metrics({metrics: field});
    if (mode === "replace") {
      const previous = task.anchor.fields.metrics?.resolvedValue as {codes?: string[]; names?: string[]} | undefined;
      const removed = (previous?.codes ?? []).flatMap((code, index) => selectedCodes.includes(code) ? [] : [{code, name: previous?.names?.[index]}]);
      if (removed.some(item => task.requirements.some(requirement => requirement.text.includes(item.code)
        || item.name && requirement.text.includes(item.name)))) {
        inputError("ANALYSIS_GOAL_CHANGE_REQUIRED", "原分析要求明确包含被替换指标，请登记变更后的新目标；不能用其它指标证据完成原要求。");
      }
    }
    if (mode === "add" && task.anchor.fields.metrics?.resolutionStatus === "resolved" && field.resolutionStatus === "resolved") {
      const previous = task.anchor.fields.metrics.resolvedValue as {codes: string[]; names: string[]};
      const selected = field.resolvedValue as {codes: string[]; names: string[]};
      const entries = new Map(previous.codes.map((code, i) => [code, previous.names[i]!]));
      selected.codes.forEach((code, i) => entries.set(code, selected.names[i]!));
      field = {...field, resolvedValue: {codes: [...entries.keys()], names: [...entries.values()]}};
    }
    return {...task.anchor, metricUpdate: {mode, codes: mode === "add" ? selectedCodes : metrics({metrics: field})},
      fields: {...task.anchor.fields, metrics: field},
      ...(task.anchor.targets ? {targets: task.anchor.targets.map(target => ({...target, fields: {...target.fields, metrics: structuredClone(field)}}))} : {})};
  }

  private requirements(input: AnalysisCreateInput["requirements"]): AnalysisRequirement[] {
    if (!Array.isArray(input) || !input.length || input.length > 32 || input.some(item => !nonEmpty(item.text))) {
      inputError("ANALYSIS_REQUIREMENTS_INVALID", "至少登记一项明确要求，最多 32 项。");
    }
    if (input.some(item => item.expectedMetricCodes !== undefined && (!Array.isArray(item.expectedMetricCodes)
      || !item.expectedMetricCodes.length || item.expectedMetricCodes.length > 100 || !unique(item.expectedMetricCodes)
      || item.expectedMetricCodes.some(code => !nonEmpty(code))))) inputError("ANALYSIS_REQUIREMENTS_INVALID", "要求绑定的指标编码必须非空且唯一。");
    const requirements = input.map((item, i) => ({id: item.id ?? `requirement-${i + 1}`, text: item.text,
      ...(item.expectedMetricCodes ? {expectedMetricCodes: [...item.expectedMetricCodes]} : {}),
      ...(item.evidenceKind ? {evidenceKind: item.evidenceKind} : {}), status: "pending" as const, evidenceRefs: []}));
    if (!unique(requirements.map(item => item.id))) inputError("ANALYSIS_REQUIREMENTS_INVALID", "要求引用必须唯一。");
    return requirements;
  }

  private async metricIdentities(item: AnalysisStepInput, request: AskMetricRequestContext): Promise<AnalysisMetricIdentity[]> {
    const selections = item.selections;
    if (selections !== undefined && (!Array.isArray(selections) || !selections.length
      || selections.some(selection => !nonEmpty(selection.catalogRef) || !nonEmpty(selection.metricCode)))) {
      inputError("ANALYSIS_METRIC_SELECTION_INVALID", "指标选择必须同时声明可信catalogRef和对应正式metricCode。");
    }
    const refs = selections?.map(selection => selection.catalogRef) ?? item.catalogRefs;
    if (!refs?.length || !unique(refs)) inputError("ANALYSIS_STEPS_INVALID", "查询步骤必须绑定唯一的正式目录引用。");
    if (selections && item.catalogRefs && businessKey([...refs].sort()) !== businessKey([...item.catalogRefs].sort())) {
      inputError("ANALYSIS_METRIC_IDENTITY_MISMATCH", "selections与catalogRefs选择的正式指标不一致。");
    }
    const identities = await Promise.all(refs.map(async (ref, index) => {
      const {payload} = await this.reference(ref, "catalog", request);
      const metricCode = String(payload.metric_code ?? payload.code);
      if (selections && selections[index]!.metricCode !== metricCode) {
        inputError("ANALYSIS_METRIC_IDENTITY_MISMATCH", `选择声明${selections[index]!.metricCode}，但引用对应${metricCode}（${payload.metric_name ?? payload.name}）；请按正式身份纠正引用。`);
      }
      const identity = {catalogRef: ref, metricCode, metricName: String(payload.metric_name ?? payload.name),
        unit: typeof payload.unit === "string" ? payload.unit : null, basis: typeof payload.dimension === "string" ? payload.dimension : null};
      const selection = selections?.[index];
      if (selection && (["metricName", "unit", "basis"] as const).some(field => selection[field] !== undefined && selection[field] !== identity[field])) {
        inputError("ANALYSIS_METRIC_IDENTITY_MISMATCH", `引用${metricCode}的名称、单位或统计口径与正式目录不一致，请原样使用工具返回的identity。`);
      }
      return identity;
    }));
    if (!unique(identities.map(identity => identity.metricCode))) inputError("ANALYSIS_METRIC_SELECTION_INVALID", "同一步不能把同编码的不同目录引用当作多个指标。");
    return identities;
  }

  /** 预期编码必须已有可信选择或用户锚点，要求文本不能自行创造指标身份。 */
  private async validateRequirementBindings(task: AnalysisTask, request: AskMetricRequestContext) {
    const identities = await Promise.all(task.steps.map(step => step.metricIdentities
      ?? (step.kind === "calculation" ? [] : this.metricIdentities(step, request))));
    const known = new Set([...this.targets(task).flatMap(target => metrics(target.fields)),
      ...identities.flatMap(items => items.map(identity => identity.metricCode))]);
    for (const requirement of task.requirements) {
      if (requirement.expectedMetricCodes?.some(code => !known.has(code))) {
        inputError("ANALYSIS_REQUIREMENT_METRIC_UNBOUND", "要求的预期指标尚未绑定可信目录选择或用户明确指标，请先登记正式选择。");
      }
    }
  }

  private async steps(input: AnalysisStepInput[], task: AnalysisTask, request: AskMetricRequestContext): Promise<AnalysisStep[]> {
    if (!Array.isArray(input) || input.length > 32) inputError("ANALYSIS_STEPS_INVALID", "每次计划最多 32 个步骤。");
    const ids = input.map((item, i) => item.id ?? `step-${i + 1}`);
    if (!unique(ids)) inputError("ANALYSIS_STEPS_INVALID", "步骤引用必须唯一。");
    const result: AnalysisStep[] = [];
    for (const [i, item] of input.entries()) {
      let metricIdentities: AnalysisMetricIdentity[] | undefined;
      if (!nonEmpty(item.purpose) || !item.requirementIds.length || !unique(item.requirementIds)
        || item.requirementIds.some(id => !task.requirements.some(requirement => requirement.id === id))) {
        inputError("ANALYSIS_STEPS_INVALID", "每个步骤必须绑定现有要求。");
      }
      if (item.kind === "calculation") {
        if (!item.methodRef || !item.bindings || item.catalogRefs?.length || item.selections?.length) inputError("ANALYSIS_CALCULATION_INVALID", "计算步骤必须提交正式方法引用和事实绑定。");
        await this.reference(item.methodRef, "method", request);
      } else {
        if (item.methodRef || item.bindings) inputError("ANALYSIS_STEPS_INVALID", "查询步骤必须绑定正式目录引用。");
        metricIdentities = await this.metricIdentities(item, request);
      }
      if (item.targetId && !this.targets(task).some(target => target.targetId === item.targetId)) {
        inputError("ANALYSIS_TARGET_INVALID", "步骤只能引用已登记的独立目标，不能交叉组合机构和日期。");
      }
      if (!item.targetId && this.targets(task).length !== 1) inputError("ANALYSIS_TARGET_REQUIRED", "多目标分析的步骤必须明确 targetId。");
      const target = this.targets(task).find(target => target.targetId === (item.targetId ?? task.anchor.targetId ?? "target-1"))!;
      if (target.requirementIds && item.requirementIds.some(id => !target.requirementIds!.includes(id))) inputError("ANALYSIS_TARGET_INVALID", "步骤要求必须属于所选目标。");
      if (item.operation && item.operation.kind !== "value") inputError("ANALYSIS_OPERATION_UNSUPPORTED", "当前分析准备仅支持普通取值；排名请使用现有准确查询路径。");
      if (item.dependsOn?.some(id => !ids.includes(id) || id === ids[i])) inputError("ANALYSIS_DEPENDENCY_INVALID", "步骤依赖必须指向同计划的其他步骤。");
      const previous = task.steps.find(step => step.id === ids[i]);
      const spec = {...item, id: ids[i]!, ...(metricIdentities ? {catalogRefs: metricIdentities.map(identity => identity.catalogRef),
        selections: metricIdentities.map(({catalogRef, metricCode}) => ({catalogRef, metricCode}))} : {})};
      const previousSpec = previous ? stepInput(previous) : undefined;
      if (previous && previous.constraintVersion === task.constraintVersion && businessKey(spec) === businessKey(previousSpec)) {
        result.push(previous); continue;
      }
      const stepRevision = (previous?.stepRevision ?? 0) + 1;
      const stepRef = await this.issueReference("step", {analysisId: task.analysisId, stepId: spec.id, stepRevision,
        constraintVersion: task.constraintVersion, spec}, request);
      result.push({...spec, ...(metricIdentities ? {metricIdentities} : {}), stepRef, stepRevision, constraintVersion: task.constraintVersion, status: "planned", evidenceRefs: []});
    }
    // 依赖环永远不会执行，登记时即拒绝。
    const visited = new Set<string>(); const visiting = new Set<string>();
    const visit = (id: string) => {
      if (visiting.has(id)) inputError("ANALYSIS_DEPENDENCY_CYCLE", "分析步骤不能循环依赖。");
      if (visited.has(id)) return;
      visiting.add(id);
      for (const dependency of result.find(step => step.id === id)?.dependsOn ?? []) visit(dependency);
      visiting.delete(id); visited.add(id);
    };
    result.forEach(step => visit(step.id));
    return result;
  }

  private targets(task: AnalysisTask) {
    return task.anchor.targets?.length ? task.anchor.targets : [{targetId: task.anchor.targetId ?? "target-1", fields: task.anchor.fields}];
  }

  async create(input: AnalysisCreateInput, request: AskMetricRequestContext): Promise<AnalysisTask> {
    if (!nonEmpty(input.goal) || !input.anchor?.fields) inputError("ANALYSIS_GOAL_INVALID", "分析目标和可信条件锚点不能为空。");
    const command = businessKey({phase: "analysis-create", ...analysisIdentity(request), input});
    const previous = (await this.session.getValue(commandAddress(command), BACKGROUND_CONTEXT))?.value;
    if (previous) return (await this.read(previous, request))!;
    const createdAt = now();
    let task: AnalysisTask = {analysisId: randomUUID(), ownerId: owner(request), sessionId: request.sessionId,
      originTurnId: request.operationId, sourceQuestion: request.originalMessage, goal: input.goal,
      planRevision: 1, constraintVersion: 1, anchor: structuredClone(input.anchor),
      requirements: this.requirements(input.requirements), steps: [], evidence: [], gaps: [], status: "active", createdAt, updatedAt: createdAt};
    task = {...task, steps: await this.steps(input.steps ?? [], task, request)};
    await this.validateRequirementBindings(task, request);
    await this.session.mutate(async (tx, context) => {
      const prior = await tx.getValue(commandAddress(command), context);
      if (prior) return;
      const ids = (await tx.getValue(indexAddress, context))?.value ?? [];
      const state = (await tx.getValue(businessStateAddress, context))?.value
        ?? {sessionId: request.sessionId, version: 0, frameOrder: [], operations: {}};
      await tx.commit([setValue(taskAddress(task.analysisId), task), setValue(indexAddress, [...ids, task.analysisId]),
        setValue(commandAddress(command), task.analysisId), setValue(businessStateAddress, {...state, version: state.version + 1,
          activeAnalysisRef: task.analysisId, currentContext: {kind: "analysis", analysisId: task.analysisId}})], context);
    }, BACKGROUND_CONTEXT);
    return (await this.read((await this.session.getValue(commandAddress(command), BACKGROUND_CONTEXT))!.value, request))!;
  }

  private async save(task: AnalysisTask, expectedRevision: number, request: AskMetricRequestContext, activate = false): Promise<AnalysisTask> {
    return this.session.mutate(async (tx, context) => {
      const previous = (await tx.getValue(taskAddress(task.analysisId), context))?.value;
      if (!previous) inputError("ANALYSIS_NOT_FOUND", "分析任务不存在。");
      assertOwner(previous, request);
      if (previous.planRevision !== expectedRevision) throw new ContextConflict();
      const evidence = [...previous.evidence, ...task.evidence.filter(item => !previous.evidence.some(existing => existing.ref === item.ref))];
      const saved = {...task, evidence, steps: task.steps.map(step => previous.steps.find(current => current.stepRef === step.stepRef) ?? step), updatedAt: now()};
      const writes = [setValue(taskAddress(task.analysisId), saved)];
      if (activate) {
        const state = (await tx.getValue(businessStateAddress, context))?.value!;
        writes.push(setValue(businessStateAddress, {...state, version: state.version + 1,
          activeAnalysisRef: task.analysisId, currentContext: {kind: "analysis", analysisId: task.analysisId}}));
      }
      await tx.commit(writes, context);
      return structuredClone(saved);
    }, BACKGROUND_CONTEXT);
  }

  /** 步骤回执按当前状态合并；并行分支和迟到回执不得覆盖其它分支的新进度。 */
  private async update(id: string, request: AskMetricRequestContext, change: (current: AnalysisTask) => AnalysisTask): Promise<AnalysisTask> {
    return this.session.mutate(async (tx, context) => {
      const current = (await tx.getValue(taskAddress(id), context))?.value;
      if (!current) inputError("ANALYSIS_NOT_FOUND", "分析任务不存在。");
      assertOwner(current, request);
      const next = {...change(structuredClone(current)), updatedAt: now()};
      await tx.commit([setValue(taskAddress(id), next)], context);
      return structuredClone(next);
    }, BACKGROUND_CONTEXT);
  }

  private async progress(task: AnalysisTask, stepRef: string, changes: Partial<AnalysisStep>, request: AskMetricRequestContext): Promise<AnalysisTask> {
    return this.update(task.analysisId, request, current => {
      if (current.constraintVersion !== task.constraintVersion || !current.steps.some(step => step.stepRef === stepRef)) {
        inputError("ANALYSIS_STEP_STALE", "准备期间分析目标或步骤已经改变，旧请求只保留审计，不执行。");
      }
      return {...current, steps: current.steps.map(step => step.stepRef === stepRef ? {...step, ...changes} : step)};
    });
  }

  async revise(id: string, expectedRevision: number, input: AnalysisRevisionInput, request: AskMetricRequestContext): Promise<AnalysisTask> {
    const task = await this.read(id, request);
    if (!task) inputError("ANALYSIS_NOT_FOUND", "分析任务不存在。");
    if (task.planRevision !== expectedRevision) throw new ContextConflict();
    let revised = {...task, planRevision: expectedRevision + 1, status: "active" as const};
    if (input.requirements) {
      const requirements = this.requirements(input.requirements);
      if (task.requirements.some(existing => !requirements.some(item => item.id === existing.id && item.text === existing.text))) {
        inputError("ANALYSIS_REQUIREMENTS_PRESERVED", "修订不能删除或改写原始要求；新增要求可追加，明确变更目标请新建分析任务。");
      }
      revised.requirements = requirements.map(item => {
        const existing = task.requirements.find(candidate => candidate.id === item.id);
        if (!existing) return item;
        if (existing.expectedMetricCodes && item.expectedMetricCodes
          && businessKey([...existing.expectedMetricCodes].sort()) !== businessKey([...item.expectedMetricCodes].sort())) {
          inputError("ANALYSIS_REQUIREMENT_BINDING_IMMUTABLE", "已绑定要求不能改成其它指标，新增或变更业务目标请保留原要求。");
        }
        return {...existing, ...(item.expectedMetricCodes ? {expectedMetricCodes: item.expectedMetricCodes} : {}),
          ...(item.expectedMetricCodes && !existing.expectedMetricCodes ? {status: "pending" as const, evidenceRefs: []} : {})};
      });
    }
    if (input.anchor && businessKey(input.anchor) !== businessKey(task.anchor)) {
      revised = {...revised, anchor: structuredClone(input.anchor), constraintVersion: task.constraintVersion + 1,
        requirements: revised.requirements.map(item => ({...item, status: "pending", evidenceRefs: []})),
        steps: task.steps.map(step => ({...step, status: "invalidated"})), sourceQuestion: request.originalMessage,
        sourceHistory: [...(task.sourceHistory ?? [task.sourceQuestion]), request.originalMessage]};
      if (task.constraintRef) revised.priorConstraintRef = task.constraintRef;
      const oldTargets = this.targets(task);
      revised.fixedMetricUpdates = this.targets(revised).flatMap(target => {
        const previous = oldTargets.find(item => item.targetId === target.targetId);
        const codes = metrics(target.fields);
        return previous && businessKey([...metrics(previous.fields)].sort()) !== businessKey([...codes].sort())
          ? [{target_id: target.targetId, mode: revised.anchor.metricUpdate?.mode ?? "replace" as const,
            codes: revised.anchor.metricUpdate?.codes ?? codes, source_span: {start: 0,
            end: Array.from(request.originalMessage).length, text: request.originalMessage}}] : [];
      });
      delete revised.constraintRef;
    }
    if (input.steps) {
      const used = new Set([...task.steps.map(step => step.id), ...input.steps.flatMap(step => step.id ? [step.id] : [])]);
      let sequence = task.steps.length + 1;
      const additions = input.steps.map(step => {
        if (step.id) return {...step, id: step.id};
        while (used.has(`step-${sequence}`)) sequence += 1;
        const id = `step-${sequence++}`; used.add(id);
        return {...step, id};
      });
      const suppliedIds = new Set(additions.map(step => step.id));
      revised.steps = await this.steps([...revised.steps.filter(step => !suppliedIds.has(step.id)).map(stepInput), ...additions], revised, request);
    } else if (input.anchor) revised.steps = await this.steps(task.steps.map(stepInput), revised, request);
    await this.validateRequirementBindings(revised, request);
    return this.save(revised, expectedRevision, request, true);
  }

  async complete(id: string, expectedRevision: number, input: AnalysisCompletionInput, request: AskMetricRequestContext): Promise<AnalysisTask> {
    const task = await this.read(id, request);
    if (!task) inputError("ANALYSIS_NOT_FOUND", "分析任务不存在。");
    if (!input.partial && this.targets(task).some(target => {
      const organizations = (target.fields.organizations?.resolvedValue as {codes?: string[]} | undefined)?.codes ?? [];
      const time = target.fields.time?.resolvedValue as BasicQuerySpec["time"] | undefined;
      const dates = time?.dates ?? (time?.start === time?.end ? [time!.start] : undefined);
      return metrics(target.fields).some(code => organizations.some(org => (dates ?? [undefined]).some(date => !task.evidence.some(evidence =>
        evidence.constraintVersion === task.constraintVersion && evidence.targetId === target.targetId
        && task.steps.some(step => step.id === evidence.stepId && step.stepRevision === evidence.stepRevision
          && step.constraintVersion === task.constraintVersion && step.status === "succeeded")
        && (evidence.usableCoverage ?? (evidence.complete ? evidence.coverage : [])).some(fact => fact.metricCode === code && fact.orgCode === org
          && (date ? fact.date === date : !!time && fact.date >= time.start && fact.date <= time.end))))));
    })) {
      inputError("ANALYSIS_FIXED_TARGETS_INCOMPLETE", "用户明确指标仍有未取证项，不能用辅助指标代替完成原始目标。");
    }
    const requirements = task.requirements.map(requirement => {
      const coverage = input.coverage.find(item => item.requirementId === requirement.id);
      const evidenceRefs = coverage?.evidenceRefs ?? [];
      if (evidenceRefs.some(ref => !task.evidence.some(evidence => evidence.ref === ref
        && (evidence.complete || requirement.expectedMetricCodes?.length && evidence.kind === "query" && evidence.usableCoverage?.length)
        && (!requirement.evidenceKind || evidence.kind === requirement.evidenceKind)
        && evidence.constraintVersion === task.constraintVersion && task.steps.some(step => step.id === evidence.stepId
          && step.stepRevision === evidence.stepRevision && step.constraintVersion === task.constraintVersion
          && step.requirementIds.includes(requirement.id) && step.status === "succeeded")))) {
        inputError("ANALYSIS_EVIDENCE_INVALID", "要求只能引用本任务当前有效、完整且属于该要求的成功步骤证据。");
      }
      const evidence = task.evidence.filter(item => evidenceRefs.includes(item.ref));
      if (evidenceRefs.length && requirement.expectedMetricCodes?.some(code => this.targets(task)
        .filter(target => !target.requirementIds || target.requirementIds.includes(requirement.id)).some(target => {
          const orgs = (target.fields.organizations?.resolvedValue as {codes?: string[]} | undefined)?.codes ?? [];
          const time = target.fields.time?.resolvedValue as BasicQuerySpec["time"] | undefined;
          const dates = time?.dates ?? (time?.start === time?.end ? [time!.start] : [undefined]);
          return !orgs.length || !time || orgs.some(org => dates.some(date => !evidence.some(item => item.targetId === target.targetId
            && (item.usableCoverage ?? (item.complete ? item.coverage : [])).some(fact => fact.metricCode === code && fact.orgCode === org
              && (date ? fact.date === date : fact.date >= time.start && fact.date <= time.end)))));
        }))) inputError("ANALYSIS_REQUIREMENT_METRICS_INCOMPLETE", "要求的正式指标尚未在其固定机构日期取得完整证据，不能用步骤用途或其它指标代替。");
      return {...requirement, evidenceRefs, status: evidenceRefs.length ? "satisfied" as const : "pending" as const};
    });
    const unresolved = requirements.filter(item => item.status !== "satisfied");
    if (unresolved.length && !input.partial) inputError("ANALYSIS_REQUIREMENTS_INCOMPLETE", "仍有要求缺少完整证据；请继续取证或明确部分完成及缺口。");
    const missingGaps = task.evidence.filter(evidence => evidence.constraintVersion === task.constraintVersion)
      .flatMap(evidence => evidence.missingMetricCodes?.map(code => `${code} 在原查询范围存在无有效值缺口`) ?? []);
    const gaps = [...new Set([...(input.gaps ?? unresolved.map(item => item.text)), ...missingGaps])];
    if (unresolved.length && !gaps.length) inputError("ANALYSIS_GAPS_REQUIRED", "部分完成必须保留未完成要求的具体缺口。");
    return this.save({...task, planRevision: task.planRevision + 1, requirements, gaps,
      status: unresolved.length || input.partial ? "partial" : "complete"}, expectedRevision, request);
  }

  /** transform_context 从持久状态恢复目标与引用，不依赖聊天摘要保存计划。 */
  async modelContext(request: AskMetricRequestContext) {
    const state = (await this.session.getValue(businessStateAddress, BACKGROUND_CONTEXT))?.value;
    const task = state?.currentContext?.kind === "analysis" ? await this.read(state.currentContext.analysisId, request) : undefined;
    return {currentContext: state?.currentContext ?? (state?.focusFrameId ? {kind: "frame", frameId: state.focusFrameId} : null),
      ...(task ? {analysis: {analysisId: task.analysisId, goal: task.goal, planRevision: task.planRevision,
        constraintVersion: task.constraintVersion, status: task.status, anchor: task.anchor, requirements: task.requirements,
        steps: task.steps, evidence: task.evidence, gaps: task.gaps}} : {})};
  }

  async hasExecutableBranches(id: string, request: AskMetricRequestContext): Promise<boolean> {
    const task = await this.read(id, request);
    return !!task?.steps.some(step => ["planned", "prepared", "preparing"].includes(step.status)
      && (step.dependsOn ?? []).every(dependency => task.steps.some(candidate => candidate.id === dependency && candidate.status === "succeeded")));
  }

  /** 只消费宿主登记的不可变步骤，生成本轮 Frame；旧 READY 不跨回合直接执行。 */
  async resolveStep(stepRef: string, request: AskMetricRequestContext, context: ResolverContext): Promise<BusinessFrame> {
    const reference = await this.reference(stepRef, "step", request);
    const task = await this.read(String(reference.payload.analysisId), request);
    const step = task?.steps.find(item => item.stepRef === stepRef && item.stepRevision === reference.payload.stepRevision
      && item.constraintVersion === task.constraintVersion);
    if (!task || !step || step.status === "invalidated") inputError("ANALYSIS_STEP_STALE", "步骤引用已失效，请读取当前分析计划。");
    if (["complete", "partial"].includes(task.status) && step.status !== "succeeded") {
      inputError("ANALYSIS_TASK_SETTLED", "该分析已登记完成或部分完成；继续取证请先修订任务，已成功步骤仍可回读。");
    }
    if ((step.dependsOn ?? []).some(id => !task.steps.some(item => item.id === id && item.status === "succeeded"))) {
      inputError("ANALYSIS_DEPENDENCY_PENDING", "该步骤依赖的证据尚未完成，可先执行独立分支。");
    }
    const frames = request.frames ?? new NativeFrameStore(this.session);
    const frameKey = businessKey({phase: "analysis-materialize", stepRef, turnId: request.operationId, requestId: request.requestId});
    const prior = await frames.command(frameKey);
    if (prior) return prior;
    const target = this.targets(task).find(target => target.targetId === (step.targetId ?? task.anchor.targetId ?? "target-1"));
    if (!target) inputError("ANALYSIS_TARGET_INVALID", "步骤目标不存在。");
    let fields = structuredClone(target.fields);
    const pendingMetric = fields.metrics && !["resolved", "missing"].includes(fields.metrics.resolutionStatus);
    const calculation = step.kind === "calculation" && !pendingMetric;
    if (calculation) fields = await this.calculationFields(step, task, request, context);
    const metricIdentities = step.kind === "calculation" ? [] : await this.metricIdentities(step, request);
    const codes = metricIdentities.map(item => item.metricCode);
    const names = metricIdentities.map(item => item.metricName);
    if (!calculation && !pendingMetric) fields.metrics = {source: "resolved", resolutionStatus: "resolved", resolver: "metric", rawValue: {catalogRefs: step.catalogRefs},
      resolvedValue: {codes, names}, metadata: {analysisSelection: true, catalogRefs: step.catalogRefs, metricIdentities}};
    if (step.preparedSpec && !calculation && !pendingMetric) {
      fields.time = {source: "resolved", resolutionStatus: "resolved", rawValue: step.time,
        resolvedValue: structuredClone(step.preparedSpec.time), resolver: "date"};
      fields.selection = {source: "resolved", resolutionStatus: "resolved", resolvedValue: step.preparedSpec.selection, resolver: "enum"};
    } else if (step.time && !calculation) {
      // 自主缩小取证日期仍用同一解析器，范围由后端固定约束再次复核。
      const resolved = await context.resolveCatalog("date", [step.time]);
      fields.time = {source: "resolved", resolutionStatus: resolved.status, rawValue: step.time,
        ...(resolved.value !== undefined ? {resolvedValue: resolved.value} : {}), resolver: "date"};
    }
    if (step.selection && !calculation && !step.preparedSpec) fields.selection = {source: "resolved", resolutionStatus: "resolved", resolvedValue: step.selection, resolver: "enum"};
    if (!calculation) fields.operation = {source: "resolved", resolutionStatus: "resolved", resolvedValue: step.operation ?? {kind: "value"}, resolver: "query_operation"};
    const capability = calculation ? "metric_calculate" : "metric_query";
    const delta = {capabilityHint: capability, baseReference: null, fieldChanges: [], executionMode: "execute"} as const;
    const schema = createCapabilities().get(capability);
    for (const name of Object.keys(schema.fields)) fields[name] ??= missingField();
    schema.completeFields?.(fields, {...delta, fieldChanges: []});
    const validation = validateFrame(schema, fields);
    const argumentIssues = validation.issues.filter(issue => issue.reason === "missing" && schema.fields[issue.field]?.missingIsArgumentError
      || issue.reason === "invalid" && fields[issue.field]?.metadata?.userInputIssue !== true);
    if (argumentIssues.length) inputError("ANALYSIS_STEP_ARGUMENTS_INVALID", argumentIssues.map(issue =>
      issue.correction?.message ?? issue.message ?? `${issue.field} 的步骤参数未通过校验，请保留目标和范围后修订步骤。`).join("；"));
    const id = randomUUID();
    let frame: BusinessFrame = {frameId: id, sessionId: request.sessionId, turnId: request.operationId, requestId: request.requestId,
      capability, operationFrameId: id, fields, delta: {...delta, fieldChanges: []}, issues: validation.issues,
      status: validation.status === "READY" ? "ready" : "clarifying", historyRole: "supporting", purpose: "supporting",
      analysisRef: {analysisId: task.analysisId, stepId: step.id, stepRevision: step.stepRevision,
        constraintVersion: task.constraintVersion, stepRef, targetId: target.targetId}, createdAt: now()};
    if (frame.status === "ready" && !calculation) frame = await this.prepare(frame, task, step, request, context);
    const state = await frames.state();
    const saved = await frames.save(frame, state.version, frameKey, false);
    const progressed = await this.progress(task, stepRef, {frameId: saved.frameId,
      status: saved.status === "success" ? "succeeded" : saved.status === "ready" ? "prepared" : "clarifying",
      ...(saved.resultRef ? {resultRef: saved.resultRef} : {}),
      issues: saved.issues.map(({field, reason}) => ({field, reason}))}, request);
    if (saved.status === "clarifying" && !await this.hasExecutableBranches(task.analysisId, request)) {
      await this.update(task.analysisId, request, current => ({...current, status: "waiting_user"}));
    } else if (progressed.status === "waiting_user") await this.update(task.analysisId, request, current => ({...current, status: "active"}));
    return saved;
  }

  private async calculationFields(step: AnalysisStep, task: AnalysisTask, request: AskMetricRequestContext,
    context: ResolverContext): Promise<Record<string, ResolvedField>> {
    const method = await this.reference(step.methodRef!, "method", request);
    const methods = {
      difference: {expression: "a-b", display: "decimal" as const, label: "差额"},
      growth_rate: {expression: "(a-b)/abs(b)", display: "percent" as const, label: "增长率"},
    };
    const methodId = method.payload.id;
    if (typeof methodId !== "string" || !Object.hasOwn(methods, methodId)) inputError("ANALYSIS_METHOD_UNSUPPORTED", "该正式方法尚未实现。");
    const definition = methods[methodId as keyof typeof methods];
    if (method.payload.expression !== definition.expression || method.payload.display !== definition.display) {
      inputError("ANALYSIS_METHOD_INVALID", "方法引用与已部署的方法版本不一致。");
    }
    const bindings = step.bindings!;
    if (businessKey(Object.keys(bindings).sort()) !== businessKey(["a", "b"]) || !context.resolveFactBindings) {
      inputError("ANALYSIS_FACT_BINDINGS_INVALID", "当前正式方法需要 a、b 两个真实事实引用。");
    }
    const checked = await context.resolveFactBindings(bindings);
    if (checked.status !== "resolved") inputError("ANALYSIS_FACT_BINDINGS_UNAVAILABLE", "计算事实尚未完整可用，请先完成取证。");
    const facts = await Promise.all(["a", "b"].map(async name => {
      const factId = bindings[name]!.fact_id;
      const match = factId.match(/^fact:([^:]+):(\d+):([^:]+)$/);
      if (!match) inputError("ANALYSIS_FACT_BINDINGS_INVALID", "事实引用格式不正确。");
      const page = await request.backend.getTaskResult(match[1]!, Number(match[2]), 1);
      const fact = page.facts?.find(item => item.fact_id === factId);
      if (!fact || page.status !== "succeeded" || page.truncated) inputError("ANALYSIS_FACT_BINDINGS_UNAVAILABLE", "指定事实不可读取或来源不完整。");
      return fact;
    }));
    const a = facts[0]!; const b = facts[1]!;
    const target = this.targets(task).find(item => item.targetId === (step.targetId ?? task.anchor.targetId ?? "target-1"))!;
    const organizations = target.fields.organizations?.resolvedValue as {codes?: string[]} | undefined;
    const time = target.fields.time?.resolvedValue as BasicQuerySpec["time"] | undefined;
    if (!organizations?.codes || !time || facts.some(fact => !organizations.codes!.includes(fact.org_code)
      || fact.date < time.start || fact.date > time.end || time.dates && !time.dates.includes(fact.date))) {
      inputError("ANALYSIS_METHOD_SCOPE_MISMATCH", "计算事实超出本步骤绑定的机构或日期，不能借历史事实扩大分析范围。");
    }
    if (a.unit !== b.unit) inputError("ANALYSIS_METHOD_UNIT_MISMATCH", "计算输入单位不一致，不能自动换算。");
    let scopePolicy: "same_org_date" | "cross_date" | "cross_org";
    if (a.org_code === b.org_code && a.date === b.date) scopePolicy = "same_org_date";
    else if (a.org_code === b.org_code && a.metric_code === b.metric_code) scopePolicy = "cross_date";
    else if (a.date === b.date && a.metric_code === b.metric_code) scopePolicy = "cross_org";
    else inputError("ANALYSIS_METHOD_SCOPE_MISMATCH", "该方法不能同时改变机构、日期和指标，需补齐可比证据。");
    if (methodId === "growth_rate" && (scopePolicy !== "cross_date" || a.date <= b.date)) {
      inputError("ANALYSIS_METHOD_SCOPE_MISMATCH", "增长率需要同机构同指标的前后日期事实，a 为较晚期、b 为基期。");
    }
    const resolved = (resolvedValue: unknown, resolver: string): ResolvedField => ({source: "resolved", resolutionStatus: "resolved", resolver, resolvedValue});
    return {bindings: resolved(bindings, "fact_bindings"),
      expressions: resolved([{name: methodId, label: definition.label, expression: definition.expression, display: definition.display}], "expressions"),
      scope_policy: resolved(scopePolicy, "enum")};
  }

  private async prepare(frame: BusinessFrame, task: AnalysisTask, step: AnalysisStep, request: AskMetricRequestContext,
    context: ResolverContext): Promise<BusinessFrame> {
    if (step.preparedQueryRef) {
      if (!step.preparedSpec) throw new Error("ANALYSIS_PREPARED_SPEC_MISSING");
      const bound = this.bindPrepared(frame, step.preparedSpec, step.preparedQueryRef);
      if (step.status === "succeeded" && step.resultRef) return {...bound, status: "success", resultRef: step.resultRef,
        delta: {...bound.delta, executionMode: "reuse_result"}};
      const source = step.frameId ? await request.frames?.get(step.frameId) : undefined;
      const state = await request.frames?.state();
      const latest = source && state ? await request.frames?.get(state.operations[source.operationFrameId] ?? source.frameId) : undefined;
      if (latest?.status === "executing" && latest.turnId !== request.operationId && step.prepareKey && task.conversationId) {
        const prepared = await request.backend.getPreparedAnalysisQuery(step.prepareKey, task.conversationId);
        if (prepared.status === "executing") inputError("ANALYSIS_STEP_EXECUTING", "上次步骤仍在后端执行，暂不重发；结果确定后继续此任务。");
        if (prepared.status === "invalidated") inputError("ANALYSIS_STEP_STALE", "上次步骤准备已经失效，请修订当前计划。");
        if (prepared.status === "settled") {
          const completed = await request.backend.getTask(prepared.task_id);
          if (completed.status !== "SUCCEEDED" || !completed.result?.result_id) inputError("ANALYSIS_STEP_FAILED", "上次步骤已经结束且未成功，请保留目标并重新规划。");
          return {...this.bindPrepared(frame, prepared.query, prepared.prepared_query_ref), status: "success", resultRef: `query:${encodeURIComponent(prepared.task_id)}:${encodeURIComponent(completed.result.result_id)}`,
            delta: {...bound.delta, executionMode: "reuse_result"}};
        }
      }
      return bound;
    }
    let conversationId = task.conversationId ?? await request.commands.getConversationId();
    if (!conversationId) {
      conversationId = (await request.backend.createAgentQueryContext(request.sessionId)).conversation_id;
      await request.commands.setConversationId(conversationId);
    }
    const targets = this.targets(task);
    const target = targets.find(target => target.targetId === (step.targetId ?? task.anchor.targetId ?? "target-1"));
    if (!target) inputError("ANALYSIS_TARGET_INVALID", "步骤目标不存在。");
    const organizations = target.fields.organizations?.resolvedValue as {codes?: string[]; scope?: unknown} | undefined;
    if (!organizations?.codes?.length || organizations.scope) inputError("ANALYSIS_SCOPE_UNSUPPORTED", "分析目前需要明确机构；集合排名仍使用现有查询路径。");
    if (step.prepareKey) {
      try {
        const recovered = await request.backend.getPreparedAnalysisQuery(step.prepareKey, conversationId);
        if (recovered.prepare_key !== step.prepareKey || !nonEmpty(recovered.prepared_query_ref)) throw new Error("ANALYSIS_PREPARED_REFERENCE_INVALID");
        if (recovered.status === "invalidated") inputError("ANALYSIS_STEP_STALE", "已准备步骤被约束修订失效，不能恢复执行。");
        if (recovered.status === "executing") inputError("ANALYSIS_STEP_EXECUTING", "原步骤仍在执行，请稍后回查，不能重新准备。");
        await this.progress(task, step.stepRef, {status: "prepared", preparedQueryRef: recovered.prepared_query_ref,
          preparedSpec: recovered.query, specHash: recovered.spec_hash}, request);
        const bound = this.bindPrepared(frame, recovered.query, recovered.prepared_query_ref);
        if (recovered.status === "settled") {
          const completed = await request.backend.getTask(recovered.task_id);
          if (completed.status !== "SUCCEEDED" || !completed.result?.result_id) inputError("ANALYSIS_STEP_FAILED", "原步骤未成功，请依据失败原因修订计划。");
          return {...bound, status: "success", resultRef: `query:${encodeURIComponent(recovered.task_id)}:${encodeURIComponent(completed.result.result_id)}`,
            delta: {...bound.delta, executionMode: "reuse_result"}};
        }
        return bound;
      } catch (error) {
        if (!(error instanceof BackendApiError) || error.status !== 404) throw error;
        // 准备请求确定未收到，仍复用同一固定键和规范重发，不生成第二份准备。
      }
    }
    if (!task.constraintRef) {
      const sourceQuestionHash = createHash("sha256").update(task.sourceQuestion, "utf8").digest("hex");
      const sourceFrame = task.anchor.baseFrameId ? await request.frames?.get(task.anchor.baseFrameId) : undefined;
      const sourceState = await request.frames?.state();
      const sourceResult = sourceFrame?.resultRef ? sourceFrame : sourceFrame && sourceState
        ? await request.frames?.get(sourceState.operations[sourceFrame.operationFrameId] ?? sourceFrame.frameId) : undefined;
      const priorQueryTaskId = sourceResult?.resultRef?.startsWith("query:") ? decodeURIComponent(sourceResult.resultRef.split(":")[1]!) : undefined;
      const metricSource = targets.map(target => target.fields.metrics).find(field => field?.resolutionStatus === "resolved"
        && typeof field.metadata?.questionText === "string" && Array.isArray(field.metadata?.mentionResolutions));
      const coverage = metricSource ? (await import("./adapters.js")).metricCoverageSource(metricSource.metadata!.questionText as string,
        metricSource.metadata!.mentionResolutions as import("./types.js").MentionResolution[],
        (metricSource.metadata!.removedMentions ?? []) as import("./types.js").MentionResolution[]) : undefined;
      const payload = {schema_version: 1 as const, conversation_id: conversationId, analysis_id: task.analysisId,
        constraint_version: task.constraintVersion, source_question: task.sourceQuestion, source_question_sha256: sourceQuestionHash,
        ...(task.sourceHistory?.length ? {source_history: task.sourceHistory.map(source_question => ({source_question,
          source_question_sha256: createHash("sha256").update(source_question, "utf8").digest("hex")}))} : {}),
        ...(coverage ? {metric_source_question: coverage.source_question, source_metric_bindings: coverage.source_metric_bindings,
          ...(coverage.source_metric_exclusions ? {source_metric_exclusions: coverage.source_metric_exclusions} : {})} : {}),
        ...(task.fixedMetricUpdates?.length ? {fixed_metric_updates: task.fixedMetricUpdates} : {}),
        ...(task.priorConstraintRef ? {prior_constraint_ref: task.priorConstraintRef} : {}),
        ...(priorQueryTaskId ? {prior_query_task_id: priorQueryTaskId} : {}),
        targets: targets.map(item => ({target_id: item.targetId,
          org_codes: (item.fields.organizations?.resolvedValue as {codes: string[]}).codes,
          time: item.fields.time?.resolvedValue as BasicQuerySpec["time"], fixed_metric_codes: metrics(item.fields),
          allowed_metric_codes: [], metric_selection_policy: "catalog" as const})),
        requirements: task.requirements.map(item => ({requirement_id: item.id,
          target_ids: targets.filter(target => !target.requirementIds || target.requirementIds.includes(item.id)).map(target => target.targetId), description: item.text}))};
      const constraint = await request.backend.registerAnalysisConstraints(payload,
        businessKey({phase: "analysis-constraint", analysisId: task.analysisId, constraintVersion: task.constraintVersion}));
      task = await this.update(task.analysisId, request, current => {
        if (current.constraintVersion !== task.constraintVersion) inputError("ANALYSIS_STEP_STALE", "约束登记期间目标已改变，请读取当前任务。");
        return {...current, constraintRef: constraint.constraint_ref, conversationId};
      });
    }
    const selected = await Promise.all((step.catalogRefs ?? []).map(ref => this.reference(ref, "catalog", request)));
    const backendReferences = await request.backend.createAnalysisCatalogReferences({conversation_id: conversationId,
      metric_codes: selected.map(item => String(item.payload.metric_code ?? item.payload.code))});
    const queryTime = frame.fields.time!.resolvedValue as BasicQuerySpec["time"];
    const query: BasicQuerySpec = step.preparedSpec ?? {schema_version: 2,
      metric_codes: metrics(frame.fields), org_codes: [...organizations.codes], time: queryTime,
      selection: frame.fields.selection!.resolvedValue as BasicQuerySpec["selection"], operation: {kind: "value"}};
    const prepareKey = step.prepareKey ?? businessKey({phase: "analysis-prepare", owner: owner(request), session: request.sessionId,
      analysisId: task.analysisId, constraintVersion: task.constraintVersion, stepId: step.id, stepRevision: step.stepRevision, query});
    const specHash = businessKey(query);
    // 双存储发送前登记固定键；断连或重启后只回查同一准备记录，不改键重建。
    task = await this.progress(task, step.stepRef, {status: "preparing", prepareKey, specHash, preparedSpec: query}, request);
    const prepared = await request.backend.prepareAnalysisQuery({constraint_ref: task.constraintRef!, prepare_key: prepareKey,
      step_id: step.id, step_revision: step.stepRevision, target_id: target.targetId, requirement_ids: step.requirementIds,
      query, catalog_refs: backendReferences.references}, prepareKey);
    if (!nonEmpty(prepared.prepared_query_ref)) throw new Error("ANALYSIS_PREPARED_REFERENCE_MISSING");
    if (prepared.status === "invalidated") inputError("ANALYSIS_STEP_STALE", "步骤准备已失效，请读取当前分析计划。");
    await this.progress(task, step.stepRef, {status: "prepared", preparedQueryRef: prepared.prepared_query_ref,
      preparedSpec: prepared.query, specHash: prepared.spec_hash}, request);
    return this.bindPrepared(frame, prepared.query, prepared.prepared_query_ref);
  }

  private bindPrepared(frame: BusinessFrame, query: BasicQuerySpec, preparedQueryRef: string): BusinessFrame {
    if (!query.org_codes?.length || query.organization_scope || query.comparison_scope || query.operation && query.operation.kind !== "value") {
      inputError("ANALYSIS_PREPARED_SPEC_INVALID", "准备回执不是受支持的普通机构取值规范。");
    }
    const metric = frame.fields.metrics!.resolvedValue as {codes: string[]; names: string[]};
    const org = frame.fields.organizations!.resolvedValue as {codes: string[]; names: string[]};
    if (businessKey([...metric.codes].sort()) !== businessKey([...query.metric_codes].sort())
      || businessKey([...org.codes].sort()) !== businessKey([...query.org_codes].sort())) {
      inputError("ANALYSIS_PREPARED_SPEC_MISMATCH", "准备回执与已登记步骤实体不一致，不能改写目标。");
    }
    return {...frame, fields: {...frame.fields,
      time: {...frame.fields.time!, resolutionStatus: "resolved", resolvedValue: structuredClone(query.time)},
      selection: {...frame.fields.selection!, resolutionStatus: "resolved", resolvedValue: query.selection},
      operation: {...frame.fields.operation!, resolutionStatus: "resolved", resolvedValue: query.operation ?? {kind: "value"}}},
      analysisRef: {...frame.analysisRef!, preparedQueryRef}};
  }

  /** 成功回执才发行证据，迟到结果保留审计，不能完成已修订要求或切换焦点。 */
  async observeFrame(frame: BusinessFrame, receipt: Record<string, unknown>, request: AskMetricRequestContext): Promise<void> {
    const analysis = frame.analysisRef;
    if (!analysis) return;
    const task = await this.read(analysis.analysisId, request);
    if (!task) return;
    const step = task.steps.find(item => item.id === analysis.stepId && item.stepRevision === analysis.stepRevision);
    const succeeded = frame.status === "success" && !!frame.resultRef;
    const facts = Array.isArray(receipt.facts) ? receipt.facts : receipt.inputs && typeof receipt.inputs === "object" ? Object.values(receipt.inputs) : [];
    const factRefs = facts.flatMap(fact => fact && typeof fact === "object"
      && typeof (fact as {fact_id?: unknown}).fact_id === "string" ? [(fact as {fact_id: string}).fact_id] : []);
    const numericFact = (fact: unknown) => {
      if (!fact || typeof fact !== "object") return false;
      const item = fact as {fact_id?: unknown; value?: unknown};
      return typeof item.fact_id === "string" && /^fact:[^:]+:\d+:[^:]+$/.test(item.fact_id)
        && typeof item.value === "string" && /^-?\d+(\.\d+)?([eE][+-]?\d+)?$/.test(item.value) && Number.isFinite(Number(item.value));
    };
    const usableFacts = facts.length > 0 && facts.every(numericFact);
    const calculated = frame.capability !== "metric_calculate" || Array.isArray(receipt.results) && receipt.results.length > 0
      && receipt.results.every(result => result && typeof result === "object" && typeof (result as {value?: unknown}).value === "string"
        && /^-?\d+(\.\d+)?([eE][+-]?\d+)?$/.test((result as {value: string}).value)
        && Number.isFinite(Number((result as {value: string}).value)));
    const metricCodesRequested = (frame.fields.metrics?.resolvedValue as {codes?: string[]} | undefined)?.codes ?? [];
    const orgCodesRequested = (frame.fields.organizations?.resolvedValue as {codes?: string[]} | undefined)?.codes ?? [];
    const timeRequested = frame.fields.time?.resolvedValue as BasicQuerySpec["time"] | undefined;
    const identities = frame.fields.metrics?.metadata?.metricIdentities as AnalysisMetricIdentity[] | undefined;
    const queryFacts = facts.filter(raw => {
      if (!numericFact(raw) || !timeRequested) return false;
      const fact = raw as {metric_code?: string; metric_name?: string; unit?: string; org_code?: string; date?: string};
      const identity = identities?.find(item => item.metricCode === fact.metric_code);
      return metricCodesRequested.includes(fact.metric_code ?? "") && orgCodesRequested.includes(fact.org_code ?? "")
        && typeof fact.date === "string" && fact.date >= timeRequested.start && fact.date <= timeRequested.end
        && (!timeRequested.dates || timeRequested.dates.includes(fact.date))
        && (!identities || !!identity && identity.metricName === fact.metric_name && (identity.unit === null || identity.unit === fact.unit));
    });
    const coversMetric = (metric: string) => {
      const time = timeRequested;
      if (!time || !orgCodesRequested.length) return false;
      const dates = time.dates ?? (time.start === time.end ? [time.start] : undefined);
      return orgCodesRequested.every(org => {
        const matching = queryFacts.filter(raw => {
          const fact = raw as {metric_code?: string; org_code?: string};
          return fact.metric_code === metric && fact.org_code === org;
        });
        return dates ? dates.every(date => matching.some(raw => (raw as {date: string}).date === date)) : matching.length > 0;
      });
    };
    const queryCoverage = frame.capability !== "metric_query" || (() => {
      const metricCodes = metricCodesRequested;
      const orgCodes = orgCodesRequested;
      const time = timeRequested;
      if (!metricCodes.length || !orgCodes.length || !time) return false;
      return queryFacts.length === facts.length && metricCodes.every(coversMetric);
    })();
    const wholeReceipt = receipt.truncated !== true && receipt.facts_truncated !== true
      && receipt.result_truncated !== true && receipt.has_more !== true && (receipt.offset === undefined || receipt.offset === 0);
    const usableCoverage = succeeded && wholeReceipt && frame.capability === "metric_query" ? queryFacts.map(raw => {
      const fact = raw as {metric_code: string; org_code: string; date: string};
      return {metricCode: fact.metric_code, orgCode: fact.org_code, date: fact.date};
    }) : [];
    const missingMetricCodes = frame.capability === "metric_query" ? metricCodesRequested.filter(code => !coversMetric(code)) : [];
    const complete = succeeded && usableFacts && calculated && queryCoverage && wholeReceipt
      && !(receipt.query_evidence as {missing_metric_notice?: unknown} | undefined)?.missing_metric_notice;
    const ref = `evidenceRef:${businessKey({analysisId: task.analysisId, stepId: analysis.stepId, stepRevision: analysis.stepRevision,
      resultRef: frame.resultRef, factRefs, complete, usableCoverage, missingMetricCodes})}`;
    const metricCodes = [...new Set(facts.flatMap(fact => fact && typeof fact === "object" && typeof (fact as {metric_code?: unknown}).metric_code === "string"
      ? [(fact as {metric_code: string}).metric_code] : []))];
    const coverage = facts.flatMap(raw => {
      const fact = raw as {metric_code?: unknown; org_code?: unknown; date?: unknown};
      return typeof fact.metric_code === "string" && typeof fact.org_code === "string" && typeof fact.date === "string"
        ? [{metricCode: fact.metric_code, orgCode: fact.org_code, date: fact.date}] : [];
    });
    const evidence: AnalysisEvidence | undefined = succeeded ? {ref, stepId: analysis.stepId, stepRevision: analysis.stepRevision,
      constraintVersion: analysis.constraintVersion, kind: frame.capability === "metric_calculate" ? "calculation" : "query",
      targetId: analysis.targetId ?? step?.targetId ?? task.anchor.targetId ?? "target-1", metricCodes, coverage,
      ...(frame.capability === "metric_query" ? {usableCoverage, missingMetricCodes} : {}),
      frameId: frame.frameId, resultRef: frame.resultRef!, factRefs, complete} : undefined;
    await this.update(task.analysisId, request, current => ({...current, steps: current.steps.map(item => item.stepRef === analysis.stepRef ? {...item,
      status: frame.status === "success" ? "succeeded" : frame.status === "executing" ? "executing" : frame.status === "failed" ? "failed" : item.status,
      frameId: frame.frameId, ...(frame.resultRef ? {resultRef: frame.resultRef} : {}), ...(evidence ? {evidenceRefs: [...new Set([...item.evidenceRefs, ref])]} : {}),
      ...(frame.errorCode ? {errorCode: frame.errorCode} : {})} : item),
      evidence: evidence && !current.evidence.some(item => item.ref === ref) ? [...current.evidence, evidence] : current.evidence}));
  }
}
