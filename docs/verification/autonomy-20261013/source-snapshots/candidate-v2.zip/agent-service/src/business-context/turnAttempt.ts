import {createHash} from "node:crypto";
import {BusinessInputError} from "./inputError.js";
import type {AskMetricRequestContext} from "../requestContext.js";
import type {FrameSelector} from "./types.js";

export interface TurnAttempt {
  attemptRef: string; ownerId: string; sessionId: string; turnId: string; requestId: string;
  promptFingerprint: string; proposal: Record<string, unknown>;
  analysisHandoff?: {sourceQuestion: string; sourceFingerprint: string};
}

export interface AnalysisAttemptHandoff {
  base: FrameSelector | "current" | null;
  scope: {organizations?: unknown; time?: unknown; selection?: unknown; operation?: unknown};
  originalMessage: string;
  sourceFingerprint: string;
  proposal: Record<string, unknown>;
}

/** 只交接来源错误的取值提案；权限、机构日期和分析授权仍由新工具动作分别核验。 */
export function canHandoffAnalysisAttempt(proposal: Record<string, unknown>, error: BusinessInputError): boolean {
  if (error.field !== "metrics" || !["INVALID_MENTION_REFERENCE", "FIELD_INPUT_NOT_CURRENT"].includes(error.code)
    || proposal.capability !== "metric_query" || proposal.mode !== "execute") return false;
  if (error.corrections?.some(correction => correction.field !== "metrics")) return false;
  if (["remove", "clear"].some(group => Object.keys((proposal[group] ?? {}) as object).length > 0)) return false;
  const set = proposal.set as Record<string, unknown> | undefined;
  if (!set || Object.keys(set).some(name => !["metrics", "organizations", "time", "selection", "operation"].includes(name))) return false;
  const operation = set.operation as {kind?: unknown} | undefined;
  return operation === undefined || operation?.kind === "value";
}

export function analysisAttemptSource(originalMessage: string, proposal: Record<string, unknown>): NonNullable<TurnAttempt["analysisHandoff"]> {
  return {sourceQuestion: originalMessage, sourceFingerprint: createHash("sha256")
    .update(JSON.stringify({originalMessage, proposal})).digest("hex")};
}

/** 引用只能转交同一已接纳请求；错误指标参数从不作为固定指标或分析选择的来源。 */
export async function loadAnalysisHandoff(request: AskMetricRequestContext, fromAttemptRef: string): Promise<AnalysisAttemptHandoff> {
  const saved = await request.frames?.getTurnAttempt?.(fromAttemptRef);
  const source = saved?.analysisHandoff;
  if (!saved || saved.ownerId !== request.actor.id || saved.sessionId !== request.sessionId
    || saved.turnId !== request.operationId || saved.requestId !== request.requestId || saved.promptFingerprint !== request.promptFingerprint
    || !source || source.sourceQuestion !== request.originalMessage
    || source.sourceFingerprint !== analysisAttemptSource(request.originalMessage, saved.proposal).sourceFingerprint) {
    throw new BusinessInputError("ANALYSIS_HANDOFF_UNAVAILABLE", "$attempt", "分析交接引用不属于本次已接纳请求，请使用当前回执或明确创建新目标。");
  }
  const proposal = structuredClone(saved.proposal);
  if (proposal.base === "current" || proposal.base && typeof proposal.base === "object"
    && typeof (proposal.base as {frameId?: unknown}).frameId !== "string") {
    throw new BusinessInputError("ANALYSIS_HANDOFF_UNAVAILABLE", "$attempt", "原交接没有固定历史来源，不能按后来焦点重新继承；请明确选择原业务来源。");
  }
  const set = (proposal.set ?? {}) as Record<string, unknown>;
  return {base: proposal.base as AnalysisAttemptHandoff["base"],
    scope: Object.fromEntries(["organizations", "time", "selection", "operation"]
      .filter(name => Object.hasOwn(set, name)).map(name => [name, structuredClone(set[name])])),
    originalMessage: source.sourceQuestion, sourceFingerprint: source.sourceFingerprint, proposal};
}

export function turnAttempt(input: Omit<TurnAttempt, "attemptRef">): TurnAttempt {
  const digest = createHash("sha256").update(JSON.stringify(input)).digest("hex");
  return {...structuredClone(input), attemptRef: `attemptRef:${digest}`};
}

/** 重试只替换明确纠正的字段，失败提案中其它变化和原来源从不可变快照恢复。 */
export function correctTurnAttempt(proposal: Record<string, unknown>, patch: Record<string, unknown>): Record<string, unknown> {
  if (proposal.capability !== patch.capability) throw new BusinessInputError("TURN_ATTEMPT_CAPABILITY_MISMATCH", "$attempt", "纠错必须保留原业务能力。");
  const changed = new Set<string>();
  for (const group of ["set", "remove", "clear", "retain"]) {
    const fields = Array.isArray(patch[group]) ? patch[group] as string[] : Object.keys((patch[group] ?? {}) as object);
    for (const name of fields) {
      if (changed.has(name)) throw new BusinessInputError("TURN_ATTEMPT_DUPLICATE_FIELD", name, "同一纠错字段只能声明一种操作。");
      changed.add(name);
    }
  }
  if (!changed.size) throw new BusinessInputError("TURN_ATTEMPT_CORRECTION_REQUIRED", "$attempt", "请只提交需要纠正的字段，已保存的其他变化无需重填。");
  const result = structuredClone(proposal);
  for (const group of ["set", "remove", "clear", "retain"]) {
    if (group === "clear" || group === "retain") {
      const prior = (result[group] ?? []) as string[];
      result[group] = [...prior.filter(name => !changed.has(name)), ...((patch[group] ?? []) as string[])];
    } else {
      const prior = (result[group] ?? {}) as Record<string, unknown>;
      result[group] = {...Object.fromEntries(Object.entries(prior).filter(([name]) => !changed.has(name))), ...((patch[group] ?? {}) as object)};
    }
    if (Object.keys(result[group] as object).length === 0) delete result[group];
  }
  return result;
}
