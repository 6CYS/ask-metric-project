import {readFile} from "node:fs/promises";
import {fileURLToPath} from "node:url";

export interface AnalysisCatalogMetric {
  code: string; dimension: string; base_code: string; base_name: string; business_label: string;
  aliases: string[]; name: string; source: {sheet: string; cell: string};
}
interface AnalysisCatalog {
  schema_version: 1; source_sha256: string; source_name: string; relationships_verified: boolean;
  metrics: AnalysisCatalogMetric[];
  groups: Array<{label: string; base_code: string | null; base_name: string | null; context_heading: string; source: {sheet: string; cell: string}; calculation_formula: null}>;
  warnings: unknown[];
  conflicted_codes?: string[];
}
const cache = new Map<string, Promise<AnalysisCatalog>>();
export function loadAnalysisCatalog(path = fileURLToPath(new URL("../config/metric-analysis-catalog.json", import.meta.url))): Promise<AnalysisCatalog> {
  let pending = cache.get(path);
  if (!pending) {
    pending = readFile(path, "utf8").then(text => {
      const data = JSON.parse(text) as AnalysisCatalog;
      if (data.schema_version !== 1 || !Array.isArray(data.metrics) || !Array.isArray(data.groups)
        || data.metrics.some(item => !item.code || !item.name || !item.dimension || !Array.isArray(item.aliases))) throw new Error("ANALYSIS_CATALOG_INVALID");
      return data;
    });
    cache.set(path, pending);
  }
  return pending;
}

function score(metric: AnalysisCatalogMetric, keyword: string): number {
  if (!keyword) return 1;
  if (metric.code === keyword) return 1000;
  if (metric.name === keyword) return 500;
  const words = [metric.business_label, metric.base_name, metric.name, ...metric.aliases];
  if (words.some(word => word === keyword)) return 100;
  if (words.some(word => word.includes(keyword))) return 50;
  const grams = Array.from(keyword).slice(0, -1).map((char, i) => char + Array.from(keyword)[i + 1]);
  return grams.filter(gram => words.some(word => word.includes(gram))).length;
}

/** 同相关度内轮转家族，并优先尚未展示的口径；不让表格行序占满主题首页。 */
function diversify(matches: Array<{metric: AnalysisCatalogMetric; score: number}>) {
  const result: typeof matches = [];
  const basisCounts = new Map<string, number>();
  for (const relevance of [...new Set(matches.map(item => item.score))]) {
    const families = new Map<string, typeof matches>();
    for (const item of matches.filter(item => item.score === relevance)) {
      const key = item.metric.base_code;
      const family = families.get(key) ?? [];
      family.push(item); families.set(key, family);
    }
    while ([...families.values()].some(items => items.length)) {
      for (const family of families.values()) {
        if (!family.length) continue;
        const counts = family.map(item => basisCounts.get(item.metric.dimension) ?? 0);
        const index = counts.indexOf(Math.min(...counts));
        const [item] = family.splice(index, 1);
        result.push(item!);
        basisCounts.set(item!.metric.dimension, (basisCounts.get(item!.metric.dimension) ?? 0) + 1);
      }
    }
  }
  return result;
}

/** 树只提供分组与口径；可执行性、名称、单位仍由实时正式目录复核。 */
export async function exploreAnalysisCatalog(input: {keyword: string; basis?: string; limit?: number; page?: number}, path?: string) {
  const data = await loadAnalysisCatalog(path);
  const matches = diversify(data.metrics.map(metric => ({metric, score: score(metric, input.keyword.trim())}))
    .filter(item => item.score > 0 && (!input.basis || item.metric.dimension === input.basis))
    .sort((a, b) => b.score - a.score));
  const limit = Math.min(input.limit ?? 12, 30);
  const page = input.page ?? 1;
  if (!Number.isInteger(page) || page < 1 || !Number.isInteger(limit) || limit < 1) throw new Error("ANALYSIS_CATALOG_PAGE_INVALID");
  const offset = (page - 1) * limit;
  const hasMore = offset + limit < matches.length;
  return {source: {name: data.source_name, sha256: data.source_sha256},
    dimensions: [...new Set(matches.map(item => item.metric.dimension))],
    groups: data.groups.filter(group => group.label?.includes(input.keyword) || matches.some(item => item.metric.base_code === group.base_code))
      .map(group => ({...group, ...(group.base_code && data.conflicted_codes?.includes(group.base_code) ? {status: "definition_conflict"} : {})})),
    total: matches.length, page, page_size: limit, has_more: hasMore, next_page: hasMore ? page + 1 : null,
    items: matches.slice(offset, offset + limit).map(item => ({...item.metric,
      definition_conflict: data.conflicted_codes?.includes(item.metric.code) ?? false})),
    warnings: data.warnings,
    relationships_verified: data.relationships_verified,
    notice: "分组不证明可加总或因果关系；无公式节点不能自动计算。指标值及单位取正式工具回执。"};
}
