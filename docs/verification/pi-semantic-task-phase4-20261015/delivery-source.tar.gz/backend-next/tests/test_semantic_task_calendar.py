from datetime import date

import pytest

from ask_metric.application.field_resolution import resolve_date_field, source_calendar_constraints
from ask_metric.api.routes.business_context import ResolveFieldRequest
from pydantic import ValidationError


@pytest.mark.parametrize("expression,start,end", [
    ("2026年1月末至2月末", "2026-01-31", "2026-02-28"),
    ("2024年1月末至2月末", "2024-01-31", "2024-02-29"),
    ("2025年12月末至2026年2月末", "2025-12-31", "2026-02-28"),
    ("2026-1-1至2026-2-1", "2026-01-01", "2026-02-01"),
    ("2026年1月至2月末", "2026-01-01", "2026-02-28"),
])
def test_calendar_preserves_qualified_endpoints(expression, start, end):
    assert resolve_date_field(expression, date(2026, 10, 14))["value"] == {"start": start, "end": end}


def test_date_failure_distinguishes_unsupported_from_invalid_calendar():
    assert resolve_date_field("上个业务结算日", date(2026, 10, 14))["metadata"]["reason"] == "unsupported_expression"
    assert resolve_date_field("2026年2月30日", date(2026, 10, 14))["metadata"]["reason"] == "invalid_calendar"


def test_original_calendar_scan_keeps_whole_range_and_relative_obligation():
    source = source_calendar_constraints("查询甲行2026年1月末至2月末的余额", date(2026, 10, 14))
    assert source == {"ranges": [{"start": "2026-01-31", "end": "2026-02-28"}], "unresolved": []}
    assert source_calendar_constraints("查甲行近5年的余额", date(2026, 10, 14))["unresolved"] == ["近5年"]


@pytest.mark.parametrize("expression", ["近5年", "最近五年", "过去5年"])
def test_recent_years_proposes_pinned_calendar_choices(expression):
    result = resolve_date_field(expression, date(2026, 10, 14))
    assert result["status"] == "ambiguous"
    assert [item["metadata"]["calendar"] for item in result["candidates"]] == [
        {"start": "2021-10-14", "end": "2026-10-14"},
        {"start": "2021-01-01", "end": "2025-12-31"},
    ]


@pytest.mark.parametrize("expression,start,end", [
    ("滚动5年，截至今天", "2021-10-14", "2026-10-14"),
    ("最近5个完整年度", "2021-01-01", "2025-12-31"),
])
def test_explicit_year_scope_has_one_meaning(expression, start, end):
    expected = {"start": start, "end": end}
    assert resolve_date_field(expression, date(2026, 10, 14))["value"] == expected
    assert source_calendar_constraints(f"查询甲行{expression}的余额", date(2026, 10, 14))["ranges"] == [expected]


def test_field_expression_length_matches_public_semantic_contract():
    assert ResolveFieldRequest(entity="metric", raw_values=["甲" * 4000]).raw_values[0] == "甲" * 4000
    with pytest.raises(ValidationError):
        ResolveFieldRequest(entity="metric", raw_values=["甲" * 4001])


@pytest.mark.parametrize("expression", ["2026年5月30日当日", "2026-05-30当天", "2026年5月30日这一天"])
def test_single_date_deictic_suffix_preserves_calendar(expression):
    assert resolve_date_field(expression, date(2026, 10, 14))["value"] == {"start": "2026-05-30", "end": "2026-05-30"}


def test_deictic_suffix_cannot_hide_range_or_invalid_day():
    assert resolve_date_field("2026年2月30日当日", date(2026, 10, 14))["metadata"]["reason"] == "invalid_calendar"
    assert resolve_date_field("2026年5月30日当日或次日", date(2026, 10, 14))["status"] != "resolved"
