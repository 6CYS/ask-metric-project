# 无 Docker 离线打包部署

部署说明由发布人员与压缩包、校验文件并列交付。本页面向 Linux 原生离线安装；源码本地启动见 [本地部署指南](../../docs/本地部署指南.md)。现有库按已审核的 GoldenDB 迁移版本升级，不能仅沿用历史“无需迁移”的结论；数据湖映射见 [DATA_LAKE_DEPLOY.md](DATA_LAKE_DEPLOY.md)。

这一套部署方式面向不能安装 Docker、但可运行 Linux、Python、systemd 和 Nginx 的行内环境。
构建产物包含 Vue 静态文件、后端项目及其全部 Linux Python wheel、GoldenDB 独立迁移链、
安装/校验/回滚脚本，不包含 `.env`、数据库口令、模型密钥或业务数据。

当前支持的目标组合：

- Linux x86_64（`linux-x86_64`）；
- Linux ARM64/aarch64（`linux-aarch64`）；
- CPython 3.11、3.12 或 3.13，推荐 3.12。

行内安全策略禁止 Bash 脚本时，使用 `--payload-only` 构建不含运维 Shell 脚本或自动数据库
写入动作的载荷包。再传入锁定并校验过的 Python standalone 归档，即可
把 Python 解释器和预装依赖一并放入最终包；目标机无需预装 Python 3.12。详细步骤见
[`KYLIN_PAYLOAD_DEPLOY.md`](KYLIN_PAYLOAD_DEPLOY.md)。

离线包与目标 CPU 架构、glibc 基线和 Python 次版本绑定。普通模式要求目标机预装相同次版本
Python；自带运行时模式不使用目标机 Python，也不创建 `venv`。构建机需要 Python、Node.js 22.12+（22.x）或 24.x/npm
和可访问 PyPI 或内部 Python 镜像源；目标机不访问互联网。Python 依赖由 `constraints.txt`
固定版本；升级依赖时必须重新执行后端全量测试和目标架构的打包检查。

指标匹配使用 HanLP 独立 Trie、pypinyin 和 RapidFuzz，不部署外部 HanLP 服务或神经模型。
构建器会将只发布源码的 HanLP 轻量依赖预制为纯 Python wheel，再下载目标架构依赖；内网目标机只离线安装。
使用 `--dependency-wheelhouse` 时必须提供包含这些新增依赖的已验证集合。版本、已测架构和边界见
[指标算法匹配与离线部署](../../docs/metric-matching.md)。

## 1. 构建离线包

在仓库根目录执行。版本号只能包含字母、数字、点、下划线和短横线：

```powershell
python deploy/package/build_bundle.py `
  --version 20260824.1 `
  --platform linux-x86_64 `
  --python-version 3.12
```

ARM64 目标机使用：

```powershell
python deploy/package/build_bundle.py `
  --version 20260824.1 `
  --platform linux-aarch64 `
  --python-version 3.12
```

麒麟 V10 x86_64 自带 Python 运行时包使用锁定文件中的归档和 SHA-256：

```powershell
python deploy/package/build_bundle.py `
  --version intranet-kylin-20260825-r2-selfcontained `
  --platform linux-x86_64 `
  --python-version 3.12 `
  --payload-only `
  --python-runtime-archive deploy/.cache/python-build-standalone/cpython-3.12.14+20260814-x86_64-unknown-linux-gnu-install_only_stripped.tar.gz `
  --python-runtime-sha256 5acfa3e9ba26b51ae161c83aff278da915b590d22373a424b2ba55b8afe91fcc
```

产物位于 `deploy/artifacts/`：

```text
ask-metric-<version>-<platform>-py<python>.tar.gz
ask-metric-<version>-<platform>-py<python>.tar.gz.sha256
```

构建器会重新执行 `npm ci` 和前端生产构建，并强制使用 Nginx 同源 `/api` 路由，不继承
开发机 `.env.local` 中的后端地址。构建器也会扫描最终静态文件；只要发现 `localhost` 或
`127.0.0.1` 后端 URL 就立即失败。仅在已单独确认 `frontend-vue/dist/` 是本次源码生成的
情况下，才可用 `--skip-frontend-build` 跳过编译，产物扫描仍不会跳过。

构建器同样在暂存副本上构建智能助手服务（`agent-service/`，pi agent harness）：执行
`npm ci`、`tsc` 构建并裁剪为生产依赖后随包携带 `node_modules`，目标机离线运行。仅在已
确认 `agent-service/dist/` 与生产依赖就绪时可用 `--skip-agent-build` 跳过。

目标机没有可用 Node.js 22.12+ 时，按 `node-runtime-lock.json` 中的官方归档与 SHA-256
内嵌 Node runtime（归档需先行下载并通过外层校验）：

```powershell
python deploy/package/build_bundle.py `
  --version 20260824.1 `
  --platform linux-x86_64 `
  --python-version 3.12 `
  --node-runtime-archive deploy/.cache/node/node-v22.23.2-linux-x64.tar.gz `
  --node-runtime-sha256 b294a556e639d64338823920e5866c21c02741742d2e1529ee1a225c1ec9252a
```

## 2. 传输与校验

把 `.tar.gz` 和同名 `.sha256` 一起传到目标机，然后执行：

```bash
sha256sum -c ask-metric-20260824.1-linux-x86_64-py3.12.tar.gz.sha256
tar -xzf ask-metric-20260824.1-linux-x86_64-py3.12.tar.gz
cd ask-metric-20260824.1-linux-x86_64-py3.12
./ops/verify.sh
```

外层校验确认传输文件完整，`verify.sh` 校验包内每个文件。任一校验失败都不要继续安装。

## 3. 首次安装

默认安装位置如下：

```text
/opt/ask-metric/releases/<version>/   不可变版本目录
/opt/ask-metric/current               当前版本软链接
/etc/ask-metric/backend.env           跨版本保留的配置
/etc/ask-metric/agent.env             智能助手服务配置（跨版本保留）
/var/lib/ask-metric/runtime-config/    模型与提示词（跨版本保留）
/var/lib/ask-metric/                   其他跨版本运行数据和配置历史
/home/appuser/log/                     行内规范日志目录（物理目录，禁止软链接）
```

首次运行安装器会离线创建版本目录和配置模板，但检测到模板占位值后不会激活或启动（退出码 2 为预期结果）。智能助手服务的 `agent.env` 独立生成与检查：存在未替换占位值时仅跳过 `ask-metric-agent` 服务激活并给出警告，不影响后端与前端安装：

```bash
sudo ./ops/install.sh
sudo vi /etc/ask-metric/backend.env
sudo vi /etc/ask-metric/agent.env   # 可选；启用智能助手时配置模型网关与密钥
# 完成下文的密钥、配置路径、权限核对后，再执行：
sudo ./ops/install.sh
```

`AGENT_COMPACT_TURN_ARGS` 是旧配置兼容项，不再选择新会话工具格式。
`AGENT_BUSINESS_PROTOCOL=semantic_v2` 为新会话默认入口，已贯通查询、复合目标、排名、覆盖、计算和结果驱动规划。
阶段4按用户要求先切换本地并交付手测，自动稳定性验收尚未完成；模板默认值变化不代表已部署生产。
修改此配置后重启 agent-service，只影响随后创建的会话。已有会话、原生 operation 及恢复始终沿用保存的协议；
新协议 Session 使用增量领域值，无需本次数据库迁移。回到 fixed_v1 默认值仍须运行支持两种 Session 的新版服务；
不能用旧二进制恢复 semantic_v2 的 READY 或在途操作。详细范围与回退见[阶段4说明](../../docs/pi-semantic-task/implementation-phase4.md)。

模型超时使用两阶段配置：`AGENT_MODEL_FIRST_RESPONSE_TIMEOUT_MS` 控制首次有效输出等待，
`AGENT_MODEL_STREAM_IDLE_TIMEOUT_MS` 控制开始输出后的空闲时限，默认均为 30000 毫秒。
非空文本、思考和工具参数输出均刷新空闲计时，响应头、开始事件和空增量不算进展。
持续输出没有固定总时长中断；未首次输出时可按重试配置重试，输出后停滞不会自动重放请求。
新空闲变量未设置或为空白时，旧 `AGENT_MODEL_TIMEOUT_MS` 兼容作为空闲时限后备。
环境文件跨版本保留，升级后重启 Agent 服务生效，无需数据库或会话迁移；回滚旧版本前必须核对环境文件，
旧版本会恢复 `AGENT_MODEL_TIMEOUT_MS` 的总时限语义，且不识别新空闲变量。

`agent.env` 中的 `AGENT_MODEL_API_KEY` 支持与后端一致的 `ENC[SM4:v1:...]` 密文，复用
`/etc/ask-metric/config-sm4.key` 主密钥；Nginx 会把同源 `/agent-api/` 反代到回环地址的
agent-service（SSE 流式，已关闭代理缓冲）。不需要智能助手时使用 `--no-agent` 跳过。

必须配置两个不同用途的数据库账号：

- `APP_DATABASE_URL`：应用元数据、账号、会话和审计库的读写账号；
- `QUERY_DATABASE_URL`：指标业务库的只读账号，数据库侧也应强制只读权限。

URL 中的特殊字符必须做百分号编码。配置文件不得放入发布包或提交到 Git。安装器默认创建
`askmetric` 系统账号，安装并启动 `ask-metric-backend.service`，并写入
`/etc/nginx/conf.d/ask-metric-backend.conf`。如果行内已有统一反向代理或服务管理平台，可执行：

模型地址、路径、模型名及认证方式可在系统管理员的“智能配置”页面维护。首次安装会从发布包
初始化运行时配置，后续升级不会覆盖已有配置。要允许页面保存、回滚和连接测试，还需在
`backend.env` 中设置 `MODEL_ADMIN_WRITE_ENABLED=true` 与独立的 `MODEL_ADMIN_TOKEN`；各模型
密钥只保存在该环境文件中，不写入运行时 JSON。

```bash
./ops/install.sh \
  --install-root /data/ask-metric \
  --state-root /data/ask-metric-state \
  --config /data/ask-metric-config/backend.env \
  --python python3.12 \
  --http-port 8080 \
  --backend-port 8010 \
  --service-name ask-metric-goldendb-backend \
  --no-systemd --no-nginx
```

这种模式不会创建系统服务。完成下文配置后，在有读取权限的终端或行内部署平台中加载环境文件并启动：

```bash
set -a
. /data/ask-metric-config/backend.env
set +a
cd /data/ask-metric/current/backend
/data/ask-metric/current/venv/bin/python -m uvicorn ask_metric.main:app \
  --host 127.0.0.1 --port 8010 --no-access-log
```

### 首次配置必须补齐的步骤

第一次安装尚未创建 `current` 链接，生成密钥和加密配置时应使用已暂存版本：

```bash
# 在 sudo/root 运维终端执行；替换为本次 manifest.json 中的 release。
RELEASE_ROOT=/opt/ask-metric/releases/<本次版本>
umask 077
# 仅第一次创建，已有主密钥必须复用，不能在升级时重新生成。
test -f /etc/ask-metric/config-sm4.key || openssl rand -hex 16 > /etc/ask-metric/config-sm4.key
chown root:askmetric /etc/ask-metric/config-sm4.key
chmod 0640 /etc/ask-metric/config-sm4.key
"$RELEASE_ROOT/venv/bin/python" "$RELEASE_ROOT/backend/scripts/generate_sm2_keypair.py" \
  --output /etc/ask-metric/sm2-initial.env
"$RELEASE_ROOT/venv/bin/python" -m ask_metric encrypt-config \
  --key-file /etc/ask-metric/config-sm4.key
```

加密命令通过隐藏输入读取一个值，重复执行以加密数据库 URL、JWT、追问签名密钥、SM2 私钥及模型凭据；两个签名密钥须各自随机生成，不使用示例常量。可在上述 `umask 077` 环境中用 `openssl rand -hex 48 > /etc/ask-metric/jwt-initial.secret` 生成临时签名文件，并用另一个新文件生成追问签名值；不得覆盖已有密钥。SM2 私钥取新生成文件中的值；导入验证后按现场流程清理临时明文文件。已有部署不要再运行私钥生成命令。

环境模板必须补齐 `ASK_METRIC_CONFIG_SM4_KEY_FILE`、所有启用服务的配置和日志标识；不用 Nacos/SSO 时关闭相应开关，并移除未启用项残留的 `<...>` 占位值。Shell 运维脚本会 source 环境文件，含空格的值（如 `APP_NAME`）应加引号，不能把未经转义的真实密码写成 Shell 语句。

**目录区别：**解压包是 `backend/runtime/`，`install.sh` 安装后是 `current/backend/`。模板还被载荷部署共用，编辑 `/etc/ask-metric/backend.env` 时需按当前安装方式显式校正以下路径，不能机械照抄 `current/backend/runtime/`：

```dotenv
MODEL_CONFIG_PATH=/var/lib/ask-metric/runtime-config/model-config.json
PROMPT_CONFIG_PATH=/var/lib/ask-metric/runtime-config/prompts.json
SEMANTIC_CONFIG_PATH=/opt/ask-metric/current/backend/config/semantic-config.json
MODEL_SECRET_ENV_PATH=/etc/ask-metric/backend.env
CONFIG_HISTORY_DIR=/var/lib/ask-metric/config-history
```

自定义安装路径时对应替换。持久状态由服务账号写入；首次安装后核对权限：

```bash
sudo chown -R askmetric:askmetric /var/lib/ask-metric
sudo chown root:askmetric /etc/ask-metric/backend.env
sudo chmod 0640 /etc/ask-metric/backend.env
```

### 行内日志配置

生产配置必须启用 `LOG_FILE_ENABLED=true`，并将 `LOG_DIRECTORY` 设置为物理目录；规范默认值为
`/home/appuser/log`。应用分别写入 `app.log`、`summary.log` 和 `alert.log`，单文件默认达到
50MB或跨日时转储到日期目录，默认仅保留最近3天。安装器会拒绝把 `--log-root` 指向软链接，
并为 systemd 服务授予该目录写权限；自定义 `--log-root` 时必须同时修改 `LOG_DIRECTORY`。

`LOG_DATA_CENTER_ID` 和 `LOG_ZONE_ID` 必须替换为行方资源配置值。调用方可传递
`X-Global-Business-Track-No`、`X-Service-Call-Seq-No`、`X-Service-Code`、`X-Trace-ID`、
`X-Segment-ID`、`X-Span-ID` 和 `X-Parent-Span-ID`；缺失的流水与链路标识由后端生成并在响应头
返回。`APP_NODE_CODE`、`APP_IDC`、`APP_UNIT` 必须分别使用主机 `/etc/profile` 中的
`App_Node_Code`、`App_IDC`、`App_Unit`；确实取不到时才使用规范兜底值 `8888888`、`888`、`8`。
全局流水号和SpanID分别采用 `G`、`R` 开头的六段40位格式；上游合法值保持透传，每次模型或
SSO下游调用生成新的SpanID并记录 SUBSTART/SUBEND。系统管理员可通过
`PUT /api/v1/logging/level` 动态调整日志级别，无需重启应用。

## 4. 数据库迁移

安装和版本切换永远不会自动迁移数据库。先生成 SQL，提交审核：

```bash
sudo /opt/ask-metric/current/ops/migrate.sh \
  --sql /tmp/ask-metric-goldendb-migration.sql
```

确认目标是 `APP_DATABASE_URL` 对应的应用库、SQL 已审批并完成备份后，才显式执行：

```bash
sudo /opt/ask-metric/current/ops/migrate.sh --apply
```

脚本只使用 `alembic-goldendb.ini` 与 `alembic_goldendb/`。

迁移完成后，受限环境可通过 Python 运维入口检查三类数据源并同步目录：

```bash
python /opt/ask-metric/current/ops/intranet_deploy.py database-check \
  --config /etc/ask-metric/backend.env
python /opt/ask-metric/current/ops/intranet_deploy.py sync-catalogs \
  --config /etc/ask-metric/backend.env --dry-run
python /opt/ask-metric/current/ops/intranet_deploy.py sync-catalogs \
  --config /etc/ask-metric/backend.env
```

When replacing external-test catalogs for the first time, back up the GoldenDB
application schema and run the guarded replacement command. It first synchronizes
both authoritative lake catalogs and refuses cleanup when either result is empty or
has errors. It deletes application `metric_values`, removes unsynchronized metric and
organization terms, retains aliases for synchronized metric codes, and preserves
users/conversations/tasks/audit data. Test users on obsolete organization codes are
reassigned to the synchronized head-office code (default `000`):

```bash
python /opt/ask-metric/current/ops/intranet_deploy.py initialize-synchronized-catalogs \
  --config /etc/ask-metric/backend.env \
  --user-org-code 000 \
  --apply --confirm INITIALIZE_SYNCHRONIZED_CATALOGS
```

Use a different `--user-org-code` only after confirming that code exists in the
synchronized organization catalog. This command is for the one-time test-data
replacement, not the recurring catalog synchronization job.

升级不再加载或合并 SQL 模板；现场旧文件保留供整包回退。已有 `backend.env` 不会自动
改写，切换 SIT 数据湖前必须人工补齐并复核 `QUERY_DATABASE_DIALECT=inceptor`、目录连接和
`SIT_*` 配置。

### 首个登录账户

迁移、正式目录同步成功后，选择目录中已启用的机构编号创建管理员，密码使用交互输入：

```bash
sudo /opt/ask-metric/current/venv/bin/python \
  /opt/ask-metric/current/backend/scripts/create_local_user.py \
  --config /etc/ask-metric/backend.env \
  --username <登录名> --display-name <显示名> --org-code <有效机构编码> --role-code SYSTEM_ADMIN
```

同名账户会被更新并使原会话失效；不要在升级时重复创建已有管理员。无内置默认密码。

### 升级已有实例

保留旧 release、配置及数据库备份。新包校验后执行 `install.sh`，所有自定义安装根、状态目录、端口和服务名参数须与原实例一致。需要增量迁移时先完成 DBA 审核与执行，再验收新版本。

当前安装器使用 `systemctl enable --now`，对已经运行的服务不等同于重启；切换版本后需要显式执行：

```bash
sudo systemctl restart ask-metric-backend.service
sudo nginx -t
sudo systemctl reload nginx
```

使用独立端口如 `--http-port 18080` 可避免抢占已有 80 端口站点；同机多个实例还必须使用不同的服务名、后端端口、安装目录、配置、状态及日志目录。只修改 Web 端口不能实现全部隔离。

## 5. 验证和回滚

服务启动后检查存活和应用库就绪状态（默认后端端口 8010；自定义端口时向 healthcheck.sh 传入对应 URL）：

```bash
/opt/ask-metric/current/ops/healthcheck.sh
systemctl status ask-metric-backend.service
```

升级安装新版本时旧 release 不会被删除。默认回滚到最近的另一个版本：

```bash
sudo /opt/ask-metric/current/ops/rollback.sh
```

也可以指定版本：

```bash
sudo /opt/ask-metric/current/ops/rollback.sh --release 20260824.1
```

回滚只切换应用文件，不反向修改数据库。若新版本包含不可向后兼容的迁移，应在变更评审中
单独准备数据库回退方案。

## 安全边界

- 安装器不读取构建机的 `backend-next/.env`，也不把它复制进离线包；
- 安装器不自动运行 Alembic，数据库变更必须显式执行；
- `QUERY_DATABASE_URL` 必须使用数据库侧只读账号；
- 不要在真实行内库上运行开发测试；
- 本文维护原生部署；已有 [腾讯云 Compose 部署](../cloud-next/README.md) 是另一套依赖预置双库的编排，不应混用两者的目录与初始化命令。

归因功能已整体移除（含旧原型与受治理归因通道），升级原试验环境须同步前后端并合并持久提示词；详见 [后端升级说明](../../backend-next/README.md#归因功能退出与升级)。已有数据库迁移链不回退。

## 启动初始化与就绪检查

后端启动即分批初始化指标目录向量。`/health` 返回 200 而 `/health/ready` 返回 503 时，
可访问 `/api/v1/query-readiness` 查看初始化状态和进度；初始化完成后才允许问数和启动测试。
失败时前端显示提示，后台每隔 30 秒自动重试。大目录需按实际模型吞吐等待，不要因初始化尚未完成
反复重启或自动回滚；用于进程存活检测的探针应访问 `/health`。缓存仍为进程内缓存，每个 worker
分别预热且重启后重建。容量、批次参数和故障说明见 [后端向量缓存说明](../../backend-next/README.md#指标目录内存向量缓存)。

### Pi 通用多轮业务上下文升级

本次需配套发布后端、Agent 和前端，不新增依赖或数据库迁移。先排空活动回合并备份 Agent 数据目录，
先确保后端字段解析接口可用，再切换 Agent/前端。业务 Frame 与结果引用保存在原有 Pi JSONL 目录，
沿用单数据根单写实例约束。不要清理或改写历史文件。

回退前同样排空活动回合并恢复配套版本。旧版本不理解新 Frame 工具协议，回退后新建会话继续，保留旧结果供查看。
完整契约及验证说明见 [Pi 通用多轮业务上下文](../../docs/pi-business-context.md)。


### 查询契约 v2 配套升级

后端 `/api/v1/basic-queries` 已移除 `selection=ranking`、顶层 `order/top_n` 及空数组缺省范围；
实际机构编码不再代表待展开的上级。Agent 与后端必须整包配套升级；旧协议请求明确拒绝。
暂停新操作，排空并对账在途任务、备份 Agent 状态后再切换；不得以清空会话绕过未知结果。
旧执行工具会话只读保留，重新查询须新建会话；当前 Frame 会话继续按新契约执行。

集合查询依赖 `org_terms.parent_org_code/hierarchy_level` 的正式层级，先在授权环境运行现有
机构目录同步的 dry-run，核对唯一省级根、法人行和支行父链，再按原审批流程实际同步。
本次未修改生产目录；原先仅同步名称的环境须完成此步骤。缺配置时明确返回配置错误，
不能靠机构名称猜层级。参数与操作说明见 [数据湖配置](../../backend-next/docs/sit-data-lake.md)。

不新增数据库字段、迁移或依赖。后端渠道集成仍有真实旧语义服务依赖，本次保留该渠道，
不宣称已移除全部旧 HTTP 入口。回退时排空新版本任务，保留新旧状态，恢复整套旧包及匹配配置；
不得让旧进程续跑新契约 Frame。新旧包联动、目录同步与真实数据库榜单须在授权环境验收。
本地验证与未验收项见 [交付记录](../../docs/verification/query-intent-v2-delivery.md)。


### SQL builder 统一生成

业务取数与数据覆盖统一使用随发布包交付的 SQLGlot builder，已删除模板文件和管理页面。
升级不再复制、注册或加载持久 SQL 模板；旧 `QUERY_SQL_ENGINE`、`QUERY_TEMPLATE_CONFIG_PATH`、
`SQL_RESOURCE_DIR` 配置不再生效，可在维护配置时移除。`SIT_*` 字段映射、数据库方言、只读账号和
SQL 安全校验继续生效。模型/提示词的配置与历史回滚功能保留。

安装与升级不会删除现场旧 SQL 文件或配置历史，便于整包回退。新版本不执行这些文件；
此前仅通过模板编辑发布的定制逻辑需迁到 builder 并验证后再升级，不能期望旧模板继续生效。

### 指标结构化识别与排名方向配套升级

指标识别改为“基础指标 + 口径”结构（规则见 [指标匹配方案](../../docs/metric-matching.md)），依赖迁移
`0005_metric_source_structure`（源字段），不新增表。按第 4 节生成 SQL、审核并执行迁移后，运行正式指标目录同步回填源字段
（先 `--dry-run`），确认目标指标 `source_metric_code/base_name/value_basis` 已填充。

同义词仍只在“指标术语”页面维护；基础指标别名与口径别名由后端从同义词自动推导，启动预热时建好识别索引，
运行中每 60 秒检查目录版本并在后台重建，无需重启。可用只读脚本检查同义词写法冲突：
`python /opt/ask-metric/current/scripts/check_metric_synonyms.py --config /etc/ask-metric/backend.env`。

未完成回填时只剩完整名称匹配与保守确认，不能识别口径省略、缺口径追问。
排名契约同时由 `operation.order` 改为 `operation.position=top|bottom`，名次类指标（单位“名”）的方向由后端决定；
Agent、后端须配套升级，旧 Frame 中的排名条件需在新回合重建。回退时整包回退，回填字段可保留。


### semantic_v2 阶段3候选

阶段3使用同一版本2协议贯通复合目标、排名、覆盖、计算和结果驱动分析。须同时更新Agent及Backend（新增inspect-goal/admit-plan与签名来源校验），无需业务数据库迁移。默认值仍为fixed_v1，不在阶段3自动切换。候选Session不能降级交给阶段2代码续跑；先停止在途操作、保留原生Session和源码快照，再按协议绑定回退。详见[阶段3实施说明](../../docs/pi-semantic-task/implementation-phase3.md)。
