import { afterEach, beforeEach, describe, expect, it, vi } from "vitest"
import { createSSRApp } from "vue"
import { renderToString } from "@vue/server-renderer"
import BackendNextChatPanel from "../../../src/components/chat/BackendNextChatPanel.vue"
import type { AgentSessionDetail, AgentStreamEvent } from "@/lib/agentApi"
import * as agentApi from "@/lib/agentApi"

vi.mock("@/components/chat/CatalogQuestionComposer.vue", () => ({ default: { render: () => null } }))
vi.mock("@/composables/useAuth", () => ({useAuth:()=>({user:{value:{id:"synthetic-user",role_code:"USER",org_name:"合成机构"}}})}))

const notice = "本轮模型响应未完成；已取得的步骤结果仍可查看，请重试未完成部分。"
const detail: AgentSessionDetail = {
  session_id: "offline-test", created_at: "", running: false, operation_id: null,
  messages: [
    { role: "user", text: "查询测试指标", timestamp: 1 },
    { role: "assistant", business_protocol: "frame_v1", text: notice, error: notice, timestamp: 2 },
  ],
}
type Message = { id: string; role: string; content: string; status?: string; failureNotice?: string; nativeAnswer?: boolean }
type PanelState = {
  activeConversationId: string
  activeConversationStorageKey: string
  handleNewConversation(): void
  loadHistory(expectedUserId: string): Promise<void>
  conversations: Array<{ id: string; serverId: string; messages: Message[]; running: boolean }>
  conversationFromDetail(detail: AgentSessionDetail): { messages: Message[] }
  handleStreamEvent(conversationId: string, assistantId: string, event: AgentStreamEvent): void
  failMessage(conversationId: string, assistantId: string, error: unknown): void
}
let state: PanelState
afterEach(()=>{vi.restoreAllMocks();vi.unstubAllGlobals()})

beforeEach(async () => {
  const app = createSSRApp(BackendNextChatPanel)
  app.mixin({ created() {
    if (this.$options.__name === "BackendNextChatPanel") {
      state = (this.$ as unknown as { setupState: PanelState }).setupState
    }
  } })
  await renderToString(app)
  state.conversations = [{ id: "c", serverId: "offline-test", messages: [{ id: "a", role: "assistant", content: "", status: "pending", nativeAnswer: true }], running: true }]
})

describe("断网失败消息的实际页面处理链", () => {
  it("历史列表迟到不能把用户刚新建的空草稿切回旧会话", async()=>{
    const stored = new Map<string,string>([[state.activeConversationStorageKey,"old-session"]])
    vi.stubGlobal("localStorage",{getItem:(k:string)=>stored.get(k)??null,setItem:(k:string,v:string)=>stored.set(k,v),removeItem:(k:string)=>stored.delete(k)})
    let release!: (value:Awaited<ReturnType<typeof agentApi.listAgentSessions>>)=>void
    vi.spyOn(agentApi,"listAgentSessions").mockImplementation(()=>new Promise(resolve=>{release=resolve}))
    const getSession=vi.spyOn(agentApi,"getAgentSession")
    const pending=state.loadHistory("synthetic-user")
    state.handleNewConversation()
    const draft=state.activeConversationId
    release({items:[{session_id:"old-session",created_at:"",last_active_at:"",running:false}]})
    await pending
    expect(state.activeConversationId).toBe(draft)
    expect(getSession).not.toHaveBeenCalled()
  })
  it("刷新读取历史只产生一个失败提示", () => {
    const messages = state.conversationFromDetail(detail).messages
    expect(messages).toHaveLength(2)
    expect(messages[1]).toMatchObject({ content: notice, status: "error" })
  })

  it("失败快照、重复终态及重连快照不会叠加提示", () => {
    const terminal: AgentStreamEvent = { type: "run_terminal", run_status: "failed", answer_status: "failed", error_code: "assistant_error" }
    const snapshot: AgentStreamEvent = { type: "snapshot", ...detail }
    state.handleStreamEvent("c", "a", snapshot)
    state.handleStreamEvent("c", "a", terminal)
    state.handleStreamEvent("c", "a", terminal)
    state.failMessage("c", "a", new Error("Failed to fetch"))
    expect(state.conversations[0]?.messages[1]).toMatchObject({ content: notice, status: "error" })
    state.handleStreamEvent("c", "a", snapshot)
    state.handleStreamEvent("c", "a", terminal)
    expect(state.conversations[0]?.messages[1]?.content).toBe(notice)
    // 重新观察已结束的 operation 时，服务端会发 idle，不能覆盖快照中的失败状态。
    state.handleStreamEvent("c", "a", { type: "run_terminal", run_status: "idle", answer_status: "idle" })
    expect(state.conversations[0]?.messages[1]).toMatchObject({ content: notice, status: "error" })
  })

  it("没有快照时，请求中断的重复处理也只提示一次", () => {
    state.failMessage("c", "a", new Error("Failed to fetch"))
    state.failMessage("c", "a", new Error("Failed to fetch"))
    expect(state.conversations[0]?.messages[0]?.content).toBe("暂时无法连接问数服务。请检查网络连接，稍后重新查询。")
  })

  it("没有失败快照时，重复终态仍保留部分正文且只追加一次说明", () => {
    state.conversations[0]!.messages[0]!.content = "已经取得的步骤说明"
    const terminal: AgentStreamEvent = { type: "run_terminal", run_status: "failed", answer_status: "failed", error_code: "MODEL_STREAM_FAILED" }
    state.handleStreamEvent("c", "a", terminal)
    state.handleStreamEvent("c", "a", terminal)
    expect(state.conversations[0]?.messages[0]?.content).toBe("已经取得的步骤说明\n模型响应流中断，本次查询未完成。请稍后重新查询。")
  })

  it("连续两轮都失败时，各自显示一次，不跨问题去重", () => {
    const repeated = { ...detail, messages: [...detail.messages, ...detail.messages] }
    const messages = state.conversationFromDetail(repeated).messages
    expect(messages).toHaveLength(4)
    expect(messages.filter(message => message.role === "assistant").map(message => message.content)).toEqual([notice, notice])
  })

  it("正常回答保持原文", () => {
    const normal: AgentSessionDetail = { ...detail, messages: [detail.messages[0]!, { role: "assistant", business_protocol: "frame_v1", text: "测试正文\n测试正文", timestamp: 2 }] }
    expect(state.conversationFromDetail(normal).messages[1]).toMatchObject({ content: "测试正文\n测试正文", status: "done" })
  })

  it("同一轮重试成功后刷新历史清除旧失败状态", () => {
    const recovered: AgentSessionDetail = { ...detail, messages: [...detail.messages,
      { role: "assistant", business_protocol: "frame_v1", text: "重试后查询完成", timestamp: 3 },
    ] }
    const messages = state.conversationFromDetail(recovered).messages
    expect(messages).toHaveLength(2)
    expect(messages[1]).toMatchObject({ content: "重试后查询完成", status: "done" })
    expect(messages[1]?.failureNotice).toBeUndefined()
  })
})

describe("复合任务结果展示", () => {
  const results = [1, 2].map(index => ({kind: "metric_query_structured", status: "succeeded", task_id: `task-${index}`, result_id: `result-${index}`,
    row_count: 1, columns: ["metric_value"], rows: [{metric_value: String(index)}], public_answer: `目标${index}完成`}))
  it("实时批次与刷新快照都保留两个正式结果", () => {
    const bundle = {kind: "semantic_results", status: "succeeded", results}
    state.handleStreamEvent("c", "a", {type: "tool_end", tool: "resolve_business_turn", tool_call_id: "multi", details: bundle, isError: false})
    const live = state.conversations[0]!.messages[0] as Message & {taskIds?: string[]; queryResults?: unknown[]}
    expect(live.taskIds).toEqual(["task-1", "task-2"])
    expect(live.queryResults).toHaveLength(2)
    const restored = state.conversationFromDetail({...detail, messages: [detail.messages[0]!, {role: "assistant", business_protocol: "frame_v1", text: "两项目标完成", timestamp: 2},
      {role: "tool", tool: "resolve_business_turn", tool_call_id: "multi", details: bundle, is_error: false, timestamp: 3}]}).messages[1] as Message & {taskIds?: string[]; queryResults?: unknown[]}
    expect(restored.taskIds).toEqual(["task-1", "task-2"])
    expect(restored.queryResults).toHaveLength(2)
  })
})


it("新增复合结果展示后，单目标正式正文仍只渲染一次", async () => {
  const app = createSSRApp(BackendNextChatPanel)
  app.mixin({ created() {
    if (this.$options.__name !== "BackendNextChatPanel") return
    const panel = (this.$ as unknown as {setupState: PanelState}).setupState
    panel.conversations = [{id: "single", serverId: "offline-test", messages: [{id: "answer", role: "assistant", content: "", status: "pending"}], running: false}]
    panel.handleStreamEvent("single", "answer", {type: "tool_end", tool: "resolve_business_turn", tool_call_id: "single-result", isError: false,
      details: {kind: "metric_query_structured", status: "succeeded", task_id: "single-task", result_id: "single-result", row_count: 0, columns: [], rows: [], public_answer: "单目标唯一正文标记"}})
    panel.conversations[0]!.messages[0]!.status = "done"
  } })
  const html = await renderToString(app)
  expect(html.split("单目标唯一正文标记")).toHaveLength(2)
})
