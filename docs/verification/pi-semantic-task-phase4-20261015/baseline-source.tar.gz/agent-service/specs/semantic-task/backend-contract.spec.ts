import {execFileSync} from "node:child_process";
import {resolve} from "node:path";
import {afterEach, expect, it} from "vitest";
import {SemanticPlanService} from "../../src/semantic-task/planService.js";
import {SemanticTaskService} from "../../src/semantic-task/service.js";
import {createSemanticExecuteTool} from "../../src/semantic-task/tools.js";
import {semanticFeedback, semanticPublicAnswer} from "../../src/semantic-task/feedback.js";
import {runTool} from "../../src/tools/testUtils.js";
import type {BackendClient} from "../../src/backendClient.js";
import {fixture, proposal} from "./fixtures.js";
const clean: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of clean.splice(0)) await close();});
const cache = new Map<string, any>();
function python(payload: unknown): any {
  const input = JSON.stringify(payload);
  if (cache.has(input)) return structuredClone(cache.get(input));
  const output = JSON.parse(execFileSync(resolve("../backend-next/.venv/bin/python"), [resolve("scripts/semantic-task-fixture.py")],
    {input, encoding: "utf8", timeout: 30000, env: {PATH: "/usr/bin:/bin:/opt/homebrew/bin"}}));
  expect(output.ok, output.message).toBe(true); cache.set(input, output.value); return output.value;
}
async function setup() {
  const f = await fixture(); clean.push(f.close);
  const request = (id: string, message: string) => ({...f.request(id, message), backend: {
    ...f.backend,
    inspectBusinessGoal: async (question: string, business_date: string, _options?: unknown, reference_year?: number) => python({action: "inspect", question, business_date, reference_year}),
    admitSemanticPlan: async (payload: unknown) => python({action: "admit", payload}),
    resolveBusinessField: async (entity: string, raw: string[], _options?: unknown, year?: number, source?: unknown) => python({action: "resolve", entity, raw, year, source}),
    matchMetricQuestion: async (question: string) => python({action: "mentions", question}),
  } as unknown as BackendClient});
  return {...f, request};
}
const base = [
  {action: "set", field: "organizations", value: "合成机构甲"},
  {action: "set", field: "metrics", value: "经营收益金额当日数"},
  {action: "set", field: "time", value: "2026年5月31日"},
] as const;
it("真实目录解析补全模型遗漏的已明确指标口径，编译请求通过后端来源校验和SQL", async () => {
  const f = await setup(), request = f.request("exact", "查询合成机构甲2026年5月31日的经营收益金额当日数");
  const result = await new SemanticTaskService(request).resolve(proposal(base.map(operation => operation.field === "metrics" ? {...operation, value: "经营收益金额"} : operation)));
  expect(result.status).toBe("ready");
  await runTool(createSemanticExecuteTool(), {task_ref: result.task!.ref, target_ref: result.task!.target.ref}, request);
  expect(python({action: "query", spec: f.backend.basicQueries.mock.calls[0]![0]}).rows).toHaveLength(1);
}, 15000);
it("真实目录按既有高置信纠错确定身份，原句绑定通过独立后端核验", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("typo", "查询合成机构甲2026年5月31日的经营收益金融当日数")).resolve(proposal(base.map(operation =>
    operation.field === "metrics" ? {...operation, value: "经营收益金额"} : operation)));
  expect(first.status).toBe("ready");
  const request = f.request("explicit", "查询合成机构甲2026年5月31日的经营收益金额");
  const pending = await new SemanticTaskService(request).resolve(proposal([...base]));
  expect(pending.status).toBe("needs_user");
  const confirmation = f.request("choice", "指标用经营收益金额当日数");
  const next = await new SemanticTaskService(confirmation).resolve(proposal([{action: "confirm", field: "metrics", value: "经营收益金额当日数"}], {kind: "current"}));
  expect(next.status).toBe("ready");
  await runTool(createSemanticExecuteTool(), {task_ref: next.task!.ref, target_ref: next.task!.target.ref}, confirmation);
  expect(python({action: "query", spec: f.backend.basicQueries.mock.calls[0]![0]}).rows).toHaveLength(1);
}, 15000);
it("真实相对年日历反馈公开完整选项，确认后保留全部数据点口径", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("years", "查询合成机构甲近5年的经营收益金额当日数全部数据")).resolve(proposal([
    ...base.filter(operation => operation.field !== "time"), {action: "set", field: "time", value: "近5年"}, {action: "set", field: "selection", value: "全部数据"},
  ]));
  expect(first.status).toBe("needs_user");
  expect(semanticPublicAnswer(semanticFeedback(first.task, first.status))).toContain("最近5个完整年度");
  const next = await new SemanticTaskService(f.request("year-choice", "日期用第二项")).resolve(proposal([{action: "confirm", field: "time", value: "第二项"}], {kind: "current"}));
  expect(next.status).toBe("ready");
  expect(next.task!.target.fields.selection!.resolvedValue).toBe("all_in_range");
}, 15000);
it("指标片段误填日期直接澄清真正缺少的日期，不进入日期修复循环", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("missing", "查询合成机构甲的经营收益金额当日数")).resolve(proposal(base.map(operation =>
    operation.field === "time" ? {...operation, value: "当日数"} : operation)));
  expect(first.status).toBe("needs_user");
  expect(first.task!.issues.map(issue => issue.code)).toEqual(["FIELD_REQUIRED"]);
  expect(first.task!.target.fields.metrics!.resolvedValue).toMatchObject({codes: ["SYNTH_M:D"]});
  expect(f.backend.basicQueries).not.toHaveBeenCalled();
}, 15000);

it("待修提案从单查询改为双查询时按步骤类型绑定，日期及算式保持整笔义务", async () => {
  const f = await setup(), request = f.request("split-repair", "查询合成机构甲2026年5月31日与2026年6月30日的经营收益金额当日数，计算六月减五月的差额");
  const service = new SemanticPlanService(request);
  const first = proposal([...base.filter(op => op.field !== "time"), {action: "set", field: "time", value: "2026年5月31日与2026年6月30日"}, {action: "set", field: "selection", value: "当日数"}], {kind: "new"}, "calculate");
  first.targets.push({source: {kind: "new"}, operations: [{action: "set", field: "calculation", value: '`2026年6月30日经营收益金额当日数` - `2026年5月31日经营收益金额当日数`'}]});
  const pending = await service.resolve(first); expect(pending.status).toBe("needs_interpretation");
  const next = proposal(base.map(op => op.field === "metrics" ? {...op, value: "经营收益"} : op), {kind: "new"}, "calculate");
  next.targets.push({source: {kind: "new"}, operations: base.map(op => op.field === "time" ? {...op, value: "2026年6月30日"} : op)}, first.targets[1]!);
  const ready = await service.resolve(next);
  expect({status: ready.status, issues: ready.issues}).toEqual({status: "ready", issues: []});
  const plan = (await request.semanticTasks!.plan(ready.state.task_ref!))!;
  expect(plan.steps.filter(step => step.kind === "query")).toHaveLength(2);
  expect(plan.steps.filter(step => step.kind === "calculation")).toHaveLength(1);
  expect(f.backend.basicQueries).not.toHaveBeenCalled();
  for (const target of ready.state.targets.filter(target => target.kind === "query")) await runTool(createSemanticExecuteTool(), {task_ref: ready.state.task_ref, target_ref: target.target_ref}, request);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(2);
  for (const [spec] of f.backend.basicQueries.mock.calls) expect(python({action: "query", spec}).rows).toHaveLength(1);
}, 25000);
it("历史来源可派生两个独立日期目标，原任务不被覆盖，本轮日期必须完整核验", async () => {
  const f = await setup(), original = f.request("history-base", "查询合成机构甲2026年5月31日的经营收益金额当日数");
  const first = await new SemanticPlanService(original).resolve(proposal([...base], {kind: "new"}, "prepare"));
  expect(first.status).toBe("prepared");
  const source = {kind: "reference" as const, task_ref: first.state.task_ref!, target_ref: first.state.targets[0]!.target_ref};
  const request = f.request("history-split", "查询2026年5月31日与2026年6月30日的原指标");
  const input = proposal([{action: "set", field: "time", value: "2026年5月31日"}], source);
  input.targets.push({source, operations: [{action: "set", field: "time", value: "2026年6月30日"}]});
  const result = await new SemanticPlanService(request).resolve(input);
  expect({status: result.status, issues: result.issues}).toEqual({status: "ready", issues: []});
  expect(new Set((await request.semanticTasks!.plan(result.state.task_ref!))!.steps.map(step => step.id)).size).toBe(2);
  expect((await request.semanticTasks!.plan(first.state.task_ref!))!.steps[0]!.targetRef).toBe(source.target_ref);
}, 25000);
it("年份省略的历史追问沿用规范来源年份，独立准入使用相同年份事实", async () => {
  const f = await setup(), request = f.request("year-base", "查询合成机构甲2025年5月31日的经营收益金额当日数");
  const first = await new SemanticPlanService(request).resolve(proposal(base.map(op => op.field === "time" ? {...op, value: "2025年5月31日"} : op), {kind: "new"}, "prepare"));
  expect(first.status).toBe("prepared");
  const followup = f.request("year-followup", "日期换成6月30日");
  const result = await new SemanticPlanService(followup).resolve(proposal([{action: "set", field: "time", value: "6月30日"}], {kind: "current"}));
  expect({status: result.status, issues: result.issues}).toEqual({status: "ready", issues: []});
  const plan = (await followup.semanticTasks!.plan(result.state.task_ref!))!, task = (await followup.semanticTasks!.get(plan.steps[0]!.taskRef!))!;
  expect(task.target.fields.time!.resolvedValue).toEqual({start: "2025-06-30", end: "2025-06-30"});
}, 15000);
it("指标口径缩写误放selection时由同一目录解析器重建身份，不能向用户追问已明确口径", async () => {
  const f = await setup(), request = f.request("basis-placement", "分析合成机构甲2026年5月31日的经营收益金额当日数与经营收益金额较同期，先查询当日数，拿到结果后继续较同期");
  const input = proposal(base.map(op => op.field === "metrics" ? {...op, value: "经营收益金额"} : op), {kind: "new"}, "analyze");
  input.targets[0]!.operations.push({action: "set", field: "selection", value: "当日"});
  const result = await new SemanticPlanService(request).resolve(input);
  expect({status: result.status, issues: result.issues}).toEqual({status: "ready", issues: []});
  const plan = (await request.semanticTasks!.plan(result.state.task_ref!))!, task = (await request.semanticTasks!.get(plan.steps[0]!.taskRef!))!;
  expect(task.target.fields.metrics!.resolvedValue).toMatchObject({codes: ["SYNTH_M:D"]});
}, 15000);


it("模型拆错同一榜单可重组未获准提案，旧提案保留且不可单独执行", async () => {
  const f = await setup(), request = f.request("rank-regroup", "合成机构甲和合成机构乙2026年5月31日的经营收益金额当日数，前1名");
  const service = new SemanticPlanService(request), wrong = proposal([...base]);
  wrong.targets.push({source: {kind: "new"}, operations: base.map(op => op.field === "organizations" ? {...op, value: "合成机构乙"} : op)});
  const blocked = await service.resolve(wrong);
  expect(blocked.status).toBe("needs_interpretation");
  const old = blocked.state.targets[1]!.target_ref;
  const merged = await service.resolve(proposal(base.map(op => op.field === "organizations" ? {...op, value: "合成机构甲和合成机构乙"} : op)));
  expect({status: merged.status, issues: merged.issues}).toEqual({status: "ready", issues: []});
  const plan = (await request.semanticTasks!.plan(merged.state.task_ref!))!;
  expect(plan.steps).toHaveLength(1); expect(plan.supersededSteps).toHaveLength(1);
  await expect(service.locate(plan.ref, old)).rejects.toMatchObject({issue: {code: "REFERENCE_INVALID"}});
  await runTool(createSemanticExecuteTool(), {task_ref: plan.ref, target_ref: merged.state.targets[0]!.target_ref}, request);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(1);
  expect(f.backend.basicQueries.mock.calls[0]![0]).toMatchObject({org_codes: ["SYNTH_O1", "SYNTH_O2"], operation: {kind: "ranking", top_n: 1}});
}, 20000);

it("离散日期的分析义务由多个成功来源联合覆盖，不能要求单个来源包含全部日期", async () => {
  const f = await setup(), request = f.request("analysis-dates", "分析合成机构甲2026年5月31日与2026年6月30日的经营收益金额当日数");
  const service = new SemanticPlanService(request), input = proposal([...base], {kind: "new"}, "analyze");
  input.targets.push({source: {kind: "new"}, operations: base.map(op => op.field === "time" ? {...op, value: "2026年6月30日"} : op)});
  const ready = await service.resolve(input); expect(ready.status).toBe("ready");
  await runTool(createSemanticExecuteTool(), {task_ref: ready.state.task_ref, target_ref: ready.state.targets[0]!.target_ref}, request);
  const partial = (await request.semanticTasks!.plan(ready.state.task_ref!))!;
  expect(partial.completion).toBe("partial"); expect(partial.issues[0]!.code).toBe("ANALYSIS_EVIDENCE_PENDING");
  await runTool(createSemanticExecuteTool(), {task_ref: ready.state.task_ref, target_ref: ready.state.targets[1]!.target_ref}, request);
  const full = (await request.semanticTasks!.plan(ready.state.task_ref!))!;
  expect(full.completion).toBe("full"); expect(full.issues).toEqual([]);
}, 20000);
