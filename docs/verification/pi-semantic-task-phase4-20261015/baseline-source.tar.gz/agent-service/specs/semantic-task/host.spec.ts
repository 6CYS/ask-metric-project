import {mkdtempSync, rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {afterEach, expect, it, vi} from "vitest";
import {BACKGROUND_CONTEXT} from "@earendil-works/pi-agent-core";
import {createAssistantMessageEventStream, createModels, createProvider, type AssistantMessage, type Model, type ProviderStreams} from "@earendil-works/pi-ai";
import {HarnessHost} from "../../src/harnessHost.js";
import {NativeSessionStore} from "../../src/nativeSessions.js";
import {createAskMetricTools} from "../../src/tools/index.js";
import {TEST_ACTOR} from "../../src/tools/testUtils.js";
import {projectEntries} from "../../src/sessionProjection.js";
import type {AgentServiceConfig} from "../../src/config.js";
import type {BackendClient} from "../../src/backendClient.js";
import {complete, proposal, syntheticBackend, addPlanBackend} from "./fixtures.js";

type Reply = string | Array<{name: string; args: unknown}>;
const cleanup: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of cleanup.splice(0).reverse()) await close(); vi.restoreAllMocks();});
function modelFixture(script: Reply[]) {
  let calls = 0;
  const contexts: unknown[] = [], payloads: unknown[] = [];
  const model: Model<"openai-completions"> = {id: "semantic-faux", name: "semantic-faux", api: "openai-completions", provider: "semantic-faux",
    baseUrl: "http://faux.invalid", reasoning: false, input: ["text"], contextWindow: 128000, maxTokens: 8192,
    cost: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0}};
  const respond: ProviderStreams["streamSimple"] = (current, context, options) => {
    contexts.push(structuredClone(context));
    const reply = script[Math.min(calls++, script.length - 1)]!;
    const message: AssistantMessage = {role: "assistant", content: typeof reply === "string" ? [{type: "text", text: reply}]
      : reply.map((call, i) => ({type: "toolCall", id: `semantic-call-${calls}-${i}`, name: call.name, arguments: call.args as Record<string, unknown>})),
      api: current.api, provider: current.provider, model: current.id, stopReason: typeof reply === "string" ? "stop" : "toolUse", timestamp: Date.now(),
      usage: {input: 100, output: 20, totalTokens: 120, cacheRead: 0, cacheWrite: 0, cost: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0}}};
    const stream = createAssistantMessageEventStream();
    queueMicrotask(async () => {
      const payload = {tools: context.tools?.map(tool => ({type: "function", function: tool})) ?? []};
      payloads.push(await options?.onPayload?.(payload, current) ?? payload);
      stream.push({type: "start", partial: message});
      stream.push({type: "done", reason: message.stopReason === "toolUse" ? "toolUse" : "stop", message});
      stream.end(message);
    });
    return stream;
  };
  const models = createModels();
  models.setProvider(createProvider({id: model.provider, name: "semantic-faux", models: [model],
    auth: {apiKey: {name: "synthetic", resolve: async () => ({auth: {}})}}, api: {stream: respond, streamSimple: respond}}));
  return {models, model, contexts, payloads, calls: () => calls};
}
function config(dir: string): AgentServiceConfig {
  return {host: "127.0.0.1", port: 0, backendBaseUrl: "http://faux.invalid", backendTimeoutMs: 1000, dataDir: dir,
    businessProtocol: "semantic_v2", compaction: {enabled: false, reserveTokens: 1000, keepRecentTokens: 1000},
    modelRetry: {enabled: false, maxRetries: 0, baseDelayMs: 1}, model: {baseUrl: "http://faux.invalid", name: "semantic-faux", apiKey: "", authHeader: "Authorization", authPrefix: "Bearer",
      userMessageSuffix: "", extraBody: {}, contextWindow: 128000, maxTokens: 8192}};
}
async function setup(script: Reply[], protocol: "fixed_v1" | "semantic_v2" = "semantic_v2") {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const dir = mkdtempSync(join(tmpdir(), "semantic-native-"));
  const model = modelFixture(script), backend = syntheticBackend(); addPlanBackend(backend);
  const store = new NativeSessionStore(dir);
  const host = new HarnessHost({...config(dir), businessProtocol: protocol}, () => model, store, createAskMetricTools());
  cleanup.push(async () => {await host.close(); await store.close(); rmSync(dir, {recursive: true, force: true});});
  const session = await host.createSession(TEST_ACTOR);
  const run = (id: string, message: string) => host.runPrompt(session, {protocol_version: 3, request_id: id, message}, {actor: TEST_ACTOR, backend: backend as unknown as BackendClient});
  return {dir, model, backend, store, host, session, run};
}
it("真实Pi宿主自动消费许可、交付正文和表格；发送只暴露唯一v2Schema", async () => {
  const f = await setup([[{name: "resolve_business_turn", args: proposal(complete())}], "已完成查询，请查看结果。"]);
  await f.run("exact", "查询合成机构甲2025年末的合成指标甲");
  expect(f.model.calls()).toBe(2);
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(1);
  const payload = JSON.stringify(f.model.payloads);
  expect(payload).toContain('"const":2');
  expect(payload).not.toContain("mentionIndexes"); expect(payload).not.toContain("fieldIntents");
  const entries = await f.session.lane.findEntries({order: "oldestFirst"}, BACKGROUND_CONTEXT);
  const projected = projectEntries(entries);
  expect(projected.some(message => message.role === "assistant" && message.text === "已完成查询，请查看结果。")).toBe(true);
  expect(projected.some(message => message.role === "tool" && (message.details as {kind?: string}).kind === "metric_query_structured")).toBe(true);
});
it("缺项澄清直接来自已保存任务，结束后不额外请求模型", async () => {
  const f = await setup([[{name: "resolve_business_turn", args: proposal(complete().filter(op => op.field !== "time"))}]]);
  await f.run("missing", "查询合成机构甲的合成指标甲");
  expect(f.model.calls()).toBe(1); expect(f.backend.basicQueries).not.toHaveBeenCalled();
  const messages = projectEntries(await f.session.lane.findEntries({order: "oldestFirst"}, BACKGROUND_CONTEXT));
  expect(messages.some(message => message.role === "assistant" && message.text.includes("日期范围") && message.text.includes("合成指标甲"))).toBe(true);
});
it("重复形状错误作为正式反馈收束，SDK不转换版本，不发第三次模型请求", async () => {
  const args = {...proposal(complete()), protocol_version: "2"};
  const f = await setup([[{name: "resolve_business_turn", args}], [{name: "resolve_business_turn", args}], "不应请求此响应"]);
  await f.run("bad-shape", "查询合成机构甲2025年末的合成指标甲");
  expect(f.model.calls()).toBe(2); expect(f.backend.basicQueries).not.toHaveBeenCalled();
  const entries = await f.session.lane.findEntries({order: "oldestFirst"}, BACKGROUND_CONTEXT);
  const feedback = entries.flatMap(entry => entry.type === "message" && entry.message.role === "toolResult" ? [entry.message.details] : []) as Array<{status?: string}>;
  expect(feedback.map(item => item.status)).toEqual(["invalid_input", "failed"]);
});
it("同一模型批次两份resolve在任何业务执行前被阻止", async () => {
  const f = await setup([[{name: "resolve_business_turn", args: proposal(complete())}, {name: "resolve_business_turn", args: proposal(complete())}]]);
  await f.run("batch", "查询合成机构甲2025年末的合成指标甲");
  expect(f.backend.basicQueries).not.toHaveBeenCalled();
});
it("重开后协议与任务条件保持，修改日期不重新解释已确认指标", async () => {
  const f = await setup([[{name: "resolve_business_turn", args: proposal(complete(), {kind: "new"}, "prepare")}]]);
  await f.run("prepare", "先整理合成机构甲2025年末的合成指标甲，暂不查询");
  const id = f.session.sessionId;
  await f.host.close(); await f.store.close();
  const model = modelFixture([[{name: "resolve_business_turn", args: proposal([{action: "set", field: "time", value: "2024年末"}], {kind: "current"})}], "已更新并查询。"]);
  const store = new NativeSessionStore(f.dir);
  const host = new HarnessHost({...config(f.dir), businessProtocol: "fixed_v1"}, () => model, store, createAskMetricTools());
  cleanup.push(async () => {await host.close(); await store.close();});
  const reopened = await host.openSession(TEST_ACTOR, id);
  expect(reopened?.businessProtocol).toBe("semantic_v2");
  await host.runPrompt(reopened!, {protocol_version: 3, request_id: "modify", message: "日期改成2024年末"}, {actor: TEST_ACTOR, backend: f.backend as unknown as BackendClient});
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(1);
  const spec = f.backend.basicQueries.mock.calls[0]![0] as {time: {start: string}; metric_codes: string[]};
  expect(spec.time.start).toBe("2024-12-31"); expect(spec.metric_codes).toEqual(["M1"]);
});
it("开启候选默认值不会把已有固定协议Session切换到新Schema", async () => {
  const f = await setup(["占位"], "fixed_v1"), id = f.session.sessionId;
  await f.host.close(); await f.store.close();
  const model = modelFixture(["占位"]), store = new NativeSessionStore(f.dir);
  const host = new HarnessHost(config(f.dir), () => model, store, createAskMetricTools());
  cleanup.push(async () => {await host.close(); await store.close();});
  expect((await host.openSession(TEST_ACTOR, id))?.businessProtocol).toBe("fixed_v1");
});
it("整批自动执行两项目标，正式证据保留两个结果身份", async () => {
  const input = proposal(complete());
  input.targets.push({source: {kind: "new"}, operations: complete().map(op => op.field === "organizations" ? {...op, value: "合成机构乙"} : op.field === "metrics" ? {...op, value: "合成指标乙"} : {...op, value: "2024年末"})});
  const f = await setup([[{name: "resolve_business_turn", args: input}], "已完成两个目标。"]);
  await f.run("multi", "查合成机构甲2025年末的合成指标甲；合成机构乙2024年末的合成指标乙");
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(2);
  const entries = await f.session.lane.findEntries({order: "oldestFirst"}, BACKGROUND_CONTEXT);
  const native = entries.flatMap(entry => entry.type === "message" && entry.message.role === "toolResult" && entry.message.toolName === "resolve_business_turn" ? [entry.message] : [])[0]!;
  const block = native.content.find(block => block.type === "text");
  expect(block?.type === "text" ? JSON.parse(block.text) : undefined).toEqual(native.details);
  const messages = projectEntries(await f.session.lane.findEntries({order: "oldestFirst"}, BACKGROUND_CONTEXT));
  expect(messages.some(item => item.role === "tool" && (item.details as {kind?: string})?.kind === "semantic_results")).toBe(true);
});

it("查询仅读取上下文后不能用计划文字结束，仍在同一Pi循环修正动作", async () => {
  const f = await setup([[{name: "business_context_read", args: {}}], "我打算去查询。", [{name: "resolve_business_turn", args: proposal(complete())}], "查询完成。"]);
  await f.run("context-only", "查询合成机构甲2025年末的合成指标甲");
  expect(f.backend.basicQueries).toHaveBeenCalledTimes(1);
});
