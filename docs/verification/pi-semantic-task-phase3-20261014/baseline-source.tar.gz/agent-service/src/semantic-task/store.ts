import {randomUUID} from "node:crypto";
import {BACKGROUND_CONTEXT, setValue, value, type Session} from "@earendil-works/pi-agent-core";
import type {ResolvedField, MentionResolution} from "../business-context/types.js";
import type {SemanticOperation, SemanticSource} from "./protocol.js";

const NS = "askmetric.semantic.v2";
export interface SemanticIssue {code: string; category: string; message: string; remediation: "pi" | "user" | "retry" | "stop"; field?: string}
export interface SemanticTarget {
  ref: string; fields: Record<string, ResolvedField>; pending: Record<string, string>;
  status: "draft" | "blocked" | "ready" | "executing" | "succeeded" | "failed" | "unknown";
  frameId?: string; coverage?: {question: string; mentions: MentionResolution[]; removed: MentionResolution[]};
  metricSource?: string;
  pendingChanges?: Record<string, {operations: SemanticOperation[]; baseline?: ResolvedField; sourceMessage: string}>;
}
export interface SemanticTask {
  ref: string; owner: string; revision: number; target: SemanticTarget; originalMessage: string;
  status: "active" | "waiting_input" | "waiting_dependency" | "completed" | "stopped";
  completion: "unmet" | "partial" | "full"; issues: SemanticIssue[];
  permit?: {operationId: string; revision: number; frameId: string; digest: string; actor: string; consumed: boolean};
}
export interface SemanticTurn {
  operationId: string; originalMessage: string; businessDate: string; admittedTask?: string; boundTask?: string;
  source?: SemanticSource; baseline?: SemanticTarget; operations: Record<string, SemanticOperation[]>;
}
interface Index {version: number; focus?: string; order: string[]}
const indexAddress = value<Index>(NS, "index");
const taskAddress = (ref: string) => value<SemanticTask>(NS, `task/${ref}`);
const turnAddress = (id: string) => value<SemanticTurn>(NS, `turn/${id}`);
const referenceAddress = (ref: string) => value<{task: string; target: SemanticTarget}>(NS, `reference/${ref}`);
export const semanticRef = () => randomUUID();

/** 领域状态只保存于同一Pi Session；CAS和许可消费不另建会话或后台循环。 */
export class NativeSemanticTaskStore {
  constructor(private readonly session: Session) {}
  async index() {return structuredClone((await this.session.getValue(indexAddress, BACKGROUND_CONTEXT))?.value ?? {version: 0, order: []});}
  async get(ref: string) {return structuredClone((await this.session.getValue(taskAddress(ref), BACKGROUND_CONTEXT))?.value);}
  async turn(id: string) {return structuredClone((await this.session.getValue(turnAddress(id), BACKGROUND_CONTEXT))?.value);}
  async reference(ref: string) {return structuredClone((await this.session.getValue(referenceAddress(ref), BACKGROUND_CONTEXT))?.value);}
  async admit(operationId: string, originalMessage: string) {
    return this.session.mutate(async (tx, context) => {
      const prior = (await tx.getValue(turnAddress(operationId), context))?.value;
      if (prior) {
        if (prior.originalMessage !== originalMessage) throw new Error("SEMANTIC_TURN_CONFLICT");
        return structuredClone(prior);
      }
      const index = (await tx.getValue(indexAddress, context))?.value;
      const businessDate = new Intl.DateTimeFormat("en-CA", {timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit"}).format(new Date());
      const turn: SemanticTurn = {operationId, originalMessage, businessDate, operations: {}, ...(index?.focus ? {admittedTask: index.focus} : {})};
      await tx.commit([setValue(turnAddress(operationId), turn)], context);
      return turn;
    }, BACKGROUND_CONTEXT);
  }
  async save(task: SemanticTask, expectedVersion: number, turn?: SemanticTurn, focus = true) {
    return this.session.mutate(async (tx, context) => {
      const index = (await tx.getValue(indexAddress, context))?.value ?? {version: 0, order: []};
      if (index.version !== expectedVersion) throw new Error("SEMANTIC_STATE_CONFLICT");
      const previous = (await tx.getValue(taskAddress(task.ref), context))?.value;
      if (previous && task.owner !== previous.owner) throw new Error("SEMANTIC_OWNER_CONFLICT");
      const next = {...index, version: index.version + 1, ...(focus ? {focus: task.ref} : {}),
        order: index.order.includes(task.ref) ? index.order : [...index.order, task.ref]};
      await tx.commit([setValue(indexAddress, next), setValue(taskAddress(task.ref), task),
        setValue(referenceAddress(task.target.ref), {task: task.ref, target: structuredClone(task.target)}),
        ...(turn ? [setValue(turnAddress(turn.operationId), turn)] : [])], context);
      return structuredClone(task);
    }, BACKGROUND_CONTEXT);
  }
  async context(limit = 20, cursor?: string) {
    const index = await this.index();
    const end = cursor ? index.order.indexOf(cursor) : index.order.length;
    if (end < 0 || !Number.isInteger(limit) || limit < 1 || limit > 50) throw new Error("SEMANTIC_HISTORY_CURSOR_INVALID");
    const start = Math.max(0, end - limit);
    const tasks = await Promise.all(index.order.slice(start, end).map(ref => this.get(ref)));
    return {current_task_ref: index.focus, next_cursor: start > 0 ? index.order[start] : null,
      tasks: tasks.filter((task): task is SemanticTask => !!task).map(task => ({
      task_ref: task.ref, target_ref: task.target.ref, status: task.status, completion: task.completion,
      goal: task.originalMessage, conditions: Object.fromEntries(Object.entries(task.target.fields).map(([field, value]) => [field,
        {status: value.resolutionStatus, expression: value.rawValue, ...(value.candidates ? {candidates: value.candidates.map(item => ({name: item.value}))} : {})}])),
      pending: task.target.pending,
    }))};
  }
}
