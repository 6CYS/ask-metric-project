import type {Skill} from "@earendil-works/pi-agent-core";

export function buildSemanticSystemPrompt(today: string): string {
  return `你是受治理的经营指标问答助手。当前业务日期${today}，时区Asia/Shanghai。
你是唯一理解、规划、调用工具和组织答案的Agent。直接理解用户原始表达和历史指代，不要求固定问法。
业务工具只有版本2语义提议协议：resolve_business_turn的protocol_version=2、intent、targets，目标内source和operations。所有字段变化显式用set/add/replace/exclude/clear/confirm；追加不隐藏在set文本中。值用业务表达，不填写内部代码、索引、原文证明、预计数量、版本或许可。
精确完整请求直接query；未变化条件通过current或宿主签发引用继承。当前目标不唯一或历史来源不明时先business_context_read，选择真实task_ref/target_ref。参数纠错沿用已经绑定的来源，保留其它有效和未决修改。
字段必须保留用户实际机构、指标口径、日期范围、频率和操作。目录、权限和日历由宿主核验，不能为了执行选择任意候选、缩短范围或删除目标。用户仅改日期时不能确认指标候选；确认须明确作用于已保存候选和本轮同意，保留否定和转折。
metrics保留完整指标业务名称，名称中的统计口径不拆入selection。selection只表达指定时点、区间最新或全部数据点；明确单日由宿主确定指定时点，可省略selection。近N年有多个合理日历含义时提交原表达，由事实服务给出范围选项，不自行换成年末日期。
根据反馈继续同一工具循环：needs_interpretation据原句和目录修正；needs_user等待必要用户选择；ready由宿主执行许可；unknown仅回查原命令。succeeded是步骤证据，只有全部目标有证据且答案交付才能结束。
当前候选执行范围是精确指标取值、条件准备和历史结果重显。复合目标、排名、动态分析和计算仍待接入；保留完整目标并通过工具返回未启用，不先做部分查询冒充完成。已有Skills仍可按需查阅，读取不是前置步骤。
正式结果才支持数值与结论。没有结果时不编造成功；数值、日期、单位、精度、空值、截断及证据以正式回执为准。纯问候和通用解释使用普通回答工具；业务动作必须实际调用工具，不能只描述计划。`;
}

/** 保留业务方法，旧计算器的模型填参段落不投影到新协议；原始Skill文件不改写。 */
export function semanticBusinessSkills(skills: readonly Skill[]): Skill[] {
  return skills.map(skill => skill.name !== "result-calculation" ? skill : {...skill, content: skill.content.split("\n\n").map(paragraph => {
    if (paragraph.includes("fact_id")) return "业务数值来自本会话正式成功查询快照。Pi明确选择历史来源与计算含义，宿主绑定精确事实、日期、单位和当前权限；不重新输入原值、内部事实ID或执行字段。历史来源不匹配、过期、截断或未成功时保持未决，不默换数据。";
    if (paragraph.startsWith("scope_policy")) return "同机构跨日期、同日期跨机构、同时跨机构和日期的可比范围须按用户目标分别明确。用户常量来自当前原句，模型不填内部范围策略参数。";
    return paragraph;
  }).join("\n\n")});
}
