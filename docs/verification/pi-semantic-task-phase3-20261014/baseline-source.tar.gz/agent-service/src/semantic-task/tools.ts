import {Type} from "@earendil-works/pi-ai";
import {Compile} from "typebox/compile";
import type {AgentHarnessTool, AgentToolResult} from "@earendil-works/pi-agent-core";
import type {AskMetricRequestContext} from "../requestContext.js";
import {createExecuteBusinessFrameTool, createReadBusinessResultTool, reconcileExecution} from "../tools/businessContext.js";
import {BusinessContextService} from "../business-context/service.js";
import {createCapabilities} from "../business-context/capabilities.js";
import {createFieldResolvers} from "../business-context/resolvers.js";
import {BackendApiError} from "../backendClient.js";
import {semanticParameters, prepareSemanticArguments} from "./protocol.js";
import {SemanticConflict, SemanticTaskService} from "./service.js";
import type {SemanticIssue, SemanticTask} from "./store.js";
import {semanticFeedback, type SemanticFeedback} from "./feedback.js";

type Tool = AgentHarnessTool<AskMetricRequestContext>;
const receipt = (feedback: SemanticFeedback, evidence?: AgentToolResult<unknown>): AgentToolResult<SemanticFeedback> => ({
  content: evidence?.content ?? [{type: "text", text: JSON.stringify(feedback)}],
  details: evidence?.details && typeof evidence.details === "object"
    ? {...feedback, state: {...feedback.state, evidence: evidence.details as Record<string, unknown>}} : feedback,
});
const refs = Type.Object({task_ref: Type.String({minLength: 1}), target_ref: Type.String({minLength: 1})}, {additionalProperties: false});
const checkRefs = Compile(refs);
const readSchema = Type.Object({cursor: Type.Optional(Type.String({minLength: 1})), limit: Type.Optional(Type.Integer({minimum: 1, maximum: 50}))}, {additionalProperties: false});
const errors = (error: unknown): SemanticFeedback => {
  const denied = error instanceof BackendApiError && [401, 403].includes(error.status)
    || error instanceof SemanticConflict && error.issue.category === "permission";
  const issue: SemanticIssue = error instanceof SemanticConflict ? error.issue : {code: denied ? "PERMISSION_DENIED" : "SEMANTIC_SERVICE_UNAVAILABLE",
    category: denied ? "permission" : "infrastructure", message: denied ? "当前身份无权继续此查询。" : "业务状态或事实服务暂不可用，原始问题已保存。", remediation: "stop"};
  return semanticFeedback(undefined, denied ? "denied" : error instanceof SemanticConflict ? "conflict" : "failed", [issue]);
};
export function createSemanticResolveTool(): Tool {
  return {name: "resolve_business_turn", label: "解析业务语义任务", description: "提交本轮完整语义提议。参数只有版本2、intent和目标operations；初始与修改共用动作。不构造目录编码、索引、原文证明或版本。精确完整请求可直接query；歧义按反馈修正或澄清。当前候选已接入query/prepare/reuse；其它能力保留目标并返回明确未启用。",
    parameters: semanticParameters, prepareArguments: prepareSemanticArguments,
    execute: async (_id, args, _update, request, _invocation, context) => {
      try {const resolution = await new SemanticTaskService(request, context.abortSignal).resolve(prepareSemanticArguments(args));
        return receipt(semanticFeedback(resolution.task, resolution.status, resolution.issues ?? resolution.task?.issues ?? []));}
      catch (error) {return receipt(error instanceof Error && error.message.startsWith("SEMANTIC_INPUT_SHAPE_INVALID")
        ? semanticFeedback(undefined, "invalid_input", [{code: "INPUT_SHAPE_INVALID", category: "input_shape", message: "工具参数不符合唯一版本2协议，请按Schema修正，原始业务目标已保留。", remediation: "pi"}]) : errors(error));}
    }};
}
export function createSemanticContextTool(): Tool {
  return {name: "business_context_read", label: "读取任务条件", description: "只读当前任务和最近历史任务，返回宿主签发task_ref/target_ref、已知条件和待解释项。读取不切焦点、不取数，不返回旧协议参数。", parameters: readSchema,
    execute: async (_id, args, _update, request) => {
      if (!request.semanticTasks) throw new Error("SEMANTIC_STORE_NOT_BOUND");
      const {cursor, limit} = args as {cursor?: string; limit?: number};
      const context = await request.semanticTasks.context(limit, cursor);
      return {content: [{type: "text", text: JSON.stringify(context)}], details: {protocol_version: 2, context}};
    }};
}
async function taskFor(request: AskMetricRequestContext, taskRef: string, targetRef: string) {
  const task = await request.semanticTasks?.get(taskRef);
  if (!task || task.owner !== request.actor.id || task.target.ref !== targetRef) throw new SemanticConflict({code: "REFERENCE_INVALID", category: "reference", message: "任务和目标引用不可读取或已修订，请重新读取上下文。", remediation: "pi"});
  return task;
}
export function createSemanticExecuteTool(): Tool {
  return {name: "execute_business_frame", label: "执行获准步骤", parameters: refs,
    prepareArguments: raw => {if (!checkRefs.Check(raw)) throw new Error("SEMANTIC_REFERENCE_SHAPE_INVALID"); return structuredClone(raw);},
    description: "只执行当前任务已签发许可的步骤。引用复制自版本2回执；宿主复核版本和权限，参数不含Frame编码、日期或SQL。结果未知仅回查原命令。",
    execute: async (id, args, update, request, invocation, context) => {
      try {
        const {task_ref, target_ref} = args as {task_ref: string; target_ref: string};
        let task = await taskFor(request, task_ref, target_ref);
        const store = request.frames!;
        const frame = task.target.frameId ? await store.get(task.target.frameId) : undefined;
        const index = await store.state();
        const latest = frame ? await store.get(index.operations[frame.operationFrameId] ?? frame.frameId) : undefined;
        const service = new SemanticTaskService(request, context.abortSignal);
        if (latest?.status === "executing") {
          const settlement = await reconcileExecution(request, latest, context.abortSignal);
          if (!settlement) return receipt(semanticFeedback(task, "unknown"));
          const frames = new BusinessContextService(store, createCapabilities(), createFieldResolvers());
          const completed = await frames.finishExecution(latest, settlement);
          task = (await service.settle(task, completed))!;
        }
        if (latest?.status === "success" || latest?.status === "failed") task = (await service.settle(task, latest))!;
        if (task.target.status === "succeeded") return createSemanticReadTool().execute(id, args, update, request, invocation, context);
        if (["unknown", "failed"].includes(task.target.status)) return receipt(semanticFeedback(task, task.target.status));
        const consumed = await service.consume(task_ref, target_ref);
        const result = await createExecuteBusinessFrameTool().execute(id, {frameId: consumed.frameId}, update, request, invocation, context);
        const state = await store.state();
        const current = frame ? await store.get(state.operations[frame.operationFrameId] ?? consumed.frameId) : undefined;
        const settled = (await service.settle(consumed.task, current))!;
        const status = settled.target.status === "succeeded" ? "succeeded" : settled.target.status === "failed" ? "failed" : "unknown";
        return receipt(semanticFeedback(settled, status), result);
      } catch (error) {return receipt(errors(error));}
    }};
}
export function createSemanticReadTool(): Tool {
  return {name: "read_business_result", label: "读取任务结果", description: "只读取指定任务已有成功结果，复核当前权限，不重新查询。引用来自宿主回执。", parameters: refs,
    execute: async (id, args, update, request, invocation, context) => {
      try {
        const {task_ref, target_ref} = args as {task_ref: string; target_ref: string};
        const task = await taskFor(request, task_ref, target_ref);
        if (task.target.status !== "succeeded" || !task.target.frameId) return receipt(semanticFeedback(task, "needs_user", [{code: "RESULT_NOT_READY", category: "reference", message: "所选目标尚无成功结果，不能重显或冒充重新查询。", remediation: "user"}]));
        const result = await createReadBusinessResultTool().execute(id, {frameId: task.target.frameId, setFocus: false}, update, request, invocation, context);
        const succeeded = (result.details as {status?: string})?.status === "succeeded";
        return receipt(semanticFeedback(task, succeeded ? "reused" : "failed"), result);
      } catch (error) {return receipt(errors(error));}
    }};
}
export function semanticTools(base: Tool[]): Tool[] {
  const replacements = [createSemanticResolveTool(), createSemanticContextTool(), createSemanticExecuteTool(), createSemanticReadTool()];
  return base.map(tool => replacements.find(candidate => candidate.name === tool.name) ?? tool);
}

/** 原生校验失败会跳过after_tool。隔离结构错误为正式回执，避免不同错误走不同恢复链。
 * 仅原生注册适配器接收未转换JSON；执行入口仍先用唯一严格Schema核验，错误绝不进入解析/执行。
 */
export function semanticRuntimeAdapter(tool: Tool): Tool {
  return tool.name === "resolve_business_turn" ? {...tool, parameters: Type.Unsafe({}), prepareArguments: raw => structuredClone(raw)} : tool;
}
/** 给模型的Schema始终唯一且严格；原生隔离适配器的容器形状不得公开。 */
export function semanticPublicToolDefinitions(payload: Record<string, unknown>): Record<string, unknown> {
  if (!Array.isArray(payload.tools)) return payload;
  return {...payload, tools: payload.tools.map(raw => {
    const definition = raw as {name?: string; function?: {name?: string}};
    if (definition.function?.name === "resolve_business_turn") return {...definition, function: {...definition.function, parameters: semanticParameters}};
    return definition.name === "resolve_business_turn" ? {...definition, parameters: semanticParameters} : raw;
  })};
}
