import {execFileSync} from "node:child_process";
import {resolve} from "node:path";
import {afterEach, expect, it} from "vitest";
import {SemanticTaskService} from "../../src/semantic-task/service.js";
import {createSemanticExecuteTool} from "../../src/semantic-task/tools.js";
import {semanticFeedback, semanticPublicAnswer} from "../../src/semantic-task/feedback.js";
import {runTool} from "../../src/tools/testUtils.js";
import type {BackendClient} from "../../src/backendClient.js";
import {fixture, proposal} from "./fixtures.js";
const clean: Array<() => Promise<void>> = [];
afterEach(async () => {for (const close of clean.splice(0)) await close();});
const cache = new Map<string, any>();
function python(payload: unknown): any {
  const input = JSON.stringify(payload);
  if (cache.has(input)) return structuredClone(cache.get(input));
  const output = JSON.parse(execFileSync(resolve("../backend-next/.venv/bin/python"), [resolve("scripts/semantic-task-fixture.py")],
    {input, encoding: "utf8", timeout: 30000, env: {PATH: "/usr/bin:/bin:/opt/homebrew/bin"}}));
  expect(output.ok, output.message).toBe(true); cache.set(input, output.value); return output.value;
}
async function setup() {
  const f = await fixture(); clean.push(f.close);
  const request = (id: string, message: string) => ({...f.request(id, message), backend: {
    ...f.backend,
    resolveBusinessField: async (entity: string, raw: string[], _options?: unknown, year?: number, source?: unknown) => python({action: "resolve", entity, raw, year, source}),
    matchMetricQuestion: async (question: string) => python({action: "mentions", question}),
  } as unknown as BackendClient});
  return {...f, request};
}
const base = [
  {action: "set", field: "organizations", value: "合成机构甲"},
  {action: "set", field: "metrics", value: "经营收益金额当日数"},
  {action: "set", field: "time", value: "2026年5月31日"},
] as const;
it("真实目录解析补全模型遗漏的已明确指标口径，编译请求通过后端来源校验和SQL", async () => {
  const f = await setup(), request = f.request("exact", "查询合成机构甲2026年5月31日的经营收益金额当日数");
  const result = await new SemanticTaskService(request).resolve(proposal(base.map(operation => operation.field === "metrics" ? {...operation, value: "经营收益金额"} : operation)));
  expect(result.status).toBe("ready");
  await runTool(createSemanticExecuteTool(), {task_ref: result.task!.ref, target_ref: result.task!.target.ref}, request);
  expect(python({action: "query", spec: f.backend.basicQueries.mock.calls[0]![0]}).rows).toHaveLength(1);
}, 15000);
it("真实目录按既有高置信纠错确定身份，原句绑定通过独立后端核验", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("typo", "查询合成机构甲2026年5月31日的经营收益金融当日数")).resolve(proposal(base.map(operation =>
    operation.field === "metrics" ? {...operation, value: "经营收益金额"} : operation)));
  expect(first.status).toBe("ready");
  const request = f.request("explicit", "查询合成机构甲2026年5月31日的经营收益金额");
  const pending = await new SemanticTaskService(request).resolve(proposal([...base]));
  expect(pending.status).toBe("needs_user");
  const confirmation = f.request("choice", "指标用经营收益金额当日数");
  const next = await new SemanticTaskService(confirmation).resolve(proposal([{action: "confirm", field: "metrics", value: "经营收益金额当日数"}], {kind: "current"}));
  expect(next.status).toBe("ready");
  await runTool(createSemanticExecuteTool(), {task_ref: next.task!.ref, target_ref: next.task!.target.ref}, confirmation);
  expect(python({action: "query", spec: f.backend.basicQueries.mock.calls[0]![0]}).rows).toHaveLength(1);
}, 15000);
it("真实相对年日历反馈公开完整选项，确认后保留全部数据点口径", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("years", "查询合成机构甲近5年的经营收益金额当日数全部数据")).resolve(proposal([
    ...base.filter(operation => operation.field !== "time"), {action: "set", field: "time", value: "近5年"}, {action: "set", field: "selection", value: "全部数据"},
  ]));
  expect(first.status).toBe("needs_user");
  expect(semanticPublicAnswer(semanticFeedback(first.task, first.status))).toContain("最近5个完整年度");
  const next = await new SemanticTaskService(f.request("year-choice", "日期用第二项")).resolve(proposal([{action: "confirm", field: "time", value: "第二项"}], {kind: "current"}));
  expect(next.status).toBe("ready");
  expect(next.task!.target.fields.selection!.resolvedValue).toBe("all_in_range");
}, 15000);
it("指标片段误填日期直接澄清真正缺少的日期，不进入日期修复循环", async () => {
  const f = await setup();
  const first = await new SemanticTaskService(f.request("missing", "查询合成机构甲的经营收益金额当日数")).resolve(proposal(base.map(operation =>
    operation.field === "time" ? {...operation, value: "当日数"} : operation)));
  expect(first.status).toBe("needs_user");
  expect(first.task!.issues.map(issue => issue.code)).toEqual(["FIELD_REQUIRED"]);
  expect(first.task!.target.fields.metrics!.resolvedValue).toMatchObject({codes: ["SYNTH_M:D"]});
  expect(f.backend.basicQueries).not.toHaveBeenCalled();
}, 15000);
