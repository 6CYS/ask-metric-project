"""正式编码回查不能丢失已确认实体，也不依赖模型或数据库。"""
from ask_metric.application.catalog_search import rank_organizations, search_metrics
from ask_metric.domain.semantics import MetricCatalogItem, OrganizationCatalogItem


def test_metric_code_exact_search():
    item = MetricCatalogItem(code="STRC_WROFF_LOAN_BAL", name="贷款余额当日数", unit="元")
    result = search_metrics("STRC_WROFF_LOAN_BAL", [item])
    assert result.total == 1
    assert result.items[0].code == item.code
    assert result.items[0].match_type == "exact"


def test_org_code_exact_search():
    item = OrganizationCatalogItem(code="C001", name="演示机构")
    result = rank_organizations("C001", [item])
    assert result.total == 1
    assert result.items[0].code == item.code
    assert result.items[0].match_type == "exact"
