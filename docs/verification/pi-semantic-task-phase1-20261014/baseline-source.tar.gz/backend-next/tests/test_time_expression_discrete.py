"""离散多日期点解析：仅在多个单日点时返回列表，区间/单点回退到 None。"""

from datetime import date

import pytest

from ask_metric.domain.time_expression import parse_discrete_dates

TODAY = date(2026, 9, 23)


def test_month_ends_share_leading_year():
    result = parse_discrete_dates("2026年2月末、3月末、4月末", today=TODAY)
    assert result == [date(2026, 2, 28), date(2026, 3, 31), date(2026, 4, 30)]


@pytest.mark.parametrize("raw", [
    "2026年3月31日,2026年4月30日",
    "2026年3月31日，2026年4月30日",
    "2026年3月31日和2026年4月30日",
])
def test_supported_separators(raw):
    assert parse_discrete_dates(raw, today=TODAY) == [date(2026, 3, 31), date(2026, 4, 30)]


def test_range_expression_is_not_discrete():
    # 含"至"是连续区间，不能被拆成离散点。
    assert parse_discrete_dates("2026年2月末至4月末", today=TODAY) is None


def test_single_point_returns_none():
    assert parse_discrete_dates("2026年3月末", today=TODAY) is None


def test_any_range_fragment_falls_back():
    # 任一片段是区间 → 整体回退。
    assert parse_discrete_dates("2026年2月末、3月至4月", today=TODAY) is None


def test_unparseable_fragment_falls_back():
    assert parse_discrete_dates("2026年2月末、随便写的", today=TODAY) is None


def test_duplicates_are_deduped_and_sorted():
    result = parse_discrete_dates("2026年4月30日、2026年3月31日、2026年3月31日", today=TODAY)
    assert result == [date(2026, 3, 31), date(2026, 4, 30)]


def test_reference_year_seeds_first_fragment_when_absent():
    result = parse_discrete_dates("2月末、3月末", today=TODAY, reference_year=2024)
    assert result == [date(2024, 2, 29), date(2024, 3, 31)]
