"""合成目录回归：短别名不得覆盖完整名称，冲突在任务写入前拒绝。"""
from contextlib import nullcontext
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

from ask_metric.application.commands import SubmitQuestionCommand
from ask_metric.application.metric_candidates import conflicting_metric_references
from ask_metric.application.requests import ActorContext, IncomingRequest
from ask_metric.application.task_service import QueryTaskApplicationService
from ask_metric.core.errors import ApplicationError
from ask_metric.domain.basic_query import BasicQuerySpec
from ask_metric.domain.semantics import MetricCatalogItem

CATALOG = [
    MetricCatalogItem(code="TOTAL", name="各项贷款余额当日数", aliases=["贷款余额"], unit="亿元"),
    MetricCatalogItem(code="EXPLICIT", name="贷款余额当日数", unit="元"),
    MetricCatalogItem(code="DEPOSIT", name="存款余额", unit="元"),
]


@pytest.mark.parametrize("question,codes,conflict", [
    ("查询省联社2026年3月31日贷款余额当日数。", ["TOTAL"], True),
    ("查询贷款余额当日数", ["EXPLICIT"], False),
    ("查询贷款余额", ["TOTAL"], False),
    ("各项贷款余额当日数", ["TOTAL"], False),
    ("各项贷款余额当日数与贷款余额当日数比较", ["TOTAL"], False),
    ("贷款余额当日数减存款余额", ["DEPOSIT"], False),
    ("那3月末呢", ["TOTAL"], False),
    ("TOTAL和贷款余额当日数", ["TOTAL"], False),
])
def test_original_name_conflict(question, codes, conflict):
    assert bool(conflicting_metric_references(question, codes, CATALOG)) is conflict


def test_conflict_rejected_before_task_or_message_write():
    uow = SimpleNamespace(
        conversations=SimpleNamespace(get=lambda _: None),
        tasks=SimpleNamespace(find_by_idempotency_key=lambda *args: None),
        metric_catalog=SimpleNamespace(list_enabled=lambda: CATALOG),
        flush=Mock(),
    )
    command = SubmitQuestionCommand(
        request=IncomingRequest(request_id="r", channel="basic_query", text="基础查询",
                                conversation_id="c", channel_context={"calculation_context": {
                                    "scope_id": "scope", "user_question": "贷款余额当日数",
                                }}),
        actor=ActorContext(subject="test", user_id="test", authentication_method="test",
                           trust_level="authenticated"),
        idempotency_key="k",
        basic_query=BasicQuerySpec(metric_codes=["TOTAL"], org_codes=["O"],
                                  time={"start": "2026-03-31", "end": "2026-03-31"},
                                  selection="exact"),
    )
    service = QueryTaskApplicationService(uow_factory=lambda: nullcontext(uow))
    with pytest.raises(ApplicationError) as error:
        service.submit_question(command)
    assert error.value.code == "QUERY_METRIC_REFERENCE_CONFLICT"
    assert error.value.status_code == 422
    uow.flush.assert_not_called()
