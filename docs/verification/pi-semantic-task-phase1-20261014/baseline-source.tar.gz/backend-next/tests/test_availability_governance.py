"""覆盖工具在SQL前校验正式编码、日期和授权范围。"""
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from pydantic import ValidationError

from ask_metric.application.data_availability import AvailabilityRequest, execute_availability
from ask_metric.application.ports import PermissionDeniedError


@pytest.mark.parametrize("scope", [
    {"org_codes": ["fake"]}, {"metric_codes": ["fake"], "org_codes": ["O"]},
])
def test_invalid_catalog_codes_never_execute_sql(scope):
    execution = SimpleNamespace(data_source=Mock(), permission_service=Mock())
    with pytest.raises(ValueError):
        execute_availability(AvailabilityRequest(dimension="metrics", **scope), object(), execution,
                             "mysql", {"M": "余额"}, {"O": "测试行"})
    execution.data_source.execute_readonly.assert_not_called()
    execution.permission_service.authorize_logical_dsl.assert_not_called()


def test_denied_scope_never_executes_sql():
    execution = SimpleNamespace(data_source=Mock(), permission_service=Mock())
    execution.permission_service.authorize_logical_dsl.side_effect = PermissionDeniedError("拒绝")
    with pytest.raises(PermissionDeniedError):
        execute_availability(AvailabilityRequest(dimension="metrics", org_codes=["O"]), object(),
                             execution, "mysql", {"M": "余额"}, {"O": "测试行"})
    execution.data_source.execute_readonly.assert_not_called()


@pytest.mark.parametrize("start,end", [("2026-02-30", "2026-03-31"), ("2026-04-01", "2026-03-31")])
def test_invalid_date_range_is_rejected(start, end):
    with pytest.raises(ValidationError):
        AvailabilityRequest(dimension="metrics", org_codes=["O"], start=start, end=end)
