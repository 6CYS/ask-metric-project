"""统一错误信封：请求校验错误与领域错误同构，且不回显输入值。"""

from typing import Annotated

from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel, Field

from ask_metric.core.errors import install_exception_handlers

NameKey = Annotated[str, Field(pattern=r"^[a-zA-Z][a-zA-Z0-9_]{0,31}$")]


class Payload(BaseModel):
    password: str = Field(min_length=8)
    constants: dict[NameKey, str] = {}


def make_client() -> TestClient:
    app = FastAPI()
    install_exception_handlers(app)

    @app.post("/echo")
    async def echo(payload: Payload):
        return {"ok": True}

    return TestClient(app)


def test_validation_error_uses_standard_envelope_without_echoing_input():
    response = make_client().post(
        "/echo",
        json={"password": "S3crt!", "constants": {"_": "unique-value-42"}},
    )
    assert response.status_code == 422
    body = response.json()
    # 与领域错误同一信封：code/message/request_id/details
    assert body["code"] == "REQUEST_INVALID"
    assert body["message"] == "请求参数未通过校验。"
    assert body["request_id"]
    paths = {field["path"] for field in body["details"]["fields"]}
    assert "password" in paths
    assert any(path.startswith("constants._") for path in paths)
    # 脱敏边界：输入值（含口令）不得出现在响应任何位置
    assert "S3crt!" not in response.text
    assert "unique-value-42" not in response.text
