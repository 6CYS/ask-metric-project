"""真实 SQL 构建器保持机构身份，名称不同或同名均不能丢失计算事实。"""

from datetime import date

import pytest
import sqlglot
from sqlalchemy import bindparam, create_engine, text

from ask_metric.application.calculation_service import build_calculation_facts
from ask_metric.domain.basic_query import BasicQuerySpec
from ask_metric.domain.query_execution import QueryPlanner
from ask_metric.infrastructure.query.sql_builder import SqlBuilder


@pytest.mark.parametrize("selection", ["exact", "latest_in_range", "all_in_range", "ranking"])
def test_mysql_result_keeps_org_code_when_names_differ(selection):
    spec = BasicQuerySpec(
        metric_codes=["M"], org_codes=["A", "B"],
        time={"start": "2026-03-31" if selection == "exact" else "2026-03-01",
              "end": "2026-03-31"},
        selection="latest_in_range" if selection == "ranking" else selection,
        operation=({"kind": "ranking", "position": "top", "top_n": 5}
                   if selection == "ranking" else {"kind": "value"}),
    )
    # 新契约的编码始终是实际机构；此处检查最终 SQL 的机构身份。
    dsl = spec.to_logical_dsl().model_copy(update={"orgs": ["A", "B"]})
    plan = QueryPlanner(dialect="mysql").build(dsl, spec.query_shape)
    sql = sqlglot.transpile(SqlBuilder("mysql").build(plan), read="mysql", write="sqlite")[0]
    engine = create_engine("sqlite://")
    try:
        with engine.begin() as conn:
            conn.exec_driver_sql(
                "CREATE TABLE metric_values (metric_code TEXT, metric_name TEXT, "
                "org_code TEXT, org_name TEXT, stat_date TEXT, metric_value TEXT)"
            )
            conn.exec_driver_sql(
                "CREATE TABLE metric_terms (metric_code TEXT, metric_name TEXT, unit TEXT)"
            )
            conn.exec_driver_sql("INSERT INTO metric_terms VALUES ('M','测试指标','元')")
            conn.exec_driver_sql(
                "INSERT INTO metric_values VALUES "
                "('M','测试指标','A','相同简称','2026-03-31','10.123456'),"
                "('M','测试指标','B','相同简称','2026-03-31','3.000001')"
            )
            statement = text(sql).bindparams(
                bindparam("metric_codes", expanding=True), bindparam("org_codes", expanding=True),
                *([bindparam("ordinal_metric_codes", expanding=True)]
                  if "ordinal_metric_codes" in plan.parameters else [])
            )
            rows = [dict(row) for row in conn.execute(statement, {
                k: v.isoformat() if isinstance(v, date) else v for k, v in plan.parameters.items()
            }).mappings()]
        assert {row["org_code"] for row in rows} == {"A", "B"}
        facts = build_calculation_facts("t", rows, {
            "metrics": [{"code": "M", "name": "测试指标", "unit": "元"}],
            "organizations": [{"code": "A", "name": "甲机构全称"},
                              {"code": "B", "name": "乙机构全称"}],
        })
        assert {fact["org_code"] for fact in facts} == {"A", "B"}
        assert {fact["value"] for fact in facts} == {"10.123456", "3.000001"}
    finally:
        engine.dispose()
