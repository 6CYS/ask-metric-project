"""计算契约回归：精确原值、范围、权限、完整性与重放（隔离内存桩）。"""

from contextlib import nullcontext
from copy import deepcopy
from types import SimpleNamespace

import pytest

from ask_metric.application.calculation_service import CalculationApplicationService
from ask_metric.application.ports import PermissionDeniedError
from ask_metric.core.errors import ApplicationError
from ask_metric.domain.calculation import (
    CalculationError,
    CalculationExpression,
    CalculationRequest,
    evaluate_expression,
    quantity,
)


def calculation_fixture():
    facts = [
        dict(
            fact_id=f"fact:t:{i}:metric_value",
            task_id="t",
            field="metric_value",
            value=value,
            unit="元",
            org_code="O",
            org_name="测试机构",
            metric_code=f"M{i}",
            metric_name=f"指标{i}",
            date="2026-03-31",
        )
        for i, value in enumerate(["9007199254740993.123456", "9007199254740992.000001"])
    ]
    state = {
        "channel_context": {
            "calculation_context": {"scope_id": "scope", "user_question": "指标甲减指标乙"}
        },
        "result_artifact": {"logical_dsl": {"orgs": ["O"]}, "result": {"facts": facts}},
    }
    task = SimpleNamespace(
        id="t", conversation_id="c", status="SUCCEEDED", expires_at=None, state_json=state
    )
    messages = []
    uow = SimpleNamespace(
        conversations=SimpleNamespace(get_owned_for_update=lambda *args: SimpleNamespace(id="c")),
        tasks=SimpleNamespace(get_owned_for_update=lambda *args: task),
        messages=SimpleNamespace(
            add=messages.append,
            get=lambda message_id, conversation_id: next((
                message for message in messages
                if message.id == message_id and message.conversation_id == conversation_id
            ), None),
        ),
        commit=lambda: None,
    )
    execution = SimpleNamespace(
        uow_factory=lambda: nullcontext(uow),
        _authorize_query=lambda **kwargs: (
            SimpleNamespace(orgs=["O"]),
            [SimpleNamespace(code=f"M{i}", unit="元") for i in range(2)],
            None,
        ),
    )
    request = CalculationRequest(
        conversation_id="c",
        scope_id="scope",
        bindings={"a": {"fact_id": facts[0]["fact_id"]}, "b": {"fact_id": facts[1]["fact_id"]}},
        expressions=[
            {"name": "difference", "label": "甲减乙", "expression": "a-b", "decimal_places": 6}
        ],
    )
    return CalculationApplicationService(execution), request, task, execution, messages


def test_precise_difference_persisted_and_replayed_after_permission_check():
    service, request, task, execution, messages = calculation_fixture()
    actor = SimpleNamespace(user_id="u")
    result = service.calculate(request, actor, "key")
    assert result["results"][0]["value"] == "1.123455"
    assert result["public_answer"] == "计算结果「甲减乙」（a-b）：1.123455元。"
    assert service.calculate(request, actor, "key") == result
    assert len(messages) == len(task.state_json["calculations"]) == 1

    def revoked(**kwargs):
        raise PermissionDeniedError("revoked")

    execution._authorize_query = revoked
    with pytest.raises(ApplicationError) as error:
        service.calculate(request, actor, "key")
    assert error.value.code == "CALCULATION_FORBIDDEN"


@pytest.mark.parametrize(
    "change",
    [
        "scope",
        "conversation",
        "truncated",
        "missing",
        "foreign_fact",
        "unit",
        "date",
        "org",
        "status",
        "null",
    ],
)
def test_invalid_sources_fail_closed(change):
    service, request, task, _, messages = calculation_fixture()
    result = task.state_json["result_artifact"]["result"]
    if change == "scope":
        request.scope_id = "other"
    if change == "conversation":
        task.conversation_id = "other"
    if change == "truncated":
        result["truncated"] = True
    if change == "missing":
        result["evidence"] = {"missing_metric_notice": "缺少指标"}
    if change == "foreign_fact":
        request.bindings["b"].fact_id = "fact:t:99:metric_value"
    if change == "unit":
        result["facts"][1]["unit"] = "户"
    if change == "date":
        result["facts"][1]["date"] = "2026-04-30"
    if change == "org":
        result["facts"][1]["org_code"] = "OTHER"
    if change == "status":
        task.status = "FAILED"
    if change == "null":
        result["facts"][1]["value"] = None
    with pytest.raises(ApplicationError):
        service.calculate(request, SimpleNamespace(user_id="u"), "key")
    assert not messages


def test_explicit_cross_date_allowed_and_changed_replay_rejected():
    service, request, task, _, _ = calculation_fixture()
    task.state_json["result_artifact"]["result"]["facts"][1]["date"] = "2026-04-30"
    request.scope_policy = "cross_date"
    service.calculate(request, SimpleNamespace(user_id="u"), "key")
    changed = deepcopy(request)
    changed.expressions[0].expression = "b-a"
    with pytest.raises(ApplicationError) as error:
        service.calculate(changed, SimpleNamespace(user_id="u"), "key")
    assert error.value.code == "CALCULATION_CONFLICT"


@pytest.mark.parametrize(
    "expression", ["a/0", "a.__class__", "a**2", "a+999", "sum()", "__import__('os')"]
)
def test_unsafe_or_invalid_expression_rejected(expression):
    with pytest.raises(CalculationError):
        evaluate_expression(
            CalculationExpression(name="x", label="测试", expression=expression),
            {"a": quantity("10", "元")},
        )


def test_legacy_rows_resolve_only_unique_formal_org_code():
    from ask_metric.application.calculation_service import build_calculation_facts

    rows = [
        {
            "metric_code": "M",
            "metric_value": "1.123456",
            "org_name": "甲行",
            "stat_date": "2026-03-31",
        }
    ]
    catalog = {
        "metrics": [{"code": "M", "name": "指标", "unit": "元"}],
        "organizations": [{"code": "O1", "name": "甲行"}],
    }
    assert build_calculation_facts("t", rows, catalog)[0]["org_code"] == "O1"
    catalog["organizations"].append({"code": "O2", "name": "甲行"})
    assert build_calculation_facts("t", rows, catalog) == []


def test_unreferenced_declared_names_rejected():
    # 常数合法（"3" 是用户问题里的独立数值 token）但未被表达式引用，必须拒绝
    from ask_metric.domain.calculation import FactBinding, UserConstant

    service, request, task, _, messages = calculation_fixture()
    context = task.state_json["channel_context"]["calculation_context"]
    context["user_question"] = "指标甲减指标乙的3倍"
    request.constants["c"] = UserConstant(value="3", source_text="3")
    with pytest.raises(ApplicationError) as error:
        service.calculate(request, SimpleNamespace(user_id="u"), "key-unused-constant")
    assert error.value.code == "CALCULATION_INVALID"
    assert "未被任何表达式引用" in error.value.message
    assert not messages

    # 绑定同理：声明了数据变量却不被任何表达式使用，同样拒绝
    service, request, task, _, messages = calculation_fixture()
    request.bindings["c"] = FactBinding(fact_id="fact:t:0:metric_value")
    with pytest.raises(ApplicationError) as error:
        service.calculate(request, SimpleNamespace(user_id="u"), "key-unused-binding")
    assert error.value.code == "CALCULATION_INVALID"
    assert "未被任何表达式引用" in error.value.message
    assert not messages
