"""Cross-cutting runtime capabilities."""
