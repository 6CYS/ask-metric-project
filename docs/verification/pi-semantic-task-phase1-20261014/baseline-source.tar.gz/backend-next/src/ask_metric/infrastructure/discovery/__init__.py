"""Service discovery integrations."""
