"""Pure business types."""
