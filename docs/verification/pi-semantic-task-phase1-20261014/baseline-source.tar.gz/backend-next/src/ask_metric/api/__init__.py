"""HTTP API adapters."""
