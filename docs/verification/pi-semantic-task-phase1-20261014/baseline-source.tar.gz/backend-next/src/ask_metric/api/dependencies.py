"""依赖装配入口：将配置、模型、权限及数据库实现交给各业务服务。

路由中的 Depends(get_xxx) 由 FastAPI 调用；这里主要创建服务，不执行用户查询。
身份来自认证依赖，模型连接和目录缓存则复用 app.state 中的进程级资源。
"""

from datetime import timedelta
from typing import Annotated

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from ask_metric.application.actor_provider import ActorProvider, ContextActorProvider
from ask_metric.application.auth_service import AuthenticationService
from ask_metric.application.metric_candidates import metric_candidate_index
from ask_metric.application.ports import ScopedOrganizationPermissionService
from ask_metric.application.query_execution_service import QueryExecutionApplicationService
from ask_metric.application.requests import ActorContext
from ask_metric.application.result_enrichment import CatalogResultEnricher
from ask_metric.application.task_service import QueryTaskApplicationService
from ask_metric.core.config import PROJECT_DIR, Settings
from ask_metric.core.security import AuthenticationError, decode_access_token
from ask_metric.domain.query_execution import QueryPlanner
from ask_metric.domain.semantics import MetricCatalogItem
from ask_metric.infrastructure.db.org_hierarchy import SqlAlchemyOrgHierarchyProvider
from ask_metric.infrastructure.db.organization_scope import SqlAlchemyOrganizationScopeProvider
from ask_metric.infrastructure.db.session import get_app_session_factory, get_query_engine
from ask_metric.infrastructure.db.unit_of_work import SqlAlchemyUnitOfWork
from ask_metric.infrastructure.model.catalog_vectors import catalog_embedding_texts
from ask_metric.infrastructure.model.configuration import (
    ModelConfigRepository,
    PromptConfigRepository,
    resolve_config_path,
)
from ask_metric.infrastructure.model.provider import (
    ConfigurableModelService,
    credential_resolver_from_env_file,
)
from ask_metric.infrastructure.query.factory import create_data_source_adapter
from ask_metric.infrastructure.query.sql_builder import sql_builder_from_settings
from ask_metric.infrastructure.semantic.configuration import SemanticConfigRepository

bearer_scheme = HTTPBearer(auto_error=False)


def warm_metric_index() -> list[MetricCatalogItem]:
    """按当前启用目录建好指标识别索引（含由同义词推导的别名）；目录未变化时直接命中缓存。"""
    with SqlAlchemyUnitOfWork() as uow:
        items = uow.metric_catalog.list_enabled()
    # 先读目录再释放数据库会话；建索引是纯内存计算，不占用数据库连接。
    metric_candidate_index(items)
    return items


def initialize_query_catalog(request: Request) -> None:
    """复用在线问数的模型配置、目录文本与缓存，避免预热和实际检索使用不同输入。"""
    initialization = request.app.state.query_initialization
    initialization.progress(0, 0)
    # 指标识别索引与向量共用同一份目录，首个提问不再现场建索引。
    items = warm_metric_index()
    model = get_model_service(request)
    if not model.is_enabled("embedding"):
        return
    settings = request.app.state.settings
    config = SemanticConfigRepository(
        resolve_config_path(PROJECT_DIR, settings.semantic_config_path),
    ).load().metric_matching
    corpus = catalog_embedding_texts(items)
    # 后面的分批模型请求不占用数据库连接。
    if not corpus:
        raise ValueError("Enabled metric catalog is empty")
    request.app.state.catalog_vector_cache.warmup(
        # 传入绑定方法作为回调，缓存每完成一批便调用它更新公共初始化状态。
        model, corpus, batch_size=config.embedding_batch_size,
        wait_seconds=config.embedding_cache_wait_seconds, progress=initialization.progress,
    )


def get_authentication_service(request: Request) -> AuthenticationService:
    return AuthenticationService(request.app.state.settings)


def require_actor(
    request: Request,
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer_scheme)],
) -> ActorContext:
    """验证令牌后再核对当前账号，防止停用账号或旧登录凭证继续访问。"""
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise AuthenticationError("AUTH_TOKEN_INVALID", "请先登录")
    return authenticate_access_token(request, credentials.credentials)


def authenticate_access_token(request: Request, token: str) -> ActorContext:
    """在线请求与刷新恢复共用账号校验；Cookie 不会成为业务接口的备用认证方式。"""
    settings: Settings = request.app.state.settings
    claims = decode_access_token(token, settings)
    user_id = str(claims.get("sub") or "")
    with SqlAlchemyUnitOfWork() as uow:
        user = uow.users.get(user_id)
        if user is None:
            raise AuthenticationError("AUTH_TOKEN_INVALID", "登录凭证无效，请重新登录")
        if not user.enabled:
            raise AuthenticationError("AUTH_USER_DISABLED", "账号已被禁用，请联系管理员")
        if user.session_version != claims.get("session_version"):
            raise AuthenticationError(
                "AUTH_SESSION_REPLACED", "账号已在其他位置重新登录，请重新认证"
            )
        if any(
            claims.get(key) != value
            for key, value in {
                "username": user.username,
                "org_code": user.org_code,
                "role_code": user.role_code,
            }.items()
        ):
            raise AuthenticationError("AUTH_TOKEN_INVALID", "登录凭证无效，请重新登录")
    return ActorContext(
        subject=user.username,
        user_id=user.id,
        org_id=user.org_code,
        role_code=user.role_code,
        authentication_method="local_jwt",
        trust_level="authenticated",
    )


def get_actor_provider(actor: Annotated[ActorContext, Depends(require_actor)]) -> ActorProvider:
    # Annotated 的第一个参数是类型，Depends 告诉框架如何取得已验证的身份。
    return ContextActorProvider(actor)


def _running_stale_after(settings: Settings) -> timedelta:
    # 查询受语句超时约束；再留 5 分钟给结果处理和应用库落库，超过即视为执行中断。
    # 执行回收与只读回查共用该时限，两处判定不能不一致。
    return timedelta(milliseconds=settings.query_statement_timeout_ms) + timedelta(minutes=5)


def get_query_task_service(request: Request) -> QueryTaskApplicationService:
    settings: Settings = request.app.state.settings
    return QueryTaskApplicationService(
        running_stale_after=_running_stale_after(settings),
        semantic_config_repository=SemanticConfigRepository(
            resolve_config_path(PROJECT_DIR, settings.semantic_config_path)
        ),
        # 追问来源的权限复核与执行链使用同一机构边界
        permission_service=ScopedOrganizationPermissionService(
            organization_scope_provider=SqlAlchemyOrganizationScopeProvider(),
            all_organization_org_codes=set(settings.all_organization_org_codes),
            allow_unscoped_development=settings.app_env.lower() in {"development", "test"},
        ),
    )


def get_model_service(request: Request) -> ConfigurableModelService:
    settings: Settings = request.app.state.settings
    return ConfigurableModelService(
        model_config_repository=ModelConfigRepository(
            resolve_config_path(PROJECT_DIR, settings.model_config_path)
        ),
        prompt_config_repository=PromptConfigRepository(
            resolve_config_path(PROJECT_DIR, settings.prompt_config_path)
        ),
        credential_resolver=credential_resolver_from_env_file(
            resolve_config_path(PROJECT_DIR, settings.model_secret_env_path)
        ),
        client=request.app.state.model_http_client,
        max_concurrency=settings.model_max_concurrency,
        concurrency_wait_seconds=settings.model_concurrency_wait_seconds,
        semaphore=request.app.state.model_semaphore,
    )


def get_query_execution_service(request: Request) -> QueryExecutionApplicationService:
    settings: Settings = request.app.state.settings
    def validate_current_actor(actor: ActorContext) -> None:
        # 长查询发布前再次核对账号、角色和登录版本，不能只复用请求开始时的身份。
        if actor.authentication_method == "local_jwt":
            authorization = request.headers.get("authorization", "")
            scheme, _, token = authorization.partition(" ")
            if scheme.lower() != "bearer" or not token:
                raise AuthenticationError("AUTH_TOKEN_INVALID", "请重新登录后查询")
            current = authenticate_access_token(request, token)
            if current != actor:
                raise AuthenticationError("AUTH_TOKEN_INVALID", "账号权限已变化，请重新登录")
    return QueryExecutionApplicationService(
        planner=QueryPlanner(
            dialect=settings.query_database_dialect,
            max_limit=settings.query_result_limit,
        ),
        sql_builder=sql_builder_from_settings(settings),
        actor_validator=validate_current_actor,
        running_stale_after=_running_stale_after(settings),
        data_source=create_data_source_adapter(
            settings.query_database_dialect,
            get_query_engine(),
            statement_timeout_ms=settings.query_statement_timeout_ms,
            **(
                {"session_init_statements": settings.query_session_init_statements}
                if settings.query_database_dialect == "inceptor"
                else {}
            ),
        ),
        permission_service=ScopedOrganizationPermissionService(
            organization_scope_provider=SqlAlchemyOrganizationScopeProvider(),
            all_organization_org_codes=set(settings.all_organization_org_codes),
            allow_unscoped_development=settings.app_env.lower() in {"development", "test"},
        ),
        # 机构层级只读应用库元数据；排名下级扩展仍受机构权限交集约束。
        org_hierarchy_provider=SqlAlchemyOrgHierarchyProvider(
            root_level=settings.sit_org_head_office_hier_code,
            cohort_level=settings.sit_org_legal_entity_hier_code,
        ),
        organization_scope_provider=SqlAlchemyOrganizationScopeProvider(),
        model_service=get_model_service(request),
        result_enricher=(
            CatalogResultEnricher(get_app_session_factory())
            if settings.query_database_dialect == "inceptor"
            else None
        ),
    )
